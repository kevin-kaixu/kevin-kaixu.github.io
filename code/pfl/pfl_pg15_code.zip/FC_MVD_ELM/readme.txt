1.FCN_MVD_ELM_Run.m: a demo for FCN-MVD-ELM on shape segmentaion. Just run the code!
2.(optional)  FCN_MVD_ELM_DataPrepare.m : data preparation for FCN-MVD-ELM. 
