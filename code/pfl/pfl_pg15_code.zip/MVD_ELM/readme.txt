This folder contains 3 demos for MVD-ELM:

MVD_ELM_singlelayer_Demo.m:   MVD-ELM for 3D shape classification: single layer ( 6 views) demo. Just Run the code!
MVD_ELM_2layer_Demo:   MVD-ELM for 3D shape classification: two layers (6 views) demo. Just Run the code!
SVM_on_MVD_ELM_features.m: SVM classifiers based on  MVD-ELM weighted features demo. Just Run the code!