Two setps:
Step 1: Run weightedFeaturesGenerate.m to generate weightedFeatures128_20TestAll.mat;
Step 2: Run pgvisfinal.m to generate visualization of features learned by MVD-ELM 