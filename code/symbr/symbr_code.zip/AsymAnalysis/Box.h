#ifndef ASYM_BOX_H
#define ASYM_BOX_H
#include <vector>
namespace Asym{
	enum BoxEdgeType{ET_Left,ET_Right,ET_Bottom,ET_Top,ET_None};
class Box{
	int _x,_y,_width,_height;
	int _label;
	int _id;
public:
	Box();
	Box(const Box&);
	Box(int x,int y,int w,int h,int L=0);
	void setLabel(int L);
	void setWidth(int w);
	void setHeight(int h);
	void setX(int x);
	void setY(int y);
	int x() const;
	int y() const;
	int height() const;
	int width() const;
	int label() const;
	int left() const;
	int right() const;
	int bottom() const;
	int top() const;
	int location(int dim) const;
	int size(int dim) const;
	int center(int dim) const;
	int area();
	~Box();
	int id() const;
	void setId(int id);

	

//geometry
	Box reflection(int loc,int dim);
	bool isIntersect(Box&);
	Box intersection(Box&);
	int areaOfOverlap(Box&);
	int distanceTo(Box&);
	float distance2(Box&);
	bool isAlignedWith(Box&,int dim);
	static void splitBox(Box& inputBox,int pos, int dim,Box& lowBox,Box& higherBox);

	bool contains(Box box);
	bool contains(int x,int y);

	void scale(float r);
	void translate(int dx,int dy);

	bool operator==(const Box& box);


	BoxEdgeType pickEdge(int x,int y,int threshold=8);

};

class BoxSet:public std::vector<Box>{
public:
	enum SaveTextType{None=0,Index,Label};
	void generateGridOfBoxes(int startx,int starty, int width,int height,int horiSpacing,int vertiSpacing,int rowNum,int colNum);
	void generateRandBoxSet(int rum,int cnum,int labelNum);
	bool readFromFile(std::string fn);
	bool writeToFile(std::string fn);
	bool saveSvg(std::string fn);
	bool saveSvgWithTextLabel(std::string fn,SaveTextType t=Index);
	Box boundingBox();
	void findMinMaxLabel(int&minL,int &maxL);

	Box boundingBox(std::vector<int>& boxIndices);

	std::vector<int> usedLabels();
	std::vector<int> usedLabels(std::vector<int>& boxIndices);
	std::vector<std::vector<int>> groupingByLables();
	std::vector<std::vector<int>> groupingByLables(std::vector<int>& boxIndices);
	std::vector<int> allBoxIndices();
	int avgWidth();
	int avgHeight();
	int avgWidth(std::vector<int>& boxIndices);
	int avgHeight(std::vector<int>& boxIndices);

	bool split(int pos,int dim,std::vector<int>& smallerBoxIndices,std::vector<int>& higherBoxIndices);
	bool split(int pos,int dim,std::vector<int>& inputBoxIndices,std::vector<int>& smallerBoxIndices,std::vector<int>& higherBoxIndices);

	void setData(BoxSet& boxset,std::vector<int>& boxIndices);
	void setData(BoxSet& boxset);
	void scaleAllBoxes(float ratio);

	void addUniqueBox(Box& box);
};


}
#endif