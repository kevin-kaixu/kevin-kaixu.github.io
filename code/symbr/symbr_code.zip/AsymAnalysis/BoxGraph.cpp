#include "BoxGraph.h"
#include <iostream>
#include <cmath>
#include <algorithm>
#include "Util.h"
#include <sstream>
#include <iomanip>
#include<map>

using namespace Asym;

Box& BoxGraph::boxOfNode(int nodeId){
	return _boxSet[nodes[nodeId].boxId];
}

int BoxGraph::newNode(int boxId){
	nodes.push_back(BoxGraphNode(boxId,nodes.size()));
	return nodes.size()-1;
}


void BoxGraph::insertIntoRow(int boxId,int row){
	Box& newBox=_boxSet[boxId];
	int newNodeId=newNode(boxId);
	if(newBox.right()<=boxOfNode(rowHead[row]).left()){
		nodes[rowHead[row]].left=newNodeId;
		nodes[newNodeId].right=rowHead[row];
		rowHead[row]=newNodeId;
	}else{
		int p=rowHead[row];
		while(nodes[p].right!=-1 && newBox.center(0)>=boxOfNode(nodes[p].right).center(0))//newBox.left()>=boxOfNode(nodes[p].right).right())
		{
			p=nodes[p].right;
		}

		if(nodes[p].right==-1){
			nodes[p].right=newNodeId;
			nodes[newNodeId].left=p;
		}else if(newBox.right()<=boxOfNode(nodes[p].right).left()){
			nodes[newNodeId].left=p;
			nodes[newNodeId].right=nodes[p].right;
			nodes[nodes[p].right].left=newNodeId;
			nodes[p].right=newNodeId;
		}
	}
}

int BoxGraph::findNodeAlignedTo(int row, int nodeId){
	Box& myBox=boxOfNode(nodeId);
	int p=rowHead[row];
	while(p!=-1){
		Box& yourBox=boxOfNode(p);
		if(myBox.isAlignedWith(yourBox,0))
			return p;
		p=nodes[p].right;
	}
	return -1;
}


BoxGraph::BoxGraph(BoxSet& bset):_boxSet(bset){	}

void BoxGraph::addBox(int boxId){
		Box& newBox=_boxSet[boxId];
		bool findRow=false;
		for(int i=0;i<rowHead.size();++i){
			Box& rowBox=boxOfNode(rowHead[i]);
			if(rowBox.isAlignedWith(newBox,1)){
				insertIntoRow(boxId,i);
				findRow=true;
				break;
			}
		}
		if(!findRow){
			int newNodeId=newNode(boxId);

			if(rowHead.empty()){
				rowHead.push_back(newNodeId);
				return;
			}
			int i=rowHead.size()-1;

			rowHead.push_back(newNodeId);
			while(i>=0&&boxOfNode(rowHead[i]).bottom()>newBox.top()){
				rowHead[i+1]=rowHead[i];
				i--;
			}
			rowHead[i+1]=newNodeId;
		}
}

void BoxGraph::updateGraphTopology(){


		for(int i=0;i<rowHead.size()-1;++i){
			int p=rowHead[i];
			while(p!=-1){
				for(int j=i+1;j<rowHead.size();++j){
					int alignedTo=findNodeAlignedTo(j,p);
					if(alignedTo!=-1){
						nodes[p].top=alignedTo;
						nodes[alignedTo].bottom=p;
						break;
					}
				}
				p=nodes[p].right;
			}
		}


}

void BoxGraph::print(){
		std::cout<<"graph"<<std::endl;
		for(int i=0;i<rowHead.size();++i){
			int p=rowHead[i];
			while(p!=-1){
				std::cout<<nodes[p].boxId<<"[";
				if(nodes[p].bottom!=-1)
					std::cout<<nodes[nodes[p].bottom].boxId<<",";
				else
					std::cout<<"-1,";

				if(nodes[p].top!=-1)
					std::cout<<nodes[nodes[p].top].boxId<<"] ";
				else
					std::cout<<"-1] ";

				p=nodes[p].right;
			}
			std::cout<<std::endl;
		}
}

	int BoxGraph::nodeDistance(int nodeA,int nodeB, int dim){
		return intFabs(boxOfNode(nodeA).center(dim)-boxOfNode(nodeB).center(dim));
	}

	std::vector<int> BoxGraph::findGridStartFrom(int i,int dx,int dy,int xthreshold,int ythreshold){
		std::vector<int> nodeIndices;
		std::vector<int> nodeStack;
		std::vector<bool> hasVisited;
		hasVisited.assign(nodes.size(),false);
		nodeStack.push_back(i);
		hasVisited[i]=true;


		while(!nodeStack.empty()){
			int curr=nodeStack.back();
			nodeStack.pop_back();
			nodeIndices.push_back(curr);

			int left=nodes[curr].left;
			int right=nodes[curr].right;
			int top=nodes[curr].top;
			int bottom=nodes[curr].bottom;

			if(left!=-1&&!hasVisited[left] && intFabs(nodeDistance(curr,left,0)-dx)<=xthreshold){
				nodeStack.push_back(left);
				hasVisited[left]=true;
			}

			if(right!=-1&&!hasVisited[right] && intFabs(nodeDistance(curr,right,0)-dx)<=xthreshold){
				nodeStack.push_back(right);
				hasVisited[right]=true;
			}

			if(top!=-1&&!hasVisited[top] && intFabs(nodeDistance(curr,top,1)-dy)<=ythreshold){
				nodeStack.push_back(top);
				hasVisited[top]=true;
			}

			if(bottom!=-1&&!hasVisited[bottom] && intFabs(nodeDistance(curr,bottom,1)-dy)<=ythreshold){
				nodeStack.push_back(bottom);
				hasVisited[bottom]=true;
			}
		}

		return nodeIndices;
	}




	Grid BoxGraph::createGridFrom(std::vector<int> &nodeIndices,int dx,int dy){
		if(nodeIndices.empty())return Grid(0,0);

		std::vector<int> boxIndices;
		boxIndices.resize(nodeIndices.size());
		for(int i=0;i<nodeIndices.size();++i)
			boxIndices[i]=nodes[nodeIndices[i]].boxId;

		Box bbox=_boxSet.boundingBox(boxIndices);

		int eleWidth=boxOfNode(nodeIndices[0]).width();
		int eleHeight=boxOfNode(nodeIndices[0]).height();


		int rowNum=1;
		int colNum=1;

		if(dx!=0)
			colNum=(bbox.width()+dx)/dx;
		if(dy!=0)
			rowNum=(bbox.height()+dy)/dy;


		Grid g(rowNum,colNum);

		for(int i=0;i<nodeIndices.size();++i){
			int curr=nodeIndices[i];
			Box& b=boxOfNode(curr);
			int r=0;
			int c=0;
			if(dx!=0)
				c=(b.left()-bbox.left()+eleWidth)/dx;
			if(dy!=0)
				r=(b.bottom()-bbox.bottom()+eleHeight)/dy;

			if(c<0||c>=colNum||r<0||r>=rowNum)continue;
			g(r,c).push_back(nodes[curr].boxId);
		}


		return g;
	}


	void BoxGraph::reset(){
		nodes.clear();
		rowHead.clear();
	}


void BoxGraph::extractGrids(std::vector<int>& boxIndices,std::vector<Grid>& grids,float xthresh,float ythresh){
		reset();
		for(int i=0;i<boxIndices.size();++i){
			addBox(boxIndices[i]);
		}
		updateGraphTopology();
		

		//int xthreshold=_boxSet.avgWidth(boxIndices)*xthresh;
		//int ythreshold=_boxSet.avgHeight(boxIndices)*ythresh;
		int xthreshold=INT_MAX;
		int ythreshold=INT_MAX;
		std::vector<bool> hasVisited;
		hasVisited.assign(nodes.size(),false);
		while(1){
			int first=-1;
			for(int i=0;i<hasVisited.size();++i){
				if(!hasVisited[i]){
					first=i;
					break;
				}
			}
			if(first==-1)break;

			int left=nodes[first].left;
			int right=nodes[first].right;
			int top=nodes[first].top;
			int bottom=nodes[first].bottom;
			int dx=0;
			int dy=0;

			if(right!=-1){
				dx=nodeDistance(first,right,0);
			}else if(left!=-1){
				dx=nodeDistance(first,left,0);
			}

			if(top!=-1)
				dy=nodeDistance(first,top,1);
			else if(bottom!=-1)
				dy=nodeDistance(first,bottom,1);

			std::vector<int> tgridIndices=findGridStartFrom(first,dx,dy,xthreshold,ythreshold);
			for(int i=0;i<tgridIndices.size();++i)
				hasVisited[tgridIndices[i]]=true;

			grids.push_back(createGridFrom(tgridIndices, dx, dy));
		}
	}
