#ifndef SYM_PROFILE_H
#define SYM_PROFILE_H
#include "Box.h"
#include <string>
namespace Asym{

	class LineProfile{
		std::vector<int> _Pos;
		std::vector<int> _value;
		void addWithoutAddPos(int startPos,int endPos,int v);
		
		std::vector<int> _tmpIndex;

	public:
		void reset();
		void add(int startPos,int endPos,int v);

		int maxValue();
		int createIndex(int eleSize,int eleNum);
		void saveSvg(std::string fn);
		//check whether the position having >= eleNum repetitions
		bool checkPos(int startPos,int endPos,int eleSize,int eleNum);
		int indexOf(int startPos,int endPos,int eleSize,int eleNum);
		int maximalRepNum(int eleSize);

		std::vector<int> zeroTurningPos();
		static LineProfile createFromBoxSet(BoxSet& bset, int dim);
		static LineProfile createFromBoxSet(BoxSet& bset, int dim,std::vector<int>& boxIndices);
	};

	enum SymProfileType{
		InterBoxSym=1,
		IntraBoxSym=2,
		WithGaussianFilter=4
	};

	struct GaussianFilterPara{
		double mean;
		double sigma;
	};

//���������ڼ���NIS�ģ����Ǹ�SymmetryMeasure
	class SymProfile{
		std::vector<int> _Pos;
		std::vector<double> _Sym;
		int _flag;
		int _dim;
		Box _bbox;
		
	public:
		double maximalSymValue();
		double symAt(int pos);
		void extractFrom(BoxSet& bset,int dim,int flag=InterBoxSym|IntraBoxSym|WithGaussianFilter);
		void extractFrom(BoxSet& bset,std::vector<int>& boxIndices,int dim,int flag=InterBoxSym|IntraBoxSym|WithGaussianFilter,GaussianFilterPara* para=NULL);
		double NIS();
		double integral();
		void saveSvg(std::string fn,BoxSet* bset=NULL);
		static double integralSymOfBox(Box& box,int dim);
	};
}
#endif