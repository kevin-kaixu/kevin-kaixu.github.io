#ifndef ASYM_ANALYSIS_H
#define ASYM_ANALYSIS_H
#include "Box.h"
#include "GenerativeHistory.h"
#include "grid.h"
#include "Box.h"
#include <ga/ga.h>
#include<iostream>
#include <sstream>
#include <math.h>
#include "GenerativeHistoryGA.h"
namespace Asym{
	

	
	
	


	class Analysis{
		BoxSet &_boxSet;
		int iii;
	
		bool needDecomp(std::vector<int>& boxIndices);

		void generateDelayerCandidates(std::vector<int>& boxIndices,std::vector<Grid>& grids,std::vector<DecompCandidate>& candidates);
		int chooseBestCandidate(std::vector<DecompCandidate>& candidates,Box space);
		float evaluateNIS(DecompCandidate& dc,Box space);

	public:

		Analysis(BoxSet& boxset):_boxSet(boxset)
		{ 
			std::vector<GenerativeHistory>c;
		}
		
		std::vector<Grid> generateAllGrids(std::vector<int>& boxIndices);
		std::vector<int> determineGridLayer(std::vector<Grid>& grids);
		void generateCandidates(std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);
		void generateDelayerCandidateswithoutlevel(std::vector<int>& boxIndices,std::vector<Grid>& grids,std::vector<DecompCandidate>& candidates);
		std::vector<std::vector<int>>combine(int n,int m);//cnm
		int iselist(std::vector<int>l0,std::vector<int>l1);

		GenerativeHistory recoverHistory(Box box);
		GenerativeHistory recoverHistoryGA();
		static float objective(GAGenome & c) 
		{
			
			GenerativeHistoryGA & chrom = (GenerativeHistoryGA &)c;
			GenerativeHistory hist=chrom.m_ghist;	
			float ab=chrom.ComputeSnisweightis1();
			return ab;
		}
		
		static void TreeInitializer(GAGenome &c)
		{
			GenerativeHistoryGA & chrom = (GenerativeHistoryGA &)c;
			GenerativeHistory hist=chrom.m_ghist;
			std::vector<int> initialBoxIndices=chrom.m_boxSet.allBoxIndices();
			int nbox=initialBoxIndices.size();
			int rootId=hist.initialize(chrom.m_boxSet.boundingBox());
			hist.nodeData(rootId).setData(chrom.m_boxSet,initialBoxIndices);
			hist.SetContentBoxesIndex(rootId,nbox,initialBoxIndices);
			typedef std::pair<std::vector<int>,int> StackNode;
			std::vector<StackNode> myStack;
			myStack.push_back(StackNode(initialBoxIndices,rootId));
			float is=0;
			std::vector<float>islist;

			while(!myStack.empty())
			{
				StackNode& currNode=myStack.back();
				if(!chrom.needDecomp(currNode.first)){
					myStack.pop_back();

					continue;
				}

				std::vector<DecompCandidate> candidates;
				chrom.generateCandidates(currNode.first,candidates);

				Box space=hist.boxOf(currNode.second);
				int sizeCandidates=candidates.size();
				std::vector<float>valueCandidates;
				valueCandidates.clear();
				valueCandidates.resize(sizeCandidates);
				float sumvalue=0;
				for (int i=0;i<sizeCandidates;i++)
				{
					valueCandidates[i]=chrom.evaluateNIS(candidates[i],space);
					sumvalue+=valueCandidates[i];
				}
				float seed=GARandomFloat(0.0,sumvalue);
				float temp=0;
				int choseCandidate=-1;
				for (int i=0;i<sizeCandidates;i++)
				{
					temp+=valueCandidates[i];
					if (temp>=seed)
					{
						choseCandidate=i;
						break;
					}
				}

				if(choseCandidate!=-1){
					is+=chrom.evaluateNIS(candidates[choseCandidate],space);
					islist.push_back(chrom.evaluateNIS(candidates[choseCandidate],space));
					DecompCandidate &bestCan=candidates[choseCandidate];

					OperationResult or;
					if(bestCan.dim<2){
						or=hist.split(currNode.second,bestCan.pos,bestCan.dim);
					}else{
						or=hist.delayer(currNode.second,chrom.m_boxSet.boundingBox(bestCan.indicesOfPartA),chrom.m_boxSet.boundingBox(bestCan.indicesOfPartB));

					}

					hist.nodeData(or.first).setData(chrom.m_boxSet,bestCan.indicesOfPartA);
					hist.nodeData(or.second).setData(chrom.m_boxSet,bestCan.indicesOfPartB);
					hist.SetContentBoxesIndex(or.first,nbox,bestCan.indicesOfPartA);
					hist.SetContentBoxesIndex(or.second,nbox,bestCan.indicesOfPartB);
				
					myStack.pop_back();

					myStack.push_back(StackNode(bestCan.indicesOfPartB,or.second));
					myStack.push_back(StackNode(bestCan.indicesOfPartA,or.first));
				}else
					myStack.pop_back();
			}
			chrom.m_ghist=hist;	
		}

		
		static int TreeMutator(GAGenome & c, float pmut)
		{

			GenerativeHistoryGA & chrom = (GenerativeHistoryGA &)c;
			if (chrom.m_ghist.nodeNum()==0)
			{
				return 0;
			}

			
			GenerativeHistory hist=chrom.m_ghist;
			std::vector<int>nonleaflist;
			nonleaflist.clear();
			for (int i=1;i<hist.nodeNum();i++)
			{
				if (!(hist.isLeafNode(i)))
				{
					nonleaflist.push_back(i);
				}

			}
			if (nonleaflist.size()==0)
			{
				return 0;
			}
			
			int index=nonleaflist[0];

			std::vector<int>selectnode;
			selectnode=hist.getChildrenNode(index);
			

			GenerativeHistory hist1;
			
			std::vector<int> initialBoxIndices=chrom.m_boxSet.allBoxIndices();
			int nbox=initialBoxIndices.size();
			
			hist1.setrootid(0);
			hist1.newhist(hist,selectnode);

			int rindex=hist1.nodeNum();
			std::vector<int> list=hist1.AddirstNode(hist,selectnode);
			typedef std::pair<std::vector<int>,int> StackNode;
			std::vector<StackNode> myStack;
			myStack.push_back(StackNode(list,rindex));

			while(!myStack.empty())
			{
				StackNode& currNode=myStack.back();

				if(!chrom.needDecomp(currNode.first)){
					myStack.pop_back();

					continue;
				}

				std::vector<DecompCandidate> candidates;
				chrom.generateCandidates(currNode.first,candidates);
				Box space=hist1.boxOf(currNode.second);
				int sizeCandidates=candidates.size();
				std::vector<float>valueCandidates;
				valueCandidates.clear();
				valueCandidates.resize(sizeCandidates);
				float sumvalue=0;
				for (int i=0;i<sizeCandidates;i++)
				{
					valueCandidates[i]=chrom.evaluateNIS(candidates[i],space);
					sumvalue+=valueCandidates[i];
				}
				float seed=GARandomFloat(0.0,sumvalue);
				float temp=0;
				int choseCandidate=-1;
				for (int i=0;i<sizeCandidates;i++)
				{
					temp+=valueCandidates[i];
					if (temp>=seed)
					{
						choseCandidate=i;
						break;
					}
				}

				if(choseCandidate!=-1){
					DecompCandidate &bestCan=candidates[choseCandidate];

					OperationResult or;
					if(bestCan.dim<2){
						or=hist1.split(currNode.second,bestCan.pos,bestCan.dim);
					}else{
						or=hist1.delayer(currNode.second,chrom.m_boxSet.boundingBox(bestCan.indicesOfPartA),chrom.m_boxSet.boundingBox(bestCan.indicesOfPartB));

					}

					hist1.nodeData(or.first).setData(chrom.m_boxSet,bestCan.indicesOfPartA);
					hist1.nodeData(or.second).setData(chrom.m_boxSet,bestCan.indicesOfPartB);
					hist1.SetContentBoxesIndex(or.first,nbox,bestCan.indicesOfPartA);
					hist1.SetContentBoxesIndex(or.second,nbox,bestCan.indicesOfPartB);

					myStack.pop_back();

					myStack.push_back(StackNode(bestCan.indicesOfPartB,or.second));
					myStack.push_back(StackNode(bestCan.indicesOfPartA,or.first));
				}else
				{
					myStack.pop_back();
				}
			}
			chrom.m_ghist=hist1;
			bool ise=hist1.iseaqual(hist,0,0);
			if (ise==false)
			{
				return 1;
			}
			return 0;
		}

		static int TreeCrossover(const GAGenome& p1, const GAGenome& p2, GAGenome* c1, GAGenome* c2)
		{
			GenerativeHistoryGA & dad = (GenerativeHistoryGA &)p1;
			GenerativeHistoryGA & mom = (GenerativeHistoryGA &)p2;
			GenerativeHistory histdad=dad.m_ghist;
			GenerativeHistory histmom=mom.m_ghist;
			GenerativeHistory histchild1;
			GenerativeHistory histchild2;
			if (c2==NULL)
			{
				std::vector<int>sel;
				sel.clear();
				if (histdad.rootBox()!=-1)
				{
					sel.resize(histdad.nodeNum());
					for (int i=0;i<histdad.nodeNum();i++)
					{
						sel[i]=0;
					}
					GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
					histchild1.setrootid(0);
					histchild1.newhist(histdad,sel);
					child1->m_ghist=histchild1;
					return 1;
				}
				else
				{
					if (histmom.rootBox()!=-1)
					{
						sel.resize(histmom.nodeNum());
						for (int i=0;i<histmom.nodeNum();i++)
						{
							sel[i]=0;
						}
						GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
						histchild1.setrootid(0);
						histchild1.newhist(histmom,sel);
						child1->m_ghist=histchild1;
						return 1;
					}
					else
					{
						return 0;
					}
				}
			}
			if ((histdad.rootBox()==-1)||(histmom.rootBox()==-1))
			{
				
				std::vector<int>sel;
				sel.clear();
				
				if (histdad.rootBox()!=-1)
				{
					sel.resize(histdad.nodeNum());
					for (int i=0;i<histdad.nodeNum();i++)
					{
						sel[i]=0;
					}
					GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
					histchild1.setrootid(0);
					histchild1.newhist(histdad,sel);
					child1->m_ghist=histchild1;
					GenerativeHistoryGA * child2 = (GenerativeHistoryGA *)c2;
					histchild2.newhist(histdad,sel);
					histchild2.setrootid(0);
					child2->m_ghist=histchild1;
					return 1;
				}
				else
				{
					if (histmom.rootBox()!=-1)
					{
						sel.resize(histmom.nodeNum());
						for (int i=0;i<histmom.nodeNum();i++)
						{
							sel[i]=0;
						}
						GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
						histchild1.setrootid(0);
						histchild1.newhist(histmom,sel);
						child1->m_ghist=histchild1;
						GenerativeHistoryGA * child2 = (GenerativeHistoryGA *)c2;
						histchild2.newhist(histmom,sel);
						histchild2.setrootid(0);
						child2->m_ghist=histchild1;
						return 1;
					}
					else
					{
						return 0;
					}
				}
				
			}
			if (histdad.iseaqual(histmom,0,0))
			{
				std::vector<int>sel;
				sel.clear();
				sel.resize(histmom.nodeNum());
				for (int i=0;i<histmom.nodeNum();i++)
				{
					sel[i]=0;
				}
				GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
				GenerativeHistoryGA * child2 = (GenerativeHistoryGA *)c2;
				histchild1.newhist(histmom,sel);
				histchild2.newhist(histmom,sel);
				histchild1.setrootid(0);
				histchild2.setrootid(0);
				child1->m_ghist=histchild1;
				child2->m_ghist=histchild2;
				return 1;
			}
			int ndad=histdad.nodeNum();
			int nmom=histmom.nodeNum();
			if ((ndad==0)||(nmom==0))
			{
				return 0;
			}
			int nbox=histdad.nodeData(0).size();
			std::vector<int>nodepair;
			nodepair.clear();
			for (int i=1;i<ndad;i++)
			{
				if (!(histdad.isLeafNode(i)))
				{
					for (int j=1;j<nmom;j++)
					{
						if (!(histmom.isLeafNode(j)))
						{
							int cancross=1;
							std::vector<int>listdadi=histdad.GetContentBoxesIndex(i);
							std::vector<int>listmomj=histmom.GetContentBoxesIndex(j);
							for (int k=0;k<nbox;k++)
							{
								if (listdadi[k]!=listmomj[k])
								{
									cancross=0;
								}
							}
							if (cancross==1)
							{
								nodepair.push_back(i);
								nodepair.push_back(j);
							}
						}
					}
				}
				
			}
			if (nodepair.size()==0)
			{
				std::vector<int>sel;
				sel.clear();
				sel.resize(histmom.nodeNum());
				for (int i=0;i<histmom.nodeNum();i++)
				{
					sel[i]=0;
				}
				GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
				GenerativeHistoryGA * child2 = (GenerativeHistoryGA *)c2;
				histchild1.newhist(histmom,sel);
				histchild2.newhist(histmom,sel);
				histchild1.setrootid(0);
				histchild2.setrootid(0);
				child1->m_ghist=histchild1;
				child2->m_ghist=histchild2;
				return 1;
			}
			int crossoverpoint=-1;
			for (int ll=0;ll<int(nodepair.size()*0.5);ll++)
			{
				int i0=nodepair[2*ll];
				int i1=nodepair[2*ll+1];
				if (histdad.iseaqual(histmom,i0,i1))
				{
					continue;
				}
				else
				{
					std::vector<int>selectnodedad;
					selectnodedad=histdad.getChildrenNode(i0);
					std::vector<int>selectnodemom;
					selectnodemom=histmom.getChildrenNode(i1);
					GenerativeHistory ghist0;
					GenerativeHistory ghist1;
					ghist0.newhist(histdad,selectnodedad);
					ghist1.newhist(histmom,selectnodemom);
					if (ghist0.iseaqual(ghist1,0,0))
					{
						continue;
					}
					else
					{
						crossoverpoint=ll;
					}

				}

			}
			if (crossoverpoint==-1)
			{
				std::vector<int>sel;
				sel.clear();
				sel.resize(histmom.nodeNum());
				for (int i=0;i<histmom.nodeNum();i++)
				{
					sel[i]=0;
				}
				GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
				GenerativeHistoryGA * child2 = (GenerativeHistoryGA *)c2;
				histchild1.newhist(histmom,sel);
				histchild2.newhist(histmom,sel);
				histchild1.setrootid(0);
				histchild2.setrootid(0);
				child1->m_ghist=histchild1;
				child2->m_ghist=histchild2;
				return 1;
			}

			int nodeindexdad=nodepair[2*crossoverpoint];
			int nodeindexmom=nodepair[2*crossoverpoint+1];
			std::vector<int>selectnodedad;
			selectnodedad=histdad.getChildrenNode(nodeindexdad);
			std::vector<int>selectnodemom;
			selectnodemom=histmom.getChildrenNode(nodeindexmom);
			
			histchild1.newhist(histdad,selectnodedad);
			histchild1.AddSubtree(histmom,selectnodemom,histdad.parentBoxId(nodeindexdad));
			histchild2.newhist(histmom,selectnodemom);
			histchild2.AddSubtree(histdad,selectnodedad,histmom.parentBoxId(nodeindexmom));

			GenerativeHistoryGA * child1 = (GenerativeHistoryGA *)c1;
			GenerativeHistoryGA * child2 = (GenerativeHistoryGA *)c2;
			if ((c1==NULL)||(c2==NULL))
			{
				return 0;
			}
			histchild1.setrootid(0);
			histchild2.setrootid(0);
			child1->m_ghist=histchild1;
			child2->m_ghist=histchild2;			
			return 1;
		}
		
		void saveSvg_SplitCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);
		void saveSvg_DelayerCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);

		

	};

}
#endif

