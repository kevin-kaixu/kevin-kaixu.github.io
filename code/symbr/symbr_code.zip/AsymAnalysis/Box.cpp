#include "Box.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include "Util.h"
#include <string>
#include <math.h>
using namespace Asym;
Box::Box():_x(0),_y(0),_width(0),_height(0),_label(0),_id(0){

}
Box::Box(int x,int y,int w,int h,int L):
_x(x),_y(y),_width(w),_height(h),_label(L),_id(0){

}

Box::Box(const Box& b):_x(b._x),_y(b._y),_height(b._height),_width(b._width),_label(b._label),_id(b.id()){

}

Box::~Box(){

}

int Box::id() const{
return _id;
}
void Box::setId(int id){
_id=id;
}
void Box::setLabel(int L){
	_label=L;
}
void  Box::setWidth(int w){
	_width=w;
}

void  Box::setHeight(int h){
	_height=h;
}

int Box::x() const{
	return _x;
}

int Box::y() const{
	return _y;
}

int Box::height() const{
	return _height;
}

int Box::width() const{
	return _width;
}

int Box::label() const{
return _label;
}

void Box::setX(int x){
_x=x;
}
void Box::setY(int y){
_y=y;
}

int Box::left() const{
	return  _x;
}
int Box::right() const{
	return _x+_width;
}

int Box::bottom() const{
	return _y;
}

int Box::top() const{
	return _y+_height;
}

int Box::location(int dim) const{
if(dim==0)return _x;
else return _y;
}

int Box::size(int dim) const{
if(dim==0)return _width;
else return _height;
}

int Box::area(){
	return _width*_height;
}

int Box::center(int dim) const{
	return location(dim)+size(dim)/2;
}

bool Box::operator==(const Box& box){
return _x==box.x()&&_y==box.y()&&_width==box.width()&&_height==box.height();
}
void Box::scale(float r){
//_x*=r;
//_y*=r;
_width*=r;
_height*=r;
}

void Box::translate(int dx,int dy){
	_x+=dx;
	_y+=dy;
}

Box Box::reflection(int loc,int dim){
Box b(*this);
if(dim==0){
	b._x=loc+(loc-this->right());
}else{
	b._y=loc+(loc-this->top());
}
return b;
}

bool Box::isIntersect(Box& b){
return !(this->left() >= b.right() || 
		         this->right()<=b.left() || 
				 this->top()<=b.bottom()||
				 this->bottom()>=b.top());
}

Box Box::intersection(Box& b){
	if(!this->isIntersect(b))
		return  Box(0,0,0,0);
	
	std::vector<int> horiz;
	horiz.push_back(left());
	horiz.push_back(right());
	horiz.push_back(b.left());
	horiz.push_back(b.right());
	std::sort(horiz.begin(),horiz.end());

	std::vector<int> verti;
	verti.push_back(bottom());
	verti.push_back(top());
	verti.push_back(b.bottom());
	verti.push_back(b.top());
	std::sort(verti.begin(),verti.end());

	return  Box(horiz[1],verti[1],horiz[2]-horiz[1],verti[2]-verti[1]);
}

bool Box::contains(Box box){
return box.left()>=left()&&box.right()<=right()&&box.bottom()>=bottom()&&box.top()<=top();
}
bool Box::contains(int x,int y){
return x>=left()&&x<=right()&&y>=bottom()&&y<=top();
}
int Box::areaOfOverlap(Box& b){
if(!isIntersect(b))return 0;
else
return intersection(b).area();
}


inline bool inBetween(int a,int b,int c){
	return a<=b&&b<=c;
}

BoxEdgeType Box::pickEdge(int x,int y,int threshold){
if(inBetween(left()-threshold,x,left()+threshold)&&inBetween(bottom(),y,top()))return ET_Left;
if(inBetween(right()-threshold,x,right()+threshold)&&inBetween(bottom(),y,top()))return ET_Right;
if(inBetween(left(),x,right())&&inBetween(bottom()-threshold,y,bottom()+threshold))return ET_Bottom;
if(inBetween(left(),x,right())&&inBetween(top()-threshold,y,top()+threshold))return ET_Top;
return ET_None;
}

float Box::distance2(Box& b1)
{
	float dist=100000;
	if (isIntersect(b1))
	{
		dist=0;
	}
	else
	{
		std::vector<int>bp0;
		std::vector<int>bp1;
		bp0.clear();
		bp1.clear();
		bp0.resize(2*9);
		bp1.resize(2*9);

		bp0[0]=left();
		bp0[1]=bottom();
		bp0[2]=0.5*(left()+right());
		bp0[3]=bottom();
		bp0[4]=right();
		bp0[5]=bottom();

		bp0[6]=left();
		bp0[7]=0.5*(bottom()+top());
		bp0[8]=0.5*(left()+right());
		bp0[9]=0.5*(bottom()+top());
		bp0[10]=right();
		bp0[11]=0.5*(bottom()+top());

		bp0[12]=left();
		bp0[13]=top();
		bp0[14]=0.5*(left()+right());
		bp0[15]=top();
		bp0[16]=right();
		bp0[17]=top();

		bp1[0]=b1.left();
		bp1[1]=b1.bottom();
		bp1[2]=0.5*(b1.left()+b1.right());
		bp1[3]=b1.bottom();
		bp1[4]=b1.right();
		bp1[5]=b1.bottom();

		bp1[6]=b1.left();
		bp1[7]=0.5*(b1.bottom()+b1.top());
		bp1[8]=0.5*(b1.left()+b1.right());
		bp1[9]=0.5*(b1.bottom()+b1.top());
		bp1[10]=b1.right();
		bp1[11]=0.5*(b1.bottom()+b1.top());

		bp1[12]=b1.left();
		bp1[13]=b1.top();
		bp1[14]=0.5*(b1.left()+b1.right());
		bp1[15]=b1.top();
		bp1[16]=b1.right();
		bp1[17]=b1.top();

		for (int i=0;i<9;i++)
		{
			int xx0=bp0[2*i];
			int yy0=bp0[2*i+1];
			for (int j=0;j<9;j++)
			{
				int xx1=bp1[2*j];
				int yy1=bp1[2*j+1];
				float distij=sqrt(float((xx0-xx1)*(xx0-xx1)+(yy0-yy1)*(yy0-yy1)));
				if (distij<dist)
				{
					dist=distij;
				}
			}
		}
	}

	return dist;
}

int Box::distanceTo(Box& b){
int dx=intFabs(center(0)-b.center(0));
int dy=intFabs(center(1)-b.center(1));
return dx+dy;
}

bool Box::isAlignedWith(Box& box,int dim){
	int dcenter=intFabs(center(dim)-box.center(dim));
	int largerSize=size(dim)>box.size(dim)?size(dim):box.size(dim);
	if(dcenter<largerSize/4)
		return true;

	return false;
}

void Box::splitBox(Box& inputBox,int pos, int dim,Box& lowBox,Box& higherBox){
	lowBox=inputBox;
	higherBox=inputBox;
	if(dim==0){
		lowBox._width=pos-inputBox.left();
		higherBox._width=inputBox.right()-pos;
		higherBox._x=pos;
	}else{
		lowBox._height=pos-inputBox.bottom();
		higherBox._height=inputBox.top()-pos;
		higherBox._y=pos;
	}
}

void BoxSet::generateGridOfBoxes(int startx,int starty, int width,int height,int horiSpacing,int vertiSpacing,int rowNum,int colNum){
reserve(rowNum*colNum);

for(int r=0;r<rowNum;r++)
	for(int c=0;c<colNum;++c){
		int x=(startx+horiSpacing)*c;
		int y=(starty+vertiSpacing)*r;
		push_back(Box(x,y,width,height));
	}
}

bool BoxSet::readFromFile(std::string fn){
	std::ifstream myfile;
	myfile.open(fn.c_str());
	if(!myfile.is_open())return false;

	std::string imgFileName;
	//myfile>>imgFileName;
	
	std::getline (myfile,imgFileName);
	int boxNum=0;
	myfile>>boxNum;
	BoxSet bset;
	reserve(boxNum);

//	std::cout<<"box num"<<boxNum<<std::endl;

	for(int i=0;i<boxNum;++i){
		int x,y,w,h,L;
		myfile>>x>>y>>w>>h>>L;
		push_back(Box(x,y,w,h,L));
	}
	return true;
}

bool BoxSet::writeToFile(std::string fn){
	std::ofstream myfile(fn.c_str());
	myfile << size()<<std::endl;
	for(BoxSet::iterator it=begin();it!=end();++it){
		myfile<<it->x()<<" "<<it->y()<<" "<<it->width()<<" "<<it->height()<<" "<<it->label()<<std::endl;
	}

	myfile.close();
	return true;
}

Box BoxSet::boundingBox(){
	if(empty())return Box(0,0,0,0);
	return boundingBox(allBoxIndices());
}

Box BoxSet::boundingBox(std::vector<int>& boxIndices){
	if(boxIndices.empty())return Box(0,0,0,0);

	int left=(*this)[boxIndices[0]].left();
	int right=(*this)[boxIndices[0]].right();
	int top=(*this)[boxIndices[0]].top();
	int bottom=(*this)[boxIndices[0]].bottom();

	for(int i=1;i<boxIndices.size();++i){
		Box &box=(*this)[boxIndices[i]];

		if(left>box.left())
			left=box.left();

		if(right<box.right())
			right=box.right();

		if(top<box.top())
			top=box.top();

		if(bottom>box.bottom())
			bottom=box.bottom();
	}
	return Box(left,bottom,right-left,top-bottom);
}

void BoxSet::findMinMaxLabel(int&minL,int &maxL){
	if(empty())return;

	maxL=front().label();
	minL=front().label();
	for(BoxSet::iterator it=begin();it!=end();++it){
		if(maxL<it->label())
			maxL=it->label();
		if(minL>it->label())
			minL=it->label();
	}
	
}

void BoxSet::generateRandBoxSet(int rnum,int cnum,int labelNum){
	generateGridOfBoxes(0,0,10,10,20,20,rnum,cnum);

	RandomNumberGenerator labelGen(0,labelNum);
	for(int i=0;i<size();++i){
		Box &box=(*this)[i];
		box.setLabel(labelGen.randomNum());
	}

	RandomNumberGenerator sizeGen(5,10);
	for(int i=0;i<size();++i){
			Box &box=(*this)[i];
			int newHeight=sizeGen.randomNum();
			int newWidth=sizeGen.randomNum();
			int dw=newWidth-box.width();
			int dh=newHeight-box.height();
			box.setWidth(newWidth);
			box.setHeight(newHeight);
			box.setX(box.x()-dw/2);
			box.setY(box.y()-dh/2);

	}

}


std::vector<int> BoxSet::usedLabels(){

std::vector<int> labels;

for(int i=0;i<size();++i){
	Box& box=(*this)[i];
	if(std::find(labels.begin(),labels.end(),box.label())==labels.end()){
		labels.push_back(box.label());
	}
}

return labels;
}

std::vector<int> BoxSet::usedLabels(std::vector<int>& boxIndices){
	std::vector<int> labels;

	for(int i=0;i<boxIndices.size();++i){
		Box& box=(*this)[boxIndices[i]];
		if(std::find(labels.begin(),labels.end(),box.label())==labels.end()){
			labels.push_back(box.label());
		}
	}

	return labels;
}


std::vector<std::vector<int>> BoxSet::groupingByLables(){
	std::vector<int> labels=usedLabels();
	std::vector<std::vector<int>> groups;
	groups.resize(labels.size());
	for(int i=0;i<size();++i){
		Box& box=(*this)[i];
		for(int j=0;j<labels.size();++j){
			if(box.label()==labels[j]){
				groups[j].push_back(i);
				break;
			}
		}
	}

	return groups;
}

std::vector<std::vector<int>> BoxSet::groupingByLables(std::vector<int>& boxIndices){
	std::vector<int> labels=usedLabels(boxIndices);
	std::vector<std::vector<int>> groups;
	groups.resize(labels.size());
	for(int i=0;i<boxIndices.size();++i){
		Box& box=(*this)[boxIndices[i]];
		for(int j=0;j<labels.size();++j){
			if(box.label()==labels[j]){
				groups[j].push_back(boxIndices[i]);
				break;
			}
		}
	}

	return groups;
}

int BoxSet::avgWidth(){
if(empty())return 0;
int totalWidth=0;
for(int i=0;i<size();++i)
	totalWidth+=(*this)[i].width();

return totalWidth/size();
}

int BoxSet::avgHeight(){
	if(empty())return 0;
	int s=0;
	for(int i=0;i<size();++i)
		s+=(*this)[i].height();

	return s/size();
}

int BoxSet::avgWidth(std::vector<int>& boxIndices){
	if(boxIndices.empty()||empty())return 0;
	int s=0;
	for(int i=0;i<boxIndices.size();++i)
		s+=(*this)[boxIndices[i]].width();

	return s/boxIndices.size();
}

int BoxSet::avgHeight(std::vector<int>& boxIndices){
	if(boxIndices.empty()||empty())return 0;
	int s=0;
	for(int i=0;i<boxIndices.size();++i)
		s+=(*this)[boxIndices[i]].height();

	return s/boxIndices.size();
}

std::vector<int> BoxSet::allBoxIndices(){
std::vector<int> indices;
indices.resize(size());
for(int i=0;i<size();++i)
indices[i]=i;
return indices;
}

bool BoxSet::split(int pos,int dim,std::vector<int>& smallerBoxIndices,std::vector<int>& higherBoxIndices){
	return split(pos,dim,allBoxIndices(),smallerBoxIndices,higherBoxIndices);
}

bool BoxSet::split(int pos,int dim,std::vector<int>& inputBoxIndices,std::vector<int>& smallerBoxIndices,std::vector<int>& higherBoxIndices){
	smallerBoxIndices.clear();
	higherBoxIndices.clear();
	for(int i=0;i<inputBoxIndices.size();++i){
		int k=inputBoxIndices[i];
		Box& box=(*this)[k];
		int lowerBound=box.location(dim);
		int higherBound=box.location(dim)+box.size(dim);
		if(lowerBound>=pos){
			higherBoxIndices.push_back(k);
		}else if(higherBound<=pos){
			smallerBoxIndices.push_back(k);
		}else
			return false;
	}
	return true;
}

void BoxSet::setData(BoxSet& boxset,std::vector<int>& boxIndices){
	clear();
	resize(boxIndices.size());
	for(int i=0;i<boxIndices.size();++i)
		(*this)[i]=boxset[boxIndices[i]];
}
void BoxSet::setData(BoxSet& boxset)
{
	clear();
	resize(boxset.size());
	for(int i=0;i<boxset.size();++i)
		(*this)[i]=boxset[i];
}

void BoxSet::scaleAllBoxes(float ratio){
Box bbox=boundingBox();
for(int i=0;i<size();++i){
	Box& box=(*this)[i];
	int x=(box.x()-bbox.x())*ratio;
	int y=(box.y()-bbox.y())*ratio;
	box.setX(x);
	box.setY(y);
	box.setWidth(box.width()*ratio);
	box.setHeight(box.height()*ratio);
}
}

void BoxSet::addUniqueBox(Box& box){
	if(std::find(begin(),end(),box)==end())
		push_back(box);
}