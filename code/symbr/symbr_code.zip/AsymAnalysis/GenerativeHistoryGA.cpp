#include "GenerativeHistoryGA.h"
#include "BoxGraph.h"
#include "SymProfile.h"
#include <algorithm>
#define ALIGN_THRESHOLD_RATIO 0.3

namespace Asym{

	GenerativeHistoryGA::~GenerativeHistoryGA(void)
	{
	}
	GenerativeHistoryGA::GenerativeHistoryGA(GAGenome::Evaluator f,Mutator m, Comparator c)
	{
		evaluator(f);
		GenerativeHistory hist=m_ghist;
	}
	GAGenome *GenerativeHistoryGA::clone(GAGenome::CloneMethod flag) const 
	{
		GenerativeHistoryGA *cpy = new GenerativeHistoryGA();
		flag=CONTENTS;
		if(flag == (int)CONTENTS){cpy->copy(this);} // cast is for metrowerks...
		else{cpy->GAGenome::copy(*this);}
		return cpy;
	}
	void GenerativeHistoryGA::copy(const GAGenome & orig) {
		const GenerativeHistoryGA* c = DYN_CAST(const GenerativeHistoryGA*, &orig);
		if(c) {
			GAGenome::copy(*c);
			BoxSet a=c->m_boxSet;
			SetBoxSet(a);
			GenerativeHistory hist=c->m_ghist;

			GenerativeHistory hist1;
			std::vector<int>sel;
			sel.clear();
			if (hist.rootBox()!=-1)
			{
				sel.resize(hist.nodeNum());
				for (int i=0;i<hist.nodeNum();i++)
				{
					sel[i]=0;
				}
				hist1.setrootid(0);
				hist1.newhist(hist,sel);
				m_ghist=hist1;

			}

		}
	}
	void GenerativeHistoryGA::copy(const GenerativeHistoryGA* orig) {
		const GenerativeHistoryGA* c=orig;
		if(c) {
			GAGenome::copy(*c);
			BoxSet a=orig->m_boxSet;
			SetBoxSet(a);
			GenerativeHistory hist=orig->m_ghist;

			GenerativeHistory hist1;
			std::vector<int>sel;
			sel.clear();
			if (hist.rootBox()!=-1)
			{
				sel.resize(hist.nodeNum());
				for (int i=0;i<hist.nodeNum();i++)
				{
					sel[i]=0;
				}
				hist1.setrootid(0);
				hist1.newhist(hist,sel);
				m_ghist=hist1;

			}

		}
	}


	bool GenerativeHistoryGA::needDecomp(std::vector<int>& boxIndices){
		if(boxIndices.empty())return false;
		std::vector<Grid> grids=generateAllGrids(boxIndices);
		return grids.size()>1;
	}
	std::vector<Grid> GenerativeHistoryGA::generateAllGrids(std::vector<int>& boxIndices){
		std::vector<Grid> grids;
		if(boxIndices.empty())return grids;
		std::vector<std::vector<int>> groups=m_boxSet.groupingByLables(boxIndices);

		BoxGraph boxGraph(m_boxSet);
		for(int i=0;i<groups.size();++i){
			boxGraph.extractGrids(groups[i],grids,ALIGN_THRESHOLD_RATIO,ALIGN_THRESHOLD_RATIO);
		}



		return grids;

	}
	void  GenerativeHistoryGA::generateCandidates(std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates){///
		std::vector<Grid> grids=generateAllGrids(boxIndices);
		removeInvalidGrids(grids,boxIndices);
		BoxSet gridBboxSet;
		for(int i=0;i<grids.size();++i)
			gridBboxSet.push_back(grids[i].boundingbox(m_boxSet));

		for(int dim=0;dim<2;++dim){
			LineProfile lp=LineProfile::createFromBoxSet(gridBboxSet,dim);
			std::vector<int> zeroPos=lp.zeroTurningPos();
			for(int i=0;i<zeroPos.size();++i){
				DecompCandidate dcan;
				dcan.dim=dim;
				dcan.pos=zeroPos[i];
				m_boxSet.split(dcan.pos,dcan.dim,boxIndices,dcan.indicesOfPartA,dcan.indicesOfPartB);
				candidates.push_back(dcan);
			}	
		}

		generateDelayerCandidateswithoutlevel(boxIndices,grids,candidates);

	}

	void GenerativeHistoryGA::generateDelayerCandidateswithoutlevel(std::vector<int>& boxIndices,std::vector<Grid>& grids,std::vector<DecompCandidate>& candidates)///
	{
		std::vector<delayernode>nodelist;
		nodelist.clear();
		nodelist.resize(grids.size());
		std::vector<edge>edgelist;
		edgelist.clear();
		for (int i=0;i<grids.size();i++)
		{
			delayernode da;
			da.index=i;
			nodelist[i]=da;

		}
		//build edgelist
		for(int i=0;i<grids.size();++i)
		{
			for(int j=0;j<grids.size();++j)
			{
				if(i==j)continue;
				Grid &g1=grids[i];
				Grid &g2=grids[j];
				if(g1.isInFrontOf(g2,m_boxSet))
				{
					edge eij;

					Box b1=g1.boundingbox(m_boxSet);
					Box b2=g2.boundingbox(m_boxSet);
					Box inter=b1.intersection(b2);
					eij.p0=i;
					eij.p1=j;
					eij.inter=inter.area();
					edgelist.push_back(eij);

					nodelist[i].outedge.push_back(edgelist.size()-1);
					nodelist[j].inedge.push_back(edgelist.size()-1);
				}
			}
		}

		//find circle
		std::vector<int>markedge;
		markedge.clear();
		markedge.resize(edgelist.size());
		for (int i=0;i<nodelist.size();i++)
		{
			delayernode di=nodelist[i];
			std::vector<int>hasvisitde;
			hasvisitde.clear();
			hasvisitde.resize(nodelist.size());
			if (di.outedge.size()!=0)
			{
				for (int j=0;j<nodelist.size();j++)
				{
					nodelist[j].isin=0;
				}
				std::vector<int> myStack;
				myStack.push_back(di.index);
				std::vector<int>path;
				path.clear();
				while(!myStack.empty())
				{
					int currNode=myStack.back();


					int have=0;
					int circleindex=0;
					//if havecircle
					int npp=path.size()-1;
					for (int j=0;j<npp;j++)
					{
						if (currNode==path[j])
						{
							have=1;
							circleindex=j;
						}
					}
					if (have)
					{
						int mininter=100000000;
						int minedge;
						for (int j=circleindex;j<path.size()-1;j++)
						{
							int interi;
							int indexi;
							for (int k=0;k<nodelist[path[j]].outedge.size();k++ )
							{
								edge jk=edgelist[nodelist[path[j]].outedge[k]];

								interi=jk.inter;
								indexi=nodelist[path[j]].outedge[k];

							}
							if (interi<mininter)
							{
								mininter=interi;
								minedge=indexi;
							}
						}
						markedge[minedge]=1;
					}

					int can=0;
					for (int k=0;k<nodelist[currNode].outedge.size();k++)
					{
						int ik=edgelist[nodelist[currNode].outedge[k]].p1;
						if (hasvisitde[ik]==0)
						{
							can=1;
						}
					}
					if (can==1)
					{
						int isin=1;
						for (int l=0;l<nodelist[currNode].outedge.size();l++)
						{
							int nodeindexi=edgelist[nodelist[currNode].outedge[l]].p1;
							if (nodelist[nodeindexi].isin==0)
							{
								isin=0;
							}
						}
						if (isin==0)
						{
							path.push_back(currNode);
							hasvisitde[currNode]=1;
							for (int l=0;l<nodelist[currNode].outedge.size();l++)
							{
								int nodeindexi=edgelist[nodelist[currNode].outedge[l]].p1;
								myStack.push_back(nodeindexi);
							}
						}
						else
						{
							nodelist[currNode].isin=1;
							myStack.pop_back();
							if (!path.empty())
							{
								path.pop_back();
							}

						}
					}
					//leaf node
					else
					{
						nodelist[currNode].isin=1;
						myStack.pop_back();
						hasvisitde[currNode]=1;
					}
				}
			}
		}//find circle end

		//build upnode
		std::vector<std::vector<int>> layerMatrix;
		layerMatrix.resize(grids.size());
		for(int i=0;i<layerMatrix.size();++i)
		{
			layerMatrix[i].assign(grids.size(),0);
		}

		for (int i=0;i<edgelist.size();i++)
		{
			if (markedge[i]==0)
			{
				edge ei=edgelist[i];
				int p0=ei.p0;
				int p1=ei.p1;
				layerMatrix[p0][p1]=1;
			}
		}

		for(int i=0;i<layerMatrix.size();++i)
		{
			std::vector<int> belowMe;
			for(int j=0;j<layerMatrix[i].size();++j)
			{
				if(layerMatrix[i][j]==1)
					belowMe.push_back(j);
			}

			std::vector<bool> hasVisited;
			hasVisited.assign(grids.size(),false);

			while(!belowMe.empty())
			{
				int current=belowMe.back();
				belowMe.pop_back();
				layerMatrix[i][current]=1;
				hasVisited[current]=true;

				for(int j=0;j<layerMatrix[current].size();++j)
				{
					if(!hasVisited[j]&&layerMatrix[current][j]==1)
					{
						belowMe.push_back(j);
						hasVisited[j]=true;
					}
				}
			}

		}

		for (int i=0;i<nodelist.size();i++)
		{
			std::vector<int>upi;
			for (int j=0;j<nodelist.size();j++)
			{
				if (layerMatrix[j][i]==1)
				{
					upi.push_back(j);
				}
			}
			nodelist[i].upnode=upi;
		}
		//end upnode
		std::vector<std::vector<int>>candidatelist;
		std::vector<delayernode>candidatenode;
		std::vector<int>i2candidate;
		i2candidate.clear();
		i2candidate.resize(nodelist.size());

		for (int i=0;i<nodelist.size();i++)
		{
			if (nodelist[i].outedge.size()!=0)
			{
				candidatenode.push_back(nodelist[i]);
				i2candidate[i]=candidatenode.size()-1;
			}
		}
		std::vector<std::vector<int>>combinelist;
		combinelist.clear();
		int ncnode=candidatenode.size();
		if (ncnode>=2)
		{
			for (int i=1;i<ncnode+1;i++)
			{
				std::vector<std::vector<int>>combinelisti=combine(ncnode,i);
				for (int j=0;j<combinelisti.size();j++)
				{
					int isej=0;
					std::vector<int>listj=combinelisti[j];
					for (int k=0;k<ncnode;k++)
					{
						if (combinelisti[j][k]==1)
						{
							for (int l=0;l<candidatenode[k].upnode.size();l++)
							{
								int indexl=i2candidate[candidatenode[k].upnode[l]];
								listj[indexl]=1;
							}
						}
					}

					for (int k=0;k<combinelist.size();k++)
					{
						if (iselist(combinelist[k],listj)==1)
						{
							isej=1;
						}
					}
					if (isej==0)
					{
						combinelist.push_back(listj);
					}
				}
			}
		}
		else
		{
			std::vector<int>listj;
			listj.resize(1);
			listj[0]=1;
			combinelist.push_back(listj);
		}


		for (int i=0;i<combinelist.size();i++)
		{
			DecompCandidate dcan;
			std::vector<int>pa;
			std::vector<int>pb;

			for (int j=0;j<ncnode;j++)
			{
				if (combinelist[i][j]==1)
				{
					int index=candidatenode[j].index;
					std::vector<int>gjlist=grids[index].allBoxIndices();
					for (int k=0;k<gjlist.size();k++)
					{
						int indexk=gjlist[k];
						int have=0;
						for (int l=0;l<pb.size();l++)
						{
							if (pb[l]==indexk)
							{
								have=1;
							}
						}
						if (have==0)
						{
							pb.push_back(indexk);
						}
					}

				}
			}

			for (int j=0;j<boxIndices.size();j++)
			{
				int have=0;
				for (int k=0;k<pb.size();k++)
				{
					if (boxIndices[j]==pb[k])
					{
						have=1;
					}
				}
				if (have==0)
				{
					pa.push_back(boxIndices[j]);
				}
			}
			dcan.indicesOfPartA=pa;
			dcan.indicesOfPartB=pb;
			dcan.dim=2;
			dcan.pos=i;
			if ((pa.size()!=0)&&(pb.size()!=0))
			{
				candidates.push_back(dcan);
			}
		}
	}
	std::vector<std::vector<int>>GenerativeHistoryGA::combine(int n,int m)
	{

		std::vector<std::vector<int>>combinelist;
		combinelist.clear();
		std::vector<int>step;
		step.clear();
		step.resize(n);
		for (int i=0;i<m;i++)
		{
			step[i]=1;
		}
		std::vector<int>l0=step;
		combinelist.push_back(l0);
		bool isend=false;
		while(!isend)
		{
			isend=true;
			for (int i=n-1;i>n-1-m;i--)
			{
				if (step[i]!=1)
				{
					isend=false;
					break;
				}
			}
			if (isend==true)
			{
				break;
			}
			int temp=0;
			int size1=0;
			for (int i=0;i<n-1;i++)
			{

				if ((step[i]==1)&&(step[i+1]==0))
				{
					step[i]=0;
					step[i+1]=1;
					temp=i;
					break;
				}
				if (step[i]==1)
				{
					size1++;
				}
			}
			for (int i=0;i<size1;i++)
			{
				step[i]=1;
			}
			for (int i=size1;i<temp;i++)
			{
				step[i]=0;
			}
			std::vector<int>l=step;
			combinelist.push_back(l);

		}
		return combinelist;
	}
	int GenerativeHistoryGA::iselist(std::vector<int>l0,std::vector<int>l1)
	{
		int n=l0.size();
		int ise=1;
		for (int i=0;i<n;i++)
		{
			if (l0[i]!=l1[i])
			{
				ise=0;
				break;
			}
		}
		return ise;
	}

	void GenerativeHistoryGA::removeInvalidGrids(std::vector<Grid>& grids,std::vector<int>& allBoxIndices)
	{
		std::vector<bool> shouldBeRemoved;
		shouldBeRemoved.assign(grids.size(),false);
		std::vector<Grid> tgrids=grids;
		grids.clear();
		for(int i=0;i<tgrids.size();++i){
			if(isGridContainedByOthers1(tgrids,i,allBoxIndices))continue;
			grids.push_back(tgrids[i]);
		}
	}

	bool GenerativeHistoryGA::isGridContainedByOthers1(std::vector<Grid>& grids,int i,std::vector<int>& allBoxIndices){

		std::vector<int> myBoxIndices=grids[i].allBoxIndices();
		std::vector<int> boxIndicesOfOtherGrids;
		for(int k=0;k<grids.size();++k){
			std::vector<int> yourBoxIndices=grids[k].allBoxIndices();
			if(k==i)continue;
			for(int j=0;j<yourBoxIndices.size();++j)
				boxIndicesOfOtherGrids.push_back(yourBoxIndices[j]);
		}

		for(int k=0;k<myBoxIndices.size();++k){
			if(std::find(boxIndicesOfOtherGrids.begin(),boxIndicesOfOtherGrids.end(),myBoxIndices[k])==boxIndicesOfOtherGrids.end())
				return false;
		}

		return true;	
	}

	float GenerativeHistoryGA::ComputeSnisweightis1()///
	{
		int nsize=m_ghist.nodeNum();
		float nis=0;
		std::vector<float>islist;
		std::vector<float>wlist;
		islist.clear();
		wlist.clear();
		Box bound=m_ghist.boxOf(0);

		for (int i=0;i<nsize;i++)
		{
			if (!m_ghist.isLeafNode(i))
			{
				BoxSet bset=m_ghist.nodeData(i);
				Box b=bset.boundingBox();
				DecompCandidate a;
				int leftb=m_ghist.leftBoxId(i);
				int rightb=m_ghist.rightBoxId(i);

				std::vector<int>aa=m_ghist.GetContentBoxesIndex(leftb);
				std::vector<int>bb=m_ghist.GetContentBoxesIndex(rightb);
				std::vector<int>pa;
				std::vector<int>pb;
				int nnsize=aa.size();
				for (int j=0;j<nnsize;j++ )
				{
					if (aa[j]==1)
					{
						pa.push_back(j);
					}
				}
				for (int j=0;j<nnsize;j++ )
				{
					if (bb[j]==1)
					{
						pb.push_back(j);
					}
				}
				Box bl=m_ghist.boxOf(leftb);
				Box br=m_ghist.boxOf(rightb);
				int dim=m_ghist.operationType(i);
				int pos=0;
				if (dim==1)
				{
					if (bl.y()>br.y())
					{
						pos=bl.y();
					}
					else
					{
						pos=br.y();
					}
				}

				if (dim==0)
				{
					if (bl.x()>br.x())
					{
						pos=bl.x();
					}
					else
					{
						pos=br.x();
					}
				}

				a.indicesOfPartA=pa;
				a.indicesOfPartB=pb;
				a.dim=dim;
				a.pos=pos;
				float cc=evaluateNIS(a,b);
				islist.push_back(cc);

				std::vector<int>dd=m_ghist.GetContentBoxesIndex(i);
				std::vector<int>pd;
				int nnsized=dd.size();
				for (int j=0;j<nnsized;j++ )
				{
					if (dd[j]==1)
					{
						pd.push_back(j);
					}
				}
				float ww=evaluateISsinglefbox(pd,b);
				wlist.push_back(ww);

			}
		}
		if (islist.size()==0)
		{
			nis=0;
			return nis;
		}
		float sumis=0;
		float sumw=0;
		for (int i=0;i<islist.size();i++)
		{
			sumis+=islist[i]*wlist[i];
			sumw+=wlist[i];
		}
		nis=sumis/sumw;
		return nis;

	}

	float GenerativeHistoryGA::evaluateISsinglefbox(std::vector<int>elist,Box space)////
	{
		SymProfile spA_X,spA_Y;
		GaussianFilterPara paraAX;
		GaussianFilterPara paraAY;
		Box subSpaceA;
		double bellRadiusRatio=1.0;

		subSpaceA=space;

		paraAX.mean=subSpaceA.center(0);
		paraAY.mean=subSpaceA.center(1);

		paraAX.sigma=bellRadiusRatio*subSpaceA.size(0)/6.6;
		paraAY.sigma=bellRadiusRatio*subSpaceA.size(1)/6.6;


		spA_X.extractFrom(m_boxSet,elist,0,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraAX);
		spA_Y.extractFrom(m_boxSet,elist,1,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraAY);


		double sumSymA_X=spA_X.integral();
		double sumSymA_Y=spA_Y.integral();
		return sumSymA_X+sumSymA_Y;
	}

	float GenerativeHistoryGA::evaluateNIS(DecompCandidate& dc,Box space){////
		SymProfile spA_X,spA_Y;
		SymProfile spB_X,spB_Y;
		GaussianFilterPara paraAX,paraBX;
		GaussianFilterPara paraAY,paraBY;
		Box subSpaceA,subSpaceB;
		double bellRadiusRatio=1.0;

		if(dc.dim<2){
			Box::splitBox(space,dc.pos,dc.dim,subSpaceA,subSpaceB);
		}else{
			subSpaceA=m_boxSet.boundingBox(dc.indicesOfPartA);
			subSpaceB=m_boxSet.boundingBox(dc.indicesOfPartB);
		}
		paraAX.mean=subSpaceA.center(0);
		paraAY.mean=subSpaceA.center(1);
		paraBX.mean=subSpaceB.center(0);
		paraBY.mean=subSpaceB.center(1);
		paraAX.sigma=bellRadiusRatio*subSpaceA.size(0)/6.6;
		paraAY.sigma=bellRadiusRatio*subSpaceA.size(1)/6.6;
		paraBY.sigma=bellRadiusRatio*subSpaceB.size(1)/6.6;
		paraBX.sigma=bellRadiusRatio*subSpaceB.size(0)/6.6;

		spA_X.extractFrom(m_boxSet,dc.indicesOfPartA,0,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraAX);
		spB_X.extractFrom(m_boxSet,dc.indicesOfPartB,0,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraBX);
		spA_Y.extractFrom(m_boxSet,dc.indicesOfPartA,1,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraAY);
		spB_Y.extractFrom(m_boxSet,dc.indicesOfPartB,1,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraBY);

		double sumSymA_X=spA_X.integral();
		double sumSymB_X=spB_X.integral();
		double sumSymA_Y=spA_Y.integral();
		double sumSymB_Y=spB_Y.integral();

		if(dc.dim<2){

			Box::splitBox(space,dc.pos,dc.dim,subSpaceA,subSpaceB);
			double IS_A_X=SymProfile::integralSymOfBox(subSpaceA,0);
			double IS_A_Y=SymProfile::integralSymOfBox(subSpaceA,1);
			double IS_B_X=SymProfile::integralSymOfBox(subSpaceB,0);
			double IS_B_Y=SymProfile::integralSymOfBox(subSpaceB,1);
			return (sumSymA_X/IS_A_X+sumSymA_Y/IS_A_Y+sumSymB_X/IS_B_X+sumSymB_Y/IS_B_Y)/4;

		}else{
			Box subSpaceA=space;
			double IS_A_X=SymProfile::integralSymOfBox(subSpaceA,0);
			double IS_A_Y=SymProfile::integralSymOfBox(subSpaceA,1);
			Box subSpaceB=m_boxSet.boundingBox(dc.indicesOfPartB);
			double IS_B_X=SymProfile::integralSymOfBox(subSpaceB,0);
			double IS_B_Y=SymProfile::integralSymOfBox(subSpaceB,1);
			return ((sumSymA_X+sumSymB_X)/(IS_A_X+IS_B_X)+(sumSymA_Y+sumSymB_Y)/(IS_A_Y+IS_B_Y))/2;
		}
	}

}
