#include "Box.h"
#include "SymProfile.h"
#include "Util.h"
#include "simple_svg_1.0.0.hpp"
#include "GenerativeHistory.h"
#include "analysis.h"
#include "BoxGraph.h"
#include<algorithm>
#include <sstream>
using namespace Asym;

bool BoxSet::saveSvg(std::string fn){
	Box bbox=this->boundingBox();
	svg::Layout layout(svg::Dimensions(bbox.width(),bbox.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(bbox.x(),bbox.y()));
	svg::Document doc(fn,layout);
	int minLabel,maxLabel;
	findMinMaxLabel(minLabel,maxLabel);

	if(maxLabel==0)
		maxLabel=1;
	for(int i=0;i<size();++i){
		Box &box=(*this)[i];
		float s= (box.label()-minLabel+1)/  (float)(maxLabel-minLabel+1);
		hsv hsvColor={s*360,1.0,1.0};
		rgb rgbColor=hsv2rgb(hsvColor);
		svg::Color mc(rgbColor.r*255,rgbColor.g*255,rgbColor.b*255);

		svg::Rectangle rect(svg::Point(box.x(),box.y()),box.width(),box.height(),svg::Fill(mc));
		doc<<rect;
	}

	return doc.save();
}

bool BoxSet::saveSvgWithTextLabel(std::string fn,SaveTextType t){
	Box bbox=this->boundingBox();
	svg::Layout layout(svg::Dimensions(bbox.width(),bbox.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(bbox.x(),bbox.y()));
	svg::Document doc(fn,layout);


	for(int i=0;i<size();++i){
		Box &box=(*this)[i];
		svg::Rectangle rect(svg::Point(box.x(),box.y()),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
		doc<<rect;

		if(t!=SaveTextType::None){
			std::stringstream st;
			if(t==SaveTextType::Label)
				st<<(char)box.label();
			else
				st<<i;


			svg::Text labelText(svg::Point(box.center(0),box.center(1)),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
			doc<<labelText;
		}
	}

	return doc.save();
}


void LineProfile::saveSvg(std::string fn){
	int maxValue=*std::max_element(_value.begin(),_value.end());
	int CanvasHight=200;

	svg::Layout layout(svg::Dimensions(_Pos.end()-_Pos.begin(),CanvasHight),svg::Layout::Origin::BottomLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	svg:: Polyline polyline(svg::Fill(),svg::Stroke(1,svg::Color::Blue));

	polyline<<svg::Point(_Pos.front(),0);

	for(int i=0;i<_Pos.size()-1;i++){
		int v=_value[i]*CanvasHight/maxValue;
		polyline<<svg::Point(_Pos[i],v)<<svg::Point(_Pos[i+1],v);
	}

	polyline<<svg::Point(_Pos.back(),0);
	doc<<polyline;
	doc.save();
}


void SymProfile::saveSvg(std::string fn,BoxSet* bset){
	Box canvas=_bbox;

	svg::Layout layout(svg::Dimensions(canvas.width(),canvas.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	svg::Polyline c(svg::Fill(),svg::Stroke(1,svg::Color::Blue));
	int maxS=canvas.area();//maximalSymValue();

	if(bset!=NULL){
		std::vector<int> allLabels=bset->usedLabels();
		maxS=maximalSymValue();
		for(int i=0;i<bset->size();++i){
			Box &box=(*bset)[i];
			int L=std::find(allLabels.begin(),allLabels.end(),box.label())-allLabels.begin();
			float s= L/(float)allLabels.size();
			hsv hsvColor={s*360,0.5,1.0};
			rgb rgbColor=hsv2rgb(hsvColor);


			svg::Rectangle rect(svg::Point(box.x()-_bbox.x(),box.y()-_bbox.y()),box.width(),box.height(),svg::Fill(svg::Color(rgbColor.r*255,rgbColor.g*255,rgbColor.b*255)),svg::Stroke(1,svg::Color::Black));
			doc<<rect;
		}
	}

	if(_dim==0){
		for(int i=0;i<_Pos.size();++i){
			float ratio=_Sym[i]/(float)maxS;
			c<<svg::Point(_Pos[i],canvas.height()-ratio*canvas.height());
		}
	}else{
		for(int i=0;i<_Pos.size();++i){
			float ratio=_Sym[i]/(float)maxS;
			c<<svg::Point(ratio*canvas.width(),canvas.height()-_Pos[i]);
		}
	}
	doc<<svg::Rectangle(svg::Point(0,0),canvas.width(),canvas.height(),svg::Fill(svg::Color::Transparent),svg::Stroke(1,svg::Color::Black));
	doc<<c;
	doc.save();

}


void GenerativeHistory::saveSvg(std::string  fn){

	if(_hierarchyBoxes.empty()||_rootBoxId==-1)return;



	Box rbox=_hierarchyBoxes[_rootBoxId]->box;
	int spacing=rbox.width()/2;
	int startX=0;
	int startY=0;

	int Lnum=levelNum();

	svg::Layout layout(svg::Dimensions((rbox.width()+spacing)*Lnum+startX,rbox.height()+startY),svg::Layout::Origin::TopLeft,1,svg::Point(0,0));
	svg::Document doc(fn,layout);
	for(int j=0;j<Lnum;++j){
		int x=startX+j*(spacing+rbox.width());
		int y=startY;
		doc<<svg::Rectangle(svg::Point(x,y),rbox.width(),rbox.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
	}

	for(int i=0;i<_hierarchyBoxes.size();++i){
		HierarchyNode* hbox=_hierarchyBoxes[i];
		int L=level(i);
		for(int j=L+1;j<Lnum;++j){
			int x=startX+j*(spacing+rbox.width());//+hbox.box.x()-rbox.x();
			int y=startY;//+hbox.box.y()-rbox.y();
			//doc<<svg::Rectangle(svg::Point(x,y),hbox.box.width(),hbox.box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
			if(hbox->rightBoxId!=-1){
				OperationType otype=operationType(i);
				Box rightBox=boxOf(hbox->rightBoxId);

				if(otype==OT_Delayer){
					doc<<svg::Rectangle(svg::Point(rightBox.x()-rbox.x()+x,y+rightBox.y()-rbox.y()),rightBox.width(),rightBox.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
				}else if(otype==OT_SplitY){
					doc<<svg::Line(svg::Point(x+rightBox.x()-rbox.x(),rightBox.bottom()-rbox.y()+y),svg::Point(x+rightBox.right()-rbox.x(),rightBox.bottom()-rbox.y()+y),svg::Stroke(1,svg::Color::Black));
				}else{
					doc<<svg::Line(svg::Point(rightBox.left()-rbox.x()+x,rightBox.y()-rbox.y()+y),svg::Point(rightBox.left()-rbox.x()+x,y+rightBox.top()-rbox.y()),svg::Stroke(1,svg::Color::Black));
				}
			}

		}
	}

	doc.save();
}

void GenerativeHistory::saveSvg_AbstractionLevel(std::string fn){
	if(_hierarchyBoxes.empty()||_rootBoxId==-1)return;
	std::vector<std::vector<int>> boxes;
	boxesOfAbstractionLevels(boxes);

	Box rbox=_hierarchyBoxes[_rootBoxId]->box;
	int spacing=rbox.width()/2;
	int startX=0;
	int startY=0;

	int Lnum=abstractionLevelNum();

	svg::Layout layout(svg::Dimensions((rbox.width()+spacing)*Lnum+startX,rbox.height()+startY),svg::Layout::Origin::TopLeft,1,svg::Point(0,0));
	svg::Document doc(fn,layout);


	for(int i=0;i<boxes.size();++i){
		std::vector<int>& bset=boxes[i];
		for(int j=0;j<bset.size();++j){
			Box &box=boxOf(bset[j]);
			int x=startX+i*(spacing+rbox.width())+box.x()-rbox.x();
			int y=startY+box.y()-rbox.y();
			doc<<svg::Rectangle(svg::Point(x,y),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
		}
	}

	doc.save();
}

void GenerativeHistory::historyNode_saveSvg(PairBoxes& nodeA,std::string fn){
	Box &boxA=nodeA.first;
	Box &boxB=nodeA.second;
	svg::Layout layout(svg::Dimensions(boxA.width()+boxB.width(),boxA.height()+boxB.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(boxA.x(),boxA.y()));

	svg::Document doc(fn,layout);
	doc<<svg::Rectangle(svg::Point(boxA.x(),boxA.y()),boxA.width(),boxA.height(),svg::Fill(svg::Color::Transparent),svg::Stroke(1,svg::Color::Black));
	doc<<svg::Rectangle(svg::Point(boxB.x(),boxB.y()),boxB.width(),boxB.height(),svg::Fill(svg::Color::Transparent),svg::Stroke(1,svg::Color::Black));
	doc.save();

}

static int findIndexFrom(std::vector<std::vector<int>> &levelNodes,int id,int level){
	for(int i=0;i<levelNodes[level].size();++i)
		if(levelNodes[level][i]==id)return i;
	return -1;
}

std::vector<std::vector<int>>  GenerativeHistory::computeXPosForLevel(int startX,std::vector<std::vector<int>> &levelNodes){
	Box rbox=boxOf(_rootBoxId);
	int hspacing=rbox.width()/2;
	int vspacing=rbox.height()/2;

	std::vector<std::vector<int>> levelXPos;
	levelXPos.resize(levelNodes.size());
	for(int i=0;i<levelNodes.size();++i){
		levelXPos[i].assign(levelNodes[i].size(),0);
		for(int j=0;j<levelXPos[i].size();++j){
			levelXPos[i][j]=(rbox.width()+hspacing)*j+startX;
		}
	}

	//bottom-up adjustment, moving children
	for(int i=levelNodes.size()-1;i>=0;--i){
		for(int j=0;j<levelXPos[i].size();++j){
			HierarchyNode* hbox=_hierarchyBoxes[levelNodes[i][j]];
			if(hbox->parentBoxId!=-1){
				int pindex=findIndexFrom(levelNodes,hbox->parentBoxId,i-1);
				int dx=levelXPos[i-1][pindex]-levelXPos[i][j];
				if(dx>0){
					for(int k=j;k<levelXPos[i].size();++k)
						levelXPos[i][k]+=dx;
				}
			}
		}
	}

	//bottom-up adjustment, moving parent
	for(int i=levelNodes.size()-2;i>=0;--i){
		for(int j=0;j<levelXPos[i].size();++j){
			HierarchyNode* hbox=_hierarchyBoxes[levelNodes[i][j]];
			if(hbox->leftBoxId!=-1&&hbox->rightBoxId!=-1){
				int leftIndex=findIndexFrom(levelNodes,hbox->leftBoxId,i+1);
				int rightIndex=findIndexFrom(levelNodes,hbox->rightBoxId,i+1);
				int leftX=levelXPos[i+1][leftIndex];
				int rightX=levelXPos[i+1][rightIndex];
				int newX=(leftX+rightX)/2;
				int dx=newX-levelXPos[i][j];
				if(dx>0){
					for(int k=j;k<levelXPos[i].size();++k){
						levelXPos[i][k]+=dx;
					}
				}
			}
		}
	}

	return levelXPos;
}
static void saveHistoryAsSvgforNIS(GenerativeHistory& hist, svg::Document &doc,int startX,int startY,std::vector<float>nis,std::vector<int>nllist,bool showContent=false)
{
	if(hist.rootBox()==-1)return;

	std::vector<svg::Color>colour;
	svg::Color c0(153,150,204);//153,50,204
	svg::Color c1(128,92,92);//128,42,42
	svg::Color c2(114,139,114);//34,139,34
	svg::Color c3(176,48,96);//176,48,96
	svg::Color c4(238,192,166);//238,92,66
	svg::Color c5(160,179,113);//60,179,113
	svg::Color c6(130,144,255);//30,44,255
	svg::Color c7(165,142,142);//165,42,42
	svg::Color c8(0,255,127);//
	svg::Color c9(160,32,240);//
	svg::Color c10(127,255,212);//
	svg::Color c11(0,0,125);//
	svg::Color c12(255,34,34);//
	svg::Color c13(0,0,255);//
	svg::Color c14(108,255,0);//
	svg::Color c15(77,255,0);//

	svg::Color c16(130,144,255);//30,44,255
	svg::Color c17(165,142,142);//165,42,42
	svg::Color c18(0,255,127);//
	svg::Color c19(160,32,240);//
	svg::Color c20(127,255,212);//
	svg::Color c21(128,92,92);//128,42,42
	svg::Color c22(114,139,114);//34,139,34
	svg::Color c23(176,48,96);//176,48,96
	svg::Color c24(238,192,166);//238,92,66
	svg::Color c25(160,179,113);//60,179,113
	svg::Color c26(130,144,255);//30,44,255
	svg::Color c27(165,142,142);//165,42,42
	svg::Color c28(0,255,127);//
	svg::Color c29(160,32,240);//
	svg::Color c30(127,255,212);//

	colour.push_back(c0);
	colour.push_back(c1);
	colour.push_back(c2);
	colour.push_back(c3);
	colour.push_back(c4);
	colour.push_back(c5);
	colour.push_back(c6);
	colour.push_back(c7);
	colour.push_back(c8);
	colour.push_back(c9);
	colour.push_back(c10);
	colour.push_back(c11);
	colour.push_back(c12);
	colour.push_back(c13);
	colour.push_back(c14);
	colour.push_back(c15);

	colour.push_back(c16);
	colour.push_back(c17);
	colour.push_back(c18);
	colour.push_back(c19);
	colour.push_back(c20);
	colour.push_back(c21);
	colour.push_back(c22);
	colour.push_back(c23);
	colour.push_back(c24);
	colour.push_back(c25);
	colour.push_back(c26);
	colour.push_back(c27);
	colour.push_back(c28);
	colour.push_back(c29);
	colour.push_back(c30);



	std::vector<int>index;
	index.clear();

	BoxSet &boxSet=hist.nodeData(0);
	for (int k=0;k<boxSet.size();++k)
	{
		int have=0;
		Box& currBox=boxSet[k];
		for (int ll=0;ll<index.size();ll++)
		{
			if (index[ll]==currBox.label())
			{
				have=1;
				break;
			}
		}
		if (have==0)
		{
			index.push_back(currBox.label());
		}
	}




	Box& rbox=hist.boxOf(hist.rootBox());
	int hspacing=rbox.width()/2;
	int vspacing=rbox.height()/2;

	std::vector<std::vector<int>> levelNodes;
	hist.nodeAtLevel(levelNodes);
	int Lnum=levelNodes.size();

	std::vector<std::vector<int>>  levelXPos=hist.computeXPosForLevel(startX,levelNodes);

	for(int i=Lnum-1;i>0;i--){//connect
		std::vector<int> & nodes=levelNodes[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			int parentX;
			int parentY;

			int pindex=findIndexFrom(levelNodes,hist.parentBoxId(nodeId),i-1);
			parentX=levelXPos[i-1][pindex];
			parentY=(rbox.height()+vspacing)*(i-1)+startY;

			int x=levelXPos[i][j];
			int y=(rbox.height()+vspacing)*i+startY;

			doc<<svg::Line(svg::Point(x+rbox.width()/2,y+rbox.height()/2),svg::Point(parentX+rbox.width()/2,parentY+rbox.height()/2),svg::Stroke(30,svg::Color::Black));
		}
	}




	for(int i=Lnum-1;i>=0;i--){
		std::vector<int> & nodes=levelNodes[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			Box& hbox=hist.boxOf(nodeId);
			int x=levelXPos[i][j];
			int y=(rbox.height()+vspacing)*i+startY;

			//draw root box with gray
			doc<<svg::Rectangle(svg::Point(x,y),rbox.width(),rbox.height(),svg::Fill(svg::Color(200,200,200)),svg::Stroke(1,svg::Color::Black));//128

			//draw my bounding box
			doc<<svg::Rectangle(svg::Point(hbox.x()-rbox.x()+x,y+hbox.y()-rbox.y()),hbox.width(),hbox.height(),svg::Fill(svg::Color::White),svg::Stroke(1,svg::Color::Black));


			int nindex=-1;
			for (int ll=0;ll<nllist.size();ll++)
			{
				if (nllist[ll]==nodes[j])
				{
					nindex=ll;
				}
			}
			std::stringstream st;
			int cc=nodeId;
			st<<cc;
			svg::Text labelText(svg::Point(hbox.center(0)-rbox.x()+x,y+hbox.y()-rbox.y()),st.str(),svg::Fill(svg::Color::Red),svg::Font(),svg::Stroke(1,svg::Color::Red));
			doc<<labelText;


			//draw my content
			if(showContent){
				BoxSet &boxSet=hist.nodeData(nodeId);
				for(int k=0;k<boxSet.size();++k){
					Box& currBox=boxSet[k];
					int label=currBox.label();
					int labelindex=-1;
					for (int ll=0;ll<index.size();ll++)
					{
						if (index[ll]==label)
						{
							labelindex=ll;
						}
					}
					doc<<svg::Rectangle(svg::Point(currBox.x()-rbox.x()+x,y+currBox.y()-rbox.y()),currBox.width(),currBox.height(),svg::Fill(colour[labelindex]),svg::Stroke(10,svg::Color::Black));
				}
			}

			if(hist.rightBoxId(nodeId)!=-1){
				OperationType otype=hist.operationType(nodeId);
				Box &rightBox=hist.boxOf(hist.rightBoxId(nodeId));
				svg::Stroke opStroke(20,svg::Color::Red,"3,1");
				if(otype==OT_Delayer){
					doc<<svg::Rectangle(svg::Point(rightBox.x()-rbox.x()+x,y+rightBox.y()-rbox.y()),rightBox.width(),rightBox.height(),svg::Fill(),opStroke);
				}else if(otype==OT_SplitY){
					doc<<svg::Line(svg::Point(x+rightBox.x()-rbox.x(),rightBox.bottom()-rbox.y()+y),svg::Point(x+rightBox.right()-rbox.x(),rightBox.bottom()-rbox.y()+y),opStroke);//
				}else{
					doc<<svg::Line(svg::Point(rightBox.left()-rbox.x()+x,rightBox.y()-rbox.y()+y),svg::Point(rightBox.left()-rbox.x()+x,y+rightBox.top()-rbox.y()),opStroke);//
				}
			}
		}
	}

};
static void saveHistoryAsSvgforGCut(GenerativeHistory& hist, svg::Document &doc,int startX,int startY,std::vector<int>edge,bool showContent=false)
{
	if(hist.rootBox()==-1)return;

	std::vector<svg::Color>colour;
	svg::Color c0(153,150,204);//153,50,204
	svg::Color c1(128,92,92);//128,42,42
	svg::Color c2(114,139,114);//34,139,34
	svg::Color c3(176,48,96);//176,48,96
	svg::Color c4(238,192,166);//238,92,66
	svg::Color c5(160,179,113);//60,179,113
	svg::Color c6(130,144,255);//30,44,255
	svg::Color c7(165,142,142);//165,42,42
	svg::Color c8(0,255,127);//
	svg::Color c9(160,32,240);//
	svg::Color c10(127,255,212);//
	svg::Color c11(0,0,125);//
	svg::Color c12(255,34,34);//
	svg::Color c13(0,0,255);//
	svg::Color c14(108,255,0);//
	svg::Color c15(77,255,0);//

	svg::Color c16(130,144,255);//30,44,255
	svg::Color c17(165,142,142);//165,42,42
	svg::Color c18(0,255,127);//
	svg::Color c19(160,32,240);//
	svg::Color c20(127,255,212);//
	svg::Color c21(128,92,92);//128,42,42
	svg::Color c22(114,139,114);//34,139,34
	svg::Color c23(176,48,96);//176,48,96
	svg::Color c24(238,192,166);//238,92,66
	svg::Color c25(160,179,113);//60,179,113
	svg::Color c26(130,144,255);//30,44,255
	svg::Color c27(165,142,142);//165,42,42
	svg::Color c28(0,255,127);//
	svg::Color c29(160,32,240);//
	svg::Color c30(127,255,212);//

	colour.push_back(c0);
	colour.push_back(c1);
	colour.push_back(c2);
	colour.push_back(c3);
	colour.push_back(c4);
	colour.push_back(c5);
	colour.push_back(c6);
	colour.push_back(c7);
	colour.push_back(c8);
	colour.push_back(c9);
	colour.push_back(c10);
	colour.push_back(c11);
	colour.push_back(c12);
	colour.push_back(c13);
	colour.push_back(c14);
	colour.push_back(c15);

	colour.push_back(c16);
	colour.push_back(c17);
	colour.push_back(c18);
	colour.push_back(c19);
	colour.push_back(c20);
	colour.push_back(c21);
	colour.push_back(c22);
	colour.push_back(c23);
	colour.push_back(c24);
	colour.push_back(c25);
	colour.push_back(c26);
	colour.push_back(c27);
	colour.push_back(c28);
	colour.push_back(c29);
	colour.push_back(c30);



	std::vector<int>index;
	index.clear();

	BoxSet &boxSet=hist.nodeData(0);
	for (int k=0;k<boxSet.size();++k)
	{
		int have=0;
		Box& currBox=boxSet[k];
		for (int ll=0;ll<index.size();ll++)
		{
			if (index[ll]==currBox.label())
			{
				have=1;
				break;
			}
		}
		if (have==0)
		{
			index.push_back(currBox.label());
		}
	}




	Box& rbox=hist.boxOf(hist.rootBox());
	int hspacing=rbox.width()/2;
	int vspacing=rbox.height()/2;

	std::vector<std::vector<int>> levelNodes;
	hist.nodeAtLevel(levelNodes);
	int Lnum=levelNodes.size();

	std::vector<std::vector<int>>  levelXPos=hist.computeXPosForLevel(startX,levelNodes);

	for(int i=Lnum-1;i>0;i--){//connect
		std::vector<int> & nodes=levelNodes[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			int parentX;
			int parentY;

			int pindex=findIndexFrom(levelNodes,hist.parentBoxId(nodeId),i-1);
			parentX=levelXPos[i-1][pindex];
			parentY=(rbox.height()+vspacing)*(i-1)+startY;

			int x=levelXPos[i][j];
			int y=(rbox.height()+vspacing)*i+startY;

			doc<<svg::Line(svg::Point(x+rbox.width()/2,y+rbox.height()/2),svg::Point(parentX+rbox.width()/2,parentY+rbox.height()/2),svg::Stroke(30,svg::Color::Black));
		}
	}



	for(int i=Lnum-1;i>=0;i--){
		std::vector<int> & nodes=levelNodes[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			Box& hbox=hist.boxOf(nodeId);
			int x=levelXPos[i][j];
			int y=(rbox.height()+vspacing)*i+startY;

			//draw root box with gray
			doc<<svg::Rectangle(svg::Point(x,y),rbox.width(),rbox.height(),svg::Fill(svg::Color(200,200,200)),svg::Stroke(1,svg::Color::Black));//128

			//draw my bounding box
			doc<<svg::Rectangle(svg::Point(hbox.x()-rbox.x()+x,y+hbox.y()-rbox.y()),hbox.width(),hbox.height(),svg::Fill(svg::Color::White),svg::Stroke(1,svg::Color::Black));

			//draw my content
			if(showContent){
				BoxSet &boxSet=hist.nodeData(nodeId);
				for(int k=0;k<boxSet.size();++k){
					Box& currBox=boxSet[k];
					int label=currBox.label();
					int labelindex=-1;
					for (int ll=0;ll<index.size();ll++)
					{
						if (index[ll]==label)
						{
							labelindex=ll;
						}
					}



					doc<<svg::Rectangle(svg::Point(currBox.x()-rbox.x()+x,y+currBox.y()-rbox.y()),currBox.width(),currBox.height(),svg::Fill(colour[labelindex]),svg::Stroke(10,svg::Color::Black));
					std::stringstream st;
					int cc=k;
					st<<cc;
					svg::Text labelText(svg::Point(currBox.x()-rbox.x()+x,y+currBox.y()-rbox.y()+currBox.height()),st.str(),svg::Fill(svg::Color::Red),svg::Font(),svg::Stroke(1,svg::Color::Red));
					doc<<labelText;
				}
			}

			if(hist.rightBoxId(nodeId)!=-1){
				OperationType otype=hist.operationType(nodeId);
				Box &rightBox=hist.boxOf(hist.rightBoxId(nodeId));
				svg::Stroke opStroke(20,svg::Color::Red,"3,1");
				if(otype==OT_Delayer){
					doc<<svg::Rectangle(svg::Point(rightBox.x()-rbox.x()+x,y+rightBox.y()-rbox.y()),rightBox.width(),rightBox.height(),svg::Fill(),opStroke);
				}else if(otype==OT_SplitY){
					doc<<svg::Line(svg::Point(x+rightBox.x()-rbox.x(),rightBox.bottom()-rbox.y()+y),svg::Point(x+rightBox.right()-rbox.x(),rightBox.bottom()-rbox.y()+y),opStroke);//
				}else{
					doc<<svg::Line(svg::Point(rightBox.left()-rbox.x()+x,rightBox.y()-rbox.y()+y),svg::Point(rightBox.left()-rbox.x()+x,y+rightBox.top()-rbox.y()),opStroke);//
				}
			}
		}
	}
	int xx=levelXPos[0][0];
	int yy=(rbox.height()+vspacing)*0+startY;
	for (int i=0;i<0.5*edge.size();i++)
	{
		int i0=edge[2*i];
		int i1=edge[2*i+1];
		Box& b0=boxSet[i0];
		Box& b1=boxSet[i1];
		doc<<svg::Line(svg::Point(b0.x()-rbox.x()+xx+b0.width()/2,b0.y()-rbox.y()+yy+b0.height()/2),svg::Point(b1.x()-rbox.x()+xx+b1.width()/2,b1.y()-rbox.y()+yy+b1.height()/2),svg::Stroke(30,svg::Color::Black));

	}

}
static void saveHistoryAsSvg_root(GenerativeHistory& hist, svg::Document &doc,int startX,int startY,bool showContent=false)
{
	if(hist.rootBox()==-1)return;

	std::vector<svg::Color>colour;
	svg::Color c0(181,230,29);//153,50,204
	svg::Color c1(255,255,128);//128,42,42
	svg::Color c2(128,255,255);//34,139,34
	svg::Color c3(255,128,64);//176,48,96
	svg::Color c4(214,251,4);//214,251,4238,92,66
	svg::Color c5(220,141,192);//60,179,113
	svg::Color c6(92,150,228);//30,44,255
	svg::Color c7(236,100,89);//165,42,42
	svg::Color c8(238,185,85);//
	svg::Color c9(255,255,128);//
	svg::Color c10(124,235,112);//
	svg::Color c11(98,249,215);//
	svg::Color c12(143,228,146);//
	svg::Color c13(201,107,214);//
	svg::Color c14(140,233,126);//
	svg::Color c15(216,153,48);//

	svg::Color c16(89,151,252);//30,44,255
	svg::Color c17(214,151,251);//165,42,42
	svg::Color c18(41,214,149);//
	svg::Color c19(114,203,128);//
	svg::Color c20(150,148,233);//
	svg::Color c21(84,205,162);//128,42,42
	svg::Color c22(228,106,65);//34,139,34
	svg::Color c23(164,217,211);//176,48,96
	svg::Color c24(255,131,134);//238,92,66
	svg::Color c25(250,183,44);//60,179,113
	svg::Color c26(234,223,89);//30,44,255
	svg::Color c27(186,189,245);//165,42,42
	svg::Color c28(83,218,225);//
	svg::Color c29(180,171,216);//
	svg::Color c30(127,255,212);//

	colour.push_back(c0);
	colour.push_back(c1);
	colour.push_back(c2);
	colour.push_back(c3);
	colour.push_back(c4);
	colour.push_back(c5);
	colour.push_back(c6);
	colour.push_back(c7);
	colour.push_back(c8);
	colour.push_back(c9);
	colour.push_back(c10);
	colour.push_back(c11);
	colour.push_back(c12);
	colour.push_back(c13);
	colour.push_back(c14);
	colour.push_back(c15);

	colour.push_back(c16);
	colour.push_back(c17);
	colour.push_back(c18);
	colour.push_back(c19);
	colour.push_back(c20);
	colour.push_back(c21);
	colour.push_back(c22);
	colour.push_back(c23);
	colour.push_back(c24);
	colour.push_back(c25);
	colour.push_back(c26);
	colour.push_back(c27);
	colour.push_back(c28);
	colour.push_back(c29);
	colour.push_back(c30);

	std::vector<int>index;
	index.clear();

	BoxSet &boxSet=hist.nodeData(0);
	for (int k=0;k<boxSet.size();++k)
	{
		int have=0;
		Box& currBox=boxSet[k];
		for (int ll=0;ll<index.size();ll++)
		{
			if (index[ll]==currBox.label())
			{
				have=1;
				break;
			}
		}
		if (have==0)
		{
			index.push_back(currBox.label());
		}
	}


	Box& rbox=hist.boxOf(hist.rootBox());
	int hspacing=rbox.width()/2;
	int vspacing=rbox.height()/2;

	std::vector<std::vector<int>> levelNodes;
	hist.nodeAtLevel(levelNodes);
	int Lnum=levelNodes.size();

	std::vector<std::vector<int>>  levelXPos=hist.computeXPosForLevel(startX,levelNodes);

	//for(int i=Lnum-1;i>0;i--){//connect
	//	std::vector<int> & nodes=levelNodes[i];
	//	for(int j=0;j<nodes.size();++j){
	//		int nodeId=nodes[j];
	//		int parentX;
	//		int parentY;

	//		int pindex=findIndexFrom(levelNodes,hist.parentBoxId(nodeId),i-1);
	//		parentX=levelXPos[i-1][pindex];
	//		parentY=(rbox.height()+vspacing)*(i-1)+startY;

	//		int x=levelXPos[i][j];
	//		int y=(rbox.height()+vspacing)*i+startY;

	//		doc<<svg::Line(svg::Point(x+rbox.width()/2,y+rbox.height()/2),svg::Point(parentX+rbox.width()/2,parentY+rbox.height()/2),svg::Stroke(30,svg::Color::Black));
	//	}
	//}

	/*for(int i=Lnum-1;i>=Lnum-2;i--){
	std::vector<int> & nodes=levelNodes[i];
	for(int j=0;j<nodes.size();++j){*/

	int i=0;
	int j=0;
	int nodeId=0;
	Box& hbox=hist.boxOf(nodeId);
	int x=levelXPos[i][j];
	int y=(rbox.height()+vspacing)*i+startY;

	//draw root box with gray
	doc<<svg::Rectangle(svg::Point(x,y),rbox.width(),rbox.height(),svg::Fill(svg::Color(200,200,200)),svg::Stroke(1,svg::Color::Black));//128

	//draw my bounding box
	doc<<svg::Rectangle(svg::Point(hbox.x()-rbox.x()+x,y+hbox.y()-rbox.y()),hbox.width(),hbox.height(),svg::Fill(svg::Color::White),svg::Stroke(1,svg::Color::Black));
	/*std::stringstream st;
	st<<hist.layer(nodeId)<<" "<<hist.abstractLevel(nodeId);
	std::string label=st.str();
	doc<<svg::Text(svg::Point(hbox.center(0)-rbox.x()+x,y+hbox.center(1)-rbox.y()),label,svg::Fill(svg::Color::White),svg::Font(),svg::Stroke(1,svg::Color::Red));*/

	/*std::stringstream st;
	int cc=nodeId;
	st<<cc;
	svg::Text labelText(svg::Point(hbox.center(0)-rbox.x()+x,y+hbox.y()-rbox.y()),st.str(),svg::Fill(svg::Color::Red),svg::Font(),svg::Stroke(1,svg::Color::Red));
	doc<<labelText;*/

	//draw my content
	if(showContent){
		BoxSet &boxSet=hist.nodeData(nodeId);
		/*std::vector<int>index;
		index.clear();

		for (int k=0;k<boxSet.size();++k)
		{
		int have=0;
		Box& currBox=boxSet[k];
		for (int ll=0;ll<index.size();ll++)
		{
		if (index[ll]==currBox.label())
		{
		have=1;
		break;
		}
		}
		if (have==0)
		{
		index.push_back(currBox.label());
		}
		}*/
		for(int k=0;k<boxSet.size();++k){
			Box& currBox=boxSet[k];
			int label=currBox.label();
			int labelindex=-1;
			for (int ll=0;ll<index.size();ll++)
			{
				if (index[ll]==label)
				{
					labelindex=ll;
				}
			}



			doc<<svg::Rectangle(svg::Point(currBox.x()-rbox.x()+x,y+currBox.y()-rbox.y()),currBox.width(),currBox.height(),svg::Fill(colour[labelindex]),svg::Stroke(10,svg::Color::Black));
		}
	}

	if(hist.rightBoxId(nodeId)!=-1){
		OperationType otype=hist.operationType(nodeId);
		Box &rightBox=hist.boxOf(hist.rightBoxId(nodeId));
		svg::Stroke opStrokes(20,svg::Color::Red);
		svg::Color cd(153,217,234);//
		svg::Stroke opStroked(20,cd);
		if(otype==OT_Delayer){
			doc<<svg::Rectangle(svg::Point(rightBox.x()-rbox.x()+x,y+rightBox.y()-rbox.y()),rightBox.width(),rightBox.height(),svg::Fill(),opStroked);
		}else if(otype==OT_SplitY){
			doc<<svg::Line(svg::Point(x+rightBox.x()-rbox.x(),rightBox.bottom()-rbox.y()+y),svg::Point(x+rightBox.right()-rbox.x(),rightBox.bottom()-rbox.y()+y),opStrokes);//
		}else{
			doc<<svg::Line(svg::Point(rightBox.left()-rbox.x()+x,rightBox.y()-rbox.y()+y),svg::Point(rightBox.left()-rbox.x()+x,y+rightBox.top()-rbox.y()),opStrokes);//
		}
	}
	//}
	//}
}
static void saveHistoryAsSvg(GenerativeHistory& hist, svg::Document &doc,int startX,int startY,bool showContent=false){
	if(hist.rootBox()==-1)return;

	std::vector<svg::Color>colour;
	svg::Color c0(181,230,29);//153,50,204
	svg::Color c1(255,255,128);//128,42,42
	svg::Color c2(128,255,255);//34,139,34
	svg::Color c3(255,128,64);//176,48,96
	svg::Color c4(214,251,4);//238,92,66
	svg::Color c5(220,141,192);//60,179,113
	svg::Color c6(92,150,228);//30,44,255
	svg::Color c7(236,100,89);//165,42,42
	svg::Color c8(238,185,85);//
	svg::Color c9(255,255,128);//
	svg::Color c10(124,235,112);//
	svg::Color c11(98,249,215);//
	svg::Color c12(143,228,146);//
	svg::Color c13(201,107,214);//
	svg::Color c14(140,233,126);//
	svg::Color c15(216,153,48);//

	svg::Color c16(89,151,252);//30,44,255
	svg::Color c17(214,151,251);//165,42,42
	svg::Color c18(41,214,149);//
	svg::Color c19(114,203,128);//
	svg::Color c20(150,148,233);//
	svg::Color c21(84,205,162);//128,42,42
	svg::Color c22(228,106,65);//34,139,34
	svg::Color c23(164,217,211);//176,48,96
	svg::Color c24(255,131,134);//238,92,66
	svg::Color c25(250,183,44);//60,179,113
	svg::Color c26(234,223,89);//30,44,255
	svg::Color c27(186,189,245);//165,42,42
	svg::Color c28(83,218,225);//
	svg::Color c29(180,171,216);//
	svg::Color c30(127,255,212);//

	colour.push_back(c0);
	colour.push_back(c1);
	colour.push_back(c2);
	colour.push_back(c3);
	colour.push_back(c4);
	colour.push_back(c5);
	colour.push_back(c6);
	colour.push_back(c7);
	colour.push_back(c8);
	colour.push_back(c9);
	colour.push_back(c10);
	colour.push_back(c11);
	colour.push_back(c12);
	colour.push_back(c13);
	colour.push_back(c14);
	colour.push_back(c15);

	colour.push_back(c16);
	colour.push_back(c17);
	colour.push_back(c18);
	colour.push_back(c19);
	colour.push_back(c20);
	colour.push_back(c21);
	colour.push_back(c22);
	colour.push_back(c23);
	colour.push_back(c24);
	colour.push_back(c25);
	colour.push_back(c26);
	colour.push_back(c27);
	colour.push_back(c28);
	colour.push_back(c29);
	colour.push_back(c30);

	std::vector<int>index;
	index.clear();

	BoxSet &boxSet=hist.nodeData(0);
	for (int k=0;k<boxSet.size();++k)
	{
		int have=0;
		Box& currBox=boxSet[k];
		for (int ll=0;ll<index.size();ll++)
		{
			if (index[ll]==currBox.label())
			{
				have=1;
				break;
			}
		}
		if (have==0)
		{
			index.push_back(currBox.label());
		}
	}


	Box& rbox=hist.boxOf(hist.rootBox());
	int hspacing=rbox.width()/2;
	int vspacing=rbox.height()/2;

	std::vector<std::vector<int>> levelNodes;
	hist.nodeAtLevel(levelNodes);
	int Lnum=levelNodes.size();

	std::vector<std::vector<int>>  levelXPos=hist.computeXPosForLevel(startX,levelNodes);

	for(int i=Lnum-1;i>0;i--){//connect
		std::vector<int> & nodes=levelNodes[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			int parentX;
			int parentY;

			int pindex=findIndexFrom(levelNodes,hist.parentBoxId(nodeId),i-1);
			parentX=levelXPos[i-1][pindex];
			parentY=(rbox.height()+vspacing)*(i-1)+startY;

			int x=levelXPos[i][j];
			int y=(rbox.height()+vspacing)*i+startY;

			doc<<svg::Line(svg::Point(x+rbox.width()/2,y+rbox.height()/2),svg::Point(parentX+rbox.width()/2,parentY+rbox.height()/2),svg::Stroke(30,svg::Color::Black));
		}
	}

	for(int i=Lnum-1;i>=0;i--){
		std::vector<int> & nodes=levelNodes[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			Box& hbox=hist.boxOf(nodeId);
			int x=levelXPos[i][j];
			int y=(rbox.height()+vspacing)*i+startY;

			//draw root box with gray
			doc<<svg::Rectangle(svg::Point(x,y),rbox.width(),rbox.height(),svg::Fill(svg::Color(200,200,200)),svg::Stroke(1,svg::Color::Black));//128

			//draw my bounding box
			doc<<svg::Rectangle(svg::Point(hbox.x()-rbox.x()+x,y+hbox.y()-rbox.y()),hbox.width(),hbox.height(),svg::Fill(svg::Color::White),svg::Stroke(1,svg::Color::Black));


			//draw my content
			if(showContent){
				BoxSet &boxSet=hist.nodeData(nodeId);
				for(int k=0;k<boxSet.size();++k){
					Box& currBox=boxSet[k];
					int label=currBox.label();
					int labelindex=-1;
					for (int ll=0;ll<index.size();ll++)
					{
						if (index[ll]==label)
						{
							labelindex=ll;
						}
					}



					doc<<svg::Rectangle(svg::Point(currBox.x()-rbox.x()+x,y+currBox.y()-rbox.y()),currBox.width(),currBox.height(),svg::Fill(colour[labelindex]),svg::Stroke(10,svg::Color::Black));
				}
			}

			if(hist.rightBoxId(nodeId)!=-1){
				OperationType otype=hist.operationType(nodeId);
				Box &rightBox=hist.boxOf(hist.rightBoxId(nodeId));
				svg::Stroke opStrokes(20,svg::Color::Red);
				svg::Color cd(153,217,234);//
				svg::Stroke opStroked(20,cd);
				if(otype==OT_Delayer){
					doc<<svg::Rectangle(svg::Point(rightBox.x()-rbox.x()+x,y+rightBox.y()-rbox.y()),rightBox.width(),rightBox.height(),svg::Fill(),opStroked);
				}else if(otype==OT_SplitY){
					doc<<svg::Line(svg::Point(x+rightBox.x()-rbox.x(),rightBox.bottom()-rbox.y()+y),svg::Point(x+rightBox.right()-rbox.x(),rightBox.bottom()-rbox.y()+y),opStrokes);//
				}else{
					doc<<svg::Line(svg::Point(rightBox.left()-rbox.x()+x,rightBox.y()-rbox.y()+y),svg::Point(rightBox.left()-rbox.x()+x,y+rightBox.top()-rbox.y()),opStrokes);//
				}
			}
		}
	}
}



Box GenerativeHistory::evaluateSizeForTreeVisualization(){
	Box rbox=boxOf(rootBox());
	int hspacing=rbox.width()/2;
	int vspacing=rbox.height()/2;
	int Lnum=levelNum();
	int leafNum=leaveNodeNum();

	Box box(0,0,leafNum*(rbox.width()+hspacing),Lnum*(rbox.height()+vspacing));
	return box;
}

void GenerativeHistory::saveSvg_TreewithNIS(std::string fn,std::vector<float>nis,std::vector<int>nllist,bool showContent)
{
	if(_hierarchyBoxes.empty()||_rootBoxId==-1)return;



	Box box=evaluateSizeForTreeVisualization();
	svg::Layout layout(svg::Dimensions(box.width(),box.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	saveHistoryAsSvgforNIS(*this,doc,0,0,nis,nllist,showContent);
	doc.save();
}
void GenerativeHistory::saveSvg_Tree_root(std::string fn,bool showContent)
{
	if(_hierarchyBoxes.empty()||_rootBoxId==-1)return;



	Box box=evaluateSizeForTreeVisualization();
	svg::Layout layout(svg::Dimensions(box.width(),box.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	saveHistoryAsSvg_root(*this,doc,0,0,showContent);
	doc.save();
}
void GenerativeHistory::saveSvg_Tree(std::string fn,bool showContent){
	if(_hierarchyBoxes.empty()||_rootBoxId==-1)return;



	Box box=evaluateSizeForTreeVisualization();
	svg::Layout layout(svg::Dimensions(box.width(),box.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	saveHistoryAsSvg(*this,doc,0,0,showContent);
	doc.save();

}
void GenerativeHistory:: saveSvg_TreeforGCut(std::string fn,std::vector<int>edge,bool showContent)
{
	if(_hierarchyBoxes.empty()||_rootBoxId==-1)return;



	Box box=evaluateSizeForTreeVisualization();
	svg::Layout layout(svg::Dimensions(box.width(),box.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	saveHistoryAsSvgforGCut(*this,doc,0,0,edge,showContent);
	doc.save();
}


void findTwoIndexFrom(std::vector<std::vector<int>>& levelNodes,int id,int &i,int &j){
	for(i=0;i<levelNodes.size();++i)
		for(j=0;j<levelNodes[i].size();++j)
			if(levelNodes[i][j]==id)
				return;
	i=-1;
	j=-1;
	return;

}

void GenerativeHistory::saveSvg_TreeMatch(std::string fn,GenerativeHistory& histA,GenerativeHistory& histB,std::vector<int> &correspondA2B,std::vector<int> &correspondB2A,int flag){
	if(histA.rootBox()==-1||histB.rootBox()==-1)return;
	Box boxSizeA=histA.evaluateSizeForTreeVisualization();
	Box boxSizeB=histB.evaluateSizeForTreeVisualization();
	int startXA=boxSizeA.x();
	int startXB=boxSizeA.x()+boxSizeA.width()+20;
	int startYA=boxSizeA.y();
	int startYB=boxSizeA.height()-boxSizeB.height();
	svg::Layout layout(svg::Dimensions(boxSizeA.width()+boxSizeB.width()+20,boxSizeA.height()>boxSizeB.height()?boxSizeA.height():boxSizeB.height()),svg::Layout::Origin::BottomLeft,1.0,svg::Point(0,0));
	svg::Document doc(fn,layout);
	saveHistoryAsSvg(histA,doc,startXA,startYA);
	saveHistoryAsSvg(histB,doc,startXB,startYB);

	std::vector<std::vector<int>> levelNodesA;
	std::vector<std::vector<int>> levelXPosA;
	std::vector<std::vector<int>> levelNodesB;
	std::vector<std::vector<int>> levelXPosB;
	Box rboxA=histA.boxOf(histA.rootBox());
	Box rboxB=histB.boxOf(histB.rootBox());
	int LnumA=histA.levelNum();
	int LnumB=histB.levelNum();

	histA.nodeAtLevel(levelNodesA);
	levelXPosA=histA.computeXPosForLevel(startXA,levelNodesA);
	histB.nodeAtLevel(levelNodesB);
	levelXPosB=histB.computeXPosForLevel(startXB,levelNodesB);

	int hspacingA=rboxA.width()/2;
	int vspacingA=rboxA.height()/2;
	int hspacingB=rboxB.width()/2;
	int vspacingB=rboxB.height()/2;

	//draw circles
	for(int i=LnumA-1;i>=0;i--){
		std::vector<int> & nodes=levelNodesA[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			if(correspondA2B[nodeId]==-1)continue;

			int x=levelXPosA[i][j]+rboxA.width()/2;
			int y=(rboxA.height()+vspacingA)*(LnumA-i-1)+startYA+rboxA.height()/2;
			doc<<svg::Circle(svg::Point(x,y),10,svg::Fill(svg::Color::Green));
		}
	}

	for(int i=LnumB-1;i>=0;i--){
		std::vector<int> & nodes=levelNodesB[i];
		for(int j=0;j<nodes.size();++j){
			int nodeId=nodes[j];
			if(correspondB2A[nodeId]==-1)continue;
			int x=levelXPosB[i][j]+rboxB.width()/2;
			int y=(rboxB.height()+vspacingB)*(LnumB-i-1)+startYB+rboxB.height()/2;
			doc<<svg::Circle(svg::Point(x,y),10,svg::Fill(svg::Color::Red));
		}
	}

	if(flag&1){
		//draw A2B
		for(int i=LnumA-1;i>=0;i--){
			std::vector<int> & nodes=levelNodesA[i];
			for(int j=0;j<nodes.size();++j){
				int nodeId=nodes[j];
				int mapToB=correspondA2B[nodeId];
				if(mapToB==-1)continue;

				int i2,j2;
				findTwoIndexFrom(levelNodesB,mapToB,i2,j2);

				int x=levelXPosA[i][j]+rboxA.width()/2;
				int y=(rboxA.height()+vspacingA)*(LnumA-i-1)+startYA+rboxA.height()/2;

				int x2=levelXPosB[i2][j2]+rboxB.width()/2;
				int y2=(rboxB.height()+vspacingB)*(LnumB-i2-1)+startYB+rboxB.height()/2;
				doc<<svg::Line(svg::Point(x,y),svg::Point(x2,y2),svg::Stroke(1,svg::Color::Green));
			}
		}
	}


	//
	////draw b2a
	if(flag&2){
		for(int i=LnumB-1;i>=0;i--){
			std::vector<int> & nodes=levelNodesB[i];
			for(int j=0;j<nodes.size();++j){
				int nodeId=nodes[j];
				int mapToA=correspondB2A[nodeId];
				if(mapToA==-1)continue;

				int i2,j2;
				findTwoIndexFrom(levelNodesA,mapToA,i2,j2);

				int x=levelXPosB[i][j]+rboxB.width()/2;
				int y=(rboxB.height()+vspacingB)*(LnumB-i-1)+startYB+rboxB.height()/2;

				int x2=levelXPosA[i2][j2]+rboxA.width()/2;
				int y2=(rboxA.height()+vspacingA)*(LnumA-i2-1)+startYA+rboxA.height()/2;
				doc<<svg::Line(svg::Point(x,y),svg::Point(x2,y2),svg::Stroke(1,svg::Color::Red));
			}
		}

	}


	doc.save();

}

void Analysis::saveSvg_SplitCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates){
	Box bbox=_boxSet.boundingBox(boxIndices);
	svg::Layout layout(svg::Dimensions(bbox.width(),bbox.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(bbox.x(),bbox.y()));
	svg::Document doc(fn,layout);


	for(int i=0;i<boxIndices.size();++i){
		Box &box=_boxSet[boxIndices[i]];
		svg::Rectangle rect(svg::Point(box.x(),box.y()),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
		doc<<rect;
		std::stringstream st;
		st<<boxIndices[i];
		svg::Text labelText(svg::Point(box.center(0),box.center(1)),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
		doc<<labelText;
	}

	for(int i=0;i<candidates.size();++i){
		DecompCandidate& dcan=candidates[i];
		if(dcan.dim==0)
			doc<<svg::Line(svg::Point(dcan.pos,bbox.bottom()),svg::Point(dcan.pos,bbox.top()),svg::Stroke(1,svg::Color::Red));
		else if(dcan.dim==1)
			doc<<svg::Line(svg::Point(bbox.left(),dcan.pos),svg::Point(bbox.right(),dcan.pos),svg::Stroke(1,svg::Color::Red));

	}

	doc.save();
}

void Analysis::saveSvg_DelayerCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates){
	int n=0;
	for(int i=0;i<candidates.size();++i)
		if(candidates[i].dim==2)
			n++;
	if(n==0)return;

	Box bbox=_boxSet.boundingBox();
	//int vspacing=bbox.height()/3;
	int hspacing=bbox.width()/3;

	svg::Layout layout(svg::Dimensions((bbox.width()+hspacing)*n,bbox.height()),svg::Layout::Origin::TopLeft,1.0);
	svg::Document doc(fn,layout);



	int printNum=0;

	for(int i=0;i<candidates.size();++i){
		DecompCandidate &dcan=candidates[i];
		if(dcan.dim<2)continue;

		for(int j=0;j<dcan.indicesOfPartA.size();++j){
			Box &box=_boxSet[dcan.indicesOfPartA[j]];
			int sx=(bbox.width()+hspacing)*printNum;//+box.x()-bbox.x();
			int sy=0;//box.y()-bbox.y();

			doc<<svg::Rectangle(svg::Point(sx,sy),bbox.width(),bbox.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));

			int x=sx+box.x()-bbox.x();
			int y=sy+box.y()-bbox.y();
			svg::Rectangle rect(svg::Point(x,y),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Blue));
			doc<<rect;
			std::stringstream st;
			st<<dcan.indicesOfPartA[j];
			svg::Text labelText(svg::Point(x+box.width()/2,y+box.height()/2),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
			doc<<labelText;
		}

		for(int j=0;j<dcan.indicesOfPartB.size();++j){
			Box &box=_boxSet[dcan.indicesOfPartB[j]];
			int sx=(bbox.width()+hspacing)*printNum;//+box.x()-bbox.x();
			int sy=0;//box.y()-bbox.y();

			doc<<svg::Rectangle(svg::Point(sx,sy),bbox.width(),bbox.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));

			int x=sx+box.x()-bbox.x();
			int y=sy+box.y()-bbox.y();
			svg::Rectangle rect(svg::Point(x,y),box.width(),box.height(),svg::Fill(svg::Color::Red),svg::Stroke(1,svg::Color::Red));
			doc<<rect;
			std::stringstream st;
			st<<dcan.indicesOfPartB[j];
			svg::Text labelText(svg::Point(x+box.width()/2,y+box.height()/2),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
			doc<<labelText;
		}




		printNum++;


	}

	doc.save();

}
void GenerativeHistoryGA::saveSvg_AllCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates)
{


}
void GenerativeHistoryGA::saveSvg_SplitCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates){
	Box bbox=m_boxSet.boundingBox(boxIndices);
	svg::Layout layout(svg::Dimensions(bbox.width(),bbox.height()),svg::Layout::Origin::TopLeft,1.0,svg::Point(bbox.x(),bbox.y()));
	svg::Document doc(fn,layout);


	for(int i=0;i<boxIndices.size();++i){
		Box &box=m_boxSet[boxIndices[i]];
		svg::Rectangle rect(svg::Point(box.x(),box.y()),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
		doc<<rect;
		std::stringstream st;
		st<<boxIndices[i];
		svg::Text labelText(svg::Point(box.center(0),box.center(1)),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
		doc<<labelText;
	}

	for(int i=0;i<candidates.size();++i){
		DecompCandidate& dcan=candidates[i];
		if(dcan.dim==0)
			doc<<svg::Line(svg::Point(dcan.pos,bbox.bottom()),svg::Point(dcan.pos,bbox.top()),svg::Stroke(1,svg::Color::Red));
		else if(dcan.dim==1)
			doc<<svg::Line(svg::Point(bbox.left(),dcan.pos),svg::Point(bbox.right(),dcan.pos),svg::Stroke(1,svg::Color::Red));

	}

	doc.save();
}
void GenerativeHistoryGA::saveSvg_DelayerCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates){
	int n=0;
	for(int i=0;i<candidates.size();++i)
		if(candidates[i].dim==2)
			n++;
	if(n==0)return;

	Box bbox=m_boxSet.boundingBox();
	//int vspacing=bbox.height()/3;
	int hspacing=bbox.width()/3;

	svg::Layout layout(svg::Dimensions((bbox.width()+hspacing)*n,bbox.height()),svg::Layout::Origin::TopLeft,1.0);
	svg::Document doc(fn,layout);



	int printNum=0;

	for(int i=0;i<candidates.size();++i){
		DecompCandidate &dcan=candidates[i];
		if(dcan.dim<2)continue;

		for(int j=0;j<dcan.indicesOfPartA.size();++j){
			Box &box=m_boxSet[dcan.indicesOfPartA[j]];
			int sx=(bbox.width()+hspacing)*printNum;//+box.x()-bbox.x();
			int sy=0;//box.y()-bbox.y();

			doc<<svg::Rectangle(svg::Point(sx,sy),bbox.width(),bbox.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));

			int x=sx+box.x()-bbox.x();
			int y=sy+box.y()-bbox.y();
			svg::Rectangle rect(svg::Point(x,y),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Blue));
			doc<<rect;
			std::stringstream st;
			st<<dcan.indicesOfPartA[j];
			svg::Text labelText(svg::Point(x+box.width()/2,y+box.height()/2),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
			doc<<labelText;
		}

		for(int j=0;j<dcan.indicesOfPartB.size();++j){
			Box &box=m_boxSet[dcan.indicesOfPartB[j]];
			int sx=(bbox.width()+hspacing)*printNum;//+box.x()-bbox.x();
			int sy=0;//box.y()-bbox.y();

			doc<<svg::Rectangle(svg::Point(sx,sy),bbox.width(),bbox.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));

			int x=sx+box.x()-bbox.x();
			int y=sy+box.y()-bbox.y();
			svg::Rectangle rect(svg::Point(x,y),box.width(),box.height(),svg::Fill(svg::Color::Red),svg::Stroke(1,svg::Color::Red));
			doc<<rect;
			std::stringstream st;
			st<<dcan.indicesOfPartB[j];
			svg::Text labelText(svg::Point(x+box.width()/2,y+box.height()/2),st.str(),svg::Fill(),svg::Font(),svg::Stroke(1,svg::Color::Black));
			doc<<labelText;
		}




		printNum++;


	}

	doc.save();

}
void BoxGraph::saveSvg(std::string fn,std::vector<int>& boxIndices){
	reset();
	for(int i=0;i<boxIndices.size();++i){
		addBox(boxIndices[i]);
	}
	updateGraphTopology();

	Box bbox=_boxSet.boundingBox(boxIndices);
	svg::Layout layout(svg::Dimensions(bbox.width(),bbox.height()),svg::Layout::Origin::BottomLeft,1.0,svg::Point(bbox.x(),bbox.y()));
	svg::Document doc(fn,layout);
	for(int i=0;i<boxIndices.size();++i){
		Box &box=_boxSet[boxIndices[i]];
		doc<<svg::Rectangle(svg::Point(box.x(),box.y()),box.width(),box.height(),svg::Fill(),svg::Stroke(1,svg::Color::Black));
	}

	for(int i=0;i<nodes.size();++i){
		Box currentBox=boxOfNode(i);
		if(nodes[i].right!=-1){
			Box you=boxOfNode(nodes[i].right);
			doc<<svg::Line(svg::Point(currentBox.center(0),currentBox.center(1)),svg::Point(you.center(0),you.center(1)),svg::Stroke(1,svg::Color::Red));
		}
		if(nodes[i].top!=-1){
			Box you=boxOfNode(nodes[i].top);
			doc<<svg::Line(svg::Point(currentBox.center(0),currentBox.center(1)),svg::Point(you.center(0),you.center(1)),svg::Stroke(1,svg::Color::Red));
		}
	}
	doc.save();
}