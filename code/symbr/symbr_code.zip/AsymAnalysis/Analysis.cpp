#include "Analysis.h"
#include "SymProfile.h"

#include <iostream>
#include <cmath>
#include <algorithm>
#include "Util.h"
#include <sstream>
#include <iomanip>
#include<map>
#include "BoxGraph.h"

#define ALIGN_THRESHOLD_RATIO 0.3
using namespace Asym;

std::vector<Grid> Analysis::generateAllGrids(std::vector<int>& boxIndices){
	std::vector<Grid> grids;
	if(boxIndices.empty())return grids;
	std::vector<std::vector<int>> groups=_boxSet.groupingByLables(boxIndices);

	BoxGraph boxGraph(_boxSet);
	for(int i=0;i<groups.size();++i){
		boxGraph.extractGrids(groups[i],grids,ALIGN_THRESHOLD_RATIO,ALIGN_THRESHOLD_RATIO);
	}



	return grids;

}


bool isAContainedByB(std::vector<int>& A, std::vector<int>& B){
	if(A.size()>B.size()||A.empty()||B.empty())return false;
	for(int i=0;i<A.size();i++){
		if(std::find(B.begin(),B.end(),A[i])==B.end())
			return false;
	}
	return true;
}

void Analysis::generateDelayerCandidates(std::vector<int>& inputBoxIndices,std::vector<Grid>& grids,std::vector<DecompCandidate>& candidates){
	std::vector<int> gridLayer=determineGridLayer(grids);
	std::vector<int> layers;
	for(int i=0;i<gridLayer.size();++i){
		if(std::find(layers.begin(),layers.end(),gridLayer[i])==layers.end())
			layers.push_back(gridLayer[i]);
	}
	if(layers.size()<2)return;

	for(int i=1;i<layers.size();++i){
		DecompCandidate dcan;
		for(int k=0;k<gridLayer.size();++k){//get foreground 
			Grid &g=grids[k];
			std::vector<int> boxIndices=g.allBoxIndices();
			if(gridLayer[k]>=i){
				for(int j=0;j<boxIndices.size();++j){
					if(std::find(dcan.indicesOfPartB.begin(),dcan.indicesOfPartB.end(),boxIndices[j])==dcan.indicesOfPartB.end())
						dcan.indicesOfPartB.push_back(boxIndices[j]);
				}
			}else{
				for(int j=0;j<boxIndices.size();++j){
					if(std::find(dcan.indicesOfPartA.begin(),dcan.indicesOfPartA.end(),boxIndices[j])==dcan.indicesOfPartA.end())
						dcan.indicesOfPartA.push_back(boxIndices[j]);
				}
			}
		}

		////get background
		//for(int j=0;j<inputBoxIndices.size();++j){
		//	if(std::find(dcan.indicesOfPartB.begin(),dcan.indicesOfPartB.end(),inputBoxIndices[j])==dcan.indicesOfPartB.end()){
		//		dcan.indicesOfPartA.push_back(inputBoxIndices[j]);
		//	}
		//}

		if(dcan.indicesOfPartA.empty()||dcan.indicesOfPartB.empty())continue;
		//if(isAContainedByB(dcan.indicesOfPartA,dcan.indicesOfPartB)||isAContainedByB(dcan.indicesOfPartB,dcan.indicesOfPartA))continue;

		dcan.dim=2;
		dcan.pos=i;
		candidates.push_back(dcan);
	}
}

static bool isGridContainedByOthers(std::vector<Grid>& grids,int i,std::vector<int>& allBoxIndices){

	std::vector<int> myBoxIndices=grids[i].allBoxIndices();
	std::vector<int> boxIndicesOfOtherGrids;
	for(int k=0;k<grids.size();++k){
		std::vector<int> yourBoxIndices=grids[k].allBoxIndices();
		if(k==i)continue;
		for(int j=0;j<yourBoxIndices.size();++j)
			boxIndicesOfOtherGrids.push_back(yourBoxIndices[j]);
	}

	for(int k=0;k<myBoxIndices.size();++k){
		if(std::find(boxIndicesOfOtherGrids.begin(),boxIndicesOfOtherGrids.end(),myBoxIndices[k])==boxIndicesOfOtherGrids.end())
			return false;
	}

	return true;	
}

static void removeInvalidGrids(std::vector<Grid>& grids,std::vector<int>& allBoxIndices){
	std::vector<bool> shouldBeRemoved;
	shouldBeRemoved.assign(grids.size(),false);
	std::vector<Grid> tgrids=grids;
	grids.clear();
	for(int i=0;i<tgrids.size();++i){
		if(isGridContainedByOthers(tgrids,i,allBoxIndices))continue;
		grids.push_back(tgrids[i]);
	}





}
std::vector<std::vector<int>>Analysis::combine(int n,int m)
{

	std::vector<std::vector<int>>combinelist;
	combinelist.clear();
	std::vector<int>step;
	step.clear();
	step.resize(n);
	for (int i=0;i<m;i++)
	{
		step[i]=1;
	}
	std::vector<int>l0=step;
	combinelist.push_back(l0);
	bool isend=false;
	while(!isend)
	{
		isend=true;
		for (int i=n-1;i>n-1-m;i--)
		{
			if (step[i]!=1)
			{
				isend=false;
				break;
			}
		}//��������
		if (isend==true)
		{
			break;
		}
		int temp=0;
		int size1=0;
		for (int i=0;i<n-1;i++)
		{

			if ((step[i]==1)&&(step[i+1]==0))
			{
				step[i]=0;
				step[i+1]=1;
				temp=i;
				break;
			}
			if (step[i]==1)
			{
				size1++;
			}
		}
		for (int i=0;i<size1;i++)
		{
			step[i]=1;
		}
		for (int i=size1;i<temp;i++)
		{
			step[i]=0;
		}
		std::vector<int>l=step;
		combinelist.push_back(l);

	}
	return combinelist;
}
int Analysis::iselist(std::vector<int>l0,std::vector<int>l1)
{
	int n=l0.size();
	int ise=1;
	for (int i=0;i<n;i++)
	{
		if (l0[i]!=l1[i])
		{
			ise=0;
			break;
		}
	}
	return ise;
}
void Analysis::generateDelayerCandidateswithoutlevel(std::vector<int>& boxIndices,std::vector<Grid>& grids,std::vector<DecompCandidate>& candidates)
{
	std::vector<delayernode>nodelist;
	nodelist.clear();
	nodelist.resize(grids.size());
	std::vector<edge>edgelist;
	edgelist.clear();
	for (int i=0;i<grids.size();i++)
	{
		delayernode da;
		da.index=i;
		nodelist[i]=da;

	}
	//build edgelist
	for(int i=0;i<grids.size();++i)
	{
		for(int j=0;j<grids.size();++j)
		{
			if(i==j)continue;
			Grid &g1=grids[i];
			Grid &g2=grids[j];
			if(g1.isInFrontOf(g2,_boxSet))
			{
				edge eij;

				Box b1=g1.boundingbox(_boxSet);
				Box b2=g2.boundingbox(_boxSet);
				Box inter=b1.intersection(b2);
				eij.p0=i;
				eij.p1=j;
				eij.inter=inter.area();
				edgelist.push_back(eij);

				nodelist[i].outedge.push_back(edgelist.size()-1);
				nodelist[j].inedge.push_back(edgelist.size()-1);
			}
		}
	}

	//find circle
	std::vector<int>markedge;
	markedge.clear();
	markedge.resize(edgelist.size());
	for (int i=0;i<nodelist.size();i++)
	{
		delayernode di=nodelist[i];
		std::vector<int>hasvisitde;
		hasvisitde.clear();
		hasvisitde.resize(nodelist.size());
		if (di.outedge.size()!=0)
		{
			for (int j=0;j<nodelist.size();j++)
			{
				nodelist[j].isin=0;
			}
			std::vector<int> myStack;
			myStack.push_back(di.index);
			std::vector<int>path;
			path.clear();
			while(!myStack.empty())
			{
				int currNode=myStack.back();


				int have=0;
				int circleindex=0;
				//if havecircle
				int npp=path.size()-1;
				for (int j=0;j<npp;j++)
				{
					if (currNode==path[j])
					{
						have=1;
						circleindex=j;
					}
				}
				if (have)
				{
					int mininter=100000000;
					int minedge;
					for (int j=circleindex;j<path.size()-1;j++)
					{
						int interi;
						int indexi;
						for (int k=0;k<nodelist[path[j]].outedge.size();k++ )
						{
							edge jk=edgelist[nodelist[path[j]].outedge[k]];

							interi=jk.inter;
							indexi=nodelist[path[j]].outedge[k];
						}
						if (interi<mininter)
						{
							mininter=interi;
							minedge=indexi;
						}
					}
					markedge[minedge]=1;
				}
				//non leaf node
				int can=0;
				for (int k=0;k<nodelist[currNode].outedge.size();k++)
				{
					int ik=edgelist[nodelist[currNode].outedge[k]].p1;
					if (hasvisitde[ik]==0)
					{
						can=1;
					}
				}
				if (can==1)
				{
					int isin=1;
					for (int l=0;l<nodelist[currNode].outedge.size();l++)
					{
						int nodeindexi=edgelist[nodelist[currNode].outedge[l]].p1;
						if (nodelist[nodeindexi].isin==0)
						{
							isin=0;
						}
					}
					if (isin==0)
					{
						path.push_back(currNode);
						hasvisitde[currNode]=1;
						for (int l=0;l<nodelist[currNode].outedge.size();l++)
						{
							int nodeindexi=edgelist[nodelist[currNode].outedge[l]].p1;
							myStack.push_back(nodeindexi);
						}
					}
					else
					{
						nodelist[currNode].isin=1;
						myStack.pop_back();
						if (!path.empty())
						{
							path.pop_back();
						}

					}
				}
				//leaf node
				else
				{
					nodelist[currNode].isin=1;
					myStack.pop_back();
					hasvisitde[currNode]=1;
					//path.pop_back();

				}
				//}
			}
		}
	}//find circle end

	//build upnode
	std::vector<std::vector<int>> layerMatrix;
	layerMatrix.resize(grids.size());
	for(int i=0;i<layerMatrix.size();++i)
	{
		layerMatrix[i].assign(grids.size(),0);
	}

	for (int i=0;i<edgelist.size();i++)
	{
		if (markedge[i]==0)
		{
			edge ei=edgelist[i];
			int p0=ei.p0;
			int p1=ei.p1;
			layerMatrix[p0][p1]=1;
		}
	}

	for(int i=0;i<layerMatrix.size();++i)
	{
		std::vector<int> belowMe;
		for(int j=0;j<layerMatrix[i].size();++j)
		{
			if(layerMatrix[i][j]==1)
				belowMe.push_back(j);
		}

		std::vector<bool> hasVisited;
		hasVisited.assign(grids.size(),false);

		while(!belowMe.empty())
		{
			int current=belowMe.back();
			belowMe.pop_back();
			layerMatrix[i][current]=1;
			hasVisited[current]=true;

			for(int j=0;j<layerMatrix[current].size();++j)
			{
				if(!hasVisited[j]&&layerMatrix[current][j]==1)
				{
					belowMe.push_back(j);
					hasVisited[j]=true;
				}
			}
		}

	}

	for (int i=0;i<nodelist.size();i++)
	{
		std::vector<int>upi;
		for (int j=0;j<nodelist.size();j++)
		{
			if (layerMatrix[j][i]==1)
			{
				upi.push_back(j);
			}
		}
		nodelist[i].upnode=upi;
	}
	//end upnode
	std::vector<std::vector<int>>candidatelist;
	std::vector<delayernode>candidatenode;
	std::vector<int>i2candidate;
	i2candidate.clear();
	i2candidate.resize(nodelist.size());

	for (int i=0;i<nodelist.size();i++)
	{
		if (nodelist[i].outedge.size()!=0)
		{
			candidatenode.push_back(nodelist[i]);
			i2candidate[i]=candidatenode.size()-1;
		}
	}
	std::vector<std::vector<int>>combinelist;
	combinelist.clear();
	int ncnode=candidatenode.size();
	if (ncnode>=2)
	{
		for (int i=1;i<ncnode+1;i++)
		{
			std::vector<std::vector<int>>combinelisti=combine(ncnode,i);
			for (int j=0;j<combinelisti.size();j++)
			{
				int isej=0;
				std::vector<int>listj=combinelisti[j];
				for (int k=0;k<ncnode;k++)
				{
					if (combinelisti[j][k]==1)
					{
						for (int l=0;l<candidatenode[k].upnode.size();l++)
						{
							int indexl=i2candidate[candidatenode[k].upnode[l]];
							listj[indexl]=1;
						}
					}
				}

				for (int k=0;k<combinelist.size();k++)
				{
					if (iselist(combinelist[k],listj)==1)
					{
						isej=1;
					}
				}
				if (isej==0)
				{
					combinelist.push_back(listj);
				}
			}
		}
	}
	else
	{
		std::vector<int>listj;
		listj.resize(1);
		listj[0]=1;
		combinelist.push_back(listj);
	}


	for (int i=0;i<combinelist.size();i++)
	{
		DecompCandidate dcan;
		std::vector<int>pa;
		std::vector<int>pb;
		for (int j=0;j<ncnode;j++)
		{
			if (combinelist[i][j]==1)
			{
				int index=candidatenode[j].index;
				std::vector<int>gjlist=grids[index].allBoxIndices();
				for (int k=0;k<gjlist.size();k++)
				{
					int indexk=gjlist[k];
					int have=0;
					for (int l=0;l<pb.size();l++)
					{
						if (pb[l]==indexk)
						{
							have=1;
						}
					}
					if (have==0)
					{
						pb.push_back(indexk);
					}
				}

			}
		}
		for (int j=0;j<boxIndices.size();j++)
		{
			int have=0;
			for (int k=0;k<pb.size();k++)
			{
				if (boxIndices[j]==pb[k])
				{
					have=1;
				}
			}
			if (have==0)
			{
				pa.push_back(boxIndices[j]);
			}
		}
		dcan.indicesOfPartA=pa;
		dcan.indicesOfPartB=pb;
		dcan.dim=2;
		dcan.pos=i;
		if ((pa.size()!=0)&&(pb.size()!=0))
		{
			candidates.push_back(dcan);
		}
	}
}
void  Analysis::generateCandidates(std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates){
	std::vector<Grid> grids=generateAllGrids(boxIndices);
	removeInvalidGrids(grids,boxIndices);
	BoxSet gridBboxSet;
	for(int i=0;i<grids.size();++i)
		gridBboxSet.push_back(grids[i].boundingbox(_boxSet));

	for(int dim=0;dim<2;++dim){
		LineProfile lp=LineProfile::createFromBoxSet(gridBboxSet,dim);
		std::vector<int> zeroPos=lp.zeroTurningPos();
		for(int i=0;i<zeroPos.size();++i){
			DecompCandidate dcan;
			dcan.dim=dim;
			dcan.pos=zeroPos[i];
			_boxSet.split(dcan.pos,dcan.dim,boxIndices,dcan.indicesOfPartA,dcan.indicesOfPartB);
			candidates.push_back(dcan);
		}	
	}

	generateDelayerCandidateswithoutlevel(boxIndices,grids,candidates);


}



std::vector<int> Analysis::determineGridLayer(std::vector<Grid>& grids){
	std::vector<std::vector<int>> layerMatrix;
	layerMatrix.resize(grids.size());
	for(int i=0;i<layerMatrix.size();++i)
		layerMatrix[i].assign(grids.size(),0);

	for(int i=0;i<grids.size();++i){
		for(int j=0;j<grids.size();++j){
			if(i==j)continue;
			Grid &g1=grids[i];
			Grid &g2=grids[j];
			if(g1.isInFrontOf(g2,_boxSet)){
				layerMatrix[i][j]=1;
			}
		}
	}

	for(int i=0;i<layerMatrix.size();++i){
		std::vector<int> belowMe;
		for(int j=0;j<layerMatrix[i].size();++j){
			if(layerMatrix[i][j]==1)
				belowMe.push_back(j);
		}

		std::vector<bool> hasVisited;
		hasVisited.assign(grids.size(),false);

		while(!belowMe.empty()){
			int current=belowMe.back();
			belowMe.pop_back();
			layerMatrix[i][current]=1;
			hasVisited[current]=true;

			for(int j=0;j<layerMatrix[current].size();++j){
				if(!hasVisited[j]&&layerMatrix[current][j]==1){
					belowMe.push_back(j);
					hasVisited[j]=true;
				}
			}
		}

	}

	std::vector<int> gridLayers;
	gridLayers.assign(grids.size(),0);
	std::vector<int> distinctLabels;

	for(int i=0;i<layerMatrix.size();++i){
		gridLayers[i]=0;
		for(int j=0;j<layerMatrix[i].size();++j){
			if(layerMatrix[i][j]==1)
				gridLayers[i]++;
		}
		if(std::find(distinctLabels.begin(),distinctLabels.end(),gridLayers[i])==distinctLabels.end())
			distinctLabels.push_back(gridLayers[i]);
	}

	std::sort(distinctLabels.begin(),distinctLabels.end());
	for(int i=0;i<gridLayers.size();++i){
		for(int j=0;j<distinctLabels.size();++j){
			if(distinctLabels[j]==gridLayers[i]){
				gridLayers[i]=j;
				break;
			}
		}
	}


	return gridLayers;
}


float Analysis::evaluateNIS(DecompCandidate& dc,Box space){
	SymProfile spA_X,spA_Y;
	SymProfile spB_X,spB_Y;
	GaussianFilterPara paraAX,paraBX;
	GaussianFilterPara paraAY,paraBY;
	Box subSpaceA,subSpaceB;
	double bellRadiusRatio=1.0;

	if(dc.dim<2){
		Box::splitBox(space,dc.pos,dc.dim,subSpaceA,subSpaceB);
	}else{
		subSpaceA=_boxSet.boundingBox(dc.indicesOfPartA);
		subSpaceB=_boxSet.boundingBox(dc.indicesOfPartB);
	}
	paraAX.mean=subSpaceA.center(0);
	paraAY.mean=subSpaceA.center(1);
	paraBX.mean=subSpaceB.center(0);
	paraBY.mean=subSpaceB.center(1);
	paraAX.sigma=bellRadiusRatio*subSpaceA.size(0)/6.6;
	paraAY.sigma=bellRadiusRatio*subSpaceA.size(1)/6.6;
	paraBY.sigma=bellRadiusRatio*subSpaceB.size(1)/6.6;
	paraBX.sigma=bellRadiusRatio*subSpaceB.size(0)/6.6;

	spA_X.extractFrom(_boxSet,dc.indicesOfPartA,0,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraAX);
	spB_X.extractFrom(_boxSet,dc.indicesOfPartB,0,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraBX);
	spA_Y.extractFrom(_boxSet,dc.indicesOfPartA,1,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraAY);
	spB_Y.extractFrom(_boxSet,dc.indicesOfPartB,1,InterBoxSym|IntraBoxSym|WithGaussianFilter,&paraBY);

	double sumSymA_X=spA_X.integral();
	double sumSymB_X=spB_X.integral();
	double sumSymA_Y=spA_Y.integral();
	double sumSymB_Y=spB_Y.integral();

	if(dc.dim<2){

		Box::splitBox(space,dc.pos,dc.dim,subSpaceA,subSpaceB);
		double IS_A_X=SymProfile::integralSymOfBox(subSpaceA,0);
		double IS_A_Y=SymProfile::integralSymOfBox(subSpaceA,1);
		double IS_B_X=SymProfile::integralSymOfBox(subSpaceB,0);
		double IS_B_Y=SymProfile::integralSymOfBox(subSpaceB,1);
		return (sumSymA_X/IS_A_X+sumSymA_Y/IS_A_Y+sumSymB_X/IS_B_X+sumSymB_Y/IS_B_Y)/4;

	}else{
		Box subSpaceA=space;
		double IS_A_X=SymProfile::integralSymOfBox(subSpaceA,0);
		double IS_A_Y=SymProfile::integralSymOfBox(subSpaceA,1);
		Box subSpaceB=_boxSet.boundingBox(dc.indicesOfPartB);
		double IS_B_X=SymProfile::integralSymOfBox(subSpaceB,0);
		double IS_B_Y=SymProfile::integralSymOfBox(subSpaceB,1);
		return ((sumSymA_X+sumSymB_X)/(IS_A_X+IS_B_X)+(sumSymA_Y+sumSymB_Y)/(IS_A_Y+IS_B_Y))/2;

	}

}

int Analysis::chooseBestCandidate(std::vector<DecompCandidate>& candidates,Box space){
	if(candidates.empty())return -1;

	float largestNIS=evaluateNIS(candidates[0],space);
	int bestCan=0;
	std::cout<<"NIS 0 (dim="<<candidates[0].dim<<", pos="<<candidates[0].pos<<")  = "<<largestNIS<<std::endl;
	for(int i=1;i<candidates.size();++i){
		float nis=evaluateNIS(candidates[i],space);
		std::cout<<"NIS "<<i<<" (dim="<<candidates[i].dim<<", pos="<<candidates[i].pos<<") = "<<nis<<std::endl;
		if(largestNIS<nis){
			largestNIS=nis;
			bestCan=i;
		}
	}
	std::cout<<"the largest NIS is "<<bestCan<<" dim="<<candidates[bestCan].dim<<std::endl;
	return bestCan;
}

bool Analysis::needDecomp(std::vector<int>& boxIndices){
	if(boxIndices.empty())return false;
	std::vector<Grid> grids=generateAllGrids(boxIndices);
	return grids.size()>1;
}

static void completeHistoryNode(GenerativeHistory& hist,int nodeId){
	BoxSet tboxSet=hist.nodeData(nodeId);
	BoxGraph boxGraph(tboxSet);
	std::vector<Grid> grids;
	boxGraph.extractGrids(tboxSet.allBoxIndices(),grids,0.1,0.1);
	if(grids.size()!=1)return;
	Grid &g=grids[0];
	hist.nodeData(nodeId).clear();
	g.completeGrid(tboxSet,hist.nodeData(nodeId));	
}

static void completeBackgroundLayer(GenerativeHistory& hist,int nodeId){
	//BoxSet tboxSet=hist.nodeData(nodeId);
	//BoxGraph boxGraph(tboxSet);
	//std::vector<Grid> grids;
	//boxGraph.extractGrids(tboxSet.allBoxIndices(),grids,0.1,0.1);
	//if(grids.size()!=1)return;
	//Grid &g=grids[0];
	//hist.nodeData(nodeId).clear();
	////g.completeGrid(tboxSet,hist.nodeData(nodeId));	
	//Box newSpace=hist.boxOf(nodeId);
	//g.retargeting(0,newSpace.width(),tboxSet,hist.nodeData(nodeId));
	//hist.nodeData(nodeId).clear();
	//g.retargeting(1,newSpace.height(),tboxSet,hist.nodeData(nodeId));
}

GenerativeHistory Analysis::recoverHistoryGA()
{
	GAParameterList params;
	GASteadyStateGA::registerDefaultParameters(params);
	params.set(gaNpopulationSize, 100);	// population size
	params.set(gaNpCrossover, 0.9);	// probability of crossover
	params.set(gaNpMutation, 0.01);	// probability of mutation 
	params.set(gaNnGenerations, 100);	// number of generations 
	params.set(gaNpReplacement, 0.25);	// how much of pop to replace each gen



	GenerativeHistory hist;
	GenerativeHistoryGA genome(objective);//
	genome.SetBoxSet(_boxSet);
	genome.initializer(TreeInitializer);
	genome.crossover(TreeCrossover);//
	genome.mutator(TreeMutator);//

	GASteadyStateGA ga(genome);
	ga.parameters(params);
	ga.evolve();

	const GenerativeHistoryGA* c = DYN_CAST(const GenerativeHistoryGA*, &ga.statistics().bestIndividual());
	hist=c->m_ghist;
	return hist;


}

GenerativeHistory Analysis::recoverHistory(Box box){
	typedef std::pair<std::vector<int>,int> StackNode;

	GenerativeHistory hist;
	if(_boxSet.empty())return hist;
	std::vector<int> initialBoxIndices=_boxSet.allBoxIndices();
	int rootId=hist.initialize(box);
	hist.nodeData(rootId).setData(_boxSet,initialBoxIndices);

	std::vector<float>is;
	is.clear();
	std::vector<float>wight;
	wight.clear();
	std::vector<StackNode> myStack;
	myStack.push_back(StackNode(initialBoxIndices,rootId));
	int kk=0;
	while(!myStack.empty()){
		StackNode& currNode=myStack.back();

		if(!needDecomp(currNode.first)){
			myStack.pop_back();

			continue;
		}

		std::vector<DecompCandidate> candidates;

		generateCandidates(currNode.first,candidates);
		int best=chooseBestCandidate(candidates,hist.boxOf(currNode.second));
		float largestNIS=evaluateNIS(candidates[best],hist.boxOf(currNode.second));
		is.push_back(largestNIS);
		int bc=hist.boxOf(currNode.second).area();
		int b0=hist.boxOf(0).area();
		float w=float(bc)/b0;
		wight.push_back(w);
		if(best!=-1){
			DecompCandidate &bestCan=candidates[best];

			OperationResult or;
			if(bestCan.dim<2){
				or=hist.split(currNode.second,bestCan.pos,bestCan.dim);
			}else{
				or=hist.delayer(currNode.second,_boxSet.boundingBox(bestCan.indicesOfPartA),_boxSet.boundingBox(bestCan.indicesOfPartB));

			}


			hist.nodeData(or.first).setData(_boxSet,bestCan.indicesOfPartA);
			hist.nodeData(or.second).setData(_boxSet,bestCan.indicesOfPartB);

			hist.setp(bestCan,currNode.second);


			myStack.pop_back();

			myStack.push_back(StackNode(bestCan.indicesOfPartB,or.second));
			myStack.push_back(StackNode(bestCan.indicesOfPartA,or.first));
		}else
			myStack.pop_back();
	}

	GenerativeHistoryGA ga;
	ga.SetBoxSet(_boxSet);
	ga.m_ghist=hist;

	return hist;
}