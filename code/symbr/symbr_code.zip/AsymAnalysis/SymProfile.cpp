#include "SymProfile.h"
//#include "simple_svg_1.0.0.hpp"
#include <vector>
#include <algorithm>
#include <iostream>
#include <cmath>
//#define PRINT_DEBUG_SYMPROFILE
using namespace Asym;

typedef std::vector<int>::iterator IntVectorIter;
void LineProfile::reset(){
_Pos.clear();
_value.clear();
}

void LineProfile::addWithoutAddPos(int startPos,int endPos,int v){

IntVectorIter itStart=std::find(_Pos.begin(),_Pos.end(),startPos);
IntVectorIter itEnd=std::find(_Pos.begin(),_Pos.end(),endPos);

for(IntVectorIter it=itStart;it!=itEnd;++it){
IntVectorIter valueIt=_value.begin()+(it-_Pos.begin());
*valueIt+=v;
}

}

void LineProfile::add(int startPos,int endPos,int v){
	std::vector<int> oldPos=_Pos;
	std::vector<int> oldValue=_value;
	bool needResort=false;
	if(std::find(_Pos.begin(),_Pos.end(),startPos)==_Pos.end()){
		_Pos.push_back(startPos);
		needResort=true;
	}
	if(std::find(_Pos.begin(),_Pos.end(),endPos)==_Pos.end()){
		_Pos.push_back(endPos);
		needResort=true;
	}

	if(needResort){
		std::sort(_Pos.begin(),_Pos.end());
		_value.assign(_Pos.size(),0);
		for(int i=0;i<(int)(oldPos.size()-1);++i){
			addWithoutAddPos(oldPos[i],oldPos[i+1],oldValue[i]);
		}
	}

	addWithoutAddPos(startPos,endPos,v);
}


int LineProfile::maxValue(){
	return *std::max_element(_value.begin(),_value.end());
}



bool LineProfile::checkPos(int startPos,int endPos,int eleSize,int eleNum){
		int startIndex=0;
		for(int i=_Pos.size()-1;i>=0;--i){
			if(startPos>=_Pos[i]){
				startIndex=i;break;
			}
		}
		int endIndex=startIndex;
		for(int i=startIndex;i<_Pos.size();++i){
			if(endPos<=_Pos[i]){
				endIndex=i;
				break;
			}
		}
	
		int s=0;
		for(int i=startIndex;i<endIndex;++i){
			s+=(_Pos[i+1]-_Pos[i])*_value[i];
		}
		s-=(startPos-_Pos[startIndex])*_value[startIndex];
		s-=(_Pos[endIndex]-endPos)*_value[endIndex-1];
		int t=eleSize*eleNum*(endPos-startPos)*0.8;
		return s>=t;
}

int LineProfile::maximalRepNum(int eleSize){
return (maxValue()+eleSize/2)/eleSize;
}

int LineProfile::createIndex(int eleSize,int eleNum){
_tmpIndex.assign(_Pos.size(),-1);
int threshold=eleSize*eleNum*0.8;

for(int i=0;i<_Pos.size()-1;++i){
	if(_value[i]>threshold)
		_tmpIndex[i]=0;
}

int indNum=-1;
int i=0;
while(i<_tmpIndex.size()){
	while(i<_tmpIndex.size()&&_tmpIndex[i]==-1)i++;
	indNum++;
	while(i<_tmpIndex.size()&&_tmpIndex[i]==0){
		_tmpIndex[i]=indNum;
		i++;
	}
}
return indNum;
}

int LineProfile::indexOf(int startPos,int endPos,int eleSize,int eleNum){
	int startIndex=0;
	for(int i=_Pos.size()-1;i>=0;--i){
		if(startPos>=_Pos[i]){
			startIndex=i;break;
		}
	}
	int endIndex=startIndex;
	for(int i=startIndex;i<_Pos.size();++i){
		if(endPos<=_Pos[i]){
			endIndex=i;
			break;
		}
	}
	for(int i=startIndex;i<endIndex;++i){
		if(_tmpIndex[i]!=-1)
			return _tmpIndex[i];
	}
	return -1;
}


LineProfile LineProfile::createFromBoxSet(BoxSet& bset, int dim){
	LineProfile lp;
	int dim2=(dim+1)%2;
	for(int i=0;i<bset.size();++i){
		Box &box=bset[i];
		lp.add(box.location(dim),box.location(dim)+box.size(dim),box.size(dim2));
	}
	return lp;
}

LineProfile LineProfile::createFromBoxSet(BoxSet& bset, int dim,std::vector<int>& boxIndices){
	LineProfile lp;
	int dim2=(dim+1)%2;
	for(int i=0;i<boxIndices.size();++i){
		Box &box=bset[boxIndices[i]];
		lp.add(box.location(dim),box.location(dim)+box.size(dim),box.size(dim2));
	}
	return lp;
}


std::vector<int> LineProfile::zeroTurningPos(){
std::vector<int> tpos;
for(int i=1;i+1<_Pos.size();++i){
	if(_value[i]==0){
		//tpos.push_back(_Pos[i]);ֻҪ�м���һ����
		tpos.push_back((_Pos[i]+_Pos[i+1])/2);
		//tpos.push_back(_Pos[i+1]);
	}
}
return tpos;
}



////----------------------------


double  SymProfile::symAt(int pos){
	int firstLargeInd=0;
	while(firstLargeInd<_Pos.size()&&_Pos[firstLargeInd]<pos)firstLargeInd++;

	if(firstLargeInd==0){
		return _Sym.front();
	}else if(firstLargeInd==_Pos.size()){
		return _Sym.back();
	}else{
		double t=(pos-_Pos[firstLargeInd-1])/(double)(_Pos[firstLargeInd]-_Pos[firstLargeInd-1]);
		return _Sym[firstLargeInd-1]+t*(_Sym[firstLargeInd]-_Sym[firstLargeInd-1]);
	}
}

struct BasicFunction{
	int positions[4];
	double values[4];
	BasicFunction (){
		for(int i=0;i<4;++i){
			positions[i]=0;
			values[i]=0;
		}
	}
	bool isValid(){
		return positions[0]||positions[1]||positions[2]||positions[3];
	}
};

double intepretSymValueAt(BasicFunction& bf,int pos){
	int ind=0;
	while(ind<4&&pos>bf.positions[ind]){
		ind++;
	}
	if(ind==0||ind==4)
		return bf.values[ind];
	
	int len=bf.positions[ind]-bf.positions[ind-1];
	int t=pos-bf.positions[ind-1];
	if(len==0){
		return bf.values[ind-1];
	}

	return bf.values[ind-1]+t* (bf.values[ind]-bf.values[ind-1])/len;
}


BasicFunction extractBasicFunc(Box& A, Box& B,int dim){
	BasicFunction bf;
	if(A.label()!=B.label())return bf;

	std::vector<int> pos;
	pos.push_back((A.location(dim)+B.location(dim))/2);
	pos.push_back((A.location(dim)+A.size(dim)+B.location(dim))/2);
	pos.push_back((A.location(dim)+A.size(dim)+B.location(dim)+B.size(dim))/2);
	pos.push_back((A.location(dim)+B.location(dim)+B.size(dim))/2);
	std::sort(pos.begin(),pos.end());

	Box refA=A.reflection((A.center(dim)+B.center(dim))/2,dim);
	double areaOfOverlapped=refA.areaOfOverlap(B);

	bf.positions[0]=pos[0];
	bf.positions[1]=pos[1];
	bf.positions[2]=pos[2];
	bf.positions[3]=pos[3];
	bf.values[0]=bf.values[3]=0;
	bf.values[1]=bf.values[2]=areaOfOverlapped*2;
	return bf;
}
 

void SymProfile::extractFrom(BoxSet& bset,int dim,int flag){
extractFrom(bset,bset.allBoxIndices(),dim,flag);
}




static void generateGaussianSamplingAtPositions(int mean,int sigma,std::vector<int> &positions,std::vector<double> &gaussianValue){
	gaussianValue.resize(positions.size());
	double s=sigma*sigma*2;
	for(int i=0;i<positions.size();++i){
		gaussianValue[i]=exp(-(positions[i]-mean)*(positions[i]-mean)/s);
	}
}


void SymProfile::extractFrom(BoxSet& boxset,std::vector<int>& boxIndices,int dim,int flag,GaussianFilterPara* para){
	if(boxIndices.empty())return;

	std::vector<BasicFunction> bfunc;
	if(flag&IntraBoxSym){
		for(int i=0;i<boxIndices.size();++i){
			Box& box=boxset[boxIndices[i]];
			BasicFunction bf=extractBasicFunc(box,box,dim);
			int newSymValue=bf.values[2]/2;
			bf.values[1]=bf.values[2]=newSymValue;
			bfunc.push_back(bf);
		}
	}

	if(flag&InterBoxSym){
		for(int i=0;i<boxIndices.size();++i){
			Box& boxA=boxset[boxIndices[i]];
			for(int j=i+1;j<boxIndices.size();++j){
				//if(i==j)continue;
				Box& boxB=boxset[boxIndices[j]];
				BasicFunction bf=extractBasicFunc(boxA,boxB,dim);
				if(bf.isValid())
				bfunc.push_back(bf);
			}
		}
	}

	_dim=dim;
	_flag=flag;
	_bbox=boxset.boundingBox(boxIndices);
	_Pos.clear();
	_Sym.clear();

	if(bfunc.empty())return;
	
	_Pos.reserve(bfunc.size()*4);

	for(int i=0;i<bfunc.size();++i){
		BasicFunction& bf=bfunc[i];
		for(int j=0;j<4;++j){
			if(std::find(_Pos.begin(),_Pos.end(),bf.positions[j])==_Pos.end()){
				_Pos.push_back(bf.positions[j]);
				std::sort(_Pos.begin(),_Pos.end());
			}
		}
	}
#ifdef PRINT_DEBUG_SYMPROFILE
	std::cout<<"bbox: "<<_bbox.x()<<" "<<_bbox.y()<<" "<<_bbox.width()<<" "<<_bbox.height()<<std::endl;

	std::cout<<"positions: ";
	for(int i=0;i<_Pos.size();++i){
		std::cout<<_Pos[i]<<" ";
	}
	std::cout<<std::endl;
#endif

	_Sym.assign(_Pos.size(),0);

#ifdef PRINT_DEBUG_SYMPROFILE
	std::cout<<"initial sym: ";
	for(int j=0;j<_Sym.size();++j){
		std::cout<<_Sym[j]<<" ";
	}
	std::cout<<std::endl;
#endif

	for(int i=0;i<bfunc.size();++i){
		BasicFunction& bf=bfunc[i];

		#ifdef PRINT_DEBUG_SYMPROFILE
		std::cout<<"bf  "<<i<< ": pos ["<<bf.positions[0]<<" "<<bf.positions[1]<<" "<<bf.positions[2]<<" "<<bf.positions[3]<<"], sym ["<<bf.values[0]<<" "<<bf.values[1]<<" "<<bf.values[2]<<" "<<bf.values[3]<<"] "<<std::endl;
       #endif

		std::vector<int>::iterator itStart=std::find(_Pos.begin(),_Pos.end(),bf.positions[0]);
		std::vector<int>::iterator itEnd=std::find(_Pos.begin(),_Pos.end(),bf.positions[3]);
		for(std::vector<int>::iterator it=itStart;it!=itEnd;++it){
			std::vector<double>::iterator sIt=_Sym.begin()+(it-_Pos.begin());
			*sIt+=intepretSymValueAt(bf,*it);
		}

		#ifdef PRINT_DEBUG_SYMPROFILE
		std::cout<<"sym: ";
		for(int j=0;j<_Sym.size();++j){
			std::cout<<_Sym[j]<<" ";
		}
		std::cout<<std::endl;
		#endif
	}
	#ifdef PRINT_DEBUG_SYMPROFILE
		std::cout<<"---------------"<<std::endl;
				#endif

		if(flag&WithGaussianFilter){
			std::vector<int> tPos;
			std::vector<double> tSym;
			
			int stepNum=100;
			int tStep=(_Pos.back()-_Pos.front())/stepNum;
			int stepDelta=(tStep<1?1:tStep);
			for(int i=0, iEnd=_Pos.size()-1;i<iEnd;++i){
				int posDelta=_Pos[i+1]-_Pos[i];
				int insertNum=posDelta/stepDelta;
				for(int j=0;j<insertNum;++j){
					int p=_Pos[i]+stepDelta*j;
					tPos.push_back(p);
					tSym.push_back(symAt(p));
				}
			}
			tPos.push_back(_Pos.back());
			tSym.push_back(symAt(_Pos.back()));

			_Pos.clear();
			_Sym.clear();
			_Pos=tPos;
			_Sym=tSym;

			double mean=_bbox.center(dim);
			double bellRadiusRatio=1.0;
			double sigma=_bbox.size(dim)*bellRadiusRatio/6.6; 
			if(para!=NULL){
				mean=para->mean;
				sigma=para->sigma;
			//	bellRadiusRatio=para->bellRadiusRatio;
			}

			std::vector<double> gaussianValue;
			generateGaussianSamplingAtPositions(mean,sigma,_Pos,gaussianValue);
			for(int i=0;i<_Sym.size();++i)
				_Sym[i]*=gaussianValue[i];
		}
}


double  SymProfile::maximalSymValue(){
	return *(std::max_element(_Sym.begin(),_Sym.end()));
}

double  SymProfile::NIS(){
double s=integral();
double n=_bbox.area()*(_bbox.size(_dim)*0.5);
return s/n;
}

double SymProfile::integral(){
	double s=0;
	for(int i=0,iend=_Sym.size()-1;i<iend;++i){
		s+=(_Sym[i]+_Sym[i+1])*(_Pos[i+1]-_Pos[i])*0.5;
	}
	return s;
}

double SymProfile::integralSymOfBox(Box& box,int dim){
double n=box.area()*0.5*box.size(dim);
return n;
}