#include "Analysis.h"
#include "SymProfile.h"
#include<iostream>
#include <sstream>



using namespace Asym;

std::string fileNameOfTag(char* i){
	std::stringstream st;
	st<<"../../input/tag/"<<i;
	return st.str();
}

std::string fileNameOfHistory(char* i){
	std::stringstream st;
	st<<"../../output/hist/"<<i<<".hist";
	return st.str();
}

std::string fileNameOfHistTree(char* i){
	std::stringstream st;
	st<<"../../output/svg/"<<i<<".svg";
	return st.str();
}

int main(int argc, char *argv[]){

	BoxSet bset;
	char* fn=argv[1];
	
	bset.readFromFile(fileNameOfTag(fn));
	std::cout << "GA started..." << std::endl;
	Analysis ana(bset);
	GenerativeHistory hist=ana.recoverHistoryGA();
	GenerativeHistoryGA ga;
	ga.SetBoxSet(bset);
	ga.m_ghist=hist;
	std::cout << "Done." << std::endl;
	hist.saveSvg_Tree(fileNameOfHistTree(fn).data());
	std::cout << "Decomposition tree (*.svg) stored." << std::endl;
	hist.saveHistory(fileNameOfHistory(fn).data() );
	std::cout << "Decomposition tree (*.hist) stored." << std::endl;

	return 0;
}