#include "GenerativeHistory.h"
#include "BoxGraph.h"
#include "Grid.h"
#include "Util.h"
#include <fstream>
#include <cfloat>
#include <iostream>
#include <cmath>
#include "SymProfile.h"
namespace Asym{

	GenerativeHistory::GenerativeHistory():
_rootBoxId(-1){
	_hierarchyBoxes.clear();

}

int GenerativeHistory::initialize(Box& rootBox){
	clear();
	HierarchyNode *hbox=allocateNewHierarchyNode();
	hbox->box=rootBox;
	_rootBoxId=0;
	return _rootBoxId;
}

int GenerativeHistory::rootBox() const{
	return _rootBoxId;
}

int GenerativeHistory::leftBoxId(int boxId) const{
	return _hierarchyBoxes[boxId]->leftBoxId;
}

int GenerativeHistory::rightBoxId(int boxId) const{
	return _hierarchyBoxes[boxId]->rightBoxId;
}

int GenerativeHistory::parentBoxId(int boxId) const{
	return _hierarchyBoxes[boxId]->parentBoxId;
}


int GenerativeHistory::level(int nodeId) const{
	int L=0;
	while(_hierarchyBoxes[nodeId]->parentBoxId!=-1){
		nodeId=_hierarchyBoxes[nodeId]->parentBoxId;
		L++;
	}
	return L;
}

int GenerativeHistory::levelNum() const{
	int L=-1;
	for(int i=0;i<_hierarchyBoxes.size();++i){
		int tL=level(i);
		if(tL>L)
			L=tL;
	}
	return L+1;
}

int GenerativeHistory::leaveNodeNum() const{
	int n=0;
	for(int i=0;i<_hierarchyBoxes.size();++i){
		if(leftBoxId(i)==-1&&rightBoxId(i)==-1)
			n++;
	}

	return n;
}

int GenerativeHistory::brotherNodeId(int nodeId) const{
	int pid=parentBoxId(nodeId);
	if(pid==-1)return -1;
	if(nodeId==leftBoxId(pid))
		return rightBoxId(pid);
	else
		return leftBoxId(pid);
}

Box GenerativeHistory::boxOf(int nodeId) const{
	return _hierarchyBoxes[nodeId]->box;
}



BoxSet& GenerativeHistory::nodeData(int nodeId){
	return _hierarchyBoxes[nodeId]->contentBoxes;
}

bool GenerativeHistory::isLeafNode(int nodeId) const{
	return leftBoxId(nodeId)==-1&&rightBoxId(nodeId)==-1;
}


OperationType GenerativeHistory::operationType(int nodeId){
	HierarchyNode* pnode=_hierarchyBoxes[nodeId];
	if(leftBoxId(nodeId)==-1||rightBoxId(nodeId)==-1){
		return OT_Undefined;
	}else{
		Box& myBox=pnode->box;
		Box& leftBox=_hierarchyBoxes[pnode->leftBoxId]->box;
		Box& rightBox=_hierarchyBoxes[pnode->leftBoxId]->box;
		if(leftBox==myBox)
			return OT_Delayer;
		else if(leftBox.width()==myBox.width()){
			return OT_SplitY;
		}else
			return OT_SplitX;
	}
}

int GenerativeHistory::layer(int nodeId) const{
	return _hierarchyBoxes[nodeId]->layer;
}
void GenerativeHistory::setAbstractLevel(int nodeId,int L){
	_hierarchyBoxes[nodeId]->abstractLevel=L;
}
int GenerativeHistory::abstractLevel(int nodeId) const{
	return _hierarchyBoxes[nodeId]->abstractLevel;
}

bool GenerativeHistory::isRightChildOf(int nodeId,int pid) const{
	if(pid==-1)return false;
	return nodeId==rightBoxId(pid);
}
void GenerativeHistory::setLayer(int nodeId,int L){
	_hierarchyBoxes[nodeId]->layer=L;
}

int GenerativeHistory::computeLayersForSubTree(int rootNodeId,int startLayerId){

	if(leftBoxId(rootNodeId)==-1){
		setLayer(rootNodeId,startLayerId);
		return startLayerId;
	}else{
		int layer=computeLayersForSubTree(leftBoxId(rootNodeId),startLayerId);

		_hierarchyBoxes[rootNodeId]->layer=startLayerId;
		OperationType otMe=operationType(rootNodeId);
		if(otMe==OT_Delayer){
			layer=computeLayersForSubTree(rightBoxId(rootNodeId),layer+1);
		}else
			layer=computeLayersForSubTree(rightBoxId(rootNodeId),startLayerId);

		return layer;
	}
}

void GenerativeHistory::computeLayers(){
	if(rootBox()==-1)return;
	computeLayersForSubTree(rootBox(),0);
}

void GenerativeHistory::boxesOfAbstractionLevels(std::vector<std::vector<int>>& bset){
	if(rootBox()==-1)return;

	computeAbstractionLevels();
	int Lnum=abstractionLevelNum();
	bset.resize(Lnum);

	std::vector<int> myStack;
	myStack.push_back(rootBox());
	bset[0].push_back(rootBox());
	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();

		int left=leftBoxId(curr);
		int right=rightBoxId(curr);

		switch(operationType(curr)){
			case OT_Delayer:{
				myStack.push_back(right);
				myStack.push_back(left);
				if(!isLeafNode(right)){
					int LofRightChild=abstractLevel(right);
					int L=abstractLevel(curr);
					for(int j=LofRightChild-1;j<Lnum;++j){
						addUniqueValue(bset[j],right);
					}
				}
							}
							break;
			case OT_SplitY:
			case OT_SplitX:{
				Box leftBox=boxOf(left);
				Box rightBox=boxOf(right);
				int L=abstractLevel(curr);
				for(int j=L;j<Lnum;++j){
					addUniqueValue(bset[j],left);
					addUniqueValue(bset[j],right);
				}
				myStack.push_back(right);
				myStack.push_back(left);
						   }
						   break;
			case OT_Undefined:{
				int L=abstractLevel(curr);
				for(int j=L;j<Lnum;++j){
					addUniqueValue(bset[j],curr);
				}
							  }
							  break;
		}
	}
}

void GenerativeHistory::boxesOfLayers(std::vector<std::vector<int>>& bset){
	if(rootBox()==-1)return;
	computeLayers();
	int Lnum=layerNum();
	bset.resize(Lnum);

	std::vector<int> myStack;
	myStack.push_back(rootBox());

	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		if(curr==-1)continue;
		int L=layer(curr);
		bset[L].push_back(curr);
		int left=leftBoxId(curr);
		int right=rightBoxId(curr);

		myStack.push_back(right);
		myStack.push_back(left);
	}
}


void GenerativeHistory::setp(DecompCandidate dc,int index)
{
	if (dc.dim==0)
	{
		_hierarchyBoxes[index]->otype=OT_SplitX;
	}
	if (dc.dim==1)
	{
		_hierarchyBoxes[index]->otype=OT_SplitY;
	}
	if (dc.dim==2)
	{
		_hierarchyBoxes[index]->otype=OT_Delayer;
	}

	std::vector<int>indexlista;
	indexlista.clear();
	indexlista.resize(_hierarchyBoxes[0]->contentBoxes.size());
	for (int j=0;j<dc.indicesOfPartA.size();j++)
	{
		indexlista[dc.indicesOfPartA[j]]=1;
	}
	std::vector<int>indexlistb;
	indexlistb.clear();
	indexlistb.resize(_hierarchyBoxes[0]->contentBoxes.size());
	for (int j=0;j<dc.indicesOfPartB.size();j++)
	{
		indexlistb[dc.indicesOfPartB[j]]=1;
	}

	std::vector<int>indexlist;
	indexlist.clear();
	indexlist.resize(_hierarchyBoxes[0]->contentBoxes.size());
	for (int j=0;j<dc.indicesOfPartB.size();j++)
	{
		indexlist[dc.indicesOfPartB[j]]=1;
	}
	for (int j=0;j<dc.indicesOfPartA.size();j++)
	{
		indexlist[dc.indicesOfPartA[j]]=1;
	}
	_hierarchyBoxes[index]->m_boxIndices=indexlist;
	_hierarchyBoxes[leftBoxId(index)]->m_boxIndices=indexlista;
	_hierarchyBoxes[rightBoxId(index)]->m_boxIndices=indexlistb;

}
void GenerativeHistory::computeAbstractionLevels(){
	if(rootBox()==-1)return;
	computeLayers();

	std::vector<int> myStack;

	myStack.push_back(rootBox());

	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		if(curr==-1)continue;

		int pid=parentBoxId(curr);
		if(pid==-1){
			setAbstractLevel(curr,0);
		}else if(layer(curr)==layer(pid)){
			OperationType opPare=operationType(pid);
			OperationType opMe=operationType(curr);
			if(opMe==OT_Delayer||opMe==OT_Undefined)

				setAbstractLevel(curr,abstractLevel(pid));
			else{
				int firstNoneDelayer=pid;
				while(pid!=-1&&layer(pid)==layer(curr)&&operationType(pid)==OT_Delayer){
					firstNoneDelayer=pid;
					pid=parentBoxId(pid);
				}

				if(opMe==operationType(firstNoneDelayer)|| (operationType(firstNoneDelayer)==OT_Delayer&&pid!=-1&&layer(pid)==layer(curr)&&operationType(pid)==operationType(curr)))
					setAbstractLevel(curr,abstractLevel(firstNoneDelayer));
				else
					setAbstractLevel(curr,abstractLevel(firstNoneDelayer)+1);

			}
		}else{
			setAbstractLevel(curr,0);
		}

		int left=leftBoxId(curr);
		int right=rightBoxId(curr);

		myStack.push_back(right);
		myStack.push_back(left);
	}

	std::vector<int> abstractLevelNumAtEachLayer;
	abstractLevelNumAtEachLayer.assign(layerNum(),0);
	for(int i=0;i<nodeNum();++i){
		int L=layer(i);
		int a=abstractLevel(i);
		if(a>abstractLevelNumAtEachLayer[L])
			abstractLevelNumAtEachLayer[L]=a;
	}

	for(int i=0;i+1<abstractLevelNumAtEachLayer.size();++i){
		abstractLevelNumAtEachLayer[i+1]+=abstractLevelNumAtEachLayer[i]+1;
	}

	abstractLevelNumAtEachLayer[0]=0;

	for(int i=0;i<nodeNum();++i){
		int L=layer(i);
		int a=abstractLevel(i);
		setAbstractLevel(i,abstractLevelNumAtEachLayer[L]+a);
	}

}
int GenerativeHistory::layerNum(){
	int maxL=-1;
	for(int i=0;i<nodeNum();++i){
		if(maxL<layer(i))
			maxL=layer(i);
	}
	return maxL+1;
}
int GenerativeHistory::abstractionLevelNum(){
	int maxL=-1;
	for(int i=0;i<nodeNum();++i){
		if(maxL<abstractLevel(i))
			maxL=abstractLevel(i);
	}
	return maxL+1;
}
OperationResult GenerativeHistory::split(int pid,int pos, int dim){
	HierarchyNode *pnode=_hierarchyBoxes[pid];
	HierarchyNode* leftNode=allocateNewHierarchyNode();
	HierarchyNode* rightNode=allocateNewHierarchyNode();
	leftNode->parentBoxId=pid;
	rightNode->parentBoxId=pid;
	Box::splitBox(pnode->box,pos,dim,leftNode->box,rightNode->box);
	pnode->leftBoxId=_hierarchyBoxes.size()-2;
	pnode->rightBoxId=_hierarchyBoxes.size()-1;
	return OperationResult(pnode->leftBoxId,pnode->rightBoxId);
}

OperationResult GenerativeHistory::delayer(int pid,Box& newBoxA,Box& newBoxB){
	HierarchyNode *pnode=_hierarchyBoxes[pid];
	HierarchyNode* leftNode=allocateNewHierarchyNode();
	HierarchyNode* rightNode=allocateNewHierarchyNode();
	leftNode->parentBoxId=pid;
	rightNode->parentBoxId=pid;
	pnode->leftBoxId=_hierarchyBoxes.size()-2;
	pnode->rightBoxId=_hierarchyBoxes.size()-1;
	leftNode->box=pnode->box;
	rightNode->box=newBoxB;
	return OperationResult(pnode->leftBoxId,pnode->rightBoxId);
}

void  GenerativeHistory::nodeAtLevel(std::vector<std::vector<int>>& tmp){
	if(_rootBoxId==-1||_hierarchyBoxes.empty())return;

	int Lnum=levelNum();
	if(tmp.size()!=Lnum){
		tmp.resize(Lnum);
	}

	std::vector<int> myStack;
	myStack.push_back(_rootBoxId);
	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		int tL=level(curr);
		tmp[tL].push_back(curr);

		if(rightBoxId(curr)!=-1)
			myStack.push_back(rightBoxId(curr));
		if(leftBoxId(curr)!=-1)
			myStack.push_back(leftBoxId(curr));
	}
}
std::vector<int>GenerativeHistory::getChildrenNode(int nodeId)
{
	std::vector<int> nodelist;
	nodelist.clear();
	HierarchyNode *pnode=_hierarchyBoxes[nodeId];

	nodelist.push_back(nodeId);
	int i0=nodeId;
	int step=0;
	while(step<nodelist.size())
	{
		i0=nodelist[step];
		HierarchyNode* node0=_hierarchyBoxes[i0];
		if (node0->leftBoxId!=-1)
		{
			nodelist.push_back(node0->leftBoxId);
		}
		if (node0->rightBoxId!=-1)
		{
			nodelist.push_back(node0->rightBoxId);
		}
		step++;
	}


	std::vector<int> nodelist1;
	nodelist1.clear();
	nodelist1.resize(nodeNum());
	for (int i=0;i<nodeNum();i++)
	{
		for (int j=0;j<int(nodelist.size());j++)
		{
			if (i>nodelist[j])
			{
				nodelist1[i]++;
			}
		}
	}
	for (int j=0;j<int(nodelist.size());j++)
	{
		nodelist1[nodelist[j]]=-1;
	}
	return nodelist1;

}
void GenerativeHistory::newhist(GenerativeHistory hist1,std::vector<int> selectlist)
{
	int droot=0;
	for (int i=0;i<int(selectlist.size());i++)
	{
		if (selectlist[i]==-1)
		{
			droot=i;
			break;
		}
	}
	int index=0;
	for (int i=0;i<hist1.nodeNum();i++)
	{

		if (selectlist[i]!=-1)
		{
			HierarchyNode *pnode=hist1._hierarchyBoxes[i];
			int leftid=pnode->leftBoxId;
			int rightid=pnode->rightBoxId;
			int pid=pnode->parentBoxId;
			HierarchyNode* nNode=allocateNewHierarchyNode();
			if (pid==-1)
			{
				_hierarchyBoxes[index]->parentBoxId=-1;
			}
			else
			{
				_hierarchyBoxes[index]->parentBoxId=pid-selectlist[pid];
			}
			if (leftid==-1)
			{
				_hierarchyBoxes[index]->leftBoxId=-1;
			} 
			else
			{
				if (leftid==droot)
				{
					_hierarchyBoxes[index]->leftBoxId=1000;
				}
				else
				{
					_hierarchyBoxes[index]->leftBoxId=leftid-selectlist[leftid];
				}

			}
			if (rightid==-1)
			{
				_hierarchyBoxes[index]->rightBoxId=-1;
			} 
			else
			{
				if (rightid==droot)
				{
					_hierarchyBoxes[index]->rightBoxId=1000;
				}
				else
				{
					_hierarchyBoxes[index]->rightBoxId=rightid-selectlist[rightid];
				}

			}
			nodeData(i-selectlist[i]).setData(hist1.nodeData(i));
			int nbox=hist1.nodeData(0).size();
			SetContentBoxesIndex(i-selectlist[i],hist1._hierarchyBoxes[i]->m_boxIndices );
			_hierarchyBoxes[i-selectlist[i]]->box=hist1._hierarchyBoxes[i]->box;
			index++;
		}
	}

}

bool GenerativeHistory::iseaqual(std::vector<int>list0,std::vector<int>list1)
{
	int n=list0.size();
	for (int i=0;i<n;i++)
	{
		if (list0[i]!=list1[i])
		{
			return false;
		}
	}
	return true;
}
bool GenerativeHistory::iseaqual(GenerativeHistory hist1,int hn0,int hn1)
{
	HierarchyNode* node0=_hierarchyBoxes[hn0];
	HierarchyNode* node1=hist1._hierarchyBoxes[hn1];
	if (!iseaqual(node0->m_boxIndices,node1->m_boxIndices))
	{
		return false;
	}
	std::vector<int> myStack0;
	myStack0.push_back(hn0);
	std::vector<int> myStack1;
	myStack1.push_back(hn1);
	bool is=false;
	bool a=myStack0.empty();
	bool b=myStack1.empty();
	while(!(myStack0.empty()||myStack1.empty()))
	{
		HierarchyNode* cnode0=_hierarchyBoxes[myStack0.back()] ;
		HierarchyNode* cnode1=hist1._hierarchyBoxes[myStack1.back()];
		int i0=myStack0.back();
		int i1=myStack1.back();

		myStack0.pop_back();
		myStack1.pop_back();
		if (isLeafNode(i0)&&hist1.isLeafNode(i1))
		{
			continue;
		}
		else
		{
			if ((!isLeafNode(i0))&&(!hist1.isLeafNode(i1)))
			{
				int i0l=cnode0->leftBoxId;
				int i0r=cnode0->rightBoxId;
				int i1l=cnode1->leftBoxId;
				int i1r=cnode1->rightBoxId;
				if (i0l==1000)
				{
					i0l=i0r;
				}
				if (i0r==1000)
				{
					i0r=i0l;
				}
				if (i1l==1000)
				{
					i1l=i1r;
				}
				if (i1r==1000)
				{
					i1r=i0l;
				}
				if (iseaqual(_hierarchyBoxes[i0l]->m_boxIndices,hist1._hierarchyBoxes[i1l]->m_boxIndices)&&iseaqual(_hierarchyBoxes[i0r]->m_boxIndices,hist1._hierarchyBoxes[i1r]->m_boxIndices))
				{
					myStack0.push_back(i0l);
					myStack0.push_back(i0r);
					myStack1.push_back(i1l);
					myStack1.push_back(i1r);
				}
				else
				{
					if (iseaqual(_hierarchyBoxes[i0l]->m_boxIndices,hist1._hierarchyBoxes[i1r]->m_boxIndices)&&iseaqual(_hierarchyBoxes[i0r]->m_boxIndices,hist1._hierarchyBoxes[i1l]->m_boxIndices))
					{
						myStack0.push_back(i0l);
						myStack0.push_back(i0r);
						myStack1.push_back(i1r);
						myStack1.push_back(i1l);
					}
					else
					{
						is=false;
						break;
					}
				}
			}
			else
			{

				is=false;
				break;
			}
		}


	}
	if (myStack0.empty()&&myStack1.empty())
	{
		is=true;
	}
	else
	{
		is=false;
	}
	return is;
}
void GenerativeHistory::AddSubtree(GenerativeHistory hist1,std::vector<int>nodelist,int parent)
{
	std::vector<int>list;
	list.clear();
	for (int i=0;i<nodelist.size();i++)
	{
		if (nodelist[i]==-1)
		{
			list.push_back(i);
		}
	}
	int index=nodeNum();
	HierarchyNode* nNode=allocateNewHierarchyNode();
	nNode->parentBoxId=parent;
	_hierarchyBoxes[index]->parentBoxId=parent;

	if (_hierarchyBoxes[parent]->leftBoxId>_hierarchyBoxes[parent]->rightBoxId )
	{
		_hierarchyBoxes[parent]->leftBoxId=index;
	}
	else
	{
		_hierarchyBoxes[parent]->rightBoxId=index;
	}
	nodeData(index).setData(hist1.nodeData(list[0]));	
	SetContentBoxesIndex(index,hist1._hierarchyBoxes[list[0]]->m_boxIndices);
	_hierarchyBoxes[index]->box=hist1._hierarchyBoxes[list[0]]->box;
	for (int i=1;i<int(list.size());i++)
	{
		HierarchyNode* nNode=allocateNewHierarchyNode();
	}
	for (int i=0;i<int(list.size());i++)
	{
		if (!(hist1.isLeafNode(list[i])))
		{
			int left=hist1.leftBoxId(list[i]);
			int right=hist1.rightBoxId(list[i]);
			int dleft=0;
			int dright=0;
			for (int j=0;j<int(list.size());j++)
			{
				if (list[j]==left)
				{
					dleft=j;
				}
				if (list[j]==right)
				{
					dright=j;
				}
			}
			int leftindex=index+dleft;
			int rightindex=index+dright;
			int pindex=i+index;
			_hierarchyBoxes[leftindex]->parentBoxId=pindex;
			_hierarchyBoxes[rightindex]->parentBoxId=pindex;
			_hierarchyBoxes[pindex]->leftBoxId=leftindex;
			_hierarchyBoxes[pindex]->rightBoxId=rightindex;

			nodeData(leftindex).setData(hist1.nodeData(left));
			SetContentBoxesIndex(leftindex,hist1._hierarchyBoxes[left]->m_boxIndices);
			_hierarchyBoxes[leftindex]->box=hist1._hierarchyBoxes[left]->box;
			nodeData(rightindex).setData(hist1.nodeData(right));
			SetContentBoxesIndex(rightindex,hist1._hierarchyBoxes[right]->m_boxIndices);
			_hierarchyBoxes[rightindex]->box=hist1._hierarchyBoxes[right]->box;
		}
	}
}
std::vector<int>GenerativeHistory::GetContentBoxesIndex(int index)
{
	return _hierarchyBoxes[index]->m_boxIndices;
}
void GenerativeHistory::SetContentBoxesIndex(int index,std::vector<int>list)
{
	std::vector<int>clist;
	clist.clear();
	clist.resize(list.size());
	for (int i=0;i<int(list.size());i++)
	{
		clist[i]=list[i];
	}
	_hierarchyBoxes[index]->m_boxIndices=clist;
}
void GenerativeHistory::SetContentBoxesIndex(int index,int n,std::vector<int>list)
{
	std::vector<int>clist;
	clist.clear();
	clist.resize(n);
	for (int i=0;i<int(list.size());i++)
	{
		clist[list[i]]=1;
	}
	_hierarchyBoxes[index]->m_boxIndices=clist;
}
std::vector<int>GenerativeHistory::AddirstNode(GenerativeHistory hist,std::vector<int> selectlist)
{
	int id=0;
	for (int i=0;i<hist.nodeNum();i++)
	{
		if (selectlist[i]==-1)
		{
			id=i;
			break;
		}
	}
	int index=nodeNum();
	HierarchyNode* nNode=allocateNewHierarchyNode();
	_hierarchyBoxes[index]->parentBoxId=hist.parentBoxId(id);
	if(_hierarchyBoxes[hist.parentBoxId(id)]->leftBoxId>_hierarchyBoxes[hist.parentBoxId(id)]->rightBoxId)
	{
		_hierarchyBoxes[hist.parentBoxId(id)]->leftBoxId=index;
	}
	else
	{
		_hierarchyBoxes[hist.parentBoxId(id)]->rightBoxId=index;
	}

	nodeData(index).setData(hist.nodeData(id));
	SetContentBoxesIndex(index,hist._hierarchyBoxes[id]->m_boxIndices);
	_hierarchyBoxes[index]->box=hist._hierarchyBoxes[id]->box;
	std::vector<int> list;
	list.clear();
	for (int i=0;i<hist.nodeData(0).size();i++)
	{
		for (int j=0;j<hist.nodeData(id).size();j++)
		{
			Box a=hist.nodeData(0)[i];
			Box b=hist.nodeData(id)[j];
			if ((a.x()==b.x())&&(a.y()==b.y())&&(a.height()==b.height())&&(a.width()==b.width()))
			{
				list.push_back(i);
			}
		}
	}
	return list;
}

PairBoxes GenerativeHistory::historyNode(int boxId) {
	if(!isLeafNode(boxId)){
		Box boxA=boxOf(leftBoxId(boxId));
		Box boxB=boxOf(rightBoxId(boxId));
		return PairBoxes(boxA,boxB);
	}else{
		return PairBoxes(boxOf(boxId),boxOf(boxId));
	}

}

#define DistanceL1(x) ((x)<0?-(x):x)
static double boxDistance(Box& boxA,Box& boxB){
	double dx=DistanceL1(boxA.x()-boxB.x());
	double dy=DistanceL1(boxA.y()-boxB.y());
	double dw=DistanceL1(boxA.width()-boxB.width());
	double dh=DistanceL1(boxA.height()-boxB.height());
	return (dw+1)*(dh+1)*(dx+1)*(dy+1);
}

double GenerativeHistory::nodeDistance(PairBoxes& nodeA,PairBoxes& nodeB){
	Box &boxA_1=nodeA.first;
	Box& boxA_2=nodeA.second;
	Box& boxB_1=nodeB.first;
	Box& boxB_2=nodeB.second;
	double d1=boxDistance(boxA_1,boxB_1)*boxDistance(boxA_2,boxB_2);
	double d2=boxDistance(boxA_1,boxB_2)*boxDistance(boxA_2,boxB_1);
	return d1>d2?d1:d2;
}


int GenerativeHistory::findCorrespondenceToMe(PairBoxes& yourNode,double *minD){

	double minDist=FLT_MAX;
	int minIndex=-1;
	for(int i=0;i<_hierarchyBoxes.size();++i){
		PairBoxes myNode=historyNode(i);
		double d=nodeDistance(yourNode,myNode);
		if(d<minDist){
			minIndex=i;
			minDist=d;
		}
	}

	if(minD!=NULL)
		*minD=minDist;
	return minIndex;

}


double GenerativeHistory::findCorrespondenceToYou(GenerativeHistory& hist,std::vector<int>& corTo,std::vector<double> &distToYou){
	Box myRootBox=boxOf(rootBox());
	Box yourRootBox=hist.boxOf(hist.rootBox());
	float xRatio=yourRootBox.width()/(float)myRootBox.width();
	float yRatio=yourRootBox.height()/(float)myRootBox.height();
	float normalizeScale=xRatio>yRatio?xRatio:yRatio;

	corTo.assign(_hierarchyBoxes.size(),-1);
	distToYou.assign(_hierarchyBoxes.size(),FLT_MAX);
	double sum=0;
	for(int i=0;i<_hierarchyBoxes.size();++i){
		PairBoxes hnode=historyNode(i);
		Box& bA=hnode.first;
		Box& bB=hnode.second;
		bA.setX((bA.x()-myRootBox.x())*normalizeScale+yourRootBox.x());
		bA.setY((bA.y()-myRootBox.y())*normalizeScale+yourRootBox.y());
		bA.setWidth(bA.width()*normalizeScale);
		bA.setHeight(bA.height()*normalizeScale);
		bB.setX((bB.x()-myRootBox.x())*normalizeScale+yourRootBox.x());
		bB.setY((bB.y()-myRootBox.y())*normalizeScale+yourRootBox.y());
		bB.setWidth(bB.width()*normalizeScale);
		bB.setHeight(bB.height()*normalizeScale);


		corTo[i]=hist.findCorrespondenceToMe(hnode,&distToYou[i]);


		sum+=distToYou[i];
	}
	return sum/_hierarchyBoxes.size();
}


void GenerativeHistory::saveHistory(char const * fn){
	std::ofstream fout(fn);
	fout<<_hierarchyBoxes.size()<<std::endl;
	for(int i=0;i<_hierarchyBoxes.size();++i){
		Box box=boxOf(i);
		BoxSet& bset=nodeData(i);
		fout<<box.x()<<" "<<box.y()<<" "<<box.width()<<" "<<box.height()<<" "<<	parentBoxId(i)<<" "<<leftBoxId(i)<<" "<<" "<<rightBoxId(i)<<std::endl;
		fout<<bset.size()<<std::endl;
		for(int j=0;j<bset.size();++j){
			box=bset[j];
			fout<<box.x()<<" "<<box.y()<<" "<<box.width()<<" "<<box.height()<<" "<<box.label()<<std::endl;
		}
	}
	fout.close();
}

void GenerativeHistory::clear(){
	for(int i=0;i<_hierarchyBoxes.size();++i)
		delete _hierarchyBoxes[i];
	_hierarchyBoxes.clear();
	_rootBoxId=-1;
}

void GenerativeHistory::debug(){
	openHistory("F:\\Projects\\asymmetrizaltion\\AsymAnalysis\\fromSvn\\AsymAnalysis\\input\\facades_data\\hist\\fac (0).jpg.txt.hist");
}
void GenerativeHistory::openHistory( char const* fn){
	clear();

	std::ifstream fileIn(fn);
	int boxNum=0;
	fileIn>>boxNum;
	if(boxNum==0){
		fileIn.close();
		return;
	}

	_rootBoxId=0;
	for(int i=0;i<boxNum;++i){
		HierarchyNode *node=allocateNewHierarchyNode();
		int x,y,w,h,L;
		fileIn>>x>>y>>w>>h;
		node->box.setX(x);
		node->box.setY(y);
		node->box.setWidth(w);
		node->box.setHeight(h);
		fileIn>>node->parentBoxId>>node->leftBoxId>>node->rightBoxId;
		int cn=0;
		fileIn>>cn;
		if(cn==0)continue;
		node->contentBoxes.resize(cn);
		for(int j=0;j<node->contentBoxes.size();++j){
			fileIn>>x>>y>>w>>h>>L;
			node->contentBoxes[j].setX(x);
			node->contentBoxes[j].setY(y);
			node->contentBoxes[j].setWidth(w);
			node->contentBoxes[j].setHeight(h);
			node->contentBoxes[j].setLabel(L);
		}
	}
	std::cout<<"ok"<<std::endl;
	fileIn.close();

}

int GenerativeHistory::nodeNum() const{
	return _hierarchyBoxes.size();
}


inline double pointDistanceL1(double x1,double y1,double x2,double y2){
	double dx=x1-x2;
	double dy=y1-y2;
	return fabs(dx)+fabs(dy);
}

#define isEqual(x,y) (fabs(x-y)<0.00001)
struct LineSeg1D{
	double x1,y1;
	double x2,y2;
	double distanceTo(LineSeg1D& d){
		double d1=pointDistanceL1(x1,y1,d.x1,d.y1)+pointDistanceL1(x2,y2,d.x2,d.y2);
		double d2=pointDistanceL1(x1,y1,d.x2,d.y2)+pointDistanceL1(x2,y2,d.x1,d.y1);
		return d1<d2?d1:d2;
	}
	bool operator==(const LineSeg1D& line){
		return isEqual(x1,line.x1)&&isEqual(x2,line.x2)&&isEqual(y1,line.y1)&&isEqual(y2,line.y2);
	}
	void translate(double dx,double dy){
		x1+=dx;
		x2+=dx;
		y1+=dy;
		y2+=dy;
	}
	void scale(double sx,double sy){
		x2=(x2-x1)*sx+x1;
		y2=(y2-y1)*sy+y1;
	}
};

void extractLineSeg1DfromBox(Box &box, int dim,LineSeg1D& lineA,LineSeg1D& lineB){

	if(dim==0){
		lineA.x1=box.left();
		lineA.x2=box.right();
		lineA.y1=box.bottom();
		lineA.y2=box.bottom();

		lineB.x1=box.left();
		lineB.x2=box.right();
		lineB.y1=box.top();
		lineB.y2=box.top();
	}else{
		lineA.x1=box.left();
		lineA.x2=box.left();
		lineA.y1=box.bottom();
		lineA.y2=box.top();

		lineB.x1=box.right();
		lineB.x2=box.right();
		lineB.y1=box.bottom();
		lineB.y2=box.top();
	}
}


//dim=0 for horizontal lines, 1 for verti lines
void extractLineSegs(GenerativeHistory& hist,std::vector<int> &nodes,int dim,std::vector<LineSeg1D>& lines,Box bbox){
	lines.clear();
	for(int i=0;i<nodes.size();++i){
		Box box=hist.boxOf(nodes[i]);
		LineSeg1D lineA,lineB;
		extractLineSeg1DfromBox(box,dim,lineA,lineB);
		if(std::find(lines.begin(),lines.end(),lineA)==lines.end())
			lines.push_back(lineA);
		if(std::find(lines.begin(),lines.end(),lineB)==lines.end())
			lines.push_back(lineB);
	}

	for(int i=0;i<lines.size();++i){
		lines[i].x1=(lines[i].x1-bbox.x())/(double)bbox.width();
		lines[i].x2=(lines[i].x2-bbox.x())/(double)bbox.width();
		lines[i].y1=(lines[i].y1-bbox.y())/(double)bbox.height();
		lines[i].y2=(lines[i].y2-bbox.y())/(double)bbox.height();
	}
}

static void findMinCorrespondenceA2B(std::vector<LineSeg1D>& lineSetA,std::vector<LineSeg1D>& lineSetB,std::vector<int>& corA2B,std::vector<double>& distA2B){
	corA2B.resize(lineSetA.size());
	distA2B.resize(lineSetA.size());
	for(int i=0;i<lineSetA.size();++i){
		LineSeg1D LA=lineSetA[i];
		std::vector<double> dist;
		dist.resize(lineSetB.size());
		for(int j=0;j<lineSetB.size();++j){
			LineSeg1D LB=lineSetB[j];
			dist[j]=LA.distanceTo(LB);
		}
		corA2B[i]=std::min_element(dist.begin(),dist.end())-dist.begin();
		distA2B[i]=dist[corA2B[i]];
	}
}

static double lineSetDistanceA2B(std::vector<LineSeg1D>& lineSetA,std::vector<LineSeg1D>& lineSetB){
	std::vector<int> corA2B;
	std::vector<int> corB2A;
	std::vector<double> distA2B;
	std::vector<double> distB2A;
	findMinCorrespondenceA2B(lineSetA,lineSetB,corA2B,distA2B);
	findMinCorrespondenceA2B(lineSetB,lineSetA,corB2A,distB2A);

	double d1=0,d2=0;
	for(int i=0;i<distA2B.size();++i)
		d1+=distA2B[i];
	for(int i=0;i<distB2A.size();++i)
		d2+=distB2A[i];
	return d1>d2?d1:d2;
}

static double histDistanceAtLevel(GenerativeHistory& histA,std::vector<int> &nodesA,GenerativeHistory& histB, std::vector<int>& nodesB){
	if(nodesA.empty()||nodesB.empty())return FLT_MAX;
	Box bboxA=histA.boxOf(histA.rootBox());
	Box bboxB=histB.boxOf(histB.rootBox());

	std::vector<LineSeg1D> verticalLinesA;
	std::vector<LineSeg1D> horizontalLinesA;
	std::vector<LineSeg1D> verticalLinesB;
	std::vector<LineSeg1D> horizontalLinesB;
	extractLineSegs(histA,nodesA,0,horizontalLinesA,bboxA);
	extractLineSegs(histA,nodesA,1,verticalLinesA,bboxA);
	extractLineSegs(histB,nodesB,0,horizontalLinesB,bboxB);
	extractLineSegs(histB,nodesB,1,verticalLinesB,bboxB);
	double dvA2B=lineSetDistanceA2B(verticalLinesA,verticalLinesB);
	double dhA2B=lineSetDistanceA2B(horizontalLinesA,horizontalLinesB);
	return dhA2B+dvA2B;
}

double GenerativeHistory::distanceTo(GenerativeHistory& hist,int myA,int yourB){
	std::vector<std::vector<int>> myLevels;
	boxesOfAbstractionLevels(myLevels);
	std::vector<std::vector<int>> yourLevels;
	hist.boxesOfAbstractionLevels(yourLevels);
	return histDistanceAtLevel(*this,myLevels[myA],hist,yourLevels[yourB]);
}

static void findMinLevelCorrespondenceA2B(GenerativeHistory& histA,GenerativeHistory& histB,std::vector<std::vector<int>>&myLevels,std::vector<std::vector<int>> &yourLevels,std::vector<int>& corA2B,std::vector<double>& distA2B){
	corA2B.resize(myLevels.size());
	distA2B.resize(myLevels.size());
	for(int i=0;i<myLevels.size();++i){
		std::vector<double> dist;
		dist.resize(yourLevels.size());
		for(int j=0;j<yourLevels.size();++j){
			dist[j]=histDistanceAtLevel(histA,myLevels[i],histB,yourLevels[j]);
		}
		corA2B[i]=std::min_element(dist.begin(),dist.end())-dist.begin();
		distA2B[i]=dist[corA2B[i]];
	}
}

double GenerativeHistory::distanceTo2(GenerativeHistory& hist)
{
	if (!(((this->boxOf(this->rootBox()).width()==100)&&(this->boxOf(this->rootBox()).width()>=this->boxOf(this->rootBox()).height()))||((this->boxOf(this->rootBox()).height()==100)&&(this->boxOf(this->rootBox()).height()>=this->boxOf(this->rootBox()).width()))))
	{
		normalize();
	}
	if (!(((hist.boxOf(hist.rootBox()).width()==100)&&(hist.boxOf(hist.rootBox()).width()>=hist.boxOf(hist.rootBox()).height()))||((hist.boxOf(hist.rootBox()).height()==100)&&(hist.boxOf(hist.rootBox()).height()>=hist.boxOf(hist.rootBox()).width()))))
	{
		hist.normalize();
	}
	double t0=maxsimilarity(*this,*this);
	double t1=maxsimilarity(hist,hist);
	double sim=maxsimilarity(*this,hist);
	double d=1-sim/(std::max(t0,t1));
	return d;
}
double GenerativeHistory::maxsimilarity(GenerativeHistory& hist0,GenerativeHistory& hist1)
{

	Box root0=hist0.boxOf(hist0.rootBox());
	Box root1=hist1.boxOf(hist1.rootBox());
	double diagonal=sqrt(double(root0.width()*root0.width()+root0.height()*root0.height()));
	double d=anchoresimilarity(hist0,hist0.rootBox(),hist1,hist1.rootBox(),diagonal);
	return d;
}
double GenerativeHistory::anchoresimilarity(GenerativeHistory& hist0,int index0,GenerativeHistory& hist1,int index1,double diagonal)
{
	double d=0;
	HierarchyNode hn0=*hist0._hierarchyBoxes[index0];
	HierarchyNode hn1=*hist1._hierarchyBoxes[index1];
	if ((hn0.leftBoxId!=-1)&&(hn1.leftBoxId!=-1))
	{
		double w=dist(hn0,hn1,diagonal);
		double w00=anchoresimilarity(hist0,hn0.leftBoxId,hist1,hn1.leftBoxId,diagonal);
		double w01=anchoresimilarity(hist0,hn0.leftBoxId,hist1,hn1.rightBoxId,diagonal);
		double w10=anchoresimilarity(hist0,hn0.rightBoxId,hist1,hn1.leftBoxId,diagonal);
		double w11=anchoresimilarity(hist0,hn0.rightBoxId,hist1,hn1.rightBoxId,diagonal);
		if ((w00+w11)>(w01+w10))
		{
			d=w+w00+w11;
		}
		else
		{
			d=w+w01+w10;
		}

	}
	else
	{
		d=dist(hn0,hn1,diagonal);	
	}
	return d;
}
Box GenerativeHistory::getboundingbox(HierarchyNode& hn0)
{
	Box boundingbox;
	int n=hn0.contentBoxes.size();
	int maxx=0;
	int maxy=0;
	int minx=100;
	int miny=100;
	for (int i=0;i<n;i++)
	{
		Box boxi=hn0.contentBoxes[i];
		if (boxi.x()>maxx)
		{
			maxx=boxi.x();
		}
		if (boxi.x()+boxi.width()>maxx)
		{
			maxx=boxi.x()+boxi.width();
		}
		if (boxi.x()<minx)
		{
			minx=boxi.x();
		}
		if (boxi.x()+boxi.width()<minx)
		{
			minx=boxi.x()+boxi.width();
		}

		if (boxi.y()>maxy)
		{
			maxy=boxi.y();
		}
		if (boxi.y()+boxi.height()>maxy)
		{
			maxy=boxi.y()+boxi.height();
		}
		if (boxi.y()<miny)
		{
			miny=boxi.y();
		}
		if (boxi.y()+boxi.height()<miny)
		{
			miny=boxi.y()+boxi.height();
		}
	}
	boundingbox.setX(minx);
	boundingbox.setY(miny);
	boundingbox.setWidth(maxx-minx);
	boundingbox.setHeight(maxy-miny);
	return boundingbox;
}
double GenerativeHistory::dist(HierarchyNode& hn0,HierarchyNode& hn1,double diagonal)
{
	std::vector<int>h0;
	std::vector<int>h1;
	h0.clear();
	h0.resize(8);
	h1.clear();
	h1.resize(8);
	//00 01 10 11
	Box b0=hn0.box;
	h0[0]=b0.x();
	h0[1]=b0.y();
	h0[2]=b0.x();
	h0[3]=b0.y()+b0.height();
	h0[4]=b0.x()+b0.width();
	h0[5]=b0.y();
	h0[6]=b0.x()+b0.width();
	h0[7]=b0.y()+b0.height();

	Box b1=hn1.box;
	h1[0]=b1.x();
	h1[1]=b1.y();
	h1[2]=b1.x();
	h1[3]=b1.y()+b1.height();
	h1[4]=b1.x()+b1.width();
	h1[5]=b1.y();
	h1[6]=b1.x()+b1.width();
	h1[7]=b1.y()+b1.height();

	double d=0.0;
	for (int i=0;i<4;i++)
	{
		double disti=diagonal;
		for (int j=0;j<4;j++)
		{
			double distij=sqrt(double((h0[2*i]-h1[2*j])*(h0[2*i]-h1[2*j])+(h0[2*i+1]-h1[2*i+1])*(h0[2*j+1]-h1[2*j+1])));
			if (distij<disti)
			{
				disti=distij;
			}	
		}
		if (disti>d)
		{
			d=disti;
		}
	}
	for (int i=0;i<4;i++)
	{
		double disti=diagonal;
		for (int j=0;j<4;j++)
		{
			double distij=sqrt(double((h0[2*j]-h1[2*i])*(h0[2*j]-h1[2*i])+(h0[2*j+1]-h1[2*i+1])*(h0[2*j+1]-h1[2*i+1])));
			if (distij<disti)
			{
				disti=distij;
			}	
		}
		if (disti>d)
		{
			d=disti;
		}
	}
	d=1-d/diagonal;
	return d;


}
void GenerativeHistory::normalize2()
{
	Box root=boxOf(rootBox());
	int x0=root.x();
	int y0=root.y();
	double h0=double(root.height());
	double w0=double(root.width());
	double h=100;
	double w=100;
	double scalex=w/w0;
	double scaley=h/h0;
	int tx=x0;
	int ty=y0;

	for (int i=0;i<_hierarchyBoxes.size();i++)
	{
		int xi=_hierarchyBoxes[i]->box.x();
		int yi=_hierarchyBoxes[i]->box.y();
		int wi=_hierarchyBoxes[i]->box.width();
		int hi=_hierarchyBoxes[i]->box.height();
		int xii=(xi-tx)*scalex;
		int yii=(yi-ty)*scaley;
		int wii=wi*scalex;
		int hii=hi*scaley;
		_hierarchyBoxes[i]->box.setX(xii);
		_hierarchyBoxes[i]->box.setY(yii);
		_hierarchyBoxes[i]->box.setWidth(wii);
		_hierarchyBoxes[i]->box.setHeight(hii);
		int n=_hierarchyBoxes[i]->contentBoxes.size();
		for (int j=0;j<n;j++)
		{
			int xj=_hierarchyBoxes[i]->contentBoxes[j].x();
			int yj=_hierarchyBoxes[i]->contentBoxes[j].y();
			int wj=_hierarchyBoxes[i]->contentBoxes[j].width();
			int hj=_hierarchyBoxes[i]->contentBoxes[j].height();
			int xjj=(xj-tx)*scalex;
			int yjj=(yj-ty)*scaley;
			int wjj=wj*scalex;
			int hjj=hj*scaley;
			_hierarchyBoxes[i]->contentBoxes[j].setX(xjj);
			_hierarchyBoxes[i]->contentBoxes[j].setY(yjj);
			_hierarchyBoxes[i]->contentBoxes[j].setWidth(wjj);
			_hierarchyBoxes[i]->contentBoxes[j].setHeight(hjj);
		}
	}
}
void GenerativeHistory::normalize0()
{
	Box root=boxOf(rootBox());
	int x0=root.x();
	int y0=root.y();
	double h0=double(root.height());
	double w0=double(root.width());
	double scalexy=0;
	double h=100;
	double w=100;
	if (w0>h0)
	{
		scalexy=w/w0;
	}
	else
	{
		scalexy=h/h0;
	}

	int tx=x0;
	int ty=y0;
	int tx1=50-0.5*w0*scalexy;
	int ty1=50-0.5*h0*scalexy;

	for (int i=0;i<_hierarchyBoxes.size();i++)
	{
		int xi=_hierarchyBoxes[i]->box.x();
		int yi=_hierarchyBoxes[i]->box.y();
		int wi=_hierarchyBoxes[i]->box.width();
		int hi=_hierarchyBoxes[i]->box.height();
		int wii=wi*scalexy;
		int hii=hi*scalexy;
		int xii=(xi-tx)*scalexy+tx1;//+50
		int yii=(yi-ty)*scalexy+ty1;//+50

		_hierarchyBoxes[i]->box.setX(xii);
		_hierarchyBoxes[i]->box.setY(yii);
		_hierarchyBoxes[i]->box.setWidth(wii);
		_hierarchyBoxes[i]->box.setHeight(hii);
	}
}
void GenerativeHistory::normalize()
{
	Box root=boxOf(rootBox());
	int x0=root.x();
	int y0=root.y();
	double h0=double(root.height());
	double w0=double(root.width());
	double scalexy=0;
	double h=100;
	double w=100;
	if (w0>h0)
	{
		scalexy=w/w0;
	}
	else
	{
		scalexy=h/h0;
	}

	int tx=x0;
	int ty=y0;
	int tx1=50-0.5*w0*scalexy;
	int ty1=50-0.5*h0*scalexy;

	for (int i=0;i<_hierarchyBoxes.size();i++)
	{
		int xi=_hierarchyBoxes[i]->box.x();
		int yi=_hierarchyBoxes[i]->box.y();
		int wi=_hierarchyBoxes[i]->box.width();
		int hi=_hierarchyBoxes[i]->box.height();
		int wii=wi*scalexy;
		int hii=hi*scalexy;
		int xii=(xi-tx)*scalexy+tx1;//+50
		int yii=(yi-ty)*scalexy+ty1;//+50

		_hierarchyBoxes[i]->box.setX(xii);
		_hierarchyBoxes[i]->box.setY(yii);
		_hierarchyBoxes[i]->box.setWidth(wii);
		_hierarchyBoxes[i]->box.setHeight(hii);
		int n=_hierarchyBoxes[i]->contentBoxes.size();
		for (int j=0;j<n;j++)
		{
			int xj=_hierarchyBoxes[i]->contentBoxes[j].x();
			int yj=_hierarchyBoxes[i]->contentBoxes[j].y();
			int wj=_hierarchyBoxes[i]->contentBoxes[j].width();
			int hj=_hierarchyBoxes[i]->contentBoxes[j].height();
			int wjj=wj*scalexy;
			int hjj=hj*scalexy;
			int xjj=(xj-tx)*scalexy+tx1;//+50
			int yjj=(yj-ty)*scalexy+ty1;//+50
			if (xjj<0)
			{
				int lll=0;
			}

			_hierarchyBoxes[i]->contentBoxes[j].setX(xjj);
			_hierarchyBoxes[i]->contentBoxes[j].setY(yjj);
			_hierarchyBoxes[i]->contentBoxes[j].setWidth(wjj);
			_hierarchyBoxes[i]->contentBoxes[j].setHeight(hjj);
		}
	}
}
double GenerativeHistory::distanceTo(GenerativeHistory& hist,int *bestLevelOfYou){
	computeAbstractionLevels();
	hist.computeAbstractionLevels();
	int LnumA=abstractionLevelNum();
	int LnumB=hist.abstractionLevelNum();
	std::vector<std::vector<int>> myLevels;
	boxesOfAbstractionLevels(myLevels);
	std::vector<std::vector<int>> yourLevels;
	hist.boxesOfAbstractionLevels(yourLevels);

	std::vector<int> corA2B;
	std::vector<int> corB2A;
	std::vector<double> distA2B;
	std::vector<double> distB2A;

	findMinLevelCorrespondenceA2B(*this,hist,myLevels,yourLevels,corA2B,distA2B);
	findMinLevelCorrespondenceA2B(hist,*this,yourLevels,myLevels,corB2A,distB2A);

	double d=0;
	for(int i=0;i<distA2B.size();++i)
		d+=distA2B[i];
	for(int i=0;i<distB2A.size();++i)
		d+=distB2A[i];
	if(bestLevelOfYou!=NULL){
		*bestLevelOfYou=*std::max_element(corA2B.begin(),corA2B.end());
	}
	return d;

}

void GenerativeHistory::normalizedHistory(int x,int y, float scaleRatio){
	if(rootBox()==-1||_hierarchyBoxes.empty())return;
	Box rBox=boxOf(rootBox());
	for(int i=0;i<_hierarchyBoxes.size();++i){
		Box &box=_hierarchyBoxes[i]->box;
		int newX=(box.x()-rBox.x())*scaleRatio+x;
		int newY=(box.y()-rBox.y())*scaleRatio+y;
		int w=box.width()*scaleRatio;
		int h=box.height()*scaleRatio;
		box.setX(newX);
		box.setY(newY);
		box.setWidth(w);
		box.setHeight(h);
	}

}

void GenerativeHistory::retargetingInside(int rightChildId,int dx,int dy){
	int pid=parentBoxId(rightChildId);
	Box pbox=boxOf(pid);
	Box myBox=boxOf(rightChildId);
	int targetLeft=myBox.left()+dx;
	int targetRight=myBox.right()+dx;
	int targetBottom=myBox.bottom()+dy;
	int targetTop=myBox.top()+dy;

	switch(operationType(pid)){
		case OT_SplitX:
			if(targetLeft<pbox.left())
				dx=pbox.left()-myBox.left();
			else if(targetLeft>pbox.right())
				dx=pbox.right()-myBox.left();
			retargeting(rightChildId,dx,0,-dx,0);
			retargeting(brotherNodeId(rightChildId),0,0,dx,0);
			break;
		case OT_SplitY:
			if(targetBottom<pbox.bottom())
				dy=pbox.bottom()-myBox.bottom();
			else if(targetBottom>pbox.top())
				dy=pbox.top()-myBox.bottom();
			retargeting(rightChildId,0,dy,0,-dy);
			retargeting(brotherNodeId(rightChildId),0,0,0,dy);

			break;
		case OT_Delayer:
			{
				if(targetLeft<pbox.left())
					dx=pbox.left()-myBox.left();
				else if(targetRight>pbox.right())
					dx=pbox.right()-myBox.right();

				if(targetBottom<pbox.bottom())
					dy=pbox.bottom()-myBox.bottom();
				else if(targetTop>pbox.top())
					dy=pbox.top()-myBox.top();
				retargeting(rightChildId,dx,dy,0,0);
			}
			break;
	}

}


void  GenerativeHistory::retargeting(int nodeId,int dx,int dy,int dw,int dh){
	Box &myBox=_hierarchyBoxes[nodeId]->box;
	double xscale=(myBox.width()+dw)/(double)myBox.width();
	double yscale=(myBox.height()+dh)/(double)myBox.height();

	switch(operationType(nodeId)){
		case OT_Delayer:{
			retargeting(leftBoxId(nodeId),dx,dy,dw,dh);
			int rightId=rightBoxId(nodeId);
			Box rightBox=boxOf(rightId);

			double xposition[4];
			xposition[0]=myBox.left();
			xposition[1]=rightBox.left();
			xposition[2]=rightBox.right();
			xposition[3]=myBox.right();

			double newxposition[4];
			newxposition[0]=xposition[0];
			newxposition[1]=(xposition[1]-xposition[0])*xscale+xposition[0];
			newxposition[2]=(xposition[2]-xposition[0])*xscale+xposition[0];
			newxposition[3]=(xposition[3]-xposition[0])*xscale+xposition[0];
			int rightDx=newxposition[1]-xposition[1]+dx;
			int rightDw=fabs(newxposition[2]-newxposition[1])-rightBox.width();


			double yposition[4];
			yposition[0]=myBox.bottom();
			yposition[1]=rightBox.bottom();
			yposition[2]=rightBox.top();
			yposition[3]=myBox.top();

			double newyposition[4];
			newyposition[0]=yposition[0];
			newyposition[1]=(yposition[1]-yposition[0])*yscale+yposition[0];
			newyposition[2]=(yposition[2]-yposition[0])*yscale+yposition[0];
			newyposition[3]=(yposition[3]-yposition[0])*yscale+yposition[0];
			int rightDy=newyposition[1]-yposition[1]+dy;
			int rightDh=fabs(newyposition[2]-newyposition[1])-rightBox.height();


			retargeting(rightBoxId(nodeId),rightDx,rightDy,rightDw,rightDh);

						}
						break;
		case OT_SplitX:{
			Box leftBox=boxOf(leftBoxId(nodeId));
			Box rightBox=boxOf(rightBoxId(nodeId));
			int leftWidth=xscale*leftBox.width();
			int rightWidth=myBox.width()+dw-leftWidth;
			int dwLeft=leftWidth-leftBox.width();
			int dwRight=rightWidth-rightBox.width();

			retargeting(leftBoxId(nodeId),dx,dy,dwLeft,dh);
			retargeting(rightBoxId(nodeId),dwLeft+dx,dy,dwRight,dh);

					   }
					   break;
		case OT_SplitY:
			{
				Box leftBox=boxOf(leftBoxId(nodeId));
				Box rightBox=boxOf(rightBoxId(nodeId));
				int leftHeight=yscale*leftBox.height();
				int rightHeight=myBox.height()+dh-leftHeight;
				int dhLeft=leftHeight-leftBox.height();
				int dhRight=rightHeight-rightBox.height();

				retargeting(leftBoxId(nodeId),dx,dy,dw,dhLeft);
				retargeting(rightBoxId(nodeId),dx,dy+dhLeft,dw,dhRight);


			}
			break;
		default:	
			break;
	}

	//x orientation
	if (dw!=0)
	{
		int x0=myBox.x()+dx;
		int y0=myBox.y()+dy;
		int w0=myBox.width()+dw;
		int h0=myBox.height()+dh;
		int containsize=_hierarchyBoxes[nodeId]->contentBoxes.size();
		Box& b=_hierarchyBoxes[nodeId]->contentBoxes[0];
		int width0=_hierarchyBoxes[nodeId]->sourcewidth;
		std::vector<int>end;
		end.clear();
		int xi=b.x();
		int yi=b.y();
		for (int i=0;i<containsize;i++)
		{
			Box& b=_hierarchyBoxes[nodeId]->contentBoxes[i];
			if (abs(b.y()-yi)>2)
			{
				end.push_back(i-1);
				yi=b.y();
			}

		}
		end.push_back(containsize-1);
		int n1row=end[0];
		for (int i=1;i<end.size();i++)
		{
			if ((end[i]-end[i-1])>n1row)
			{
				n1row=end[i]-end[i-1];
			}
		}
		float delta=0.2;
		if (dw>0)
		{			
			int nsize=(w0-delta*width0)/((1+delta)*width0);
			if (nsize==0)
			{
				nsize++;
			}

			int width11=w0/(nsize/delta+nsize+1);
			int width00=width11/delta;
			float scalew=width00/width0;
			int lastsize=-1;
			for (int i=0;i<end.size();i++)
			{
				for (int j=0;j<(end[i]-lastsize);j++)
				{
					Box& bj=_hierarchyBoxes[nodeId]->contentBoxes[lastsize+j+1];
					bj.setX( x0+(width11+width00)*(j+1)-width00);
					bj.setWidth(width00);
				}
				for (int j=end[i]-lastsize;j<nsize;j++)
				{
					Box& b=_hierarchyBoxes[nodeId]->contentBoxes[end[i]];
					Box bi(b);
					bi.setX(x0+(width11+width00)*(j+1)-width00);
					bi.setWidth(width00);
					_hierarchyBoxes[nodeId]->contentBoxes.push_back(bi);

				}
				lastsize=end[i];	
			}
		}
		else
		{
			if (dw<0)
			{
				int nsize=(w0-delta*width0)/((1+delta)*width0);
				if (nsize==0)
				{
					nsize++;
				}
				int width11=w0/(nsize/delta+nsize+1);
				int width00=width11/delta;

				int lastsize=-1;
				std::vector<int>er;
				er.clear();
				for (int i=0;i<end.size();i++)
				{
					for (int j=0;j<(end[i]-lastsize);j++)
					{
						Box& bj=_hierarchyBoxes[nodeId]->contentBoxes[lastsize+j+1];
						bj.setX( x0+(width11+width00)*(j+1)-width00);
						bj.setWidth(width00);
					}
					for (int j=nsize;j<end[i]-lastsize;j++)
					{
						er.push_back(lastsize+j+1);
					}
					lastsize=end[i];	
				}
				std::vector<Box>avb;
				avb.clear();
				for (int i=0;i<_hierarchyBoxes[nodeId]->contentBoxes.size();i++)
				{
					int have=0;
					for (int j=0;j<er.size();j++)
					{
						if (i==er[j])
						{
							have=1;
						}
					}
					if (have==0)
					{
						Box& bi=_hierarchyBoxes[nodeId]->contentBoxes[i];
						Box bj(bi);
						avb.push_back(bj);
					}
				}
				_hierarchyBoxes[nodeId]->contentBoxes.clear();
				for (int i=0;i<avb.size();i++)
				{
					_hierarchyBoxes[nodeId]->contentBoxes.push_back(avb[i]);
				}

			}
		}

	}
	else
	{
		//y orientation
		if (dh!=0)
		{
			int x0=myBox.x()+dx;
			int y0=myBox.y()+dy;
			int w0=myBox.width()+dw;
			int h0=myBox.height()+dh;
			int containsize=_hierarchyBoxes[nodeId]->contentBoxes.size();
			Box& b=_hierarchyBoxes[nodeId]->contentBoxes[0];
			int height0=_hierarchyBoxes[nodeId]->sourceheight;
			std::vector<int>end;
			end.clear();
			int xi=b.x();
			int yi=b.y();
			for (int i=0;i<containsize;i++)
			{
				Box& b=_hierarchyBoxes[nodeId]->contentBoxes[i];
				if (abs(b.x()-xi)>2)
				{
					end.push_back(i-1);
					xi=b.x();
				}

			}
			end.push_back(containsize-1);
			int n1row=end[0];
			for (int i=1;i<end.size();i++)
			{
				if ((end[i]-end[i-1])>n1row)
				{
					n1row=end[i]-end[i-1];
				}
			}
			float delta=0.1;
			if (dh>0)
			{			
				int nsize=(h0-delta*height0)/((1+delta)*height0);
				if (nsize==0)
				{
					nsize++;
				}

				int height11=h0/(nsize/delta+nsize+1);
				int height00=height11/delta;
				int lastsize=-1;
				for (int i=0;i<end.size();i++)
				{
					for (int j=0;j<(end[i]-lastsize);j++)
					{
						Box& bj=_hierarchyBoxes[nodeId]->contentBoxes[lastsize+j+1];
						bj.setY( y0+(height11+height00)*(j+1)-height00);
						bj.setHeight(height00);
					}
					for (int j=end[i]-lastsize;j<nsize;j++)
					{
						Box& b=_hierarchyBoxes[nodeId]->contentBoxes[end[i]];
						Box bi(b);
						bi.setY( y0+(height11+height00)*(j+1)-height00);
						bi.setHeight(height00);
						_hierarchyBoxes[nodeId]->contentBoxes.push_back(bi);

					}
					lastsize=end[i];	
				}
			}
			else
			{
				if (dh<0)
				{
					int nsize=(h0-delta*height0)/((1+delta)*height0);
					if (nsize==0)
					{
						nsize++;
					}
					int height11=h0/(nsize/delta+nsize+1);
					int height00=height11/delta;
					int lastsize=-1;
					std::vector<int>er;
					er.clear();
					for (int i=0;i<end.size();i++)
					{
						for (int j=0;j<(end[i]-lastsize);j++)
						{
							Box& bj=_hierarchyBoxes[nodeId]->contentBoxes[lastsize+j+1];
							bj.setY( y0+(height11+height00)*(j+1)-height00);
							bj.setHeight(height00);
						}
						for (int j=nsize;j<end[i]-lastsize;j++)
						{
							er.push_back(lastsize+j+1);
						}
						lastsize=end[i];	
					}
					std::vector<Box>avb;
					avb.clear();
					for (int i=0;i<_hierarchyBoxes[nodeId]->contentBoxes.size();i++)
					{
						int have=0;
						for (int j=0;j<er.size();j++)
						{
							if (i==er[j])
							{
								have=1;
							}
						}
						if (have==0)
						{
							Box& bi=_hierarchyBoxes[nodeId]->contentBoxes[i];
							Box bj(bi);
							avb.push_back(bj);
						}
					}
					_hierarchyBoxes[nodeId]->contentBoxes.clear();
					for (int i=0;i<avb.size();i++)
					{
						_hierarchyBoxes[nodeId]->contentBoxes.push_back(avb[i]);
					}

				}
			}
		}
		else
		{
			for(int i=0;i<_hierarchyBoxes[nodeId]->contentBoxes.size();++i)
			{
				Box& b=_hierarchyBoxes[nodeId]->contentBoxes[i];
				b.setX( (b.x()-myBox.x())*xscale+myBox.x()+dx);
				b.setY( (b.y()-myBox.y())*yscale+myBox.y()+dy);
				b.setWidth( b.width()*xscale);
				b.setHeight(b.height()*yscale);
			}
		}

	}



	myBox.translate(dx,dy);
	myBox.setWidth(myBox.width()+dw);
	myBox.setHeight(myBox.height()+dh);

}

void GenerativeHistory::scaleHistory(int rootNodeId,Box& newRootBoxSize){
	Box rBox=boxOf(rootNodeId);
	float xScale=newRootBoxSize.width()/(float)rBox.width();
	float yScale=newRootBoxSize.height()/(float)rBox.height();

	std::vector<int> myStack;
	myStack.push_back(rootNodeId);
	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		Box myBox=_hierarchyBoxes[curr]->box;
		myBox.setX((myBox.x()-rBox.x())*xScale+newRootBoxSize.x()+0.5);
		myBox.setY((myBox.y()-rBox.y())*yScale+newRootBoxSize.y()+0.5);
		myBox.setWidth(myBox.width()*xScale+0.5);
		myBox.setHeight(myBox.height()*yScale+0.5);
		if(leftBoxId(curr)!=-1)
			myStack.push_back(leftBoxId(curr));
		if(rightBoxId(curr)!=-1)
			myStack.push_back(rightBoxId(curr));
	}
}

void GenerativeHistory::translateHistory(int rootNodeId,int dx,int dy){
	std::vector<int> myStack;
	myStack.push_back(rootNodeId);
	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		Box myBox=_hierarchyBoxes[curr]->box;
		myBox.setX(myBox.x()+dx);
		myBox.setY(myBox.y()+dy);
		if(leftBoxId(curr)!=-1)
			myStack.push_back(leftBoxId(curr));
		if(rightBoxId(curr)!=-1)
			myStack.push_back(rightBoxId(curr));
	}
}

GenerativeHistory& GenerativeHistory::operator=(const GenerativeHistory&you){
	clear();
	for(int i=0;i<you._hierarchyBoxes.size();++i){
		HierarchyNode* node=new HierarchyNode(*you._hierarchyBoxes[i]);
		_hierarchyBoxes.push_back(node);
	}

	_rootBoxId=you._rootBoxId;
	return *this;
}

HierarchyNode* GenerativeHistory::allocateNewHierarchyNode(){
	HierarchyNode* node=new HierarchyNode();
	_hierarchyBoxes.push_back(node);
	return node;
}

GenerativeHistory::GenerativeHistory(const GenerativeHistory& you){
	*this=you;
}

GenerativeHistory::~GenerativeHistory(){
	clear();
}

int GenerativeHistory::findContainerNode(int x,int y){
	if(rootBox()==-1)return -1;
	if(!boxOf(rootBox()).contains(x,y))return -1;

	std::vector<int> myStack;
	myStack.push_back(rootBox());
	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		if(isLeafNode(curr))
			return curr;
		int right=rightBoxId(curr);
		if(boxOf(right).contains(x,y))
			myStack.push_back(right);
		else
			myStack.push_back(leftBoxId(curr));
	}
	return -1;
}

int GenerativeHistory::findContainerNode(Box box){
	if(rootBox()==-1)return -1;
	if(!boxOf(rootBox()).contains(box))return -1;

	std::vector<int> myStack;
	myStack.push_back(rootBox());
	while(!myStack.empty()){
		int curr=myStack.back();
		myStack.pop_back();
		if(isLeafNode(curr))
			return curr;
		int right=rightBoxId(curr);
		if(boxOf(right).contains(box))
			myStack.push_back(right);
		else
			myStack.push_back(leftBoxId(curr));
	}
	return -1;
}

void GenerativeHistory::updateHistoryWithBoundingBox(Box& box){
	if(rootBox()==-1||boxOf(rootBox())==box)return;
	int newRootId=updateHistoryWithBoundingBox_recursive(box,_rootBoxId);
	_rootBoxId=newRootId;
}


int GenerativeHistory::updateHistoryWithBoundingBox_recursive(Box& box,int rid){
	Box rbox=boxOf(rootBox());

	Box horiBoxes[2]={box,box};
	Box vertiBoxes[2]={box,box};
	int pos[2]={0,0};
	bool isHigh[2]={false,false};
	if(rbox.left()-box.left()>box.right()-rbox.right()){
		pos[0]=rbox.left();
		isHigh[0]=true;
	}else{
		pos[0]=rbox.right();
		isHigh[0]=false;
	}

	Box::splitBox(box,pos[0],0,horiBoxes[0],horiBoxes[1]);

	if(rbox.bottom()-box.bottom()>box.top()-rbox.top()){
		pos[1]=rbox.bottom();
		isHigh[1]=true;
	}
	else{
		pos[1]=rbox.top();
		isHigh[1]=false;
	}
	Box::splitBox(box,pos[1],1,vertiBoxes[0],vertiBoxes[1]);

	double horiSym=0,vertiSym=0;

	if(pos[0]!=box.left()&&pos[0]!=box.right())
		horiSym=SymProfile::integralSymOfBox(horiBoxes[0],0)+SymProfile::integralSymOfBox(horiBoxes[0],1)+SymProfile::integralSymOfBox(horiBoxes[1],0)+SymProfile::integralSymOfBox(horiBoxes[1],1);
	if(pos[1]!=box.bottom()&&pos[1]!=box.top())
		vertiSym=SymProfile::integralSymOfBox(vertiBoxes[0],0)+SymProfile::integralSymOfBox(vertiBoxes[0],1)+SymProfile::integralSymOfBox(vertiBoxes[1],0)+SymProfile::integralSymOfBox(vertiBoxes[1],1);


	int newRootId;
	HierarchyNode* newRootNode=allocateNewHierarchyNode();
	newRootId=_hierarchyBoxes.size()-1;
	newRootNode->box=box;

	if(horiSym>vertiSym){
		int newLeftId,newRightId;
		if(isHigh[0]){
			HierarchyNode* leftNode=allocateNewHierarchyNode();
			newLeftId=_hierarchyBoxes.size()-1;

			int rightChildId=rid;

			leftNode->box==horiBoxes[0];

			newRootNode->leftBoxId=newLeftId;
			newRootNode->rightBoxId=rightChildId;
			_hierarchyBoxes[rightChildId]->parentBoxId=newRootId;
			leftNode->parentBoxId=newRootId;
		}else{
			HierarchyNode* rightNode=allocateNewHierarchyNode();
			newRightId=_hierarchyBoxes.size()-1;
			int leftChildId=rid;

			rightNode->box=horiBoxes[1];
			newRootNode->leftBoxId=leftChildId;
			newRootNode->rightBoxId=newRightId;
			_hierarchyBoxes[leftChildId]->parentBoxId=newRootId;
			rightNode->parentBoxId=newRootId;
		}
	}else{
		int newBottomId,newTopId;
		if(isHigh[1]){
			HierarchyNode* bottomNode=allocateNewHierarchyNode();
			newBottomId=_hierarchyBoxes.size()-1;
			int topChildId=rid;

			bottomNode->box=vertiBoxes[0];
			newRootNode->leftBoxId=newBottomId;
			newRootNode->rightBoxId=topChildId;
			_hierarchyBoxes[topChildId]->parentBoxId=newRootId;
			bottomNode->parentBoxId=newRootId;
		}else{
			HierarchyNode* topNode=allocateNewHierarchyNode();
			newTopId=_hierarchyBoxes.size()-1;
			int bottomChildId=rid;
			topNode->box=vertiBoxes[1];
			newRootNode->leftBoxId=bottomChildId;
			newRootNode->rightBoxId=newTopId;
			_hierarchyBoxes[bottomChildId]->parentBoxId=newRootId;
			topNode->parentBoxId=newRootId;
		}
	}

	return newRootId;
}

void GenerativeHistory::contentBoxesFromLeaveNodes(BoxSet &bset){
	if(rootBox()==-1)return;

	std::vector<std::vector<int>>isshow;
	std::vector<int>leaf;
	leaf.clear();
	leaf.clear();
	for (int i=0;i<_hierarchyBoxes.size();i++)
	{
		if (isLeafNode(i))
		{
			leaf.push_back(i);
			std::vector<int>isshowi;
			isshowi.clear();
			isshowi.resize(_hierarchyBoxes[i]->contentBoxes.size() );
			isshow.push_back(isshowi);
		}
	}
	for (int i=0;i<leaf.size();i++)
	{
		BoxSet& tseti=_hierarchyBoxes[leaf[i]]->contentBoxes;
		int leveli=_hierarchyBoxes[leaf[i]]->abstractLevel;
		for (int j=0;j<leaf.size();j++)
		{
			if (i==j)
			{
				continue;
			}
			BoxSet& tsetj=_hierarchyBoxes[leaf[j]]->contentBoxes;
			int levelj=_hierarchyBoxes[leaf[j]]->abstractLevel;
			for (int k=0;k<tseti.size();k++)
			{
				for (int l=0;l<tsetj.size();l++)
				{
					Box & tk=tseti[k];
					Box & tl=tsetj[l];
					int xk=tk.x();
					int yk=tk.y();
					int wk=tk.width();
					int hk=tk.height();
					int xl=tl.x();
					int yl=tl.y();
					int wl=tl.width();
					int hl=tl.height();
					if (((xk<xl)&&(xl<xk+wk)&&(yk<yl)&&(yl<yk+hk))||
						((xk<xl+wl)&&(xl+wl<xk+wk)&&(yk<yl)&&(yl<yk+hk))||
						((xk<xl)&&(xl<xk+wk)&&(yk<yl+hl)&&(yl+hl<yk+hk))||
						((xk<xl+wl)&&(xl+wl<xk+wk)&&(yk<yl+hl)&&(yl+hl<yk+hk)))
					{
						if (leveli>levelj)
						{
							isshow[j][l]=1;
						}
						else
						{
							isshow[i][k]=1;
						}

					}
				}
			}
		}
	}
	for (int i=0;i<leaf.size();i++)
	{
		BoxSet& tseti=_hierarchyBoxes[leaf[i]]->contentBoxes;
		for(int j=0;j<tseti.size();j++)
		{
			if (isshow[i][j]==0)
			{
				bset.push_back(tseti[j]);
			}	
		}

	}
}

void HierarchyNode::retargetContentData(int dx,int dy,double xscale,double yscale){
	for(int i=0;i<contentBoxes.size();++i){
		Box& b=contentBoxes[i];
		b.setX( (b.x()-box.x()-dx)*xscale+box.x());
		b.setY( (b.y()-box.y()-dy)*yscale+box.y());
		b.setWidth( b.width()*xscale);
		b.setHeight(b.height()*yscale);
	}
}
//////////////////////////////////////////////////////////////////////////
//ga
float GenerativeHistory::nofnonleafnode()
{
	float d=0.0;
	int nsize=_hierarchyBoxes.size();
	for (int i=0;i<nsize;i++)
	{
		if (Asym::GenerativeHistory::isLeafNode(i)!=true)
		{
			d+=1.0;
		}
	}
	return d;
}

//////////////////////////////////////////////////////////////////////////


}
