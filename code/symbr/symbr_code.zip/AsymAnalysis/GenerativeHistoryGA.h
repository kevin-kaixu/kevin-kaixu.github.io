#include <ga\gagenome.h>
#include "GenerativeHistory.h"
#include "Box.h"
#include "grid.h"
#include "SymProfile.h"
namespace Asym{
	struct DecompCandidate;
	struct edge
	{
		int p0;
		int p1;
		int inter;
	};
	struct delayernode
	{
		std::vector<int>inedge;
		std::vector<int>outedge;
		int index;
		std::vector<int>upnode;
		int isin;
		delayernode()
		{
			index=-1;
			isin=0;
		}
	};
class GenerativeHistoryGA :
	public GAGenome
{
public:

	~GenerativeHistoryGA(void);
	GenerativeHistoryGA(GAGenome::Evaluator f=NULL,Mutator m=0, Comparator c=0);//,BoxSet boxset

	BoxSet m_boxSet;
	GenerativeHistory m_ghist;

public:
	void SetBoxSet(BoxSet boxset){m_boxSet=boxset;}
	virtual GAGenome *clone(GAGenome::CloneMethod flag=CONTENTS) const;
	virtual void copy(const GenerativeHistoryGA* orig);//const GAGenome &
	void copy(const GAGenome & orig);
	std::vector<Grid> generateAllGrids(std::vector<int>& boxIndices);
	bool needDecomp(std::vector<int>& boxIndices);
	void generateDelayerCandidateswithoutlevel(std::vector<int>& boxIndices,std::vector<Grid>& grids,std::vector<DecompCandidate>& candidates);///
	void generateCandidates(std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);///
	void removeInvalidGrids(std::vector<Grid>& grids,std::vector<int>& allBoxIndices);
	float evaluateNIS(DecompCandidate& dc,Box space);///
	float evaluateISsinglefbox(std::vector<int>elist,Box space);///
	bool isGridContainedByOthers1(std::vector<Grid>& grids,int i,std::vector<int>& allBoxIndices);
	std::vector<int> determineGridLayer(std::vector<Grid>& grids);
	GenerativeHistoryGA & operator=(const GenerativeHistoryGA * orig)
	{copy(orig); return *this;}
	void saveSvg_SplitCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);
	void  saveSvg_DelayerCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);
	void saveSvg_AllCandidates(std::string fn,std::vector<int>& boxIndices,std::vector<DecompCandidate>& candidates);
	float ComputeSnisweightis1();///
	std::vector<std::vector<int>>combine(int n,int m);//cnm
	int iselist(std::vector<int>l0,std::vector<int>l1);

	
};
}
