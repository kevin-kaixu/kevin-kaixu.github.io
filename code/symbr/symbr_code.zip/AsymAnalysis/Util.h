#ifndef ASYM_UTIL_H
#define ASYM_UTIL_H
//#include "simple_svg_1.0.0.hpp"
#include <vector>
#include <iostream>
#include <algorithm>

namespace Asym{
	class RandomNumberGenerator{
		int _minNum;
		int _maxNum;
	public:
		RandomNumberGenerator(int min,int max);
		int randomNum();
	};

	typedef struct {
		double r;       // percent
		double g;       // percent
		double b;       // percent
	} rgb;

	typedef struct {
		double h;       // angle in degrees
		double s;       // percent
		double v;       // percent
	} hsv;

	hsv rgb2hsv(rgb in);
	rgb hsv2rgb(hsv in);

	inline int intFabs(int a){
		return a>0?a:-a;
	}

	void addUniqueValue(std::vector<int>&arr,int v);
}

#endif