#include "grid.h"
#include <sstream>
#include <iomanip>
#include <iostream>
#include <algorithm>
using namespace Asym;

void Grid::print(){
	int rnum=rowNum();
	int cnum=colNum();
	std::cout<<std::endl<<"grid ("<<rnum<<","<<cnum<<")"<<std::endl;
	for(int i=0;i<rnum;++i){
		for(int j=0;j<cnum;++j){
			std::cout<<" [";
			if(matrix[i][j].empty()){
				std::cout<<"  ";
			}else{
				for(int k=0;k<matrix[i][j].size();++k){
					std::cout<<matrix[i][j][k];
					if(k!=matrix[i][j].size()-1)
						std::cout<<",";
				}
			}

			std::cout<<"] ";
		}
		std::cout<<std::endl;
	}
}

bool Grid::operator==(const Grid& g){
	if(this->rowNum()!=g.rowNum()||this->colNum()!=g.colNum())return false;

	for(int r=0;r<matrix.size();++r)
		for(int c=0;c<matrix[r].size();++c)
			if(matrix[r][c]!=g.matrix[r][c])return false;

	return true;

}

int Grid::sumOfElementArea(BoxSet& bset){
	int s=0;
	for(int i=0;i<matrix.size();++i)
		for(int j=0;j<matrix[i].size();++j)
			for(int k=0;k<matrix[i][j].size();++k){
				Box &box=bset[matrix[i][j][k]];
				s+=box.area();
			}
			return s;
}

std::vector<int>  Grid::allBoxIndices(){
std::vector<int> indices;
for(int i=0;i<matrix.size();++i)
for(int j=0;j<matrix[i].size();++j)
for(int k=0;k<matrix[i][j].size();++k)
	indices.push_back(matrix[i][j][k]);

return indices;
}

std::vector<int>  Grid::allBoxIndices(std::vector<std::pair<int,int>>& matrixIndices){
	std::vector<int> indices;
	for(int i=0;i<matrixIndices.size();++i){
		int r=matrixIndices[i].first;
		int c=matrixIndices[i].second;
		for(int j=0;j<matrix[r][c].size();++j){
			indices.push_back(matrix[r][c][j]);
		}
	}
	return indices;
}

Box Grid::boundingbox(BoxSet& bset){
	return bset.boundingBox(allBoxIndices());
}


bool Grid::isIntersectWith(Grid& grid,BoxSet& bset){
	Box myBB=boundingbox(bset);
	Box yourBB=grid.boundingbox(bset);
	return myBB.isIntersect(yourBB);
}

bool Grid::isInFrontOf(Grid& grid,BoxSet& bset){
	Box myBB=boundingbox(bset);
	Box yourBB=grid.boundingbox(bset);
	if(!myBB.isIntersect(yourBB))return false;
	Box intersectRegion=myBB.intersection(yourBB);
	std::vector<int> myBoxIndices=allBoxIndices(selectCells(intersectRegion,bset));
	std::vector<int> yourBoxIndices=grid.allBoxIndices(grid.selectCells(intersectRegion,bset));
	if(!myBoxIndices.empty()&&yourBoxIndices.empty())
		return true;

	if(myBoxIndices.empty()||yourBoxIndices.empty())
		return false;

	//int mySmallestIndex=*std::min_element(myBoxIndices.begin(),myBoxIndices.end());
	//int yourLargestIndex=*std::max_element(yourBoxIndices.begin(),yourBoxIndices.end());



	//if(mySmallestIndex>yourLargestIndex)
	//	return true;
	
	//int dLeft=myBB.left()-yourBB.left();
	//int dRight=yourBB.right()-myBB.right();
	//int dBottom=myBB.bottom()-yourBB.bottom();
	//int dTop=yourBB.top()-myBB.top();
	//int posi=dLeft+dRight+dBottom+dTop;
	//if( posi>0 && ( (dLeft>=0&&dRight>=0)||(dBottom>=0&&dTop>=0) ))return true;

	//return false;
	return myBB.area()<yourBB.area();
}

Box Grid::cellBoundingBox(int r,int c,BoxSet&bset){
	return bset.boundingBox(matrix[r][c]);
}

std::vector<std::pair<int,int>> Grid::selectCells(Box& region,BoxSet& bset){
	std::vector<std::pair<int,int>> results;

for(int i=0;i<matrix.size();++i)
for(int j=0;j<matrix[i].size();++j){
Box cellBB=cellBoundingBox(i,j,bset);
if(cellBB.isIntersect(region))
results.push_back(std::pair<int,int>(i,j));
}

return results;

}

void Grid::copyRowsToEnd(int startRow,int num){
	for(int i=0;i<num;++i){
		matrix.push_back(matrix[startRow+i]);
	}
}

void Grid::copyColsToEnd(int startCol,int num){
	for(int r=0;r<matrix.size();++r){
		for(int i=0;i<num;++i){
			matrix[r].push_back(matrix[r][i+startCol]);
		}
	}
}

void Grid::removeBackRows(int num){
	while((num--)>0){
		matrix.pop_back();
	}
}


void Grid::removeBackCols(int num){
	while((num--)>0){
		for(int r=0;r<matrix.size();++r){
			matrix[r].pop_back();
		}
	}
}


void Grid::completeGrid(BoxSet& inBoxset,BoxSet &outBoxSet){
	if(matrix.empty()||matrix[0].empty())return;

int rIndex=0;
int cIndex=0;
for(int r=0;r<matrix.size();++r)
for(int c=0;c<matrix[r].size();++c){
	if(matrix[r][c].size()>matrix[rIndex][cIndex].size()){
		rIndex=r;
		cIndex=c;
	}
}


Box cellSize=cellBoundingBox(rIndex,cIndex,inBoxset);
Box bbox=boundingbox(inBoxset);
int vspacing=0;
if(rowNum()>1)
vspacing=(bbox.height()-cellSize.height()*rowNum())/(rowNum()-1);

int hspacing=0;
if(colNum()>1)
hspacing=(bbox.width()-cellSize.width()*colNum())/(colNum()-1);

for(int r=0;r<matrix.size();++r)
for(int c=0;c<matrix[r].size();++c){
	if(matrix[r][c].size()<matrix[rIndex][cIndex].size()){
		int dx=(c-cIndex)*(cellSize.width()+hspacing);
		int dy=(r-rIndex)*(cellSize.height()+vspacing);
		for(int k=0;k<matrix[rIndex][cIndex].size();++k){
			Box box=inBoxset[matrix[rIndex][cIndex][k]];
			box.setX(box.x()+dx);
			box.setY(box.y()+dy);
			outBoxSet.push_back(box);
		}
	}else{
		for(int k=0;k<matrix[r][c].size();++k){
			outBoxSet.push_back(inBoxset[matrix[r][c][k]]);
		}
	}
}


}

void Grid::retargeting(int dim, int newSize,BoxSet& inBset,BoxSet &outSet){
	std::vector<int> boxIndices=allBoxIndices();
	Box currentBBox=inBset.boundingBox(boxIndices);
	outSet.clear();

	if(dim==0){//add/remove cols
		if(colNum()<2){
			for(int i=0;i<boxIndices.size();++i){
				Box box=inBset[boxIndices[i]];
				box.setWidth(newSize);
				outSet.push_back(box);
			}
			return;
		}else{
			int avgW=inBset.avgWidth(boxIndices);
			int spacing=(currentBBox.width()-colNum()*avgW)/(colNum()-1);
			int dw=newSize-currentBBox.width();
			int addNum=0;
			int itemSize=avgW+spacing;
			while(dw>itemSize){
				addNum++;
				dw-=itemSize;
			}

			while(dw<itemSize){
				addNum--;
				dw+=itemSize;
			}

			if(addNum>0){
				copyColsToEnd(0,addNum);

			}else
				removeBackCols(addNum);

			for(int r=0;r<matrix.size();r++){
				int c=0;
				while(c+addNum<matrix[r].size()){
					for(int k=0;k<matrix[r][c].size();++k)
					outSet.push_back(inBset[matrix[r][c][k]]);
					c++;
				}
				int startX=currentBBox.right()+spacing;
				while(c<matrix[r].size()){
					for(int k=0;k<matrix[r][c].size();++k){
						Box tbox=inBset[matrix[r][c][k]];
						tbox.setX(startX);
						outSet.push_back(tbox);
					}
					startX+=itemSize;
					c++;
				}
			}

		}
	}else{//add/remove rows
		if(rowNum()<2){
			for(int i=0;i<boxIndices.size();++i){
				Box box=inBset[boxIndices[i]];
				box.setHeight(newSize);
				outSet.push_back(box);
			}
			return;
		}else{
			int avgH=inBset.avgHeight(boxIndices);
			int spacing=(currentBBox.height()-rowNum()*avgH)/(rowNum()-1);
			int dh=newSize-currentBBox.height();
			int addNum=0;
			int itemSize=avgH+spacing;
			while(dh>itemSize){
				addNum++;
				dh-=itemSize;
			}

			while(dh<itemSize){
				addNum--;
				dh+=itemSize;
			}

			if(addNum>0)
				copyRowsToEnd(0,addNum);
			else
				removeBackRows(addNum);

			int r=0;
			while(r+addNum<matrix.size()){
				for(int c=0;c<matrix[r].size();c++){
					for(int k=0;k<matrix[r][c].size();++k){
					outSet.push_back(inBset[matrix[r][c][k]]);
					}
				}
				r++;
			}

			int startY=currentBBox.top()+spacing;
			while(r<matrix.size()){
				for(int c=0;c<matrix[r].size();++c){
					for(int k=0;k<matrix[r][c].size();++k){
						
						Box tbox=inBset[matrix[r][c][k]];
						tbox.setY(startY);
						outSet.push_back(tbox);
					}
				}
				startY+=itemSize;
				r++;
			}

		}
	}


}