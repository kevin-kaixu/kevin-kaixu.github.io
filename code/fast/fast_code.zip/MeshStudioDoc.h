// MeshStudioDoc.h : interface of the CMeshStudioDoc class
//


#pragma once

// CGAL
#include <CGAL/basic.h>
#include <CGAL/Simple_cartesian.h>
#include "Lib/Mesh/enriched_polyhedron.h"
#include "GlobalFunc.h"
#include "Lib/GL/GpuShader.h"
#include "Lib/Mesh/Crest/Crestline.h"

typedef FTP number_type;
typedef CGAL::Simple_cartesian<number_type> Enriched_kernel;
typedef Enriched_polyhedron<Enriched_kernel, Enriched_items> Mesh;
typedef CCrestline<Mesh, Enriched_kernel> Crestline;

class CMeshStudioView;
class CDlgRidgeParam;
class CDlgCrestParam;
class CDlgTexSynSetting;

class CMeshStudioDoc : public CDocument
{
protected: // create from serialization only
	CMeshStudioDoc();
	DECLARE_DYNCREATE(CMeshStudioDoc)

// Attributes
public:
	Mesh *m_pMesh;

	CMeshStudioView *m_pView;
	BOOL			m_bClosing;	// TRUE if this document has call OnCloseDocument
	int				m_method_curvature;
	CString			m_sMeshPathName;

	Crestline		*m_pCrestline;

// Operations
public:
	// status message
	void StatusMessage(char* fmt, ... );
	void ResetMeshProperties();
	void UpdateMeshProperties(Mesh *pMesh, bool update_component=false, bool update_boundary=false);
	BOOL SaveModel(LPCTSTR lpszPathName, Mesh *pMesh);
// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CMeshStudioDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
public:
	// Reload mesh data from current mesh data file
	bool ReloadMesh(Mesh *&pMesh);
	// Load mesh data from a mesh file
	bool LoadMesh(const CString &sMeshPathName, Mesh *&pMesh);

public:
	afx_msg void OnFileReload();
	afx_msg void OnUpdateFileReload(CCmdUI *pCmdUI);
	afx_msg void OnCamManipSpin();
	afx_msg void OnUpdateCamManipSpin(CCmdUI *pCmdUI);
	afx_msg void OnCamManipZoom();
	afx_msg void OnUpdateCamManipZoom(CCmdUI *pCmdUI);
	afx_msg void OnCamManipMove();
	afx_msg void OnUpdateCamManipMove(CCmdUI *pCmdUI);
	afx_msg void OnCamRestoreView();
	afx_msg void OnCamSaveView();
	afx_msg void OnCamLoadView();
	afx_msg void OnCamViewAll();
	afx_msg void OnCamManipAnimSpin();
	afx_msg void OnUpdateCamManipAnimSpin(CCmdUI *pCmdUI);
	afx_msg void OnCamManipAnimSpinY();
	afx_msg void OnUpdateCamManipAnimSpinY(CCmdUI *pCmdUI);
	afx_msg void OnCamManipSpinX();
	afx_msg void OnCamManipSpinRX();
	afx_msg void OnCamManipSpinY();
	afx_msg void OnCamManipSpinRY();
	afx_msg void OnCamManipSpinZ();
	afx_msg void OnCamManipSpinRZ();
	afx_msg void OnCamManipZoomIn();
	afx_msg void OnCamManipZoomOut();
	afx_msg void OnRenderAxes();
	afx_msg void OnUpdateRenderAxes(CCmdUI *pCmdUI);
	afx_msg void OnRenderBoundingbox();
	afx_msg void OnUpdateRenderBoundingbox(CCmdUI *pCmdUI);
	afx_msg void OnFileExport();
	afx_msg void OnPickVertex();
	afx_msg void OnUpdatePickVertex(CCmdUI *pCmdUI);
	afx_msg void OnSaveSelVert();
	afx_msg void OnUpdateSaveSelVert(CCmdUI *pCmdUI);
	afx_msg void OnSaveSelTri();
	afx_msg void OnUpdateSaveSelTri(CCmdUI *pCmdUI);
	afx_msg void OnOpenSelVert();
	afx_msg void OnUpdateOpenSelVert(CCmdUI *pCmdUI);
	afx_msg void OnOpenSelTri();
	afx_msg void OnUpdateOpenSelTri(CCmdUI *pCmdUI);
	afx_msg void OnUnpickVertex();
	afx_msg void OnUpdateUnpickVertex(CCmdUI* pCmdUI);
	afx_msg void OnPickTriangle();
	afx_msg void OnUpdatePickTriangle(CCmdUI *pCmdUI);
	afx_msg void OnRenderModeFill();
	afx_msg void OnUpdateRenderModeFill(CCmdUI *pCmdUI);
	afx_msg void OnRenderModePoint();
	afx_msg void OnUpdateRenderModePoint(CCmdUI *pCmdUI);
	afx_msg void OnRenderModeLine();
	afx_msg void OnUpdateRenderModeLine(CCmdUI *pCmdUI);
	afx_msg void OnRenderModeFillLine();
	afx_msg void OnUpdateRenderModeFillLine(CCmdUI *pCmdUI);
	afx_msg void OnSaveSiteHVF();
	afx_msg void OnHVFSample();
	afx_msg void OnOpenCrest();
	afx_msg void OnUpdateOpenCrest(CCmdUI *pCmdUI);
};