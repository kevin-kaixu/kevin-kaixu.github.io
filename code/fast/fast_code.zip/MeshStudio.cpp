// MeshStudio.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MeshStudio.h"
#include "MainFrm.h"

#include "ChildFrm.h"
#include "MeshStudioDoc.h"
#include "MeshStudioView.h"
#include ".\meshstudio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMeshStudioApp

BEGIN_MESSAGE_MAP(CMeshStudioApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	//ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
END_MESSAGE_MAP()


// CMeshStudioApp construction

CMeshStudioApp::CMeshStudioApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_OptionGLPreDfMatSel = -1;
	m_OptionPCTypeSel = 0;
}


// The one and only CMeshStudioApp object

CMeshStudioApp theApp;

// CMeshStudioApp initialization

BOOL CMeshStudioApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));
	LoadStdProfileSettings(6);  // Load standard INI file options (including MRU)
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(IDR_MeshStudioTYPE,
		RUNTIME_CLASS(CMeshStudioDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CMeshStudioView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);
	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame || !pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Load options
	LoadOptions();
	
	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it
	// Enable drag/drop open
	pMainFrame->DragAcceptFiles();
	pMainFrame->ShowWindow(SW_SHOWMAXIMIZED);
	pMainFrame->UpdateWindow();

	TCHAR Buffer[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, Buffer);
	m_sAppPath.SetString(Buffer);

	return TRUE;
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// App command to run the dialog
void CMeshStudioApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}


// CMeshStudioApp message handlers
void CMeshStudioApp::OnFileOpen()
{
	CString filename;
	static char BASED_CODE szFilter[] = "VRML 2.0 (*.wrl)|*.wrl|\
										OBJ File Format (*.off)|*.off|\
										Wave Front Format (*.obj)|*.obj|\
										Stanford PLY2 (*.ply2)|*.tm|\
										Michael Garland's SMF 2.0 (*.smf)|*.smf|\
										All Files (*.*)|*.*||";

	CFileDialog loadmesh(TRUE, "wrl", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	loadmesh.m_ofn.lpstrTitle = "Open mesh file";
	
	if (loadmesh.DoModal() == IDOK)
	{
		filename = loadmesh.GetPathName();
		if (!filename.IsEmpty()) {
			OpenDocumentFile(filename);
		}
	}
}

BOOL CMeshStudioApp::LoadOptions()
{
	UINT red, green, blue;

	// GL back color
	red =   GetProfileInt("OpenGL back color", "Red", 223);
	green = GetProfileInt("OpenGL back color", "Green", 255);
	blue =  GetProfileInt("OpenGL back color", "Blue", 223);
	m_OptionColorGLBack = RGB(red, green, blue);

	// GL light ambient color
	red =   GetProfileInt("OpenGL light ambient color", "Red", 33);
	green = GetProfileInt("OpenGL light ambient color", "Green", 31);
	blue =  GetProfileInt("OpenGL light ambient color", "Blue", 17);
	m_OptionColorGLMatAmbient = RGB(red, green, blue);

	// GL light diffuse color
	red =   GetProfileInt("OpenGL light diffuse color", "Red", 253);
	green = GetProfileInt("OpenGL light diffuse color", "Green", 216);
	blue =  GetProfileInt("OpenGL light diffuse color", "Blue", 72);
	m_OptionColorGLMatDiffuse = RGB(red, green, blue);

	// GL light specular color
	red =   GetProfileInt("OpenGL light specular color", "Red", 160);
	green = GetProfileInt("OpenGL light specular color", "Green", 160);
	blue =  GetProfileInt("OpenGL light specular color", "Blue", 160);
	m_OptionColorGLMatSpecular = RGB(red, green, blue);

	m_OptionGLMatShininess = GetProfileInt("OpenGL mat shininess", "Value", 34);
	m_OptionGLPreDfMatSel = GetProfileInt("OpenGL predefine mat selection", "Value", -1);
	m_OptionPCTypeSel = GetProfileInt("Pseudocolor type", "Value", 0);
	return TRUE;
}

BOOL CMeshStudioApp::SaveOptions()
{
	BYTE red, green, blue;

	// GL back color
	red = GetRValue(m_OptionColorGLBack);
	green = GetGValue(m_OptionColorGLBack);
	blue = GetBValue(m_OptionColorGLBack);
	WriteProfileInt("OpenGL back color", "Red", red);
	WriteProfileInt("OpenGL back color", "Green", green);
	WriteProfileInt("OpenGL back color", "Blue", blue);
	
	// GL light ambient color
	red = GetRValue(m_OptionColorGLMatAmbient);
	green = GetGValue(m_OptionColorGLMatAmbient);
	blue = GetBValue(m_OptionColorGLMatAmbient);
	WriteProfileInt("OpenGL light ambient color", "Red", red);
	WriteProfileInt("OpenGL light ambient color", "Green", green);
	WriteProfileInt("OpenGL light ambient color", "Blue", blue);

	// GL light diffuse color
	red = GetRValue(m_OptionColorGLMatDiffuse);
	green = GetGValue(m_OptionColorGLMatDiffuse);
	blue = GetBValue(m_OptionColorGLMatDiffuse);
	WriteProfileInt("OpenGL light diffuse color", "Red", red);
	WriteProfileInt("OpenGL light diffuse color", "Green", green);
	WriteProfileInt("OpenGL light diffuse color", "Blue", blue);

	// GL light specular color
	red = GetRValue(m_OptionColorGLMatSpecular);
	green = GetGValue(m_OptionColorGLMatSpecular);
	blue = GetBValue(m_OptionColorGLMatSpecular);
	WriteProfileInt("OpenGL light specular color", "Red", red);
	WriteProfileInt("OpenGL light specular color", "Green", green);
	WriteProfileInt("OpenGL light specular color", "Blue", blue);

	// GL mat shininess
	WriteProfileInt("OpenGL mat shininess", "Value", m_OptionGLMatShininess);
	// GL redefine mat selection
	WriteProfileInt("OpenGL predefine mat selection", "Value", m_OptionGLPreDfMatSel);
	WriteProfileInt("Pseudocolor type", "Value", m_OptionPCTypeSel);
	return TRUE;
}

int CMeshStudioApp::ExitInstance()
{
	SaveOptions();
	return CWinApp::ExitInstance();
}
