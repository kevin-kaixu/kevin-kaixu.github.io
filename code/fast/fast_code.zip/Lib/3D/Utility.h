
#ifndef _UTILITY_H
#define _UTILITY_H

class Vector3;
const int iNCS = 18;
const GLubyte ColorSet[18][3] = { 
								  {10, 100, 200}, {220, 50, 20}, {140, 60, 150}, {40, 200, 10},
								  {139, 75, 41}, {198, 230, 10},
								  {53, 180, 130}, {172, 62, 62}, {148, 177, 56},
								  {82, 90, 152}, {52, 255, 228}, {87, 0, 0},
								  {0, 0, 102}, {128, 120, 0}, {128, 128, 192},
								  {78, 163, 63}, {232, 243, 12}, {103, 92, 52}};

long elapsed(void);

void DrawAxes(void);
void DrawManipFrame(int iHighlightAxis);

void CalcBillBoardTransform(const Vector3 &dir, const Vector3 &pos, float *m);

#endif