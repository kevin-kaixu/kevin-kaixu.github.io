// TrackBall.h: interface for the CTrackBall class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRACKBALL_H__B7ACDD4B_9D15_4447_BAF2_0D65CBD7BF72__INCLUDED_)
#define AFX_TRACKBALL_H__B7ACDD4B_9D15_4447_BAF2_0D65CBD7BF72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../Math/mathlib.h"
#include <afxwin.h>

template <class FT>
class CTrackBall  
{
public:
	CTrackBall::CTrackBall(CWnd *pWnd, UINT nTimerID, UINT nRate)
	{
		m_Transform.setidentity();
		m_pWnd = pWnd;
		TIMER_EVENT_ID = nTimerID;
		TIMER_RATE = nRate;
		m_bTracking = FALSE;
		m_bAnimate = FALSE;
		m_fRotAngle = 0.0f;
		TIME_EPSILON = 10;
		m_bAutoAnim = false;
		m_dAntoRotAngle = 0.0;
	}
	CTrackBall::~CTrackBall()
	{
	}
	void Reset(void)
	{
		m_Transform.setidentity();
		m_bTracking = FALSE;
		m_bAnimate = FALSE;
		m_fRotAngle = 0.0f;
	}
	void SetAnimate(BOOL b)
	{
		m_bAnimate = b;
		if (m_bAnimate) {
			m_pWnd->SetTimer(TIMER_EVENT_ID, TIMER_RATE, NULL);
		} else {
			m_pWnd->KillTimer(TIMER_EVENT_ID);
		}
	}
	BOOL GetAnimate(void)
	{
		return m_bAnimate;
	}
	void TBMatrix(void)
	{
		if (m_bAnimate || m_bTracking) {
			// If under Animate or Tracking mode, accumulate new rotation
			m_Transform.rotate(m_fRotAngle, &m_RotAxis[0]);
		}
		glMultMatrixF(&m_Transform.M[0]);
	}
	void GetTBMatrix(FT *mat)
	{
		if (mat == NULL) {
			return;
		}
		for (int i=0; i<16; i++) {
			mat[i] = m_Transform.M[i];
		}
	}
	Matrix3 GetTBMatrix(void)
	{
		Matrix3 mat;
		mat.M[0] = m_Transform.M[0];
		mat.M[1] = m_Transform.M[1];
		mat.M[2] = m_Transform.M[2];
		mat.M[3] = m_Transform.M[4];
		mat.M[4] = m_Transform.M[5];
		mat.M[5] = m_Transform.M[6];
		mat.M[6] = m_Transform.M[8];
		mat.M[7] = m_Transform.M[9];
		mat.M[8] = m_Transform.M[10];
		return mat;
	}
	void SetTBMatrix(FT *mat)
	{
		if (mat == NULL) {
			return;
		}
		m_Transform.set(mat);
	}
	void ReSize(UINT width, UINT height)
	{
		m_nWinWidth = width;
		m_nWinHeight = height;
	}
	void MouseDown(int x, int y)
	{
		m_bTracking = TRUE;
		elapsed();
		pointToVector(x, y, m_LastPosition);
	}
	void MouseUp(void)
	{
		m_bTracking = FALSE;

		if (elapsed()<TIME_EPSILON && m_bAnimate) {
			m_pWnd->SetTimer(TIMER_EVENT_ID, TIMER_RATE, NULL);
		} else {
			m_fRotAngle = 0.0f;
			if (m_bAnimate) {
				m_pWnd->KillTimer(TIMER_EVENT_ID);
			}
		}
	}
	void Motion(int x, int y)
	{
		if (!m_bTracking) {
			return;
		}

		FT current_position[3], dx, dy, dz;

		pointToVector(x, y, current_position);

		// calculate the angle to rotate by (directly proportional to the
		//  length of the mouse movement) 
		dx = current_position[0] - m_LastPosition[0];
		dy = current_position[1] - m_LastPosition[1];
		dz = current_position[2] - m_LastPosition[2];
		m_fRotAngle = 90.0 * (FT)sqrt(dx * dx + dy * dy + dz * dz);

		// calculate the axis of rotation (cross product)
		m_RotAxis[0] = m_LastPosition[1] * current_position[2] - 
			m_LastPosition[2] * current_position[1];
		m_RotAxis[1] = m_LastPosition[2] * current_position[0] - 
			m_LastPosition[0] * current_position[2];
		m_RotAxis[2] = m_LastPosition[0] * current_position[1] - 
			m_LastPosition[1] * current_position[0];

		// XXX - constrain motion 
		m_RotAxis[2] = 0;

		// reset for next time 
		elapsed();
		m_LastPosition[0] = current_position[0];
		m_LastPosition[1] = current_position[1];
		m_LastPosition[2] = current_position[2];

		// remember to draw new position 
		//return true;
		m_pWnd->InvalidateRect(NULL, FALSE);
	}
	void SetMotionSpinY(void)
	{
		m_fRotAngle = 2.0;
		m_RotAxis[0] = 0.0;
		m_RotAxis[1] = 1.0;
		m_RotAxis[2] = 0.0;
		m_dAntoRotAngle = 0.0;
		MSG_BOX_INFO("Begin!");
		m_bAutoAnim = true;
	}
	FT Animate(void)
	{
		if (m_bAutoAnim) {
			if (m_dAntoRotAngle==360.0) {
				m_bAutoAnim = false;
				SetAnimate(FALSE);
				m_pWnd->InvalidateRect(NULL, FALSE);
				MSG_BOX_INFO("End!");
				return m_dAntoRotAngle;
			}
			m_dAntoRotAngle += m_fRotAngle;
			m_pWnd->InvalidateRect(NULL, FALSE);
		} else {
			m_pWnd->InvalidateRect(NULL, FALSE);
		}
		return m_dAntoRotAngle;
	}
	void Rotate(FT angle, Vector3 axis)
	{
		m_Transform.rotate(angle, axis);
	}

private:
	void pointToVector(int x, int y, FT v[3])
	{
		float d, a;

		// project x, y onto a hemi-sphere centered within width, height.
		v[0] = (2.0f * x - m_nWinWidth) / m_nWinWidth;
		v[1] = (m_nWinHeight - 2.0f * y) / m_nWinHeight;
		d = (FT)sqrt(v[0] * v[0] + v[1] * v[1]);
		v[2] = (FT)cos((3.14159265 / 2.0) * ((d < 1.0) ? d : 1.0));
		a = 1.0f / (FT)sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
		v[0] *= a;
		v[1] *= a;
		v[2] *= a;
	}
	
private:
	bool m_bAutoAnim;
	FT	 m_dAntoRotAngle;
	CWnd *m_pWnd;

	FT m_LastPosition[3];
	FT m_fRotAngle;
	FT m_RotAxis[3];
	Matrix4 m_Transform;

	UINT m_nWinWidth;
	UINT m_nWinHeight;

	BOOL m_bTracking;
	BOOL m_bAnimate;

	UINT TIMER_EVENT_ID;
	UINT TIMER_RATE;

	long TIME_EPSILON;
};

#endif // !defined(AFX_TRACKBALL_H__B7ACDD4B_9D15_4447_BAF2_0D65CBD7BF72__INCLUDED_)
