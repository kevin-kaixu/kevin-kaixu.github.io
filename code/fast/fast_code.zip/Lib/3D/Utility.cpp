
#include "stdafx.h"
#include "Utility.h"
#include "..\Math\mathlib.h"

#if defined(_WIN32)
#include <sys/timeb.h>
#else
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/times.h>
#endif

long elapsed(void)
{
    static long begin = 0;
    static long finish, difference;
    
#if defined(_WIN32)
    static struct timeb tb;
    ftime(&tb);
    finish = tb.time*1000+tb.millitm;
#else
    static struct tms tb;
    finish = times(&tb);
#endif
    
    difference = finish - begin;
    begin = finish;
    
    return difference;
}

void CalcBillBoardTransform(const Vector3 &dir, const Vector3 &pos, float *m)
{
	Vector3 xaxis;
	Vector3 up(0.0f, 1.0f, 0.0f);
	Vector3 at(dir);

	at.normalize();
	// Cross product of the new look at vector and the current
    //   up vector will produce a vector which is the new
    //   positive X axis of our transformed object.
	xaxis = at.cross(up);
	xaxis.normalize();
	// Calculate the new up vector, which will be the
    //   positive Y axis of our transformed object. Note
    //   that it will lie in the same plane as the new
    //   look at vector and the old up vector.
	up = xaxis.cross(at);
	m[0] = xaxis.v[0]; m[1] = xaxis.v[1]; m[2] = xaxis.v[2];
	m[4] = up.v[0]; m[5] = up.v[1]; m[6] = up.v[2];
	m[8] = -at.v[0]; m[9] = -at.v[1]; m[10] = -at.v[2];
    // Fill out the rest of the 4x4 matrix
    m[3] = 0.0f;     // x-axis is m[0..2]
    m[7] = 0.0f;     // up is m[4..6]
    m[11] = 0.0f;    // -at is m[8..10]
    m[12] = pos.v[0]; m[13] = pos.v[1]; m[14] = pos.v[2];  // ƽ�Ʊ任
    m[15] = 1.0f;
}

void DrawManipFrame(int iHighlightAxis)
{
	GLfloat fXColor[4] = {1.0f, 0.0f, 0.0f, 0.4f};
	GLfloat fYColor[4] = {0.0f, 1.0f, 0.0f, 0.4f};
	GLfloat fZColor[4] = {0.0f, 0.0f, 1.0f, 0.4f};
	double r = 0.1;

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glDisable(GL_LIGHTING);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	glPushMatrix();
	glScalef(0.5f, 0.5f, 0.5f);

	// x axis
	glColor3fv (fXColor);
	if (iHighlightAxis == 0) {
		glLineWidth(4.0);
	} else {
		glLineWidth(2.0);
	}
	glBegin(GL_LINES);
	glVertex3f( -1.0f, 0.0f, 0.0f);
	glVertex3f( 1.0f, 0.0f, 0.0f);
	glEnd();

	// y axis
	glColor3fv (fYColor);
	if (iHighlightAxis == 1) {
		glLineWidth(4.0);
	} else {
		glLineWidth(2.0);
	}
	glBegin(GL_LINES);
	glVertex3f( 0.0f, -1.0f, 0.0f);
	glVertex3f( 0.0f, 1.0f, 0.0f);
	glEnd();

	// z axis
	glColor3fv (fZColor);
	if (iHighlightAxis == 2) {
		glLineWidth(4.0);
	} else {
		glLineWidth(2.0);
	}
	glBegin(GL_LINES);
	glVertex3f( 0.0f, 0.0f, -1.0f);
	glVertex3f( 0.0f, 0.0f, 1.0f);
	glEnd();

	glEnable(GL_LIGHTING);
//	glEnable(GL_BLEND);
	glDisable(GL_LINE_SMOOTH);
	glDepthMask(GL_FALSE);

	r = (iHighlightAxis==0) ? 0.15 : 0.1;
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, fXColor);
	glPushMatrix();
	glTranslatef(1.0f, 0.0f, 0.0f);
	glutSolidSphere(r, 12, 12);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-1.0f, 0.0f, 0.0f);
	glutSolidSphere(r, 12, 12);
	glPopMatrix();

	r = (iHighlightAxis==1) ? 0.15 : 0.1;
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, fYColor);
	glPushMatrix();
	glTranslatef(0.0f, 1.0f, 0.0f);
	glutSolidSphere(r, 12, 12);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.0f, -1.0f, 0.0f);
	glutSolidSphere(r, 12, 12);
	glPopMatrix();

	r = (iHighlightAxis==2) ? 0.15 : 0.1;
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, fZColor);
	glPushMatrix();
	glTranslatef(0.0f, 0.0f, 1.0f);
	glutSolidSphere(r, 12, 12);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.0f, 0.0f, -1.0f);
	glutSolidSphere(r, 12, 12);
	glPopMatrix();

	glPopMatrix();
	glPopAttrib();
}

void DrawAxes(void)
{
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glLineWidth(2.0);
	glDisable(GL_LIGHTING);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glPushMatrix();

	glScalef(2.0f, 2.0f, 2.0f);

	glBegin(GL_LINES);
	// x axis
	glColor3f ( 1.0f, 0.0f, 0.0f);
	glVertex3f( 0.0f, 0.0f, 0.0f);
	glVertex3f( 1.0f, 0.0f, 0.0f);

	// y axis
	glColor3f ( 0.0f, 1.0f, 0.0f);
	glVertex3f( 0.0f, 0.0f, 0.0f);
	glVertex3f( 0.0f, 1.0f, 0.0f);

	// z axis
	glColor3f ( 0.0f, 0.0f, 1.0f);
	glVertex3f( 0.0f, 0.0f, 0.0f);
	glVertex3f( 0.0f, 0.0f, 1.0f);
	glEnd();

	glBegin(GL_TRIANGLES);	

	// x axis arrow
	glColor3f ( 1.0f, 0.0f,  0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    0.0f,    0.04f);
	glVertex3f(0.9f,    0.028f,  0.028f);
	glVertex3f(0.9f,    0.0f,    0.04f);
	glVertex3f(0.9f,    0.028f,  0.028f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    0.028f,  0.028f);
	glVertex3f(0.9f,    0.04f,   0.0f);
	glVertex3f(0.9f,    0.028f,  0.028f);
	glVertex3f(0.9f,    0.04f,   0.0f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    0.04f,   0.0f);
	glVertex3f(0.9f,    0.028f,  -0.028f);
	glVertex3f(0.9f,    0.04f,   0.0f);
	glVertex3f(0.9f,    0.028f,  -0.028f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    0.028f,  -0.028f);
	glVertex3f(0.9f,    0.0f,    -0.04f);
	glVertex3f(0.9f,    0.028f,  -0.028f);
	glVertex3f(0.9f,    0.0f,    -0.04f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    0.0f,    -0.04f);
	glVertex3f(0.9f,    -0.028f, -0.028f);
	glVertex3f(0.9f,    0.0f,    -0.04f);
	glVertex3f(0.9f,    -0.028f, -0.028f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    -0.028f, -0.028f);
	glVertex3f(0.9f,    -0.04f,  0.0f);
	glVertex3f(0.9f,    -0.028f, -0.028f);
	glVertex3f(0.9f,    -0.04f,  0.0f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    -0.04f,  0.0f);
	glVertex3f(0.9f,    -0.028f, 0.028f);
	glVertex3f(0.9f,    -0.04f,  0.0f);
	glVertex3f(0.9f,    -0.028f, 0.028f);
	glVertex3f(0.9f,    0.0f,    0.0f);
	glVertex3f(1.0f,    0.0f,    0.0f);
	glVertex3f(0.9f,    -0.028f, 0.028f);
	glVertex3f(0.9f,    0.0f,    0.04f);
	glVertex3f(0.9f,    -0.028f, 0.028f);
	glVertex3f(0.9f,    0.0f,    0.04f);
	glVertex3f(0.9f,    0.0f,    0.0f);

	// y axis arrow
	glColor3f ( 0.0f, 1.0f, 0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(0.0f,    0.9f,    0.04f);
	glVertex3f(0.028f,  0.9f,    0.028f);
	glVertex3f(0.0f,    0.9f,    0.04f);
	glVertex3f(0.028f,  0.9f,    0.028f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(0.028f,  0.9f,    0.028f);
	glVertex3f(0.04f,   0.9f,    0.0f);
	glVertex3f(0.028f,  0.9f,    0.028f);
	glVertex3f(0.04f,   0.9f,    0.0f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(0.04f,   0.9f,    0.0f);
	glVertex3f(0.028f,  0.9f,    -0.028f);
	glVertex3f(0.04f,   0.9f,    0.0f);
	glVertex3f(0.028f,  0.9f,    -0.028f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(0.028f,  0.9f,    -0.028f);
	glVertex3f(0.0f,    0.9f,    -0.04f);
	glVertex3f(0.028f,  0.9f,    -0.028f);
	glVertex3f(0.0f,    0.9f,    -0.04f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(0.0f,    0.9f,    -0.04f);
	glVertex3f(-0.028f, 0.9f,    -0.028f);
	glVertex3f(0.0f,    0.9f,    -0.04f);
	glVertex3f(-0.028f, 0.9f,    -0.028f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(-0.028f, 0.9f,    -0.028f);
	glVertex3f(-0.04f,  0.9f,    0.0f);
	glVertex3f(-0.028f, 0.9f,    -0.028f);
	glVertex3f(-0.04f,  0.9f,    0.0f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(-0.04f,  0.9f,    0.0f);
	glVertex3f(-0.028f, 0.9f,    0.028f);
	glVertex3f(-0.04f,  0.9f,    0.0f);
	glVertex3f(-0.028f, 0.9f,    0.028f);
	glVertex3f(0.0f,    0.9f,    0.0f);
	glVertex3f(0.0f,    1.0f,    0.0f);
	glVertex3f(-0.028f, 0.9f,    0.028f);
	glVertex3f(0.0f,    0.9f,    0.04f);
	glVertex3f(-0.028f, 0.9f,    0.028f);
	glVertex3f(0.0f,    0.9f,    0.04f);
	glVertex3f(0.0f,    0.9f,    0.0f);

	// z axis arrow
	glColor3f ( 0.0f, 0.0f, 1.0f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(0.0f,    0.04f,   0.9f);
	glVertex3f(0.028f,  0.028f,  0.9f);
	glVertex3f(0.0f,    0.04f,   0.9f);
	glVertex3f(0.028f,  0.028f,  0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(0.028f,  0.028f,  0.9f);
	glVertex3f(0.04f,   0.0f,    0.9f);
	glVertex3f(0.028f,  0.028f,  0.9f);
	glVertex3f(0.04f,   0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(0.04f,   0.0f,    0.9f);
	glVertex3f(0.028f,  -0.028f, 0.9f);
	glVertex3f(0.04f,   0.0f,    0.9f);
	glVertex3f(0.028f,  -0.028f, 0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(0.028f,  -0.028f, 0.9f);
	glVertex3f(0.0f,    -0.04f,  0.9f);
	glVertex3f(0.028f,  -0.028f, 0.9f);
	glVertex3f(0.0f,    -0.04f,  0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(0.0f,    -0.04f,  0.9f);
	glVertex3f(-0.028f, -0.028f, 0.9f);
	glVertex3f(0.0f,    -0.04f,  0.9f);
	glVertex3f(-0.028f, -0.028f, 0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(-0.028f, -0.028f, 0.9f);
	glVertex3f(-0.04f,  0.0f,    0.9f);
	glVertex3f(-0.028f, -0.028f, 0.9f);
	glVertex3f(-0.04f,  0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(-0.04f,  0.0f,    0.9f);
	glVertex3f(-0.028f, 0.028f,  0.9f);
	glVertex3f(-0.04f,  0.0f,    0.9f);
	glVertex3f(-0.028f, 0.028f,  0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);
	glVertex3f(0.0f,    0.0f,    1.0f);
	glVertex3f(-0.028f, 0.028f,  0.9f);
	glVertex3f(0.0f,    0.04f,   0.9f);
	glVertex3f(-0.028f, 0.028f,  0.9f);
	glVertex3f(0.0f,    0.04f,   0.9f);
	glVertex3f(0.0f,    0.0f,    0.9f);

	glEnd();

	glPopMatrix();

	glPopAttrib();
}