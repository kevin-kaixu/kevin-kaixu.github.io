//
// ==[ XPGL: eXPerimental Graphics Library ]== 
//
// Copyright 2006 JeGX / oZone3D.Net
// http://www.oZone3D.Net - jegx@ozone3d.net
//
// This SOFTWARE is distributed in the hope that it will be useful.
// TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
// *AS IS* AND oZone3D.Net DISCLAIM ALL WARRANTIES, EITHER EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL oZone3D.Net 
// BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF oZone3D.Net HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES 
//


#pragma once
#include "..\..\GlobalFunc.h"

#include<map>


//===================================================================
/**
CGpuShader: a GPU vertex/pixel shader.
*/
//===================================================================
class CGpuShader
{

public:

	CGpuShader();
	~CGpuShader();


	void destroy();

	int loadVertexShaderFromFile(const char *shaderSourceFile );
	int loadVertexShaderFromMemory(const char *buffer, int buffer_size );

	int loadPixelShaderFromFile(const char *shaderSourceFile );
	int loadPixelShaderFromMemory(const char *buffer, int buffer_size );


	void setUniform_1i(char *name, int v);
	void setUniform_1f(char *name, float v);
	void setUniform_1fv(char *name, int count, float *v);
	void setUniform_2f(char *name, float v1, float v2);
	void setUniform_3f(char *name, float v1, float v2, float v3);
	void setUniform_4f(char *name, float v1, float v2, float v3, float v4);
	void setUniform_3fv(char *name, int count, float *v);
	void setUniformMat_fv(char *name, int count, bool transpose, int dim, float *v);
	void activeVertexAttribArray_v(char *name, int size, int type, bool normalized, int stride, void *v);
	void activePerVertexAttrib_bo(char *name, int size, int type, bool normalized, int stride, GLuint vabo);
	void disactiveVertexAttribArray(char *name);

	void active();
	void desactive();
	void activeVarying(const char *name);
	void activeVaryings(const CString &varyings);
	GLint getVaryingLocation(const char *name);
	void setFeedbackVaryings(const CString &varyings, int size);
	void beginTransformFeedback(GLenum item);
	void endTransformFeedback();
	float* mapFeedbackData(const CString &sVaryingName);
	void unmapFeedbackData(const CString &sVaryingName);
	// get buffer object of feedback data
	GLuint getFeedbackDataBO(const CString &sVaryingName);

public:
	
	unsigned long m_program_id;
	int m_is_linked;
	unsigned long m_vs_id;
	int m_is_vs_compiled;
	unsigned long m_ps_id;
	int m_is_ps_compiled;
	
	char *m_p_vs_source;
	int m_vs_source_len;
	char *m_p_ps_source;
	int m_ps_source_len;

	std::map<CString,GLuint> m_tfbo; // transform feedback buffer object

private:

	void _printVertexShaderInfoLog();
	void _printPixelShaderInfoLog();
	void _printProgramInfoLog();
};