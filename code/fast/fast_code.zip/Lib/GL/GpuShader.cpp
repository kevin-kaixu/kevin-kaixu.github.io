//
// ==[ XPGL: eXPerimental Graphics Library ]== 
//
// Copyright 2006 JeGX / oZone3D.Net
// http://www.oZone3D.Net - jegx@ozone3d.net
//
// This SOFTWARE is distributed in the hope that it will be useful.
// TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
// *AS IS* AND oZone3D.Net DISCLAIM ALL WARRANTIES, EITHER EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL oZone3D.Net 
// BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF oZone3D.Net HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES 
//

#include "stdafx.h"
#include "GPUShader.h"
#include <vector>

CGpuShader::CGpuShader()
{
	m_program_id = 0;
	m_is_linked = 0;
	m_vs_id = 0;
	m_is_vs_compiled = 0;
	m_ps_id = 0;
	m_is_ps_compiled = 0;
	
	m_p_vs_source = NULL;
	m_vs_source_len = 0;
	m_p_ps_source = NULL;
	m_ps_source_len = 0;
}


CGpuShader::~CGpuShader()
{
	destroy();
}


void CGpuShader::destroy()
{
	if(m_vs_id>0)
	{
		glDetachShader(m_program_id, m_vs_id);
		glDeleteShader( m_vs_id );
		m_vs_id = 0;
		
		if(m_p_vs_source)
		{
			delete [] m_p_vs_source;
			m_p_vs_source=NULL;
		}
	}

	if(m_ps_id>0)
	{
		glDetachShader(m_program_id, m_ps_id);
		glDeleteShader( m_ps_id );
		m_ps_id = 0;
		
		if(m_p_ps_source)
		{
			delete [] m_p_ps_source;
			m_p_ps_source=NULL;
		}
	}


	glDeleteProgram(m_program_id);
	m_program_id = 0;
}



int CGpuShader::loadVertexShaderFromFile(const char *shaderSourceFile )
{
	FILE *fp = fopen(shaderSourceFile, "rb");
	if( fp == NULL)
	{
		return -1;
	}
	else
	{
		fseek(fp,  0, SEEK_END);
		int len = ftell(fp);
		fseek(fp,  0, SEEK_SET);
		char *source = new char[len+1]; // +1 for the final 0.
		fread(source, len, 1, fp);
		fclose(fp);
		source[len] = '\0';

		int res = loadVertexShaderFromMemory(source, len+1);

		delete [] source;

		return(res);
	}
	
	return -1;
}

int CGpuShader::loadVertexShaderFromMemory(const char *buffer, int buffer_size )
{
	if( !buffer || buffer_size<1 )
	{
		return -1;
	}

	if(m_p_vs_source)
	{
		delete [] m_p_vs_source;
		m_p_vs_source=NULL;
	}
	
	m_vs_source_len = buffer_size;
	m_p_vs_source = new char[buffer_size];
	memcpy(m_p_vs_source, buffer, buffer_size);

	if( glIsProgram(m_program_id)==GL_FALSE )
	{
		m_program_id = glCreateProgram();
	}


	m_vs_id = glCreateShader( GL_VERTEX_SHADER );

	const char *v = m_p_vs_source;
	glShaderSource( m_vs_id, 1, &v, NULL );

	glCompileShader( m_vs_id );

	int compiled = 0;
	glGetShaderiv( m_vs_id, GL_COMPILE_STATUS, &compiled );

	if(compiled)
	{
		m_is_vs_compiled = 1;
		glAttachShader( m_program_id, m_vs_id );
		return 0;
	}
	else
	{
		_printVertexShaderInfoLog();
	}
	

	return -1;
}

void CGpuShader::_printVertexShaderInfoLog()
{
	int len = 0;
	int charsWritten  = 0;
	char *infoLog;

	glGetShaderiv(m_vs_id, GL_INFO_LOG_LENGTH, &len);

	if (len > 0) {
		infoLog = new char[len];
		glGetShaderInfoLog(m_vs_id, len, &charsWritten, infoLog);
		MSG_BOX_ERROR( "Vertex Shader Error: %s", infoLog);
		delete [] infoLog;
	}
}


int CGpuShader::loadPixelShaderFromFile(const char *shaderSourceFile )
{
	FILE *fp = fopen(shaderSourceFile, "rb");
	if (fp == NULL) {
		return -1;
	} else {
		fseek(fp,  0, SEEK_END);
		int len = ftell(fp);
		fseek(fp,  0, SEEK_SET);
		char *source = new char[len+1]; // +1 for the final 0.
		fread(source, len, 1, fp);
		fclose(fp);
		source[len] = '\0';
		int res = loadPixelShaderFromMemory(source, len+1);
		delete [] source;
		return(res);
	}
	return -1;
}

int CGpuShader::loadPixelShaderFromMemory(const char *buffer, int buffer_size )
{
	if( !buffer || buffer_size<1 )
	{
		return -1;
	}


	if(m_p_ps_source)
	{
		delete [] m_p_ps_source;
		m_p_ps_source=NULL;
	}
	
	m_ps_source_len = buffer_size;
	m_p_ps_source = new char[buffer_size];
	memcpy(m_p_ps_source, buffer, buffer_size);

	if( glIsProgram(m_program_id)==GL_FALSE )
	{
		m_program_id = glCreateProgram();
	}

	m_ps_id = glCreateShader( GL_FRAGMENT_SHADER );

	const char *v = m_p_ps_source;
	glShaderSource( m_ps_id, 1, &v,NULL );

	glCompileShader( m_ps_id );

	int compiled = 0;
	glGetShaderiv( m_ps_id, GL_COMPILE_STATUS, &compiled );

	if(compiled)
	{
		m_is_ps_compiled = 1;
		glAttachShader( m_program_id, m_ps_id );
		return 0;
	}
	else
	{
		_printPixelShaderInfoLog();
	}

	return -1;
}

void CGpuShader::_printPixelShaderInfoLog()
{
	int len = 0;
	int charsWritten  = 0;
	char *infoLog;

	glGetShaderiv(m_ps_id, GL_INFO_LOG_LENGTH, &len);

	if( len > 0)
	{
		infoLog = new char[len];
		glGetShaderInfoLog(m_ps_id, len, &charsWritten, infoLog);
		MSG_BOX_ERROR( "Pixel Shader Error: %s", infoLog );
		delete [] infoLog;
	}
}



void CGpuShader::setUniform_1i(char *name, int v)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform1i(location, v);
	}
}

void CGpuShader::setUniform_1f(char *name, float v)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform1f(location, v);
	}
}

void CGpuShader::setUniform_1fv(char *name, int count, float *v)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform1fv(location, count, v);
	}
}

void CGpuShader::setUniform_2f(char *name, float v1, float v2)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform2f(location, v1, v2);
	}
}

void CGpuShader::setUniform_3f(char *name, float v1, float v2, float v3)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform3f(location, v1, v2, v3);
	}
}

void CGpuShader::setUniform_3fv(char *name, int count, float *v)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform3fv(location, count, v);
	}
}

void CGpuShader::setUniform_4f(char *name, float v1, float v2, float v3, float v4)
{
	int location = glGetUniformLocation(m_program_id, name);
	if(location >= 0)
	{
		glUniform4f(location, v1, v2, v3, v4);
	}
}

void CGpuShader::setUniformMat_fv(char *name, int count, bool transpose, int dim, float *v)
{
	int location = glGetUniformLocation(m_program_id, name);
	if (location >= 0)
	{
		switch(dim)
		{
		case 2:
			glUniformMatrix2fv(location, count, transpose, v);
			break;
		case 3:
			glUniformMatrix3fv(location, count, transpose, v);
			break;
		case 4:
			glUniformMatrix4fv(location, count, transpose, v);
			break;
		default:
			break;
		}
	}
}

void CGpuShader::activeVertexAttribArray_v(char *name, int size, int type, bool normalized, int stride, void *v)
{
	int location = glGetAttribLocation(m_program_id, name);
	if (location >= 0)
	{
		glEnableVertexAttribArray(location);
		glVertexAttribPointer(location, size, type, normalized, stride, v);
	}
}

void CGpuShader::disactiveVertexAttribArray(char *name)
{
	int location = glGetAttribLocation(m_program_id, name);
	if (location >= 0)
	{
		glDisableVertexAttribArray(location);
	}
}

void CGpuShader::activePerVertexAttrib_bo(char *name, int size, int type, bool normalized, int stride, GLuint vabo)
{
	int location = glGetAttribLocation(m_program_id, name);
	if (location >= 0)
	{
		glBindBufferARB(GL_ARRAY_BUFFER, vabo);
		glEnableVertexAttribArray(location);
		glVertexAttribPointer(location, size, type, normalized, stride, NULL);
	}
}

void CGpuShader::active()
{
	if (m_is_linked==0)
	{
		glLinkProgram(m_program_id);
		int linked=0;
		glGetProgramiv(m_program_id, GL_LINK_STATUS, &linked);
		if (linked) {
			m_is_linked = 1;
		} else {
			_printProgramInfoLog();
			return;
		}
	}
		
	glUseProgram(m_program_id);
}

void CGpuShader::desactive()
{
	glUseProgram(0);
}

void CGpuShader::_printProgramInfoLog()
{
	int len = 0;
	int charsWritten  = 0;
	char *infoLog;

	glGetProgramiv(m_program_id, GL_INFO_LOG_LENGTH, &len);

	if( len > 0)
	{
		infoLog = new char[len];
		glGetProgramInfoLog(m_program_id, len, &charsWritten, infoLog);
		MSG_BOX_ERROR( infoLog );
		delete [] infoLog;
	}
}

void CGpuShader::activeVarying(const char *name)
{
	glActiveVaryingNV(m_program_id, name);
}

GLint CGpuShader::getVaryingLocation(const char *name)
{
	return glGetVaryingLocationNV(m_program_id, name);
}

void CGpuShader::setFeedbackVaryings(const CString &sVaryings, int size)
{
	if (sVaryings.IsEmpty()) {
		return;
	}
	std::vector<GLint> Loc;
	char cToken = ' ';
	CString sRight = sVaryings;
	CString sName;
	int iLength = sRight.GetLength();
	int iTokenPos;
	GLuint bo;

	// Parse the sVaryings and collect varying locations
	do {
		iTokenPos = sRight.Find(cToken);
		if (iTokenPos != -1) {
			sName = sRight.Left(iTokenPos);
		} else {	// reach the end of sRight
			sName = sRight;
		}
		Loc.insert(Loc.begin(), glGetVaryingLocationNV(m_program_id, sName));
		// Allocate buffer objects ids
		glGenBuffers(1, &bo);
		m_tfbo.insert(std::make_pair(sName, bo));
		sRight = sVaryings.Right(iLength-iTokenPos-1);
		iLength = sRight.GetLength();
	} while (iTokenPos != -1);
	
	// Begin preparing the transform feedback
	glTransformFeedbackVaryingsNV(m_program_id, Loc.size(), (GLint*)&(*(Loc.begin())), GL_SEPARATE_ATTRIBS_NV);
	// Generate Loc.size() buffers to store feedback
	std::map<CString,GLuint>::iterator it;
	int i;
	for (it=m_tfbo.begin(), i=0; it!=m_tfbo.end(); it++, i++)
	{
		glBindBuffer(GL_ARRAY_BUFFER, it->second);
		glBufferData(GL_ARRAY_BUFFER, size, 0, GL_STATIC_DRAW);
		glBindBufferOffsetNV(GL_TRANSFORM_FEEDBACK_BUFFER_NV, i, it->second, 0);
	}
}

void CGpuShader::activeVaryings(const CString &sVaryings)
{
	if (sVaryings.IsEmpty()) {
		return;
	}
	char cToken = ' ';
	CString sRight = sVaryings;
	CString sName;
	int iLength = sRight.GetLength();
	int iTokenPos;
	// Parse the sVaryings and collect varying locations
	do {
		iTokenPos = sRight.Find(cToken);
		if (iTokenPos != -1) {
			sName = sRight.Left(iTokenPos);
		} else {	// reach the end of sRight
			sName = sRight;
		}
		glActiveVaryingNV(m_program_id, sName);
		sRight = sVaryings.Right(iLength-iTokenPos-1);
		iLength = sRight.GetLength();
	} while (iTokenPos != -1);
}

void CGpuShader::beginTransformFeedback(GLenum item)
{
	glBeginTransformFeedbackNV(item);
}

void CGpuShader::endTransformFeedback(void)
{
	glEndTransformFeedbackNV();
}

GLuint CGpuShader::getFeedbackDataBO(const CString &sVaryingName)
{
	std::map<CString,GLuint>::iterator it;
	if ((it=m_tfbo.find(sVaryingName)) != m_tfbo.end()) {
		return it->second;
	} else {
		return 0;
	}
}

float* CGpuShader::mapFeedbackData(const CString &sVaryingName)
{
	std::map<CString,GLuint>::iterator it;
	if ((it=m_tfbo.find(sVaryingName)) != m_tfbo.end())
	{
		glBindBuffer(GL_ARRAY_BUFFER, it->second);
		return (float*)glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY);
	}
	return NULL;
}

void CGpuShader::unmapFeedbackData(const CString &sVaryingName)
{
	std::map<CString,GLuint>::iterator it;
	if ((it=m_tfbo.find(sVaryingName)) != m_tfbo.end())
	{
		glBindBuffer(GL_ARRAY_BUFFER, it->second);
		glUnmapBuffer(GL_ARRAY_BUFFER);
	}
}