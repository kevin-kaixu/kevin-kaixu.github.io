//
// ==[ XPGL: eXPerimental Graphics Library ]== 
//
// Copyright 2006 JeGX / oZone3D.Net
// http://www.oZone3D.Net - jegx@ozone3d.net
//
// This SOFTWARE is distributed in the hope that it will be useful.
// TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
// *AS IS* AND oZone3D.Net DISCLAIM ALL WARRANTIES, EITHER EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL oZone3D.Net 
// BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF oZone3D.Net HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES 
//

#include "stdafx.h"
#include "OpenGLFunc.h"

int IsOpenGLVersionSupported( int atLeastMajor, int atLeastMinor )
{
	const char *version;
	int major, minor;
	
	version = (const char *) glGetString(GL_VERSION);

	if (sscanf(version, "%d.%d", &major, &minor) == 2) 
	{
		if (major > atLeastMajor)
			return 1;

		if (major == atLeastMajor && minor >= atLeastMinor)
			return 1;
	} 
	
	return 0;
}

int CheckOpenGLExtension( char *extension_name )
{
	if( extension_name ) 
	{
		char *extension_list = (char *)glGetString( GL_EXTENSIONS );
		if( extension_list )
		{
			if( strstr( extension_list, extension_name ) != NULL )
			{
				return(1);
			}
		}
	}
	return(0);
}

