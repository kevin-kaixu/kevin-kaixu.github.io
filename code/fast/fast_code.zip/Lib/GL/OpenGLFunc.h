//
// ==[ XPGL: eXPerimental Graphics Library ]== 
//
// Copyright 2006 JeGX / oZone3D.Net
// http://www.oZone3D.Net - jegx@ozone3d.net
//
// This SOFTWARE is distributed in the hope that it will be useful.
// TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
// *AS IS* AND oZone3D.Net DISCLAIM ALL WARRANTIES, EITHER EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL oZone3D.Net 
// BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF oZone3D.Net HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES 
//


#pragma once
#include "..\..\GlobalFunc.h"


// Utility class to OpenGL
// Convert T type to the corresponding OpenGL constant (called GL_TYPE)
template<class T> struct GL_TYPE {};
template<> struct GL_TYPE<double> {
	enum { FLAG = GL_DOUBLE };
};
template<> struct GL_TYPE<float>  {
	enum { FLAG = GL_FLOAT };
};
template<> struct GL_TYPE<unsigned short> {
	enum { FLAG = GL_UNSIGNED_SHORT };
};
template<> struct GL_TYPE<short> {
	enum { FLAG = GL_SHORT };
};
template<> struct GL_TYPE<unsigned int> {
	enum { FLAG = GL_UNSIGNED_INT };
};
template<> struct GL_TYPE<int> {
	enum { FLAG = GL_INT };
};
template<> struct GL_TYPE<unsigned char> {
	enum { FLAG = GL_UNSIGNED_BYTE };
};
template<> struct GL_TYPE<char> {
	enum { FLAG = GL_BYTE };
};

#ifdef DOUBLE_PRECISION
#define glVertex3F		glVertex3d
#define glVertex3Fv		glVertex3dv
#define glNormal3F		glNormal3d
#define glNormal3Fv		glNormal3dv
#define glTexCoord2Fv	glTexCoord2dv
#define glTexCoord2F	glTexCoord2d
#define glMultMatrixF	glMultMatrixd
#else
#define glVertex3F		glVertex3f
#define glVertex3Fv		glVertex3fv
#define glNormal3F		glNormal3f
#define glNormal3Fv		glNormal3fv
#define glTexCoord2Fv	glTexCoord2fv
#define glTexCoord2F	glTexCoord2d
#define glMultMatrixF	glMultMatrixf
#endif

int IsOpenGLVersionSupported( int atLeastMajor, int atLeastMinor );
int CheckOpenGLExtension( char *extension_name );

