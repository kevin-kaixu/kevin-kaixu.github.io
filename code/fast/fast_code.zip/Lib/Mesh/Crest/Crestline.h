/***************************************************************************
crestline.h  - processing crestlines output by Yoshizawa's crestline program
----------------------------------------------------------------------------
Note: 
----------------------------------------------------------------------------
begin                : jun 2007
copyright            : Kevin (Kai) Xu - NUDT/SFU
contact              : kevin.kai.xu@gmail.com
***************************************************************************/

#pragma once
#include "../../../MeshStudio.h"
#include "../Enriched_polyhedron.h"

typedef enum _Crest_type{CONVEX=0, CONCAVE} Crest_type;

template <typename FT>
class CLI	// crest line information
{
public:
	class CSeg
	{
	public:
		CSeg() {v[0]=v[1]=fi=0;};
		CSeg(int a, int b, int f) {v[0]=a; v[1]=b; fi=f; l=0.0;};
		~CSeg() {};
		void set(int a, int b, int f) {v[0]=a; v[1]=b; fi=f;};
		CSeg& operator=(const CSeg& in) {v[0]=in.v[0]; v[1]=in.v[1]; fi=in.fi; return *this;};
		CSeg& operator&(const CSeg& in) {v[0]=in.v[1]; v[1]=in.v[0]; fi=in.fi; return *this;};
		int v[2], fi;
		FT l;
	};
	typedef std::vector<Vector3>	VV;
	typedef std::vector<CSeg>		SV;

	SV seg;
	VV dir;
	int tag;	// 0:filtered 1:unfiltered
	Crest_type type;
	FT l;	// length
	FT r;	// ridgeness
	FT s;	// sphericalness
	FT c;	// cyclideness
	CLI() {tag=1; r=0.0; s=0.0; c=0.0; l=0.0; type=CONVEX;};
	~CLI() {};
};

template <class Polyhedron, class Kernel>
class CCrestline
{
	typedef typename Kernel::FT							FT;
	typedef typename Kernel::Point_3					Point_3;
	typedef typename Kernel::Vector_3					Vector_3;
	typedef typename Polyhedron::Vertex_const_handle	Vertex_const_handle;
	typedef typename Polyhedron::Vertex_handle			Vertex_handle;
	typedef typename Polyhedron::Vertex_const_iterator	Vertex_const_iterator;
	typedef typename Polyhedron::Halfedge_const_handle	Halfedge_const_handle;
	typedef typename Polyhedron::Halfedge_around_vertex_const_circulator  HAV_circulator;
	typedef typename Polyhedron::MAP_IVS				MAP_IVS;
	typedef std::vector<std::vector<std::pair<int,int>>> Branch;

private:
	// polygonal mesh
	Polyhedron			*m_pMesh;

	// threshold for filtering
	FT					m_dMinR;		// minimum ridgeness
	FT					m_dMaxR;		// maximum ridgeness
	FT					m_dTR;			// threshold of ridgeness
	FT					m_dMinS;		// minimum sphericalness
	FT					m_dMaxS;		// maximum sphericalness
	FT					m_dTS;			// threshold of sphericalness
	FT					m_dMinC;		// minimum cyclideness
	FT					m_dMaxC;		// maximum cyclideness
	FT					m_dTC;			// threshold of cyclideness
	FT					m_dMinL;		// minimum length
	FT					m_dMaxL;		// maximum length
	FT					m_dTL;			// threshold of length

	std::vector<int>		m_FConvex, m_FConcave;

	std::vector<CLI<FT>>	m_pCLInfo;

	MAP_IVS					m_hvf_sites;

	int						m_iPickLine[2];
	int						m_iPickLP[2];

	std::vector<Vector3>	m_Points;
	std::vector<int>		m_PInL;

	bool					m_bSegConsist;
	bool					m_bSegSequent;
	bool					m_bCompLen;
	FT						m_dAvgSegLen;

	Branch					m_Branch;

	bool					m_bShowDir;
	bool					m_bShowEpDir;
	bool					m_bShowOptState;

public:
	// life cycle
	CCrestline()
	{
		m_pMesh = NULL;
		// default parameter values
		m_dMinR = 0;
		m_dMaxR = 0;
		m_dTR = 0;
		m_dMinS = 0;
		m_dMaxS = 0;
		m_dTS = 0;
		m_dMinC = 0;
		m_dMaxC = 0;
		m_dTC = 0;
		m_dMinL = 0;
		m_dMaxL = 0;
		m_dTL = 0;
		m_iPickLine[0] = m_iPickLine[1] = -1;
		m_iPickLP[0] = m_iPickLP[1] = -1;
		m_bSegConsist = false;
		m_bSegSequent = false;
		m_dAvgSegLen = 0.0;
		m_bShowDir = true;
		m_bShowEpDir = false;
		m_bCompLen = false;
		m_SO_iCurrStep = 0;
		m_bShowOptState = false;
	}
	CCrestline(Polyhedron *pMesh)
	{
		m_pMesh = pMesh;
		// default parameter values
		m_dMinR = 0;
		m_dMaxR = 0;
		m_dTR = 0;
		m_dMinS = 0;
		m_dMaxS = 0;
		m_dTS = 0;
		m_dMinC = 0;
		m_dMaxC = 0;
		m_dTC = 0;
		m_dMinL = 0;
		m_dMaxL = 0;
		m_dTL = 0;
		m_iPickLine[0] = m_iPickLine[1] = -1;
		m_iPickLP[0] = m_iPickLP[1] = -1;
		m_bSegConsist = false;
		m_bSegSequent = false;
		m_dAvgSegLen = 0.0;
		m_bShowDir = true;
		m_bShowEpDir = false;
		m_bCompLen = false;
		m_bShowOptState = false;
	}
	~CCrestline() {}

	FT GetTRidgeness(void) {return m_dTR;};
	void SetTRidgeness(FT t) {m_dTR = t;};
	FT GetTSphericalness(void) {return m_dTS;};
	void SetTSphericalness(FT t) {m_dTS = t;};
	FT GetTCyclideness(void) {return m_dTC;};
	void SetTCyclideness(FT t) {m_dTC = t;};
	FT GetTLength(void) {return m_dTL;};
	void SetTLength(FT t) {m_dTL = t;};
	FT GetMaxRidgeness(void) {return m_dMaxR;};
	void SetMaxRidgeness(FT r) {m_dMaxR = r;};
	FT GetMinRidgeness(void) {return m_dMinR;};
	void SetMinRidgeness(FT r) {m_dMinR = r;};
	FT GetMaxSphericalness(void) {return m_dMaxS;};
	void SetMaxSphericalness(FT s) {m_dMaxS = s;};
	FT GetMinSphericalness(void) {return m_dMinS;};
	void SetMinSphericalness(FT s) {m_dMinS = s;};
	FT GetMaxCyclideness(void) {return m_dMaxC;};
	void SetMaxCyclideness(FT c) {m_dMaxC = c;};
	FT GetMinCyclideness(void) {return m_dMinC;};
	void SetMinCyclideness(FT c) {m_dMinC = c;};
	FT GetMaxLength(void) {return m_dMaxL;};
	void SetMaxLength(FT l) {m_dMaxL = l;};
	FT GetMinLength(void) {return m_dMinL;};
	void SetMinLength(FT l) {m_dMinL = l;};
	void SetShowDir(bool b) {m_bShowDir = b;};
	bool GetShowDir(void) {return m_bShowDir;};
	void SetShowEpDir(bool b) {m_bShowEpDir = b;};
	bool GetShowEpDir(void) {return m_bShowEpDir;};
	void SetShowOptState(bool b) {m_bShowOptState = b;};
	bool GetShowOptState(void) {return m_bShowOptState;};

	FT GetAvgSegLen(void)
	{
		if (m_dAvgSegLen > 0.0) {
			return m_dAvgSegLen;
		}
		if (!m_bCompLen) {
			compute_line_length();
		}
		m_dAvgSegLen = 0.0;
		int num_seg = 0;
		for (int i=0; i<m_pCLInfo.size(); i++) {
			m_dAvgSegLen += m_pCLInfo[i].l;
			num_seg += m_pCLInfo[i].seg.size();
		}
		m_dAvgSegLen /= (FT) num_seg;
		return m_dAvgSegLen;
	}

	void compute_line_length()
	{
		for (int i=0; i<m_pCLInfo.size(); i++) {
			FT dLen = 0.0;
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++) {
				m_pCLInfo[i].seg[j].l = m_Points[m_pCLInfo[i].seg[j].v[0]].distance(m_Points[m_pCLInfo[i].seg[j].v[1]]);
				dLen += m_pCLInfo[i].seg[j].l;
			}
			m_pCLInfo[i].l = dLen;
		}
		m_bCompLen = true;
	}

	// compute optimal orientation for the curves
	int compute_optimal_orien(void)
	{
		if (!m_bSegConsist) {
			make_seg_consistent();	// make orientation of segments in each curve consistent
		}
		if (!m_bSegSequent) {	// order the segments sequentially
			make_seg_sequent();
		}
		if (!m_bCompLen) {	// compute length for each curve
			compute_line_length();
		}
		int iMax = 0;
		FT dMaxLen = 0.0;
		int iNumLine = 0;
		std::vector<int> scan(m_pCLInfo.size(), 0);
		std::vector<int> line;
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			if (m_pCLInfo[i].l > dMaxLen) {
				iMax = i;
				dMaxLen = m_pCLInfo[i].l;
			}
			iNumLine++;
		}
		if (dMaxLen == 0.0) {
			MSG_BOX_ERROR("compute_optimal_orien: the longest line has 0 length!");
			return -1;
		}
		scan[iMax] = 1;
		line.push_back(iMax);
		for (int t=0; t<iNumLine-1; t++)
		{
			compute_site_vectors(line);
			m_pMesh->compute_s_hvf();
			FT dMTotalC = std::numeric_limits<FT>::min();
			FT dMAvgC = 0.0;
			bool bMReverse = false;
			bool bFound = false;
			for (int i=0; i<m_pCLInfo.size(); i++) {
				if (m_pCLInfo[i].tag==0 || scan[i]==1) {
					continue;
				}
				FT dTotalC, dAvgC;
				bool bReverse;
				compute_consistency(i, dTotalC, dAvgC, bReverse);	// get consistency score
				if (dTotalC > dMTotalC) {
					iMax = i;
					dMTotalC = dTotalC;
					dMAvgC = dAvgC;
					bMReverse = bReverse;
					bFound = true;
				}
			}
			if (!bFound) {
				MSG_BOX_ERROR("compute_optimal_orien: loop time error!");
				return -1;
			}
			//////////////////////////////////////////////////////////////////////////
			if (bMReverse) {
				reverse_line_orien(iMax);
			}
			//////////////////////////////////////////////////////////////////////////
			line.push_back(iMax);
			scan[iMax] = 1;
		}
		return 0;
	}

	void filter_crestlines(void)
	{
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].r<m_dTR || m_pCLInfo[i].s<m_dTS
				|| m_pCLInfo[i].c<m_dTC || m_pCLInfo[i].l<m_dTL) {
				m_pCLInfo[i].tag = 0;
			} else {
				m_pCLInfo[i].tag = 1;
			}
		}
	}

	void filter_picked(void)
	{
		if (m_iPickLine[0]<0 || m_iPickLine[0]>=m_pCLInfo.size()) {
			return;
		}
		m_pCLInfo[m_iPickLine[0]].tag = 0;
	}

	bool break_picked(void)
	{
		if (m_iPickLine[0]<0 || m_iPickLine[0]>=m_pCLInfo.size()) {
			return false;
		}
		if (m_iPickLP[0]<0 || m_iPickLP[0]>=m_pCLInfo[m_iPickLine[0]].seg.size()) {
			return false;
		}
		int ls = m_pCLInfo.size();
		m_pCLInfo.resize(m_pCLInfo.size()+2);
		if (break_at_point(m_pCLInfo[m_iPickLine[0]], m_iPickLP[0], m_pCLInfo[ls], m_pCLInfo[ls+1]) == -1) {
			m_pCLInfo.resize(m_pCLInfo.size()-2);
			return false;
		} else {
			std::set<int> dels;
			dels.insert(m_iPickLine[0]);
			del_crestlines(dels);
			m_iPickLine[0] = ls;
			m_iPickLP[0] = 0;
			return true;
		}
	}

	bool remove_picked_line_point(void)
	{
		if (m_iPickLine[0]<0 || m_iPickLine[0]>=m_pCLInfo.size()) {
			return false;
		}
		if (m_iPickLP[0]<0 || m_iPickLP[0]>=m_pCLInfo[m_iPickLine[0]].seg.size()) {
			return false;
		}
		if (m_pCLInfo[m_iPickLine[0]].seg.size() < 3) {
			return false;
		}
		int &i = m_iPickLine[0];
		int &j = m_iPickLP[0];
		if (j == 0) {
			m_pCLInfo[i].seg.erase(m_pCLInfo[i].seg.begin());
			m_pCLInfo[i].dir.erase(m_pCLInfo[i].dir.begin());
		} else if (j == m_pCLInfo[i].seg.size()-1) {
			m_pCLInfo[i].seg.erase(m_pCLInfo[i].seg.end()-1);
			m_pCLInfo[i].dir.erase(m_pCLInfo[i].dir.end()-1);
		} else {
			m_pCLInfo[i].seg[j-1].v[1] = m_pCLInfo[i].seg[j].v[1];
			m_pCLInfo[i].seg[j-1].fi = (m_pCLInfo[i].seg[j-1].fi==m_pCLInfo[i].seg[j].fi)?m_pCLInfo[i].seg[j-1].fi:-1;
			m_pCLInfo[i].seg.erase(m_pCLInfo[i].seg.begin()+j);
			m_pCLInfo[i].dir.erase(m_pCLInfo[i].dir.begin()+j);
		}
		compute_smooth_dir(i);
		j = __max(0, j-1);
		return true;
	}

	bool link_picked(void)
	{
		if (m_iPickLine[0]<0 || m_iPickLine[0]>=m_pCLInfo.size()) {
			return false;
		}
		if (m_iPickLine[1]<0 || m_iPickLine[1]>=m_pCLInfo.size()) {
			return false;
		}
		const CLI<FT> &CL1 = m_pCLInfo[m_iPickLine[0]];
		const CLI<FT> &CL2 = m_pCLInfo[m_iPickLine[1]];
		//////////////////////////////////////////////////////////////////////////
		const CLI<FT>::SV &pIS = CL1.seg;
		const CLI<FT>::SV &pJS = CL2.seg;
		bool bCL1R=false, bCL2R=false;
		FT dMinDist = std::numeric_limits<FT>::max();
		FT dDist = m_Points[pIS.back().v[1]].distance(m_Points[pJS.front().v[0]]);
		if (dDist < dMinDist) {
			dMinDist = dDist;
			bCL1R = false;
			bCL2R = false;
		}
		dDist = m_Points[pIS.back().v[1]].distance(m_Points[pJS.back().v[1]]);
		if (dDist < dMinDist) {
			dMinDist = dDist;
			bCL1R = false;
			bCL2R = true;
		}
		dDist = m_Points[pIS.front().v[0]].distance(m_Points[pJS.back().v[1]]);
		if (dDist < dMinDist) {
			dMinDist = dDist;
			bCL1R = true;
			bCL2R = true;
		}
		dDist = m_Points[pIS.front().v[0]].distance(m_Points[pJS.front().v[0]]);
		if (dDist < dMinDist) {
			dMinDist = dDist;
			bCL1R = true;
			bCL2R = false;
		}
		//////////////////////////////////////////////////////////////////////////
		int ls = m_pCLInfo.size();
		m_pCLInfo.resize(m_pCLInfo.size()+1);
		merge_two_lines(m_pCLInfo[ls], m_pCLInfo[m_iPickLine[0]], bCL1R, m_pCLInfo[m_iPickLine[1]], bCL2R, false);
		std::set<int> dels;
		dels.insert(m_iPickLine[0]);
		dels.insert(m_iPickLine[1]);
		del_crestlines(dels);
		m_iPickLine[0] = ls-2;
		m_iPickLP[0] = 0;
		m_iPickLine[1] = -1;
		m_iPickLP[1] = -1;
		return true;
	}

	void filter_concave(void)
	{
		m_FConcave.clear();
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag!=0 && m_pCLInfo[i].type==CONCAVE) {
				m_pCLInfo[i].tag = 0;
				m_FConcave.push_back(i);
			}
		}
	}
	void unfilter_concave(void)
	{
		for (int i=0; i<m_FConcave.size(); i++) {
			m_pCLInfo[m_FConcave[i]].tag = 1;
		}
	}

	void filter_convex(void)
	{
		m_FConvex.clear();
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag!=0 && m_pCLInfo[i].type==CONVEX) {
				m_pCLInfo[i].tag = 0;
				m_FConvex.push_back(i);
			}
		}
	}
	void unfilter_convex(void)
	{
		for (int i=0; i<m_FConvex.size(); i++) {
			m_pCLInfo[m_FConvex[i]].tag = 1;
		}
	}

	bool pick_line_by_colomn(Vector3 &sp, Vector3 &dx, Vector3 &dy, Vector3 &dz, bool bSec)
	{
		FT min_t = FLT_MAX;
		FT t = 0.0f;
		Vector3 vec;
		FT width = dx.magnitude();
		FT height = dy.magnitude();
		dx.normalize();
		dy.normalize();
		dz.normalize();
		int &iL = (bSec&&m_iPickLine[0]!=-1) ? m_iPickLine[1] : m_iPickLine[0];
		int &iLP = (bSec&&m_iPickLine[0]!=-1) ? m_iPickLP[1] : m_iPickLP[0];
		bool retval = false;
		for (int i=0; i<m_pCLInfo.size(); i++)
		{
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++)
			{
				vec = m_Points[m_pCLInfo[i].seg[j].v[0]] -sp;
				t = dz.dot(vec);
				if (t <= 0 || t >= min_t) {
					continue;
				}
				if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
					continue;
				}
				if (width < fabs(dx.dot(vec))) {
					continue;
				}
				if (height < fabs(dy.dot(vec))) {
					continue;
				}
				if (t < min_t) {
					min_t = t;
					iL = i;
					iLP = j;
					retval = true;
				}
			}
		}
		return retval;
	}

	bool site_vectors_empty(void)
	{
		return m_hvf_sites.empty();
	}

	// compute site vectors for computing harmonic vector fields
	// in this function, we use (site->second).second=2 to denote the vectors which will
	// be changed but not to be added or deleted
	void compute_site_vectors(void)
	{
		if (m_pMesh == NULL)
		{ MSG_BOX_ERROR("No mesh information!"); return; }

		MAP_IVS::iterator it;
		int vid;
		FT w;
		for (int i=0; i<m_pCLInfo.size(); i++)
		{
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++) {
				if (j%5!=0 || m_pCLInfo[i].seg[j].fi==-1) {
					continue;
				}
				// find the closest vertex in triangle m_pCLInfo[i].seg[j].fi
				int fi = m_pCLInfo[i].seg[j].fi;
				Vector3 v;
				const Vector3 &ev1 = m_Points[m_pCLInfo[i].seg[j].v[0]];
				const Vector3 &ev2 = m_Points[m_pCLInfo[i].seg[j].v[1]];
				FT min_sqd = std::numeric_limits<FT>::max();
				int min_k = 0;
				for (int k=0; k<3; k++) {
					const Point_3 &vp = m_pMesh->fvp(fi, k);
					v.set(vp[0], vp[1], vp[2]);
					FT sqd = sqdPnt2LineSeg(ev1, ev2, v);
					if (sqd < min_sqd) {
						min_sqd = sqd;
						min_k = k;
					}
				}
				int vid = m_pMesh->fvid(fi, min_k);
				w = 1.0 / min_sqd;
				// check if existed
				if ((it=m_hvf_sites.find(vid)) != m_hvf_sites.end()) {
					if ((it->second).second == 0) {	// existed and first time handling in this round
						(it->second).first.set(0.0, 0.0, 0.0);	// reset
						(it->second).second = 2;	// up-to-date, handled this round
					}
					(it->second).first += m_pCLInfo[i].dir[j]*w;
				} else {
					m_hvf_sites.insert(std::make_pair(vid, std::make_pair(m_pCLInfo[i].dir[j]*w,1)));
				}
			}
		}
		// normalize all site vectors
		std::vector<MAP_IVS::iterator> deli;
		m_pMesh->clear_hvf_sites();
		for (it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++)
		{
			if ((it->second).second == 0) {	// not appear this round, should be deleted
				m_pMesh->insert_hvf_site(std::make_pair(it->first, std::make_pair(Vector3(0.0,0.0,0.0), -1)));
				deli.push_back(it);
			} else {
				if ((it->second).second == 2) {	// 2 == 0 : distinctive from old, to-be-deleted 0
					(it->second).second = 0;
				}
				Vector3 v((it->second).first);
				v.normalize();
				v *= 0.15;
				m_pMesh->insert_hvf_site(std::make_pair(it->first, std::make_pair(v, (it->second).second)));
				// clear to be up-to-date
				(it->second).second = 0;
			}
		}
		// delete those should be deleted at once in this->m_hvf_sites
		for (unsigned int i=0; i<deli.size(); i++) {
			m_hvf_sites.erase(deli[i]);
		}
	}

	// compute site vectors for computing harmonic vector fields
	void compute_site_vectors(const std::vector<int> &CL)
	{
		if (m_pMesh == NULL)
		{ MSG_BOX_ERROR("No mesh information!"); return; }
		if (!m_bCompLen) {
			compute_line_length();
		}
		MAP_IVS::iterator it;
		for (int i=0; i<CL.size(); i++)
		{
			FT dDist = 0;
			FT dStep = __min(GetAvgSegLen()*16.0, m_pCLInfo[CL[i]].l/10.0);
			for (int j=0; j<m_pCLInfo[CL[i]].seg.size(); j++)
			{
				dDist += m_pCLInfo[CL[i]].seg[j].l;
				if (dDist < dStep) {
					continue;
				}
				if (m_pCLInfo[CL[i]].seg[j].fi == -1) {
					if (j<m_pCLInfo[CL[i]].seg.size()-1 && m_pCLInfo[CL[i]].seg[j+1].fi!=-1) {
						dDist += m_pCLInfo[CL[i]].seg[++j].l;
					} else {
						continue;
					}
				}
				dDist = 0.0;	// clear to 0
				// find the closest vertex in triangle m_pCLInfo[i].seg[j].fi
				int fi = m_pCLInfo[CL[i]].seg[j].fi;
				Vector3 v;
				const Vector3 &ev1 = m_Points[m_pCLInfo[CL[i]].seg[j].v[0]];
				const Vector3 &ev2 = m_Points[m_pCLInfo[CL[i]].seg[j].v[1]];
				FT min_sqd = std::numeric_limits<FT>::max();
				int min_k = 0;
				for (int k=0; k<3; k++) {
					const Point_3 &vp = m_pMesh->fvp(fi, k);
					v.set(vp[0], vp[1], vp[2]);
					FT sqd = sqdPnt2LineSeg(ev1, ev2, v);
					if (sqd < min_sqd) {
						min_sqd = sqd;
						min_k = k;
					}
				}
				int vid = m_pMesh->fvid(fi, min_k);
				FT w = 1.0 / min_sqd;
				// check if existed
				if ((it=m_hvf_sites.find(vid)) != m_hvf_sites.end()) {
					if ((it->second).second == 0) {	// existed and first time handling in this round
						(it->second).first.set(0.0, 0.0, 0.0);	// reset
						(it->second).second = 2;	// up-to-date, handled this round
					}
					(it->second).first += m_pCLInfo[CL[i]].dir[j]*w;
				} else {
					m_hvf_sites.insert(std::make_pair(vid, std::make_pair(m_pCLInfo[CL[i]].dir[j]*w,1)));
				}
			}
		}
		// normalize all site vectors
		std::vector<MAP_IVS::iterator> deli;
		m_pMesh->clear_hvf_sites();
		for (it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++)
		{
			if ((it->second).second == 0) {	// not appear this round, should be deleted
				m_pMesh->insert_hvf_site(std::make_pair(it->first, std::make_pair(Vector3(0.0,0.0,0.0), -1)));
				deli.push_back(it);
			} else {
				if ((it->second).second == 2) {	// 2 == 0 : distinctive from old, to-be-deleted 0
					(it->second).second = 0;
				}
				Vector3 v((it->second).first);
				v.normalize();
				v *= 0.15;
				m_pMesh->insert_hvf_site(std::make_pair(it->first, std::make_pair(v, (it->second).second)));
				// clear to be up-to-date
				(it->second).second = 0;
			}
		}
		// delete those should be deleted at once in this->m_hvf_sites
		for (unsigned int i=0; i<deli.size(); i++) {
			m_hvf_sites.erase(deli[i]);
		}
	}

	//void write_ridges(std::ofstream &stream)
	//{
	//	stream << "V " << m_pMesh->size_of_vertices() << std::endl;
	//	stream << "E " << m_pMesh->size_of_halfedges() << std::endl;
	//	stream << "F " << m_pMesh->size_of_facets() << std::endl;
	//	int num_ridges = 0;
	//	for (int i=0; i<ridge_lines.size(); i++)
	//	{
	//		if (m_pCLInfo[i].tag == 1) {
	//			num_ridges++;
	//		}
	//	}
	//	stream << "R " << num_ridges << std::endl;
	//	for (int i=0; i<ridge_lines.size(); i++)
	//	{
	//		if (m_pCLInfo[i].tag == 0) {
	//			continue;
	//		}
	//		ridge_lines[i]->dump_raw(stream);
	//	}
	//}

	int load_crestlines(const CString &sPathName)
	{
		CString sExt = sPathName;
		sExt = sExt.Right(sExt.GetLength()-sExt.ReverseFind('.')-1);
		if (sExt == "ccl") {
			std::ifstream stream(sPathName);
			if (!stream) {
				MSG_BOX_ERROR("Cannot open file: %s!", sPathName);
				return -1;
			} else {
			//	m_pCLInfo.clear();
				if (readCCL(stream) != 0) {
					MSG_BOX_ERROR("Load convex crest lines error!");
					return -1;
				}
			}
			m_bSegConsist = true;
			m_bSegSequent = true;
			m_bCompLen = false;
			compute_line_length();
			// get min-max of stength and sharpness
			get_crest_range();
		}
		else if (sExt == "txt") {
			CString sDirName = sPathName;
			CString sModelName = sPathName;
			sDirName = sDirName.Left(sDirName.ReverseFind('\\')+1);
			sModelName = sModelName.Right(sModelName.GetLength()-sModelName.ReverseFind('_')-1);
			std::ifstream stream1(sDirName+"ridges_"+sModelName);
			if (!stream1) {
				MSG_BOX_ERROR("Cannot open file: %s!", sDirName+"ridges_"+sModelName);
				return -1;
			} else {
				m_pCLInfo.clear();
				if (read_crestlines(stream1, CONCAVE) != 0) {
					MSG_BOX_ERROR("Load convex crest lines error!");
					return -1;
				}
			}
			std::ifstream stream2(sDirName+"ravines_"+sModelName);
			if (!stream2) {
				MSG_BOX_ERROR("Cannot open file: %s!", sDirName+"ravines_"+sModelName);
				return -1;
			} else {
				if (read_crestlines(stream2, CONVEX) != 0) {
					MSG_BOX_ERROR("Load concave crest lines error!");
					return -1;
				}
			}
			m_bSegConsist = false;
			m_bSegSequent = false;
			m_bCompLen = false;
			// clean the crest lines
			clean_lines();
			compute_line_length();
			// get min-max of stength and sharpness
			get_crest_range();
		}
		return 0;
	}

	int readCCL(std::ifstream &stream)
	{
		std::string buf;
		int num_points, num_segs, num_lines;
		stream >> num_points;
		if (num_points<0 || num_points>=m_pMesh->size_of_vertices()) {
			return -1;
		}
		stream >> num_segs;
		if (num_segs < 0) {
			return -1;
		}
		stream >> num_lines;
		if (num_lines < 0) {
			return -1;
		}
		if (num_lines == 0) {
			return 0;
		}
		int ls = m_pCLInfo.size();
		int ps = m_Points.size();
		m_pCLInfo.resize(m_pCLInfo.size() + num_lines);
		m_Points.resize(m_Points.size() + num_points);
		m_Branch.resize(m_Branch.size() + num_points);
		for (int i=0; i<num_points; i++)
		{
			m_Branch[ps+i].resize(1);
			stream >> m_Points[ps+i].x >> m_Points[ps+i].y >> m_Points[ps+i].z >> m_Branch[ps+i][0].first;
			m_Branch[ps+i][0].first += ls;
			m_Branch[ps+i][0].second = 0;
		}
		for (int i=0; i<num_lines; i++)
		{
			int type;
			stream >> m_pCLInfo[ls+i].r >> m_pCLInfo[ls+i].s >> m_pCLInfo[ls+i].c >> type;
			m_pCLInfo[ls+i].type = (Crest_type)type;
		}
		int ev1, ev2, fi;
		FT  x, y, z;
		for (int i=0; i<num_segs; i++)
		{
			stream >> ev1 >> ev2 >> fi;
			if (m_Branch[ps+ev1][0].first != m_Branch[ps+ev2][0].first) {
				MSG_BOX_ERROR("read_crestlines: component ambiguous!");
				return -1;
			}
			if (m_Branch[ps+ev1][0].first-ls<0 || m_Branch[ps+ev1][0].first-ls>=num_lines) {
				MSG_BOX_ERROR("read_crestlines: error component number!");
				return -1;
			}
			m_pCLInfo[m_Branch[ps+ev1][0].first].seg.push_back(CLI<FT>::CSeg(ps+ev1, ps+ev2, fi));
			stream >> x >> y >> z;
			m_pCLInfo[m_Branch[ps+ev1][0].first].dir.push_back(Vector3(x, y, z));
		}
		return 0;
	}

	int read_crestlines(std::ifstream &stream, Crest_type type)
	{
		std::string buf;
		int num_points, num_segs, num_lines;
		stream >> num_points;
		if (num_points<0 || num_points>=m_pMesh->size_of_vertices()) {
			return -1;
		}
		stream >> num_segs;
		if (num_segs < 0) {
			return -1;
		}
		stream >> num_lines;
		if (num_lines < 0) {
			return -1;
		}
		if (num_lines == 0) {
			return 0;
		}
		int ls = m_pCLInfo.size();
		int ps = m_Points.size();
		m_pCLInfo.resize(m_pCLInfo.size() + num_lines);
		m_Points.resize(m_Points.size() + num_points);
		m_Branch.resize(m_Branch.size() + num_points);
		for (int i=0; i<num_points; i++)
		{
			m_Branch[ps+i].resize(1);
			stream >> m_Points[ps+i].x >> m_Points[ps+i].y >> m_Points[ps+i].z >> m_Branch[ps+i][0].first;
			m_Branch[ps+i][0].first += ls;
			m_Branch[ps+i][0].second = 0;
		}
		for (int i=0; i<num_lines; i++)
		{
			stream >> m_pCLInfo[ls+i].r >> m_pCLInfo[ls+i].s >> m_pCLInfo[ls+i].c;
			m_pCLInfo[ls+i].type = type;
		}
		int ev1, ev2, fi;
		for (int i=0; i<num_segs; i++)
		{
			stream >> ev1 >> ev2 >> fi;
			if (m_Branch[ps+ev1][0].first != m_Branch[ps+ev2][0].first) {
				MSG_BOX_ERROR("read_crestlines: component ambiguous!");
				return -1;
			}
			if (m_Branch[ps+ev1][0].first-ls<0 || m_Branch[ps+ev1][0].first-ls>=num_lines) {
				MSG_BOX_ERROR("read_crestlines: error component number!");
				return -1;
			}
			m_pCLInfo[m_Branch[ps+ev1][0].first].seg.push_back(CLI<FT>::CSeg(ps+ev1, ps+ev2, fi));
		}
		return 0;
	}

	int write_cleaned_crestlines(std::ofstream &stream)
	{	// *.ccl
		int iNumLine = 0;
		int iNumSeg = 0;
		std::vector<int> PI(m_Points.size(), -1);
		std::vector<int> LI(m_pCLInfo.size(), -1);
		std::vector<std::vector<int>> PInL(m_Points.size()); 
		int iLMapId = 0;
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++) {
				PI[m_pCLInfo[i].seg[j].v[0]] = 1;
				PI[m_pCLInfo[i].seg[j].v[1]] = 1;
			}
			iNumLine++;
			iNumSeg += m_pCLInfo[i].seg.size();
			LI[i] = iLMapId;
			iLMapId++;
		}
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			PInL[m_pCLInfo[i].seg[0].v[0]].push_back(LI[i]);
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++) {
				PInL[m_pCLInfo[i].seg[j].v[1]].push_back(LI[i]);
			}
		}
		int iPMapId = 0;
		for (int i=0; i<PI.size(); i++) {
			if (PI[i] == -1) {
				continue;
			}
			PI[i] = iPMapId;
			iPMapId += PInL[i].size();
		}
		stream << iPMapId << std::endl;
		stream << iNumSeg << std::endl;
		stream << iNumLine << std::endl;
		for (int i=0; i<PI.size(); i++) {
			if (PI[i] == -1) {
				continue;
			}
			for (int j=0; j<PInL[i].size(); j++) {
				stream << m_Points[i].x << " " << m_Points[i].y << " "
					   << m_Points[i].z << " " << PInL[i][j] << std::endl;
			}
		}
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			stream << m_pCLInfo[i].r << " " << m_pCLInfo[i].s << " "
				   << m_pCLInfo[i].c << " " << m_pCLInfo[i].type << std::endl;
		}
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++) {
				for (int k=0; k<PInL[m_pCLInfo[i].seg[j].v[0]].size(); k++) {
					if (PInL[m_pCLInfo[i].seg[j].v[0]][k] == LI[i]) {
						stream << PI[m_pCLInfo[i].seg[j].v[0]]+k << " ";
						break;
					}
				}
				for (int k=0; k<PInL[m_pCLInfo[i].seg[j].v[1]].size(); k++) {
					if (PInL[m_pCLInfo[i].seg[j].v[1]][k] == LI[i]) {
						stream << PI[m_pCLInfo[i].seg[j].v[1]]+k << " ";
						break;
					}
				}
				stream << m_pCLInfo[i].seg[j].fi << " ";
				stream << m_pCLInfo[i].dir[j].x << " "
					   << m_pCLInfo[i].dir[j].y << " "
					   << m_pCLInfo[i].dir[j].z << std::endl;
			}
		}
		return 0;
	}

	void gl_draw_crestlines_3d(void)
	{
		GLfloat red[] = {1.0f, 0.1f, 0.1f, 1.0f};
		GLfloat blue[] = {0.1f, 0.1f, 1.0f, 1.0f};
		GLfloat yellow[] = {0.8f, 0.8f, 0.0f, 1.0f};
		GLfloat green[] = {0.1f, 0.8f, 0.0f, 1.0f};
		GLfloat white[] = {1, 1, 1, 1.0f};
		GLfloat magenta[] = {0.7f, 0.1f, 0.4f, 1.0f};
		GLUquadricObj *pQuadric = ::gluNewQuadric();
		Vector3 z_axis(0.0f, 0.0f, 1.0f);
		::glPushAttrib(GL_CURRENT_BIT|GL_POINT_BIT|GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_POLYGON_BIT);
		::glEnable(GL_LIGHTING);
		::glEnable(GL_CULL_FACE);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		::glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, white);
		::glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 40.0);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag == 0) {
				continue;
			}
			if (i==m_iPickLine[0]) {
				if (m_iPickLP[0]>=0 && m_iPickLP[0]<m_pCLInfo[i].seg.size()) {
					::glColor4fv(red);
					::glPushMatrix();
					::glTranslatef(m_Points[m_pCLInfo[i].seg[m_iPickLP[0]].v[0]].x,
								   m_Points[m_pCLInfo[i].seg[m_iPickLP[0]].v[0]].y,
								   m_Points[m_pCLInfo[i].seg[m_iPickLP[0]].v[0]].z);
					::glutSolidSphere(0.018f, 6, 6);
					::glPopMatrix();
				}
				::glColor4fv(yellow);
			} else if (i==m_iPickLine[1]) {
				::glColor4fv(green);
			} else if (m_pCLInfo[i].type == CONCAVE) {
				::glColor4fv(blue);
			} else if (m_pCLInfo[i].type == CONVEX) {
				::glColor4fv(red);
			}
			for (int j=0; j<m_pCLInfo[i].seg.size(); j++) {
				int v1 = m_pCLInfo[i].seg[j].v[0];
				int v2 = m_pCLInfo[i].seg[j].v[1];
				::glPushMatrix();
				::glTranslatef(m_Points[v1].x, m_Points[v1].y, m_Points[v1].z);
				::glutSolidSphere(0.016f, 6, 6);
				Vector3 v(m_Points[v2].x-m_Points[v1].x,
						  m_Points[v2].y-m_Points[v1].y,
						  m_Points[v2].z-m_Points[v1].z);
				float angle = acos(v.z/v.magnitude()) * ML_RAD_TO_DEG;
				Vector3 axis = z_axis.cross(v);
				::glRotatef(angle, axis.x, axis.y, axis.z);
				::gluCylinder(pQuadric, 0.016, 0.016, v.magnitude(), 6, 2);
				::glPopMatrix();
			}
			if (m_bShowDir && m_pCLInfo[i].dir.size()>0) {
				glPushAttrib(GL_CURRENT_BIT|GL_LIGHTING_BIT);
				if (i==m_iPickLine[0] || i==m_iPickLine[1]) {
					::glColor4fv(green);
				} else {
					::glColor4fv(yellow);
				}
				int mid = m_pCLInfo[i].dir.size() / 2;
				const Vector3 &vec1 = m_pCLInfo[i].dir[mid];
				int v = m_pCLInfo[i].seg[mid].v[0];
				FT rot_angle = Acos(vec1.z/vec1.magnitude());
				Vector3 rot_axis = z_axis.cross(vec1);
				::glPushMatrix();
				::glTranslatef(m_Points[v].x, m_Points[v].y, m_Points[v].z);
				::glRotatef(rot_angle, rot_axis.x, rot_axis.y, rot_axis.z);
				::gluDisk(pQuadric, 0.0, 0.075, 16, 2);	// cone bottom
				::gluCylinder(pQuadric, 0.075, 0.0, 0.075*4.0, 16, 4);	// cone
				::glPopMatrix();
				::glPopAttrib();
			}
			if (m_bShowEpDir && m_pCLInfo[i].dir.size()>0) {
				glPushAttrib(GL_CURRENT_BIT|GL_LIGHTING_BIT);
				if (i==m_iPickLine[0] || i==m_iPickLine[1]) {
					::glColor4fv(yellow);
				} else {
					::glColor4fv(green);
				}
				const Vector3 &vec1 = m_pCLInfo[i].dir[0];
				int v = m_pCLInfo[i].seg[0].v[0];
				FT vec_length = vec1.magnitude() * 0.2;
				FT arrow_bar_len = vec_length - 0.09;
				FT rot_angle = Acos(vec1.z/vec1.magnitude());
				Vector3 rot_axis = z_axis.cross(vec1);
				::glPushMatrix();
				::glTranslatef(m_Points[v].x, m_Points[v].y, m_Points[v].z);
				::glRotatef(rot_angle, rot_axis.x, rot_axis.y, rot_axis.z);
				::gluCylinder(pQuadric, 0.015, 0.015, arrow_bar_len, 6, 2);
				::glTranslatef(0.0f, 0.0f, arrow_bar_len);
				::gluCylinder(pQuadric, 0.03, 0.0, 0.09, 8, 4);	// cone
				::glPopMatrix();
				const Vector3 &vec2 = m_pCLInfo[i].dir[m_pCLInfo[i].dir.size()-1];
				v = m_pCLInfo[i].seg[m_pCLInfo[i].seg.size()-1].v[1];
				vec_length = vec2.magnitude() * 0.2;
				arrow_bar_len = vec_length - 0.09;
				rot_angle = Acos(vec2.z/vec2.magnitude());
				rot_axis = z_axis.cross(vec2);
				::glPushMatrix();
				::glTranslatef(m_Points[v].x, m_Points[v].y, m_Points[v].z);
				::glRotatef(rot_angle, rot_axis.x, rot_axis.y, rot_axis.z);
				::gluCylinder(pQuadric, 0.015, 0.015, arrow_bar_len, 6, 2);
				::glTranslatef(0.0f, 0.0f, arrow_bar_len);
				::gluCylinder(pQuadric, 0.03, 0.0, 0.09, 8, 4);	// cone
				::glPopMatrix();
				::glPopAttrib();
			}
		}
		::glPopAttrib();
		::gluDeleteQuadric(pQuadric);
	}

	void weld_close_lines(FT dWeldTRate=3.0)
	{
		if (!m_bSegConsist) {
			make_seg_consistent();
		}
		if (!m_bSegSequent) {
			make_seg_sequent();
		}
		FT dT = GetAvgSegLen() * dWeldTRate;
		std::vector<std::vector<int>> connect(m_pCLInfo.size());
		for (int i=0; i<m_pCLInfo.size(); i++) {
			connect[i].resize(2, -1); // [0]:front [1]:back
		}
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].tag==0 || (connect[i][0]!=-1 && connect[i][1]!=-1)) {
				continue;
			}
			const CLI<FT>::SV &pIS = m_pCLInfo[i].seg;
			const CLI<FT>::VV &pID = m_pCLInfo[i].dir;
			for (int j=i+1; j<m_pCLInfo.size(); j++) {
				if (m_pCLInfo[j].tag==0 || (connect[j][0]!=-1 && connect[j][1]!=-1)) {
					continue;
				}
				const CLI<FT>::SV &pJS = m_pCLInfo[j].seg;
				const CLI<FT>::VV &pJD = m_pCLInfo[j].dir;
				if (connect[i][1]==-1 && connect[j][0]==-1 && pIS.back().v[1]!=pJS.front().v[0] 
					&& pID.back().dot(pJD.front())>0.92
					&& m_Points[pIS.back().v[1]].distance(m_Points[pJS.front().v[0]])<dT)
				{
					connect[i][1] = (j!=connect[i][0]) ? j : connect[i][1];
					connect[j][0] = (i!=connect[j][1]) ? i : connect[j][0];
				}
				if (connect[i][1]==-1 && connect[j][1]==-1 && pIS.back().v[1]!=pJS.back().v[1]
					&& pID.back().dot(pJD.back())<-0.92
					&& m_Points[pIS.back().v[1]].distance(m_Points[pJS.back().v[1]])<dT)
				{
					connect[i][1] = (j!=connect[i][0]) ? j : connect[i][1];
					connect[j][1] = (i!=connect[j][0]) ? i : connect[j][1];
				}
				if (connect[i][0]==-1 && connect[j][1]==-1 && pIS.front().v[0]!=pJS.back().v[1]
					&& pID.front().dot(pJD.back())>0.92
					&& m_Points[pIS.front().v[0]].distance(m_Points[pJS.back().v[1]])<dT)
				{
					connect[i][0] = (j!=connect[i][1]) ? j : connect[i][0];
					connect[j][1] = (i!=connect[j][0]) ? i : connect[j][1];
				}
				if (connect[i][0]==-1 && connect[j][0]==-1 && pIS.front().v[0]!=pJS.front().v[0]
					&& pID.front().dot(pJD.front())<-0.92
					&& m_Points[pIS.front().v[0]].distance(m_Points[pJS.front().v[0]])<dT)
				{
					connect[i][0] = (j!=connect[i][1]) ? j : connect[i][0];
					connect[j][0] = (i!=connect[j][1]) ? i : connect[j][0];
				}
			}
		}
		std::set<int> dels, adds;
		int nOriginNum = m_pCLInfo.size();
		std::vector<int> scan(nOriginNum, 0);
		std::list<std::vector<int>> comp;
		std::list<std::vector<int>>::iterator it;
		std::vector<int> c(3);
		int ls;
		for (int i=0; i<nOriginNum; i++)
		{
			if (scan[i] == 1) {
				continue;
			}
			scan[i] = 1;
			if (connect[i][0]==-1 && connect[i][1]==-1) {
				continue;
			}
			comp.clear();
			c[0] = i; c[1] = 0; c[2] = 1;
			comp.push_front(c);
			find_connect_component(connect, scan, i, 0, true, comp);
			find_connect_component(connect, scan, i, 1, false, comp);
			// begin merge
			ls = m_pCLInfo.size();
			m_pCLInfo.resize(m_pCLInfo.size()+1);
			if (merge_multiple_lines(m_pCLInfo[ls], m_pCLInfo, comp, connect, false) == -1) {
				m_pCLInfo.resize(m_pCLInfo.size()-1);
			} else {
				adds.insert(ls);
				for (it=comp.begin(); it!=comp.end(); it++) {
					int d = (*it)[0];
					dels.insert(d);
					for (int j=1; j<m_pCLInfo[d].seg.size(); j++) {
						if (m_Branch[m_pCLInfo[d].seg[j].v[0]].size() > 1) {
							for (int k=0; k<m_Branch[m_pCLInfo[d].seg[j].v[0]].size(); k++) {
								if (m_Branch[m_pCLInfo[d].seg[j].v[0]][k].first == d) {
									m_Branch[m_pCLInfo[d].seg[j].v[0]][k].first = ls;
								}
							}
						} else {
							m_Branch[m_pCLInfo[d].seg[j].v[0]][0].first = ls;
						}
						if (m_Branch[m_pCLInfo[d].seg[j].v[1]].size() > 1) {
							for (int k=0; k<m_Branch[m_pCLInfo[d].seg[j].v[1]].size(); k++) {
								if (m_Branch[m_pCLInfo[d].seg[j].v[1]][k].first == d) {
									m_Branch[m_pCLInfo[d].seg[j].v[1]][k].first = ls;
								}
							}
						} else {
							m_Branch[m_pCLInfo[d].seg[j].v[1]][0].first = ls;
						}
					}
				}
			}
		}
		// update smooth directions for newly added lines
		for (std::set<int>::iterator si=adds.begin(); si!=adds.end(); si++) {
			compute_smooth_dir(*si);
		}
		// delete really
		del_crestlines(dels, m_Branch);
		// update length
		compute_line_length();
		//
		get_crest_range();
	}

private:
	void compute_consistency(int l, FT &dTC, FT &dAC, bool &bR)
	{
		if (!m_bCompLen) {
			compute_line_length();
		}
		FT dDist = 0;
		FT dStep = __min(GetAvgSegLen()*16.0, m_pCLInfo[l].l/10.0);
		int iNumSeg = m_pCLInfo[l].seg.size();
		FT dTC1(0.0), dTC2(0.0);
		int iNumSample = 0;
		for (int i=0; i<m_pCLInfo[l].seg.size(); i++)
		{
			dDist += m_pCLInfo[l].seg[i].l;
			if (dDist < dStep) {
				continue;
			}
			if (m_pCLInfo[l].seg[i].fi == -1) {
				if (i<iNumSeg-1 && m_pCLInfo[l].seg[i+1].fi!=-1) {
					dDist += m_pCLInfo[l].seg[++i].l;
				} else {
					continue;
				}
			}
			dDist = 0.0;	// clear to 0
			// find the closest vertex in triangle m_pCLInfo[i].seg[j].fi
			int fi = m_pCLInfo[l].seg[i].fi;
			Vector3 v;
			const Vector3 &ev1 = m_Points[m_pCLInfo[l].seg[i].v[0]];
			const Vector3 &ev2 = m_Points[m_pCLInfo[l].seg[i].v[1]];
			FT min_sqd = std::numeric_limits<FT>::max();
			int min_k = 0;
			for (int k=0; k<3; k++) {
				const Point_3 &vp = m_pMesh->fvp(fi, k);
				v.set(vp[0], vp[1], vp[2]);
				FT sqd = sqdPnt2LineSeg(ev1, ev2, v);
				if (sqd < min_sqd) {
					min_sqd = sqd;
					min_k = k;
				}
			}
			const Vector3 &fv = m_pMesh->get_hvf_v(m_pMesh->fvid(fi, min_k));
			const Vector3 &lv = m_pCLInfo[l].dir[i];
			FT dAngle = AcosR(fv.dot(lv)/(fv.magnitude()*lv.magnitude()));
			dTC1 += (ML_PI-dAngle) / (ML_PI+dAngle);
			dAngle = AcosR(fv.dot(m_pCLInfo[l].dir[i]*(-1.0)));
			dTC2 += (ML_PI-dAngle) / (ML_PI+dAngle);
			iNumSample++;
		}
		dTC = __max(dTC1, dTC2);
		dAC = dTC / (FT)iNumSample;
		bR = (dTC==dTC2);
	}

	void get_crest_range(void)
	{
		if (!m_bCompLen) {
			compute_line_length();
		}
		m_dMinR = FT_MAX;	// minimum ridgeness
		m_dMaxR = 0.0;		// maximum ridgeness
		m_dMinS = FT_MAX;	// minimum sphericalness
		m_dMaxS = 0.0;		// maximum sphericalness
		m_dMinC = FT_MAX;	// minimum cyclideness
		m_dMaxC = 0.0;		// maximum cyclideness
		m_dMinL = FT_MAX;	// minimum length
		m_dMaxL = 0.0;		// maximum length
		for (int i=0; i<m_pCLInfo.size(); i++) {
			if (m_pCLInfo[i].r > m_dMaxR) {
				m_dMaxR = m_pCLInfo[i].r;
			}
			if (m_pCLInfo[i].r < m_dMinR) {
				m_dMinR = m_pCLInfo[i].r;
			}
			if (m_pCLInfo[i].s > m_dMaxS) {
				m_dMaxS = m_pCLInfo[i].s;
			}
			if (m_pCLInfo[i].s < m_dMinS) {
				m_dMinS = m_pCLInfo[i].s;
			}
			if (m_pCLInfo[i].c > m_dMaxC) {
				m_dMaxC = m_pCLInfo[i].c;
			}
			if (m_pCLInfo[i].c < m_dMinC) {
				m_dMinC = m_pCLInfo[i].c;
			}
			if (m_pCLInfo[i].l > m_dMaxL) {
				m_dMaxL = m_pCLInfo[i].l;
			}
			if (m_pCLInfo[i].l < m_dMinL) {
				m_dMinL = m_pCLInfo[i].l;
			}
		}
	}

	void clean_lines(void)
	{
		if (!m_bSegConsist) {
			make_seg_consistent();
		}
		// first, clean lines with branches and order the points in the line order
		Branch pSegBranch;
		// find segment branches at each point
		find_branch(pSegBranch);
		// trace segment branches to get line branches
		std::set<int> dels;
		for (int i=0; i<m_Points.size(); i++)
		{
			if (pSegBranch[i].size() < 3) {
				continue;
			}
			int iOriginBN = m_Branch[i][0].first;	// record original
			m_Branch[i].clear();	// clear this big line and seperate it now
			for (int j=0; j<pSegBranch[i].size(); j++)
			{
				if (pSegBranch[i][j].second == 1) {
					// this exit has been accessed, delete it from this branch node
					pSegBranch[i][j].second = -1;	// mark as deleted
					continue;
				}
				int ls = m_pCLInfo.size();
				m_pCLInfo.resize(m_pCLInfo.size()+1);
				trace_seg_branch(m_pCLInfo[ls], m_pCLInfo[iOriginBN], pSegBranch, i, pSegBranch[i][j].first);
				m_Branch[i].push_back(std::make_pair(ls,0));
				//////////////////////////////////////////////////////////////////////////
				for (int k=0; k<pSegBranch.size(); k++) {
					if (pSegBranch[k].size()>0 && pSegBranch[k].size()<3 && pSegBranch[k][0].second==-1) {
						m_Branch[k][0].first = ls;
						pSegBranch[k][0].second = 0;
					}
				}
			}
			dels.insert(iOriginBN);
		}
		// delete really
		del_crestlines(dels, m_Branch);
		//////////////////////////////////////////////////////////////////////////
		// NOTE: from now on, m_PInL should not be used any more because i did no
		//		 update for it. Actually, similar information can be found in branch.
		//		 What's more, a point might belong to multiple lines currently.
		//////////////////////////////////////////////////////////////////////////
		// make sequence for the the rest lines
		make_seg_sequent();
		// compute smooth direction
		compute_smooth_dir();
		// weld lines
		weld_at_branches(m_Branch);
		//weld_close_lines(branch);
	}

	void del_crestlines(std::set<int> &dels, Branch &branch)
	{
		// delete really
		std::set<int>::iterator it, jt;
		std::vector<int> rslt_line_no(m_pCLInfo.size());
		int mv_id=0, shift=0;
		for (it=dels.begin(); it!=dels.end(); it++) {
			for (int i=mv_id; i<(*it); i++) {
				rslt_line_no[i] = i-shift;
			}
			mv_id = (*it)+1;
			shift++;
		}
		for (int i=mv_id; i<m_pCLInfo.size(); i++) {
			rslt_line_no[i] = i-shift;
		}
		for (it=dels.begin(); it!=dels.end(); it++) {
			m_pCLInfo.erase(m_pCLInfo.begin()+(*it));
			for (jt=dels.begin(); jt!=dels.end(); jt++) {
				if (*jt > *it) {
					(*jt)--;
				}
			}
		}
		// update line# in branch nodes
		for (int i=0; i<m_Points.size(); i++)
		{
			for (int j=0; j<branch[i].size(); j++) {
				branch[i][j].first = rslt_line_no[branch[i][j].first];
			}
		}
	}

	void del_crestlines(std::set<int> &dels)
	{
		// delete really
		std::set<int>::iterator it, jt;
		for (it=dels.begin(); it!=dels.end(); it++) {
			m_pCLInfo.erase(m_pCLInfo.begin()+(*it));
			for (jt=dels.begin(); jt!=dels.end(); jt++) {
				if (*jt > *it) {
					(*jt)--;
				}
			}
		}
	}

	void find_connect_component(const std::vector<std::vector<int>> &connect, std::vector<int> &scan,
								int i, int d, bool front, std::list<std::vector<int>> &comp)
	{
		if (connect[i][d] == -1) {
			return;
		}
		if (scan[connect[i][d]] == 1) {
			return;
		}
		std::vector<int> c(3);
		c[0] = connect[i][d];
		if (front) {
			if (connect[c[0]][0] == i) {
				c[1] = 1; c[2] = 0;
			} else {
				c[1] = 0; c[2] = 1;
			}
		} else {
			if (connect[c[0]][0] == i) {
				c[1] = 0; c[2] = 1;
			} else {
				c[1] = 1; c[2] = 0;
			}
		}
		if (front) {
			comp.push_front(c);
		} else {
			comp.push_back(c);
		}
		if (connect[c[0]][0] == i) {
			d = 1;
		} else {
			d = 0;
		}
		scan[c[0]] = 1;
		find_connect_component(connect, scan, c[0], d, front, comp);
	}
	void weld_at_branches(Branch &branch)
	{
		std::set<int> dels;
		for (int i=0; i<branch.size(); i++)
		{
			if (branch[i].size() < 3) {
				continue;
			}
			FT avg_len = 0;
			for (int j=0; j<branch[i].size(); j++) {
				avg_len += m_pCLInfo[branch[i][j].first].seg.size();
			}
			avg_len /= (FT)branch[i].size();
			std::vector<int> Left;
			for (int j=0; j<branch[i].size(); j++) {
				if (m_pCLInfo[branch[i][j].first].seg.size() > avg_len*0.12) {
					Left.push_back(j);
				}
			}
			if (Left.size() == 2) {
				int ls = m_pCLInfo.size();
				m_pCLInfo.resize(m_pCLInfo.size()+1);
				const CLI<FT> &CL1 = m_pCLInfo[branch[i][Left[0]].first];
				const CLI<FT> &CL2 = m_pCLInfo[branch[i][Left[1]].first];
				merge_two_lines(m_pCLInfo[ls], CL1, (CL1.seg.back().v[1]!=i), CL2, (CL2.seg.front().v[0]!=i), true);
				// effect to other branches
				for (int j=0; j<branch.size(); j++) {
					if (j==i) {
						continue;
					}
					for (int k=0; k<branch[j].size(); k++) {
						if (branch[j][k].first==branch[i][Left[0]].first
							|| branch[j][k].first==branch[i][Left[1]].first) {
							branch[j][k].first = ls;
						}
					}
				}
				// record to delete old branches at this branch node
				for (int j=0; j<branch[i].size(); j++) {
					dels.insert(branch[i][j].first);
				}
				branch[i].resize(1);
				branch[i][0].first = ls;	// update line#: only one line pass through this branch now
			}
		}
		// delete really
		del_crestlines(dels, branch);
	}
	int merge_two_lines(CLI<FT> &NewCL, const CLI<FT> &CL1, bool bL1R, const CLI<FT> &CL2, bool bL2R, bool bCP)
	{
		if (CL1.type != CL2.type) {
			MSG_BOX_ERROR("merge_two_lines: trying to merge two lines with different types!");
			return -1;
		}
		FT lambda = (FT)CL1.seg.size() / (FT)(CL1.seg.size()+CL2.seg.size());
		NewCL.r = CL1.r * lambda + CL2.r * (1.0-lambda);
		NewCL.s = CL1.s * lambda + CL2.s * (1.0-lambda);
		NewCL.c = CL1.c * lambda + CL2.c * (1.0-lambda);
		NewCL.type = CL1.type;
		NewCL.tag = (CL1.tag!=0||CL2.tag!=0) ? 1 : 0;
		NewCL.seg.resize(CL1.seg.size()+CL2.seg.size());
		NewCL.dir.resize(CL1.dir.size()+CL2.dir.size());
		//////////////////////////////////////////////////////////////////////////
		if (bL1R) {
			int n = CL1.seg.size();
			for (int i=0; i<n; i++) {
				NewCL.seg[i] & CL1.seg[n-1-i];
			}
			n = CL1.dir.size();
			for (int i=0; i<n; i++) {
				NewCL.dir[i] & CL1.dir[n-1-i];
			}
		} else {
			std::copy(CL1.seg.begin(), CL1.seg.end(), NewCL.seg.begin());
			std::copy(CL1.dir.begin(), CL1.dir.end(), NewCL.dir.begin());
		}
		//////////////////////////////////////////////////////////////////////////
		if (!bCP) {	// have common point
			NewCL.seg.resize(NewCL.seg.size()+1);
			int fi1 = (bL1R) ? CL1.seg.front().fi : CL1.seg.back().fi;
			int fi2 = (bL2R) ? CL2.seg.back().fi : CL2.seg.front().fi;
			int vi1 = (bL1R) ? CL1.seg.front().v[0] : CL1.seg.back().v[1];
			int vi2 = (bL2R) ? CL2.seg.back().v[1] : CL2.seg.front().v[0];
			if (fi1 == fi2) {
				NewCL.seg[CL1.seg.size()].set(vi1, vi2, fi1);
			} else {
				NewCL.seg[CL1.seg.size()].set(vi1, vi2, -1);
			}
			if (CL1.dir.size()!=0 && CL2.dir.size()!=0) {
				NewCL.dir.resize(NewCL.dir.size()+1);
				const Vector3 &dir1 = (bL1R) ? CL1.dir.front() : CL1.dir.back();
				const Vector3 &dir2 = (bL2R) ? CL2.dir.back() : CL2.dir.front();
				NewCL.dir[CL1.dir.size()] = dir1 + dir2;
				NewCL.dir[CL1.dir.size()].normalize();
			}
		}
		//////////////////////////////////////////////////////////////////////////
		int ss = (!bCP) ? CL1.seg.size()+1 : CL1.seg.size();
		int ds = (!bCP && CL1.dir.size()!=0 && CL2.dir.size()!=0) ? CL1.dir.size()+1 : CL1.dir.size();
		if (bL2R) {
			int n = CL2.seg.size();
			for (int i=0; i<n; i++) {
				NewCL.seg[ss+i] & CL2.seg[n-1-i];
			}
			n = CL2.dir.size();
			for (int i=0; i<n; i++) {
				NewCL.dir[ds+i] & CL2.dir[n-1-i];
			}
		} else {
			std::copy(CL2.seg.begin(), CL2.seg.end(), NewCL.seg.begin()+ss);
			std::copy(CL2.dir.begin(), CL2.dir.end(), NewCL.dir.begin()+ds);
		}
		return 0;
	}

	int break_at_point(const CLI<FT> &InCL, int p, CLI<FT> &CL1, CLI<FT> &CL2)
	{
		if (InCL.seg.size()<3 || p<2 || p>InCL.seg.size()-3 || InCL.seg.size()!=InCL.dir.size()) {
			return -1;
		}
		CL1.r = CL2.r = InCL.r;
		CL1.s = CL2.s = InCL.s;
		CL1.c = CL2.c = InCL.c;
		CL1.type = CL2.type = InCL.type;
		CL1.tag = CL2.tag = InCL.tag;
		CL1.seg.resize(p);
		CL1.dir.resize(p);
		CL2.seg.resize(InCL.seg.size()-p-1);
		CL2.dir.resize(InCL.seg.size()-p-1);
		//////////////////////////////////////////////////////////////////////////
		std::copy(InCL.seg.begin(), InCL.seg.begin()+p, CL1.seg.begin());
		std::copy(InCL.dir.begin(), InCL.dir.begin()+p, CL1.dir.begin());
		std::copy(InCL.seg.begin()+p+1, InCL.seg.end(), CL2.seg.begin());
		std::copy(InCL.dir.begin()+p+1, InCL.dir.end(), CL2.dir.begin());
		return 0;
	}

	int merge_multiple_lines(CLI<FT> &DstCL, std::vector<CLI<FT>> &pCL, const std::list<std::vector<int>> &CI,
						 const std::vector<std::vector<int>> &CN, bool bCP)
	{
		int iNumCL = CI.size();
		if (iNumCL < 2) {
			MSG_BOX_ERROR("merge_multiple_lines: less than two lines input, no merging will be done!");
			return -1;
		}
		std::list<std::vector<int>>::const_iterator i1 = CI.begin();
		std::list<std::vector<int>>::const_iterator i2 = i1; i2++;
		std::list<std::vector<int>>::const_iterator iu = CI.end(); iu--;

		Crest_type type = pCL[(*i1)[0]].type;
		int tag = 0;
		FT r(0.0), s(0.0), c(0.0);
		int iNumSeg=0, iNumDir=0;
		std::list<std::vector<int>>::const_iterator i;
		for (i=CI.begin(); i!=CI.end(); i++)
		{
			if (pCL[(*i)[0]].type != type) {
			//	MSG_BOX_ERROR("merge_multiple_lines: trying to merge lines with different types!");
				return -1;
			}
			if (pCL[(*i)[0]].seg.size() != pCL[(*i)[0]].dir.size()) {
				pCL[(*i)[0]].dir.resize(pCL[(*i)[0]].seg.size());
			}
			pCL[(*i)[0]].tag = (pCL[(*i)[0]].tag!=0) ? 1 : pCL[(*i)[0]].tag;
			tag |= pCL[(*i)[0]].tag;
			r += pCL[(*i)[0]].r * pCL[(*i)[0]].seg.size();
			s += pCL[(*i)[0]].s * pCL[(*i)[0]].seg.size();
			c += pCL[(*i)[0]].c * pCL[(*i)[0]].seg.size();
			iNumSeg += pCL[(*i)[0]].seg.size();
			iNumDir += pCL[(*i)[0]].dir.size();
		}
		DstCL.r = r / iNumSeg;
		DstCL.s = s / iNumSeg;
		DstCL.c = c / iNumSeg;
		DstCL.type = type;
		DstCL.tag = tag;
		bool bLoop = ( iNumCL!=2 && (CN[(*i1)[0]][(*i1)[1]]==(*iu)[0] || (CN[(*i1)[0]][(*i1)[2]]==(*iu)[0])) );
		//////////////////////////////////////////////////////////////////////////
		if (bCP) {
			DstCL.seg.resize(iNumSeg);
			DstCL.dir.resize(iNumDir);
		} else {
			DstCL.seg.resize(iNumSeg+((bLoop)?iNumCL:iNumCL-1));
			DstCL.dir.resize(iNumDir+((bLoop)?iNumCL:iNumCL-1));
		}
		//////////////////////////////////////////////////////////////////////////
		int ss=0, ds=0;
		if ((*i1)[1] == 0) {
			std::copy(pCL[(*i1)[0]].seg.begin(), pCL[(*i1)[0]].seg.end(), DstCL.seg.begin()+ss);
			std::copy(pCL[(*i1)[0]].dir.begin(), pCL[(*i1)[0]].dir.end(), DstCL.dir.begin()+ds);
		} else {
			int n = pCL[(*i1)[0]].seg.size();
			for (int j=0; j<n; j++) {
				DstCL.seg[ss+j] & pCL[(*i1)[0]].seg[n-1-j];
			}
			n = pCL[(*i1)[0]].dir.size();
			for (int j=0; j<n; j++) {
				DstCL.dir[ds+j] & pCL[(*i1)[0]].dir[n-1-j];
			}
		}
		ss += pCL[(*i1)[0]].seg.size();
		ds += pCL[(*i1)[0]].seg.size();
		bool bL1R, bL2R;
		int fi1, fi2, vi1, vi2;
		std::list<std::vector<int>>::const_iterator li;
		i = CI.begin(); i++;
		for (; i!=CI.end(); i++)
		{
			li = i; li--;
			bL1R = ((*li)[1]!=0);
			bL2R = ((*i)[1]!=0);
			CLI<FT> &CL1 = pCL[(*li)[0]];
			CLI<FT> &CL2 = pCL[(*i)[0]];
			if (!bCP) {
				fi1 = (bL1R) ? CL1.seg.front().fi : CL1.seg.back().fi;
				fi2 = (bL2R) ? CL2.seg.back().fi : CL2.seg.front().fi;
				vi1 = (bL1R) ? CL1.seg.front().v[0] : CL1.seg.back().v[1];
				vi2 = (bL2R) ? CL2.seg.back().v[1] : CL2.seg.front().v[0];
				if (fi1 == fi2) {
					DstCL.seg[ss].set(vi1, vi2, fi1);
				} else {
					DstCL.seg[ss].set(vi1, vi2, -1);
				}
				ss++;
				const Vector3 &dir1 = (bL1R) ? CL1.dir.front() : CL1.dir.back();
				const Vector3 &dir2 = (bL2R) ? CL2.dir.back() : CL2.dir.front();
				DstCL.dir[ds] = dir1 + dir2;
				DstCL.dir[ds].normalize();
				ds++;
			}
			if (bL2R) {
				int n = CL2.seg.size();
				for (int j=0; j<n; j++) {
					DstCL.seg[ss+j] & CL2.seg[n-1-j];
				}
				n = CL2.dir.size();
				for (int j=0; j<n; j++) {
					DstCL.dir[ds+j] & CL2.dir[n-1-j];
				}
			} else {
				std::copy(CL2.seg.begin(), CL2.seg.end(), DstCL.seg.begin()+ss);
				std::copy(CL2.dir.begin(), CL2.dir.end(), DstCL.dir.begin()+ds);
			}
			ss += CL2.seg.size();
			ds += CL2.dir.size();
		}
		if (bLoop && !bCP) {
			bL1R = ((*iu)[1]!=0);
			bL2R = ((*i1)[1]!=0);
			CLI<FT> &CL1 = pCL[(*iu)[0]];
			CLI<FT> &CL2 = pCL[(*i1)[0]];
			if (!bCP) {
				fi1 = (bL1R) ? CL1.seg.front().fi : CL1.seg.back().fi;
				fi2 = (bL2R) ? CL2.seg.back().fi : CL2.seg.front().fi;
				vi1 = (bL1R) ? CL1.seg.front().v[0] : CL1.seg.back().v[1];
				vi2 = (bL2R) ? CL2.seg.back().v[1] : CL2.seg.front().v[0];
				if (fi1 == fi2) {
					DstCL.seg[ss].set(vi1, vi2, fi1);
				} else {
					DstCL.seg[ss].set(vi1, vi2, -1);
				}
				ss++;
				const Vector3 &dir1 = (bL1R) ? CL1.dir.front() : CL1.dir.back();
				const Vector3 &dir2 = (bL2R) ? CL2.dir.back() : CL2.dir.front();
				DstCL.dir[ds] = dir1 + dir2;
				DstCL.dir[ds].normalize();
				ds++;
			}
		}
		return 0;
	}
	void compute_smooth_dir(void)
	{
		if (!m_bSegConsist) {
			make_seg_consistent();
		}
		if (!m_bSegSequent) {
			make_seg_sequent();
		}
		for (int i=0; i<m_pCLInfo.size(); i++)
		{
			int num_seg = m_pCLInfo[i].seg.size();
			int step = __max(__min(num_seg*0.03, 5), 1);
			m_pCLInfo[i].dir.resize(num_seg);
			for (int j=0; j<num_seg; j++) {
				int ts = __min(num_seg-1, j+step);
				int hs = __max(ts-step,0);
				m_pCLInfo[i].dir[j] = m_Points[m_pCLInfo[i].seg[ts].v[1]] - m_Points[m_pCLInfo[i].seg[hs].v[0]];
				m_pCLInfo[i].dir[j].normalize();
			}
			// perform a smoothing
			for (int j=0; j<num_seg; j++) {
				Vector3 v;
				if ((j-3)>=0) {
					v += m_pCLInfo[i].dir[j-3];
				}
				if ((j-2)>=0) {
					v += m_pCLInfo[i].dir[j-2] * 2.0;
				}
				if ((j-1)>=0) {
					v += m_pCLInfo[i].dir[j-1] * 4.0;
				}
				v += m_pCLInfo[i].dir[j] * 4.0;
				if ((j+1)<num_seg) {
					v += m_pCLInfo[i].dir[j+1] * 2.0;
				}
				if ((j+2)<num_seg) {
					v += m_pCLInfo[i].dir[j+2];
				}
				v.normalize();
				m_pCLInfo[i].dir[j] = v;
			}
		}
	}
	void compute_smooth_dir(int l)
	{
		if (!m_bSegConsist) {
			make_seg_consistent();
		}
		if (!m_bSegSequent) {
			make_seg_sequent();
		}
		int num_seg = m_pCLInfo[l].seg.size();
		int step = __max(__min(num_seg*0.03, 5), 1);
		m_pCLInfo[l].dir.resize(num_seg);
		for (int j=0; j<num_seg; j++) {
			int ts = __min(num_seg-1, j+step);
			int hs = __max(ts-step,0);
			m_pCLInfo[l].dir[j] = m_Points[m_pCLInfo[l].seg[ts].v[1]] - m_Points[m_pCLInfo[l].seg[hs].v[0]];
			m_pCLInfo[l].dir[j].normalize();
		}
		// perform a smoothing
		for (int j=0; j<num_seg; j++) {
			Vector3 v;
			if ((j-3)>=0) {
				v += m_pCLInfo[l].dir[j-3];
			}
			if ((j-2)>=0) {
				v += m_pCLInfo[l].dir[j-2] * 2.0;
			}
			if ((j-1)>=0) {
				v += m_pCLInfo[l].dir[j-1] * 4.0;
			}
			v += m_pCLInfo[l].dir[j] * 4.0;
			if ((j+1)<num_seg) {
				v += m_pCLInfo[l].dir[j+1] * 2.0;
			}
			if ((j+2)<num_seg) {
				v += m_pCLInfo[l].dir[j+2];
			}
			v.normalize();
			m_pCLInfo[l].dir[j] = v;
		}
	}
	void compute_smooth_dir(int i, int j)
	{
		if (!m_bSegConsist) {
			make_seg_consistent();
		}
		if (!m_bSegSequent) {
			make_seg_sequent();
		}
		m_pCLInfo[i].dir.resize(m_pCLInfo[l].seg.size());
		m_pCLInfo[i].dir[j] = m_Points[m_pCLInfo[i].seg[j].v[1]] - m_Points[m_pCLInfo[i].seg[j].v[0]];
		// perform a smoothing
		Vector3 v;
		if ((j-3)>=0) {
			v += m_pCLInfo[i].dir[j-3];
		}
		if ((j-2)>=0) {
			v += m_pCLInfo[i].dir[j-2] * 2.0;
		}
		if ((j-1)>=0) {
			v += m_pCLInfo[i].dir[j-1] * 4.0;
		}
		v += m_pCLInfo[i].dir[j] * 4.0;
		if ((j+1)<num_seg) {
			v += m_pCLInfo[i].dir[j+1] * 2.0;
		}
		if ((j+2)<num_seg) {
			v += m_pCLInfo[i].dir[j+2];
		}
		v.normalize();
		m_pCLInfo[i].dir[j] = v;
	}
	void trace_seg_branch(CLI<FT> &NewCL, const CLI<FT> &CL, Branch &branch, int p, int s)
	{
		NewCL.type = CL.type;
		NewCL.r = CL.r;
		NewCL.s = CL.s;
		NewCL.c = CL.c;
		int cp=p, cs, vi;
		if (cp == CL.seg[s].v[0]) {
			NewCL.seg.push_back(CL.seg[s]);
			cp = CL.seg[s].v[1];
			cs = s;
			vi = 1;
		} else if (cp == CL.seg[s].v[1]) {
			NewCL.seg.push_back(CL.seg[s]);
			cp = CL.seg[s].v[0];
			cs = s;
			vi = 0;
		} else {
			MSG_BOX_ERROR("trace_seg_branch: branch info. error!");
		}
		bool bFound = true;
		while (branch[cp].size()==2 && bFound)
		{
			bFound = false;
			//
			branch[cp][0].second = -1;	// stepped on this point
			for (int i=0; i<CL.seg.size(); i++)
			{
				if (i == cs) {
					continue;
				}
				if (CL.seg[i].v[1-vi] == cp) {	// come sequentially
					NewCL.seg.push_back(CL.seg[i]);
					cp = CL.seg[i].v[vi];
					cs = i;
					bFound = true;
					break;
				}
				if (CL.seg[i].v[vi] == cp) {
					NewCL.seg.push_back(CLI<FT>::CSeg(CL.seg[i].v[1],CL.seg[i].v[0],CL.seg[i].fi));
					cp = CL.seg[i].v[1-vi];;
					cs = i;
					bFound = true;
					break;
				}
			}
		}
		if (!bFound) {
			MSG_BOX_ERROR("trace_seg_branch: branch info. error!");
		}
		if (branch[cp].size() > 2) {
			for (int i=0; i<branch[cp].size(); i++) {
				if (branch[cp][i].first == cs) {
					branch[cp][i].second = 1;
					break;
				}
			}
		} else if (branch[cp].size() == 1) {	// must be branch[cp].size()==1
			branch[cp][0].second = -1;	// stepped on this point
		}
	}
	void find_branch(Branch &branch)
	{
		branch.clear();
		branch.resize(m_Points.size());
		for (int i=0; i<m_pCLInfo.size(); i++) {
			int num_seg = m_pCLInfo[i].seg.size();
			for (int j=0; j<num_seg; j++)
			{
				branch[m_pCLInfo[i].seg[j].v[0]].push_back(std::make_pair(j,0));
				branch[m_pCLInfo[i].seg[j].v[1]].push_back(std::make_pair(j,0));
			}
		}
	}

	void make_seg_sequent(void)
	{
		std::list<CLI<FT>::CSeg> seg_order;
		std::vector<short> seg_added;
		for (int i=0; i<m_pCLInfo.size(); i++) {
			int num_seg = m_pCLInfo[i].seg.size();
			seg_added.clear();
			seg_added.resize(num_seg, 0);
			seg_order.clear();
			seg_order.push_back(m_pCLInfo[i].seg[0]);
			seg_added[0] = 1;
			int vl = m_pCLInfo[i].seg[0].v[0];
			int vr = m_pCLInfo[i].seg[0].v[1];
			int t = 0;
			while (seg_order.size()<num_seg && t<num_seg) {	// find t times
				for (int j=0; j<num_seg; j++) {
					if (seg_added[j] == 1) {
						continue;
					}
					if (m_pCLInfo[i].seg[j].v[0] == vr) {
						seg_order.push_back(m_pCLInfo[i].seg[j]);
						seg_added[j] = 1;
						vr = m_pCLInfo[i].seg[j].v[1];
					} else if (m_pCLInfo[i].seg[j].v[1] == vl) {
						seg_order.push_front(m_pCLInfo[i].seg[j]);
						seg_added[j] = 1;
						vl = m_pCLInfo[i].seg[j].v[0];
					}
				}
				t++;
			}
			if (t == num_seg) {
				MSG_BOX_ERROR("make_seg_sequent: max times of loop exceeded for line %d!", i);
				continue;
			}
			int j;
			std::list<CLI<FT>::CSeg>::iterator it;
			for (it=seg_order.begin(), j=0; it!=seg_order.end(); it++, j++) {
				 m_pCLInfo[i].seg[j] = *it;
			}
		}
		m_bSegSequent = true;
	}

	void make_seg_consistent(void)
	{
		for (int i=0; i<m_pCLInfo.size(); i++) {
			int num_seg = m_pCLInfo[i].seg.size();
			m_pCLInfo[i].dir.resize(num_seg);
			std::vector<short> scan(num_seg, 0);
			scan[num_seg/2] = 1;
			bool bFinished = false;
			while (!bFinished)
			{
				bFinished = true;
				for (int j=0; j<scan.size(); j++)
				{
					if (scan[j] != 1) {
						continue;
					}
					for (int k=0; k<num_seg; k++) {
						if ( k!=j && scan[k]==0)
						{
							if (m_pCLInfo[i].seg[j].v[0]==m_pCLInfo[i].seg[k].v[0]
								|| m_pCLInfo[i].seg[j].v[1]==m_pCLInfo[i].seg[k].v[1])
							{	// found a un-scanned neighbor
								m_pCLInfo[i].dir[k] *= -1.0;
								int tmp = m_pCLInfo[i].seg[k].v[0];
								m_pCLInfo[i].seg[k].v[0] = m_pCLInfo[i].seg[k].v[1];
								m_pCLInfo[i].seg[k].v[1] = tmp;
								scan[j] = 2;
								scan[k] = 1;
								bFinished = false;
							}
							else if (m_pCLInfo[i].seg[j].v[0]==m_pCLInfo[i].seg[k].v[1]
								|| m_pCLInfo[i].seg[j].v[1]==m_pCLInfo[i].seg[k].v[0])
							{	// found a un-scanned neighbor
								scan[j] = 2;
								scan[k] = 1;
								bFinished = false;
							}
						}
					}
				}
			}
		}
		m_bSegConsist = true;
	}

	void reverse_line_orien(int l)
	{
		int n = m_pCLInfo[l].seg.size();
		CLI<FT>::SV TempSeg(n);
		for (int j=0; j<n; j++) {
			TempSeg[j] & m_pCLInfo[l].seg[n-1-j];
		}
		n = m_pCLInfo[l].dir.size();
		CLI<FT>::VV TempDir(n);
		for (int j=0; j<n; j++) {
			TempDir[j] & m_pCLInfo[l].dir[n-1-j];
		}
		std::copy(TempSeg.begin(), TempSeg.end(), m_pCLInfo[l].seg.begin());
		std::copy(TempDir.begin(), TempDir.end(), m_pCLInfo[l].dir.begin());
	}

	static FT sqdPnt2LineSeg(const Vector3 &ls, const Vector3 &le, const Vector3 &p)
	{	// Square distance from a point to a line segment
		FT len = ls.sqauredistance(le);
		FT t = (p-ls).dot(le-ls) / len;
		if (t < 0.0) {
			return p.sqauredistance(ls);
		}
		if (t > 1.0) {
			return p.sqauredistance(le);
		}
		Vector3 pp = ls + (le-ls) * t;
		return p.sqauredistance(pp);
	}
};
