///////////////////////////////////////////////////////////////////////////
//																																			 //
//	Class: Enriched_polyhedron
//																																			 //
///////////////////////////////////////////////////////////////////////////

#pragma once

// CGAL	stuff
#include <CGAL/Cartesian.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/HalfedgeDS_vertex_max_base_with_id.h>
#include <CGAL/HalfedgeDS_halfedge_max_base_with_id.h>
#include <CGAL/HalfedgeDS_face_max_base_with_id.h>
#include <CGAL/HalfedgeDS_decorator.h> 
#include <CGAL/Random_access_adaptor.h>
#include <CGAL/intersections.h>
#include <CGAL/Kd_tree.h>
#include <CGAL/Fuzzy_sphere.h>
#include <CGAL/Search_traits_3.h>
#include <list>
#include <set>
#include <stack>
#include <map>
#include <queue>
#include <string>
#include <algorithm>
#include <functional>
#include "../Math/mathlib.h"
#include "../3D/Utility.h"
#include "../3D/PsudoColorRGB.h"
#include <fstream>
#include "../GL/OpenGLFunc.h"

// linear solver
#include <CGAL/Cholmod_matrix.h>
#include <CGAL/Cholmod_vector.h>

#define VH(v) index_to_vertex_map[(v)]
#define VP(v) index_to_vertex_map[(v)]->point()
#define VN(v) index_to_vertex_map[(v)]->normal()
#define VB(v) index_to_vertex_map[(v)]->vertex_begin()
#define VT(v) index_to_vertex_map[(v)]->tag()
#define FH(f) index_to_facet_map[(f)]
#define FN(f) index_to_facet_map[(f)]->normal()
#define FB(f) index_to_facet_map[(f)]->facet_begin()
#define BN (1.0e8)
#define SQBN (1.0e4)



// a refined facet with a normal and a tag
template <class	Refs, class T, class P,	class Norm>
class Enriched_facet : public CGAL::HalfedgeDS_face_max_base_with_id<Refs, CGAL::Tag_false, std::size_t>
{
	// tag
	int m_tag;
	// normal
	Norm m_normal;

public:
	// life	cycle
	// no constructors to repeat, since only default constructor mandatory
	Enriched_facet() {}

	// tag
	const int& tag() const {return m_tag;}
	int& tag() {return m_tag;}
	void tag(const int& t) {m_tag = t;}

	// normal
	typedef	Norm Normal_3;
	Normal_3& normal() { return	m_normal; }
	const Normal_3& normal() const { return m_normal; }
};

// a refined halfedge with a general tag and a binary tag to indicate whether it belongs 
// to the control mesh or not
template <class	Refs, class Tprev, class Tvertex, class Tface, class Norm>
class Enriched_halfedge : public CGAL::HalfedgeDS_halfedge_max_base_with_id<Refs, std::size_t>
{
	// tag
	int m_tag;
	// normal
	Norm m_vnormal;

public:
	// life	cycle
	Enriched_halfedge() {}

	// tag
	const int& tag() const {return m_tag;}
	int& tag() {return m_tag;}
	void tag(const int& t) {m_tag = t;}

	// normal
	Norm& vnormal() { return m_vnormal; }
	const Norm& vnormal() const { return m_vnormal; }
};

// a refined vertex with a normal and a tag
template <class	Refs, class T, class P, class N, class Kernel>
class Enriched_vertex : public CGAL::HalfedgeDS_vertex_max_base_with_id<Refs, P, std::size_t>
{
public:
	typedef	typename Kernel::FT FT;
	typedef	typename N Normal;
	//typedef typename CCurvature<Kernel> Curvature;

private:
	int m_tag;
	short m_dup;	// need duplicating? If a vertex has more than one attributes, it must
					//	be duplicated in building vertex buffer for VBO rendering
	Normal m_normal;
	//Curvature m_curvature;
	union 
	{
		struct { FT m_u, m_v; };
		struct { FT m_texcoord[2]; };
	};	// texture coordinates u, v

public:
	// life	cycle
	Enriched_vertex() {}
	// repeat mandatory constructors
	Enriched_vertex(const P& pt) : CGAL::HalfedgeDS_vertex_max_base_with_id<Refs,P,std::size_t>(pt) {}

	// normal
	Normal& normal() { return m_normal; }
	const Normal& normal() const { return m_normal; }

	//// curvature
	//Curvature& curvature() { return m_curvature; }
	//const Curvature& curvature() const { return m_curvature; }

	// tag
	int& tag() { return m_tag; }
	const int& tag() const { return m_tag; }
	void tag(const int& t)	{ m_tag	= t; }

	// dup
	short& dup() { return m_dup; }
	const short& dup() const { return m_dup; }
	void dup(const short& d)	{ m_dup	= d; }

	// texcoord
	FT& u() { return m_u; }
	FT& v() { return m_v; }
	FT* texcoord() { return &m_texcoord[0]; }
	const FT& u() const { return m_u; }
	const FT& v() const { return m_v; }
	const FT* texcoord() const { return &m_texcoord[0]; }
	void u(const FT uc) { m_u = uc; }
	void v(const FT vc) { m_v = vc; }
	void texcoord(const FT uc, const FT vc) { m_u = uc; m_v = vc; }
	void texcoord(const FT* const tc) { m_u = tc[0]; m_v = tc[1]; }
};

// A redefined items class for the Polyhedron_3	
// with	a refined vertex class that	contains a 
// member for the normal vector	and	a refined
// facet with a normal vector instead of the 
// plane equation (this is an alternative	
// solution	instead	of using 
// Polyhedron_traits_with_normals_3).

struct Enriched_items : public CGAL::Polyhedron_items_3
{
		// wrap	vertex
		template <class Refs, class Traits>
		struct Vertex_wrapper
		{
			typedef	typename Traits::Point_3	Point;
			typedef	typename Traits::Vector_3	Normal;
			typedef	Enriched_vertex<Refs, CGAL::Tag_true, Point, Normal, Traits> Vertex;
		};

		// wrap	face
		template <class Refs, class Traits>
		struct Face_wrapper
		{
			typedef	typename Traits::Point_3	Point;
			typedef	typename Traits::Vector_3	Normal;
			typedef	Enriched_facet<Refs, CGAL::Tag_true, Point, Normal> Face;
		};

		// wrap	halfedge
		template <class Refs, class Traits>
		struct Halfedge_wrapper
		{
			typedef	typename Traits::Vector_3	Normal;
			typedef	Enriched_halfedge<Refs, CGAL::Tag_true, CGAL::Tag_true, CGAL::Tag_true, Normal>	Halfedge;
		};
};

template <class	kernel, class items>
class ROI_vertex;

//*********************************************************
template <class	kernel, 
		  class items, 
		#ifndef CGAL_CFG_NO_TMPL_IN_TMPL_PARAM
			template <class T, class I, class A>
		#endif
		  class T_HDS = CGAL::HalfedgeDS_default,
		  class A = CGAL_ALLOCATOR(int)>
class Enriched_polyhedron : public CGAL::Polyhedron_3<kernel,items>
{
public :
	typedef	typename kernel::FT			FT;
	typedef	typename kernel::Point_3	Point;
	typedef	typename kernel::Vector_3	Vector;
	typedef typename Vertex::Normal		Normal;
	typedef CGAL::Random_access_adaptor<Vertex_iterator>	Random_access_vertex_index;
	typedef CGAL::Random_access_adaptor<Facet_iterator>		Random_access_facet_index;
	typedef CGAL::HalfedgeDS_decorator<HalfedgeDS>			HalfedgeDS_decorator;
	typedef std::stack<std::pair<int, std::list<int>>>		Stack_list;
	typedef CGAL::Search_traits_3<kernel>					STraits;
	typedef CGAL::Kd_tree<STraits>							KD_tree;
	typedef CGAL::Fuzzy_sphere<STraits>						Fuzzy_sphere;

	typedef CGAL::Cholmod_matrix<double>			CMatrix;	// CHOLMOD only supports double floating-point number
	typedef CGAL::Cholmod_vector<double>			CVector;	// CHOLMOD only supports double floating-point number
	typedef std::vector<std::set<int>>				VEC_SI;
	typedef std::vector<std::list<Facet_handle>>	VEC_LFh;
	typedef std::map<int,std::pair<short,short>>	MAP_ISP;	// map int to short pair
	typedef std::map<int,std::pair<Vector3,short>>	MAP_IVS;	// map int to Vector3&short
	
public:
	std::set<int> picked_vertices;
	std::set<int> picked_facets;

private:
	// bounding box
	FT m_min[3];
	FT m_max[3];
	FT m_scale;
	FT m_center[3];
	GLuint m_gl_bb_disp_list;

	bool m_is_set_items_id;
	bool m_is_set_id_to_items_map;

	// type
	bool m_pure_quad;
	bool m_pure_triangle;
	
	GLuint m_gl_display_list;
	GLuint m_gl_vbo_pos;
	GLuint m_gl_vbo_norm;
	GLuint m_gl_vbo_color;		// for drawing handles
	GLuint m_gl_vbo_hf_color;
	GLuint m_gl_vbo_cluster_color;
	GLuint m_gl_vbo_hv;			// harmonic values buffer object
	GLuint m_gl_ibo;
	std::vector<GLuint> m_gl_ibo_mf_hdl;
	std::vector<int> m_vb_id;	// vertex id of vertices of vertex buffer
	GLuint *m_ibo_array;
	std::vector<int> m_vb_ia_id;// id (in ibo array) of vertices of vertex buffer
	
	std::list<Facet_handle>		m_roi_f;			// facets in roi

	FT m_min_mean_curvature;
	FT m_max_mean_curvature;
	
	// Deformation
	ROI_vertex<kernel,items>	*m_roi_v;
	std::map<int, int>			m_gi_to_ri_map;		// map global index to roi index 
	int							m_nb_roi_v;
	int							m_nb_broi_v;
	int							m_roi_hdl_v;		// roi index of handle
	int							m_roi_hdl_gi;
	FT							m_roi_hdl_r;		// radia
	//
	std::set<int>				m_fixed_hdl_v;		// fixed handle vertices
	std::set<int>				m_manipl_hdl_v;		// manipulating handle vertices
	//////////////////////////////////////////////////////////////////////////
	short						*m_hdl;				// handle config: handle no. of each vertex
	short						*m_hdl_tag;			// handle tag:  0: up-to-date -1: need to be downdated
													//				1: newly added or need to be updated
													//				2: non-constraint
	VEC_SI						m_hdl_v;			// vertex ids in each handle
	VEC_LFh						m_hdl_f;			// facets handle in each handle
	int							m_curr_manip;		// current manipulated handle
	bool						m_is_comp_mh_hf;
	bool						m_is_mh_hf_utd;
	std::vector<FT*>			m_mh_hf;
	//////////////////////////////////////////////////////////////////////////
	std::vector<std::set<int>>	m_joint_v;			// vertices in joint set
	std::list<Facet_handle>		m_fixed_hdl_f;		// fixed handle facets
	std::list<Facet_handle>		m_manipl_hdl_f;		// manipulating handle facets
	int							m_pick_hdl_f;		// picked handle facet
	Vector3						m_pick_hdl_pos;
	Vector3						*m_dif_coords;
	int							m_d_LM;				// Laplacian matrix dimension
	FT							m_pc_weight;		// weight of positional constraint
	bool						m_is_set_roi;
	bool						m_is_set_roi_hdl;	// have set handle vertex?
	bool						m_is_init_roi_df;
	bool						m_is_comp_roi_hf;	// have computed harmonic field
	bool						m_is_init_hb_df;
	bool						m_is_set_manipl_hdl;
	bool						m_is_set_fixed_hdl;
	bool						m_is_comp_hb_hf;
#ifdef CGAL_USE_TAUCS
	taucs_ccs_matrix			*m_LM;				// Laplacian matrix
	TMatrix						*m_tmAM;			// associated matrix
	TVector						*m_tvROIDC[3];		// roi differential coordinates
	TVector						*m_tvB;				// B vector
	TVector						*m_tvX[3];			// X vector
#endif
	void						*m_CF;				// Cholesky factorization
	cholmod_factor				*m_L;				// factor
	FT							*m_roi_hf;			// harmonic field in roi
	FT							*m_hb_hf;			// handle-based hf over the entire mesh
	bool						m_is_unitized;
	FT							m_unitize_sf;
	MAP_ISP						m_sf_sites;			// flag: 1: source  0: sink
													// tag: -1: downdate  0: up-to-date  1: update
	int							m_pick_sf_site;
	FT							*m_s_sf;			// site-based scalar field
	cholmod_factor				*m_s_F;				// factor
	bool						m_is_built_sf_color_vbo;
	bool						m_is_built_cluster_color_vbo;
	bool						m_is_s_hf_utd;
	float						m_hf_site_radii;

	MAP_IVS						m_hvf_sites;		// harmonic vector fields, tag: -1:downdate 0:up-to-date 1:update
	int							m_pick_hvf_site;
	bool						m_is_built_hvf_s_vbo;
	bool						m_is_s_hvf_utd;
	Vector3						*m_s_vf;			// site-based vector field
	FT							m_s_hvm_max;		// maximum magnitude
	FT							m_s_hvm_min;		// minimum magnitude
	cholmod_factor				*m_s_hvf_F;			// factor
	float						m_hvf_site_radii;
	std::vector<int>			m_s_hvf_p;			// sampled points for illustrating site-based harmonic vector field

	std::list<int>				m_curve;
	std::list<int>				m_c_add, m_c_rm;
	int							m_cd_head, m_cd_curr, m_cd_tail; // draw head and draw tail
	short						m_c_status;
	int							m_seed;
	std::vector<int>			m_hole_v;
	cholmod_factor				*m_mbr_F;			// factor for computing membrane
	cholmod_factor				*m_mbr_F_e;			// factor for evolving membrane
	cholmod_sparse				*m_mbr_Lt;			// L^t for evolving membrane
	bool						m_is_mbr_utd;
	Vector3						*m_mbr_dc;

	FT							m_avg_edge_len;

	GLubyte						*m_texture_mat;		// material per vertex for synthesized texture
	GLuint						m_gl_vbo_tex_color;
	bool						m_is_built_tex_color_vbo;

	std::vector<int>			m_voter;	// voter vertices
	std::vector<FT>				m_vote;
	GLuint						m_gl_vbo_vote_col;
	bool						m_is_built_vote_vbo;
	std::vector<int>			m_mid_gh;
	std::vector<Vector3>		m_mid_pl;

	std::string					m_s_hf_ws;	// weight
	std::string					m_s_hf_cs;	// constraint

public:
	Random_access_vertex_index	index_to_vertex_map;
	Random_access_facet_index	index_to_facet_map;

	// life	cycle
	Enriched_polyhedron()	
	{
		m_pure_quad = false;
		m_pure_triangle = false;
		m_roi_v = NULL;
		picked_vertices.clear();
		picked_facets.clear();
		m_dif_coords = NULL;
		m_d_LM = NULL;
		m_pc_weight = 100.0f;
		m_is_set_roi = false;
		m_is_set_roi_hdl = false;
		m_fixed_hdl_v.clear();
		m_manipl_hdl_v.clear();
		m_hdl_v.clear();
		m_hdl_f.clear();
		m_hdl = NULL;
		m_hdl_tag = NULL;
		m_curr_manip = -1;
		m_mh_hf.clear();
		m_is_comp_mh_hf = false;
		m_is_mh_hf_utd = false;
		m_L = NULL;
		m_roi_hdl_v = -1;
		m_is_init_hb_df = false;
		m_pick_hdl_f = -1;
#ifdef CGAL_USE_TAUCS
		m_LM = NULL;
		m_tmAM = NULL;
		m_tvROIDC[0] = m_tvROIDC[1] = m_tvROIDC[2] = NULL;
		m_tvB = NULL;
		m_tvX[0] = m_tvX[1] = m_tvX[2] = NULL;
		taucs_logfile("taucslog.txt");
#endif
		m_CF = NULL;
		m_roi_hf = NULL;
		m_hb_hf = NULL;
		m_roi_hdl_gi = -1;
		m_roi_hdl_r = 0.25;
		m_is_comp_roi_hf = false;
		m_is_init_roi_df = false;
		m_is_set_items_id = false;
		m_is_set_manipl_hdl = false;
		m_is_set_fixed_hdl = false;
		m_is_comp_hb_hf = false;
		m_is_set_id_to_items_map = false;
		m_is_unitized = false;
		m_unitize_sf = 5.0;
		m_gl_vbo_pos = 0;
		m_gl_vbo_norm = 0;
		m_gl_vbo_hf_color = 0;
		m_gl_vbo_cluster_color = 0;
		m_gl_vbo_vote_col = 0;
		m_gl_vbo_tex_color = 0;
		m_gl_vbo_color = 0;
		m_gl_vbo_hv = 0;
		m_gl_ibo = 0;
		m_ibo_array = NULL;
		m_sf_sites.clear();
		m_s_sf = NULL;
		m_s_F = NULL;
		m_is_built_sf_color_vbo = false;
		m_is_built_cluster_color_vbo = false;
		m_is_built_tex_color_vbo = false;
		m_is_built_vote_vbo = false;
		m_is_s_hf_utd = false;
		m_hvf_sites.clear();
		m_pick_sf_site = 0;
		m_pick_hvf_site = 0;
		m_is_built_hvf_s_vbo = false;
		m_is_s_hvf_utd = false;
		m_s_hvf_p.clear();
		m_s_vf = NULL;
		m_s_hvf_F = NULL;
		m_hf_site_radii = 0.06;
		m_hvf_site_radii = 0.03;
		m_curve.clear(); m_c_add.clear(); m_c_rm.clear();
		m_cd_head = m_cd_curr = m_cd_tail = 0;
		m_c_status = 0;
		m_seed = -1;
		m_hole_v.clear();
		m_mbr_F = NULL; m_mbr_F_e = NULL;
		m_is_mbr_utd = false;
		m_mbr_dc = NULL; m_mbr_Lt = NULL;
		m_avg_edge_len = 0.0;
		m_texture_mat = NULL;
		m_s_hvm_min = 0.0;
		m_s_hvm_max = 0.0;
		m_s_hf_ws = "Cotangent";
		m_s_hf_cs = "Penalty";
	}
	Enriched_polyhedron(const Enriched_polyhedron& poly)
		: Polyhedron_3(poly)
	{
		m_pure_quad = false;
		m_pure_triangle = false;
		m_roi_v = NULL;
		picked_vertices.clear();
		picked_facets.clear();
		m_dif_coords = NULL;
		m_d_LM = NULL;
		m_pc_weight = 100.0f;
		m_is_set_roi_hdl = false;
		m_is_set_roi = false;
		m_L = NULL;
		m_fixed_hdl_v.clear();
		m_manipl_hdl_v.clear();
		m_hdl = NULL;
		m_hdl_tag = NULL;
		m_hdl_v.clear();
		m_hdl_f.clear();
		m_mh_hf.clear();
		m_curr_manip = -1;
		m_is_comp_mh_hf = false;
		m_is_mh_hf_utd = false;
		m_roi_hdl_v = -1;
		m_is_init_hb_df = false;
		m_pick_hdl_f = -1;
#ifdef CGAL_USE_TAUCS
		m_LM = NULL;
		m_tmAM = NULL;
		m_tvROIDC[0] = m_tvROIDC[1] = m_tvROIDC[2] = NULL;
		m_tvB = NULL;
		m_tvX[0] = m_tvX[1] = m_tvX[2] = NULL;
	//	taucs_logfile("taucslog.txt");
#endif
		m_CF = NULL;
		m_roi_hf = NULL;
		m_hb_hf = NULL;
		m_roi_hdl_gi = -1;
		m_roi_hdl_r = 0.25;
		m_is_comp_roi_hf = false;
		m_is_init_roi_df = false;
		m_is_set_items_id = false;
		m_is_set_manipl_hdl = false;
		m_is_set_fixed_hdl = false;
		m_is_comp_hb_hf = false;
		m_is_set_id_to_items_map = false;
		m_is_unitized = false;
		m_unitize_sf = 5.0;
		m_gl_vbo_pos = 0;
		m_gl_vbo_norm = 0;
		m_gl_vbo_hf_color = 0;
		m_gl_vbo_cluster_color = 0;
		m_gl_vbo_vote_col = 0;
		m_gl_vbo_tex_color = 0;
		m_gl_vbo_color = 0;
		m_gl_vbo_hv = 0;
		m_gl_ibo = 0;
		m_ibo_array = NULL;
		m_sf_sites.clear();
		m_s_sf = NULL;
		m_s_F = NULL;
		m_is_built_sf_color_vbo = false;
		m_is_built_cluster_color_vbo = false;
		m_is_built_tex_color_vbo = false;
		m_is_built_vote_vbo = false;
		m_is_s_hf_utd = false;
		m_hvf_sites.clear();
		m_pick_sf_site = 0;
		m_pick_hvf_site = 0;
		m_is_built_hvf_s_vbo = false;
		m_is_s_hvf_utd = false;
		m_s_hvf_p.clear();
		m_s_vf = NULL;
		m_s_hvf_F = NULL;
		m_hf_site_radii = 0.06;
		m_hvf_site_radii = 0.02;
		m_curve.clear(); m_c_add.clear(); m_c_rm.clear();
		m_cd_head = m_cd_curr = m_cd_tail = 0;
		m_c_status = 0;
		m_seed = -1;
		m_hole_v.clear();
		m_mbr_F = NULL; m_mbr_F_e = NULL;
		m_is_mbr_utd = false;
		m_mbr_dc = NULL; m_mbr_Lt = NULL;
		m_avg_edge_len = 0.0;
		m_texture_mat = NULL;
		m_s_hvm_min = 0.0;
		m_s_hvm_max = 0.0;
		m_s_hf_ws = "Cotangent";
		m_s_hf_cs = "Penalty";
	}
	virtual	~Enriched_polyhedron() 
	{
		if (::glIsList(m_gl_display_list)) {
			::glDeleteLists(m_gl_display_list, 1);
		}
		if (m_gl_vbo_pos != 0) {
			glDeleteBuffers(1, &m_gl_vbo_pos);
		}
		if (m_gl_vbo_norm != 0) {
			glDeleteBuffers(1, &m_gl_vbo_norm);
		}
		if (m_gl_vbo_hf_color != 0) {
			glDeleteBuffers(1, &m_gl_vbo_hf_color);
		}
		if (m_gl_vbo_cluster_color != 0) {
			glDeleteBuffers(1, &m_gl_vbo_cluster_color);
		}
		if (m_gl_vbo_vote_col != 0) {
			glDeleteBuffers(1, &m_gl_vbo_vote_col);
		}
		if (m_gl_vbo_tex_color != 0) {
			glDeleteBuffers(1, &m_gl_vbo_tex_color);
		}
		if (m_gl_vbo_color != 0) {
			glDeleteBuffers(1, &m_gl_vbo_color);
		}
		if (m_gl_vbo_hv != 0) {
			glDeleteBuffers(1, &m_gl_vbo_hv);
		}
		if (m_gl_ibo != 0) {
			glDeleteBuffers(1, &m_gl_ibo);
		}
		for (int i=0; i<m_mh_hf.size(); i++) {
			delete [] m_mh_hf[i];
		}
#ifdef CGAL_USE_TAUCS
		delete [] m_CF;
		delete m_tvROIDC[0];
		delete m_tvROIDC[1];
		delete m_tvROIDC[2];
		delete m_tvB;
		delete m_tvX[0];
		delete m_tvX[1];
		delete m_tvX[2];
		delete m_tmAM;
		taucs_ccs_free(m_LM);
#endif
		cholmod_common c;
		cholmod_start(&c);	// start CHOLMOD
		cholmod_free_factor(&m_L, &c);
		cholmod_free_factor(&m_s_F, &c);
		cholmod_free_factor(&m_s_hvf_F, &c);
		cholmod_free_factor(&m_mbr_F, &c);
		cholmod_free_factor(&m_mbr_F_e, &c);
		cholmod_free_sparse(&m_mbr_Lt, &c);
		cholmod_finish(&c);
		SAFE_DELETE_ARRAY(m_texture_mat);
		SAFE_DELETE_ARRAY(m_mbr_dc);
		SAFE_DELETE_ARRAY(m_s_vf);
		SAFE_DELETE_ARRAY(m_s_sf);
		SAFE_DELETE_ARRAY(m_roi_hf);
		SAFE_DELETE_ARRAY(m_hb_hf);
		SAFE_DELETE_ARRAY(m_dif_coords);
		SAFE_DELETE_ARRAY(m_roi_v);
		SAFE_DELETE_ARRAY(m_ibo_array);
		SAFE_DELETE_ARRAY(m_hdl);
	}

	bool is_set_items_id() {return m_is_set_items_id;}
	bool is_set_id_to_items_map() {return m_is_set_id_to_items_map;}

	// type
	bool is_pure_triangle() { return m_pure_triangle; }
	bool is_pure_quad() { return m_pure_quad; }

	// normals (per	facet, then	per	vertex)
	void compute_normals_per_facet()
	{
		std::for_each(facets_begin(), facets_end(), Facet_normal2<kernel, Facet>());
	}
	void compute_normals_per_vertex()
	{
		std::for_each(vertices_begin(), vertices_end(), Vertex_normal<kernel, Vertex>());
	}
	void compute_normals_per_he_vertex()
	{
		std::for_each(vertices_begin(),
					  vertices_end(),
					  HalfedgeVertex_normal<kernel, Vertex>(85.0));
	}
	void compute_normals()
	{
		compute_normals_per_facet();
		compute_normals_per_vertex();
		compute_normals_per_he_vertex();
	}

	void reverse_winding()
	{
		inside_out();
		compute_normals();
	}

	void reverse_picked_facets()
	{
	}

	// compute average edge length
	FT get_avg_edge_len(bool bRecalc=false)
	{
		if (m_avg_edge_len!=0.0 && !bRecalc) {
			return m_avg_edge_len;
		}
		Vector edge;
		FT len_edge = 0.0;
		int num_edge = 0;
		Halfedge_iterator pHalfEdge = halfedges_begin();
		CGAL_For_all(pHalfEdge, halfedges_end())
		{
			const Point& p1 = pHalfEdge->vertex()->point();
			const Point& p2 = pHalfEdge->opposite()->vertex()->point();
			edge = p1 - p2;
			len_edge += (FT)std::sqrt(edge*edge);
			num_edge++;
		}
		m_avg_edge_len = len_edge/(FT)num_edge;
		return m_avg_edge_len;
	}

	// compute bounding	box
	void compute_bounding_box(void)
	{
		if (size_of_vertices() == 0) {
			return;
		}
		Vertex_iterator pVertex=vertices_begin();
		m_min[0] = pVertex->point().x();
		m_max[0] = pVertex->point().x();
		m_min[1] = pVertex->point().y();
		m_max[1] = pVertex->point().y();
		m_min[2] = pVertex->point().z();
		m_max[2] = pVertex->point().z();
		for (; pVertex!=vertices_end(); pVertex++)
		{
			const Point& p = pVertex->point();
			m_min[0] = std::min(m_min[0], p.x());
			m_min[1] = std::min(m_min[1], p.y());
			m_min[2] = std::min(m_min[2], p.z());
			m_max[0] = std::max(m_max[0], p.x());
			m_max[1] = std::max(m_max[1], p.y());
			m_max[2] = std::max(m_max[2], p.z());
		}
	}

	// bounding box
	FT xmin() { return m_min[0]; }
	FT xmax() { return m_max[0]; }
	FT ymin() { return m_min[1]; }
	FT ymax() { return m_max[1]; }
	FT zmin() { return m_min[2]; }
	FT zmax() { return m_max[2]; }

	void unitize(void)
	{
		compute_bounding_box();
		FT w, h, d;
		FT scale;
		// calculate model width, height, and depth
		w = m_max[0] - m_min[0];
		h = m_max[1] - m_min[1];
		d = m_max[2] - m_min[2];
		// calculate center of the model
		m_center[0] = (m_max[0] + m_min[0]) / 2.0;
		m_center[1] = (m_max[1] + m_min[1]) / 2.0;
		m_center[2] = (m_max[2] + m_min[2]) / 2.0;
		// calculate unitizing scale factor
		m_scale = m_unitize_sf / std::max(std::max(w, h), d);
		// translate around center then scale
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			point = Point((point.x()-m_center[0])*m_scale,
						  (point.y()-m_center[1])*m_scale,
						  (point.z()-m_center[2])*m_scale);
		}
		for (int i=0; i<3; i++)
		{
			m_min[i] *= m_scale;
			m_max[i] *= m_scale;
		}
		m_is_unitized = true;
	}
	void unitize(FT sf)
	{
		compute_bounding_box();
		FT cx, cy, cz, w, h, d;
		FT scale;
		m_unitize_sf = sf;
		// calculate model width, height, and depth
		w = m_max[0] - m_min[0];
		h = m_max[1] - m_min[1];
		d = m_max[2] - m_min[2];
		// calculate center of the model
		m_center[0] = (m_max[0] + m_min[0]) / 2.0;
		m_center[1] = (m_max[1] + m_min[1]) / 2.0;
		m_center[2] = (m_max[2] + m_min[2]) / 2.0;
		// calculate unitizing scale factor
		m_scale = m_unitize_sf / std::max(std::max(w, h), d);
		// translate around center then scale
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			point = Point((point.x()-m_center[0])*m_scale,
						  (point.y()-m_center[1])*m_scale,
						  (point.z()-m_center[2])*m_scale);
		}
		for (int i=0; i<3; i++)
		{
			m_min[i] *= m_scale;
			m_max[i] *= m_scale;
		}
		m_is_unitized = true;
	}
	void ununitize(void)
	{
		FT scl = 1.0 / m_scale;
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			point = Point(point.x()*scl+m_center[0],
						  point.y()*scl+m_center[1],
						  point.z()*scl+m_center[2]);
		}
	}
	void apply_rotation(Matrix3 rot)
	{
		Vector3 pos;
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			pos = rot.mul(Vector3(point.x(), point.y(), point.z()));
			point = Point(pos[0], pos[1], pos[2]);
		}
	}
	bool is_unitized(void)
	{
		return m_is_unitized;
	}
	FT	get_unitizing_scale_factor(void)
	{
		return m_unitize_sf;
	}

	void gl_build_bounding_box_disp_list(void)
	{
		if (size_of_vertices() == 0) {
			return;
		}
	//	compute_bounding_box();
		FT w, h, d;
		// calculate model width, height, and depth
		w = m_max[0] - m_min[0];
		h = m_max[1] - m_min[1];
		d = m_max[2] - m_min[2];
		FT length = (std::min(std::min(w, h), d)) / 4.0f;
		if (::glIsList(m_gl_bb_disp_list)) {
			::glDeleteLists(m_gl_bb_disp_list, 1);
		}
		m_gl_bb_disp_list = ::glGenLists(1);
		::glNewList(m_gl_bb_disp_list, GL_COMPILE);
		::glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT);
		::glDisable(GL_LIGHTING);
		::glColor3f(1.0f, 1.0f, 1.0f);
		::glBegin(GL_LINES);
		// Far Left Buttom
		::glVertex3f(m_min[0], m_min[1], m_min[2]);
		::glVertex3f(m_min[0]+length, m_min[1], m_min[2]);
		::glVertex3f(m_min[0], m_min[1], m_min[2]);
		::glVertex3f(m_min[0], m_min[1]+length, m_min[2]);
		::glVertex3f(m_min[0], m_min[1], m_min[2]);
		::glVertex3f(m_min[0], m_min[1], m_min[2]+length);
		// Far Right Buttom
		::glVertex3f(m_max[0], m_min[1], m_min[2]);
		::glVertex3f(m_max[0]-length, m_min[1], m_min[2]);
		::glVertex3f(m_max[0], m_min[1], m_min[2]);
		::glVertex3f(m_max[0], m_min[1]+length, m_min[2]);
		::glVertex3f(m_max[0], m_min[1], m_min[2]);
		::glVertex3f(m_max[0], m_min[1], m_min[2]+length);
		// Far Right Top
		::glVertex3f(m_max[0], m_max[1], m_min[2]);
		::glVertex3f(m_max[0]-length, m_max[1], m_min[2]);
		::glVertex3f(m_max[0], m_max[1], m_min[2]);
		::glVertex3f(m_max[0], m_max[1]-length, m_min[2]);
		::glVertex3f(m_max[0], m_max[1], m_min[2]);
		::glVertex3f(m_max[0], m_max[1], m_min[2]+length);
		// Far Left Top
		::glVertex3f(m_min[0], m_max[1], m_min[2]);
		::glVertex3f(m_min[0]+length, m_max[1], m_min[2]);
		::glVertex3f(m_min[0], m_max[1], m_min[2]);
		::glVertex3f(m_min[0], m_max[1]-length, m_min[2]);
		::glVertex3f(m_min[0], m_max[1], m_min[2]);
		::glVertex3f(m_min[0], m_max[1], m_min[2]+length);
		// Near Left Buttom
		::glVertex3f(m_min[0], m_min[1], m_max[2]);
		::glVertex3f(m_min[0]+length, m_min[1], m_max[2]);
		::glVertex3f(m_min[0], m_min[1], m_max[2]);
		::glVertex3f(m_min[0], m_min[1]+length, m_max[2]);
		::glVertex3f(m_min[0], m_min[1], m_max[2]);
		::glVertex3f(m_min[0], m_min[1], m_max[2]-length);
		// Near Right Buttom
		::glVertex3f(m_max[0], m_min[1], m_max[2]);
		::glVertex3f(m_max[0]-length, m_min[1], m_max[2]);
		::glVertex3f(m_max[0], m_min[1], m_max[2]);
		::glVertex3f(m_max[0], m_min[1]+length, m_max[2]);
		::glVertex3f(m_max[0], m_min[1], m_max[2]);
		::glVertex3f(m_max[0], m_min[1], m_max[2]-length);
		// Near Right Top
		::glVertex3f(m_max[0], m_max[1], m_max[2]);
		::glVertex3f(m_max[0]-length, m_max[1], m_max[2]);
		::glVertex3f(m_max[0], m_max[1], m_max[2]);
		::glVertex3f(m_max[0], m_max[1]-length, m_max[2]);
		::glVertex3f(m_max[0], m_max[1], m_max[2]);
		::glVertex3f(m_max[0], m_max[1], m_max[2]-length);
		// Near Left Top
		::glVertex3f(m_min[0], m_max[1], m_max[2]);
		::glVertex3f(m_min[0]+length, m_max[1], m_max[2]);
		::glVertex3f(m_min[0], m_max[1], m_max[2]);
		::glVertex3f(m_min[0], m_max[1]-length, m_max[2]);
		::glVertex3f(m_min[0], m_max[1], m_max[2]);
		::glVertex3f(m_min[0], m_max[1], m_max[2]-length);
		::glEnd();
		::glPopAttrib();
		::glEndList();
	}

	void gl_draw_bounding_box2(void)
	{
		::glCallList(m_gl_bb_disp_list);
	}

	// copy bounding box
	void copy_bounding_box(Enriched_polyhedron<kernel,items> *pMesh)
	{
		m_min[0] = pMesh->xmin(); m_max[0] = pMesh->xmax();
		m_min[1] = pMesh->ymin(); m_max[1] = pMesh->ymax();
		m_min[2] = pMesh->zmin(); m_max[2] = pMesh->zmax();
	}

	// degree of a face
	static unsigned int degree(Facet_handle pFace)
	{
		return CGAL::circulator_size(pFace->facet_begin());    
	}

	// valence of a vertex
	static unsigned int valence(Vertex_handle pVertex)
	{
		return CGAL::circulator_size(pVertex->vertex_begin());
	}

	unsigned int fvid(Facet_handle pFace, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = pFace->facet_begin();
		if (v==0) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v==1) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v==2) {
			return pHE->vertex()->id();
		}
		return -1;
	}

	unsigned int fvid(int f, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = FH(f)->facet_begin();
		if (v==0) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v==1) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v==2) {
			return pHE->vertex()->id();
		}
		return -1;
	}

	const Point_3& fvp(Facet_handle pFace, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = pFace->facet_begin();
		if (v==0) {
			return pHE->vertex()->point();
		}
		pHE++;
		if (v==1) {
			return pHE->vertex()->point();
		}
		pHE++;
		return pHE->vertex()->point();
	}

	const Point_3& fvp(int f, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = FH(f)->facet_begin();
		if (v==0) {
			return pHE->vertex()->point();
		}
		pHE++;
		if (v==1) {
			return pHE->vertex()->point();
		}
		pHE++;
		return pHE->vertex()->point();
	}

	// get the id of the opposite facet of v (0, 1 or 2) in facet f
	int fvofid(int f, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = FH(f)->facet_begin();
		if (v==1) {
			if (pHE->opposite()->is_border()) {
				return -1;
			} else {
				return pHE->opposite()->facet()->id();
			}
		} else if (v==2) {
			if (pHE->next()->opposite()->is_border()) {
				return -1;
			} else {
				return pHE->next()->opposite()->facet()->id();
			}
		} else if (v==0) {
			if (pHE->next()->next()->opposite()->is_border()) {
				return -1;
			} else {
				return pHE->next()->next()->opposite()->facet()->id();
			}
		} else {
			return -1;
		}
	}

	// check wether	a vertex is on a boundary or not
	static bool	is_border(Vertex_handle	pVertex)
	{
		Halfedge_around_vertex_circulator	pHalfEdge	=	pVertex->vertex_begin();
		if(pHalfEdge ==	NULL)	// isolated	vertex
			return true;
		Halfedge_around_vertex_circulator	d	=	pHalfEdge;
		CGAL_For_all(pHalfEdge,d)
			if(pHalfEdge->is_border())
				return true;
		return false;
	}

	// get any border halfedge attached	to a vertex
	Halfedge_handle	get_border_halfedge(Vertex_handle pVertex)
	{
		Halfedge_around_vertex_circulator pHalfEdge = pVertex->vertex_begin();
		Halfedge_around_vertex_circulator d = pHalfEdge;
		CGAL_For_all(pHalfEdge,d)
			if(pHalfEdge->is_border())
				return pHalfEdge;
		return NULL;
	}

	// tag all halfedges
	void tag_halfedges(const short tag)
	{
		for (Halfedge_iterator pHalfedge=halfedges_begin(); pHalfedge!=halfedges_end(); pHalfedge++) {
			 pHalfedge->tag(tag);
		}
	}

	// tag all facets
	void tag_facets(const short tag)
	{
		for(Facet_iterator pFace=facets_begin(); pFace!=facets_end(); pFace++) {
			pFace->tag(tag);
		}
	}

	// tag all vertices
	void tag_vertices(const short tag)
	{
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++) {
			pVertex->tag(tag);
		}
	}

	// set index for all vertices: vertex->index / index->vertex
	void set_id_to_items_map()
	{
		index_to_vertex_map = Random_access_vertex_index(vertices_begin(), vertices_end());
		index_to_facet_map = Random_access_facet_index(facets_begin(), facets_end());
		m_is_set_id_to_items_map = true;
	}

	void set_hds_items_id()
	{
		int	index = 0;
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++) {
			pVertex->id() = index++;
		}
		index = 0;
		for (Halfedge_iterator pHalfedge=halfedges_begin(); pHalfedge!=halfedges_end(); pHalfedge++) {
			pHalfedge->id() = index++;
		}
		index = 0;
		for (Face_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++) {
			pFacet->id() = index++;
		}
		m_is_set_items_id = true;
	}

	// is pure degree ?
	bool is_pure_degree(unsigned int d)
	{
		for(Facet_iterator pFace	=	facets_begin();
				pFace	!= facets_end();
				pFace++)
			if(degree(pFace) != d)
				return false;
		return true;
	}

	// compute type
	void compute_type()
	{
		m_pure_quad = is_pure_degree(4);
		m_pure_triangle = is_pure_degree(3);
	}

	// compute facet center
	void compute_facet_center(Facet_handle pFace, Point& center)
	{
		Halfedge_around_facet_circulator pHalfEdge = pFace->facet_begin();
		Halfedge_around_facet_circulator end = pHalfEdge;
		Vector vec(0.0,0.0,0.0);
		int	degree = 0;
		CGAL_For_all(pHalfEdge,end)
		{
			vec	= vec + (pHalfEdge->vertex()->point()-CGAL::ORIGIN);
			degree++;
		}
		center = CGAL::ORIGIN + (vec/(kernel::FT)degree);
	}

	// compute average edge length around a vertex
	FT average_edge_length_around(Vertex_handle pVertex)
	{
		FT sum = 0.0;
		Halfedge_around_vertex_circulator pHalfEdge = pVertex->vertex_begin();
		Halfedge_around_vertex_circulator end = pHalfEdge;
		Vector vec(0.0,0.0,0.0);
		int	degree = 0;
		CGAL_For_all(pHalfEdge,end)
		{
			Vector vec = pHalfEdge->vertex()->point()-
				           pHalfEdge->opposite()->vertex()->point();
			sum += std::sqrt(vec*vec);
			degree++;
		}
		return sum / (FT) degree;
	}

	// compute average edge length around a vertex
	FT min_edge_length_around(Vertex_handle pVertex)
	{
		FT min_edge_length = 1e38;
		Halfedge_around_vertex_circulator pHalfEdge = pVertex->vertex_begin();
		Halfedge_around_vertex_circulator end = pHalfEdge;
		Vector vec(0.0,0.0,0.0);
		int	degree = 0;
		CGAL_For_all(pHalfEdge,end)
		{
			Vector vec = pHalfEdge->vertex()->point()-
				           pHalfEdge->opposite()->vertex()->point();
			FT len = std::sqrt(vec*vec);
			if(len < min_edge_length)
				min_edge_length = len;
		}
		return min_edge_length;
	}

	int pick_vertex_by_ray(Vector3 &sp, Vector3 &d, float epsilon)
	{
		int pi = -1;
		float min_t = FLT_MAX;
		float min_dist = epsilon, dist;
		float t = 0.0f;
		Vector3 vert, vec;

		d.normalize();
		for(Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			vert.set(pVertex->point()[0], pVertex->point()[1], pVertex->point()[2]);
			t = d.dot(vert - sp);
			if (t <= 0 || t >= min_t) {
				continue;
			}
			vec = vert - (sp + d * t);
			dist = vec.sqauremagnitude();
			if (dist < min_dist) {
				pi = pVertex->id();	// vertex index
				min_dist = dist;
				min_t = t;
			}
		}
		if (pi != -1) {	// picked
			if (picked_vertices.find(pi) == picked_vertices.end()) {
				picked_vertices.insert(pi);
				return pi;
			} else {
				picked_vertices.erase(pi);
			}
		}
		return -1;
	}

	int pick_vertex_by_ray_normal(Vector3 &sp, Vector3 &d, float epsilon)
	{
		int pi = -1;
		float min_t = FLT_MAX;
		float min_dist = epsilon, dist;
		float t = 0.0f;
		Vector3 vec;
		d.normalize();
		for(Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			vec.set(pVertex->point()[0], pVertex->point()[1], pVertex->point()[2]);
			t = d.dot(vec - sp);
			if (t <= 0 || t >= min_t) {
				continue;
			}
			vec = vec - (sp + d * t);
			dist = vec.sqauremagnitude();
			if (dist < min_dist) {
				vec.set(pVertex->normal()[0], pVertex->normal()[1], pVertex->normal()[2]);
				if (vec.dot(d) < 0.2) {
					pi = pVertex->id();	// vertex index
					min_dist = dist;
					min_t = t;
				}
			}
		}
		return pi;
	}

	void pick_mh_hdl_by_ray_n(const Vector3 &sp, const Vector3 &d, int &ph, int &pv, float epsilon)
	{
		float min_t=FLT_MAX;
		float min_dist=epsilon, dist;
		float t=0.0f;
		Vector3 vert;
		Vector3 dir(d);
		dir.normalize();
		std::set<int>::iterator v;
		ph = -1;
		pv = -1;
		for (int i=0; i<m_hdl_v.size(); i++)
		{
			for(v=m_hdl_v[i].begin(); v!=m_hdl_v[i].end(); v++)
			{
				vert.set(VP(*v)[0], VP(*v)[1], VP(*v)[2]);
				t = dir.dot(vert - sp);
				if (t <= 0 || t >= min_t) {
					continue;
				}
				vert = vert - (sp + dir * t);
				dist = vert.sqauremagnitude();
				if (dist < min_dist) {
					vert.set(VN(*v)[0], VN(*v)[1], VN(*v)[2]);
					if (vert.dot(dir) < 0) {
						ph = i;
						pv = *v;	// vertex index
						min_dist = dist;
						min_t = t;
					}
				}
			}
		}
	}

	void pick_vertices_by_column(Vector3 &sp, Vector3 &dx, Vector3 &dy, Vector3 &dz)
	{
		float t1 = 0.0f, t2 = 0.0f, t3 = 0.0f;
		float width = dx.magnitude();
		float height = dy.magnitude();
		dx.normalize();
		dy.normalize();
		dz.normalize();
		Vector3 vec, vert;

		for(Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			vert.set(pVertex->point()[0], pVertex->point()[1], pVertex->point()[2]);
			vec = vert - sp;
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			picked_vertices.insert(pVertex->id());
		}
	}

	void unpick_vertices_by_column(Vector3 &sp, Vector3 &dx, Vector3 &dy, Vector3 &dz)
	{
		float t1 = 0.0f, t2 = 0.0f, t3 = 0.0f;
		float width = dx.magnitude();
		float height = dy.magnitude();
		dx.normalize();
		dy.normalize();
		dz.normalize();
		Vector3 vec, vert;
		std::vector<std::set<int>::iterator> its;
		for (std::set<int>::iterator it=picked_vertices.begin(); it!=picked_vertices.end(); it++)
		{
			vert.set(index_to_vertex_map[(*it)]->point().x(), 
					 index_to_vertex_map[(*it)]->point().y(),
					 index_to_vertex_map[(*it)]->point().z());
			vec = vert - sp;
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			its.push_back(it);
		}
		for (unsigned int i=0; i<its.size(); i++)
		{
			picked_vertices.erase(its[i]);
		}
	}

	void clear_picked_vertices(void)
	{
		picked_vertices.clear();
	}

	int nb_picked_vertices(void)
	{
		return picked_vertices.size();
	}

	void write_picked_vertices(std::ofstream &stream)
	{
		stream << picked_vertices.size() << std::endl;
		std::set<int>::iterator pv;
		for (pv=picked_vertices.begin(); pv!=picked_vertices.end(); pv++)
		{
			stream << *pv << std::endl;
		}
	}

	void write_picked_facets(std::ofstream &stream)
	{
		stream << picked_facets.size() << std::endl;
		std::set<int>::iterator pf;
		for (pf=picked_facets.begin(); pf!=picked_facets.end(); pf++)
		{
			stream << *pf << std::endl;
		}
	}

	void read_picked_vertices(std::ifstream &stream)
	{
		int nV, v;
		stream >> nV;
		int nMV = size_of_vertices();
		if (nMV <= nV)
		{
			return;
		}
		picked_vertices.clear();
		for (int i=0; i<nV; i++) {
			stream >> v;
			if (v >= nMV)
			{
				v = nMV-1;
			}
			picked_vertices.insert(v);
		}
	}

	void read_picked_facets(std::ifstream &stream)
	{
		int nF, f;
		stream >> nF;
		int nMF = size_of_facets();
		if (nMF <= nF)
		{
			return;
		}
		picked_facets.clear();
		for (int i=0; i<nF; i++) {
			stream >> f;
			if (f >= nMF)
			{
				f = nMF-1;
			}
			picked_facets.insert(f);
		}
	}

	void gl_draw_vertex(int i)
	{
		if (i<0 || i>=size_of_vertices()) {
			return;
		}
		GLfloat red[] = {1.0f, 0.1f, 0.1f, 1.0f};
		GLfloat white[] = {1, 1, 1, 1.0f};
		::glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_POLYGON_BIT
						|GL_HINT_BIT|GL_LINE_BIT|GL_CURRENT_BIT);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		::glEnable(GL_LIGHTING);
		::glDisable(GL_TEXTURE_2D);
		::glDisable(GL_BLEND);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		::glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, white);
		::glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 40.0);
		::glColor4fv(red);
		Point &pos = VP(i);
		::glPushMatrix();
		::glTranslatef(pos[0], pos[1], pos[2]);
		::glutSolidSphere(0.05f, 12, 12);
		::glPopMatrix();
		::glPopAttrib();
	}

	void gl_draw_picked_vertices(void)
	{
		if (picked_vertices.size() == 0) {
			return;
		}
		::glPushAttrib(GL_LIGHTING_BIT|GL_CURRENT_BIT);
		::glDisable(GL_LIGHTING);
		::glColor3f(1.0f, 0.0f, 0.0f);
		for (std::set<int>::iterator pv=picked_vertices.begin(); pv!=picked_vertices.end(); pv++) {
			Point &pos = VP(*pv);
			::glPushMatrix();
			::glTranslatef(pos[0], pos[1], pos[2]);
			::glutSolidSphere(0.016f, 6, 6);
			::glPopMatrix();
		}
		::glPopAttrib();
	}

	int intersect_with_ray(FT *startp, FT *dir)
	{
		Vector3 sp(startp), d(dir);
		Vector3 e1, e2, p, s, q;
		float   t(0.0f), u(0.0f), v(0.0f), w(0.0f), tmp(0.0f);
		Point_3 v1, v2, v3;
		int     times = 0;
		Halfedge_around_facet_circulator pHalfedge;

		for (Facet_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++)
		{
			pHalfedge = pFacet->facet_begin();
			v1 = pHalfedge->vertex()->point();
			v2 = pHalfedge->next()->vertex()->point();
			v3 = pHalfedge->next()->next()->vertex()->point();
			e1.set(v2.x()-v1.x(), v2.y()-v1.y(), v2.z()-v1.z());
			e2.set(v3.x()-v1.x(), v3.y()-v1.y(), v3.z()-v1.z());
			p = d.cross(e2);
			tmp = p.dot(e1);
			if (tmp > -FLT_EPSILON && tmp < FLT_EPSILON) {//0.000001f
				continue;
			}
			tmp = 1.0f / tmp;
			s.set(sp.x-v1.x(), sp.y-v1.y(), sp.z-v1.z());
			u = tmp * p.dot(s);
			if (u < 0.0f || u > 1.0f) {
				continue;
			}
			q = s.cross(e1);
			v = tmp * q.dot(d);
			if (v < 0.0f || v > 1.0f) {
				continue;
			}
			w = u + v;
			if (w > 1.0f) {
				continue;
			}
			t = tmp * q.dot(e2);
			if (t > 0) {
				times++;
			}
		}
		return times;
	}

	void check_picked(int f)
	{
		Facet_handle FH = index_to_facet_map[f];
		Halfedge_around_facet_circulator pHE = FH->facet_begin();
		int v1, v2, ov1, ov2;
		do {
			v1 = pHE->vertex()->id();
			v2 = pHE->next()->vertex()->id();
			ov1 = pHE->opposite()->next()->next()->vertex()->id();
			ov2 = pHE->opposite()->vertex()->id();
		} while(++pHE != FH->facet_begin());
	}
	int pick_facet_by_ray(Vector3 &sp, Vector3 &d)
	{
		Vector3 e1, e2, p, s, q;
		FT   t(0), u(0), v(0), w(0), tmp(0);
		FT   min_t = FLT_MAX;
		int     pi = -1;
		Point_3 v1, v2, v3;
		int		i = 0;
		Halfedge_around_facet_circulator pHalfedge;

		for(Facet_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++, i++)
		{
			pHalfedge = pFacet->facet_begin();
			v1 = pHalfedge->vertex()->point();
			v2 = pHalfedge->next()->vertex()->point();
			v3 = pHalfedge->next()->next()->vertex()->point();
			e1.set(v2.x()-v1.x(), v2.y()-v1.y(), v2.z()-v1.z());
			e2.set(v3.x()-v1.x(), v3.y()-v1.y(), v3.z()-v1.z());
			p = d.cross(e2);
			tmp = p.dot(e1);

			if (tmp > -FLT_EPSILON && tmp < FLT_EPSILON) {
				continue;
			}
			tmp = 1.0f / tmp;
			s.set(sp.x-v1.x(), sp.y-v1.y(), sp.z-v1.z());
			u = tmp * p.dot(s);
			if (u < 0.0f || u > 1.0f) {
				continue;
			}
			q = s.cross(e1);
			v = tmp * q.dot(d);
			if (v < 0.0f || v > 1.0f) {
				continue;
			}
			w = u + v;
			if (w > 1.0f) {
				continue;
			}
			t = tmp * q.dot(e2);
			if (t > 0 && t < min_t) {
				pi = i;
				min_t = t;
			}
		}
		if (pi != -1) {
			if (picked_facets.find(pi) == picked_facets.end()) {
				picked_facets.insert(pi);
			} else {
				picked_facets.erase(pi);
			}
		//	check_picked(pi);
			return pi;
		}
		return -1;
	}

	void pick_facets_by_column(Vector3 &sp, Vector3 &dx, Vector3 &dy, Vector3 &dz)
	{
		FT t1(0), t2(0), t3(0);
		FT width = dx.magnitude();
		FT height = dy.magnitude();
		dx.normalize();
		dy.normalize();
		dz.normalize();
		Vector3 vec;
		Halfedge_handle pHalfedge;
		Point_3 v1, v2, v3;
		int i = 0;

		for(Facet_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++, i++)
		{
			pHalfedge = pFacet->halfedge();
			v1 = pHalfedge->vertex()->point();
			v2 = pHalfedge->next()->vertex()->point();
			v3 = pHalfedge->next()->next()->vertex()->point();
			vec.set(v1.x()-sp.x, v1.y()-sp.y, v1.z()-sp.z);
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			vec.set(v2.x()-sp.x, v2.y()-sp.y, v2.z()-sp.z);
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			vec.set(v3.x()-sp.x, v3.y()-sp.y, v3.z()-sp.z);
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			picked_facets.insert(i);
		}
	}

	void clear_picked_facets(void)
	{
		picked_facets.clear();
	}

	int nb_picked_facets(void)
	{
		return picked_facets.size();
	}

	void gl_draw_picked_facets(bool smooth_shading, bool use_normals)
	{
		if (picked_facets.size() == 0) {
			return;
		}
		GLfloat mat[4] = {0.85f, 0.6f, 0.1f};
		::glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT);
		::glEnable(GL_LIGHTING);
		::glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat);
	
		std::set<int>::iterator pf;
	//	Halfedge_around_facet_circulator pHalfedge;
	//	Point_3 v1, v2, v3;
		::glBegin(GL_TRIANGLES);
			for (pf=picked_facets.begin(); pf!=picked_facets.end(); pf++)
			{
				gl_draw_facet(index_to_facet_map[(*pf)], smooth_shading, use_normals, false);
			/*	pHalfedge = (index_to_facet_map[(*pf)])->facet_begin();
				::glVertex3f(pHalfedge->vertex()->point().x(), 
							 pHalfedge->vertex()->point().y(), 
							 pHalfedge->vertex()->point().z());
				::glVertex3f(pHalfedge->next()->vertex()->point().x(), 
							 pHalfedge->next()->vertex()->point().y(), 
							 pHalfedge->next()->vertex()->point().z());
				::glVertex3f(pHalfedge->next()->next()->vertex()->point().x(), 
							 pHalfedge->next()->next()->vertex()->point().y(), 
							 pHalfedge->next()->next()->vertex()->point().z());*/
			}
		::glEnd();
		::glPopAttrib();
	}

	void clamp_harmonic_field(FT *hf, int n)
	{
		for (int i=0; i<n; i++) {
			if (hf[i] > 1.0) {
				hf[i] = 1.0;
			} else if (hf[i] < 0.0) {
				hf[i] = 0.0;
			}
		}
	}

	bool is_s_hf_uptodate(void)
	{
		return m_is_s_hf_utd;
	}
	bool is_s_hvf_uptodate(void)
	{
		return m_is_s_hvf_utd;
	}
	bool is_built_hf_s_vbo(void)
	{
		return m_is_built_sf_color_vbo;
	}
	bool is_built_cluster_vbo(void)
	{
		return m_is_built_cluster_color_vbo;
	}
	bool is_built_vote_vbo(void)
	{
		return m_is_built_vote_vbo;
	}
	bool is_built_tex_vbo(void)
	{
		return m_is_built_tex_color_vbo;
	}
	int get_site_num(void)
	{
		return m_sf_sites.size();
	}
	int get_hvf_site_num(void)
	{
		return m_hvf_sites.size();
	}
	void set_hvf_sites(MAP_IVS &sites)
	{
		m_hvf_sites = sites;
		m_is_s_hvf_utd = false;
	}
	void clear_hvf_sites()
	{
		m_hvf_sites.clear();
		m_is_s_hvf_utd = false;
	}
	void insert_hvf_site(std::pair<int,std::pair<Vector3,short>> item)
	{
		m_hvf_sites.insert(item);
		m_is_s_hvf_utd = false;
	}
	void clear_hf_sites()
	{
		m_sf_sites.clear();
		m_is_s_hf_utd = false;
	}
	void insert_hf_site(int i, short f)
	{
		MAP_ISP::iterator it;
		if ((it=m_sf_sites.find(i)) == m_sf_sites.end()) {
			m_sf_sites.insert(std::make_pair(i,std::make_pair(f,1)));
			m_is_s_hvf_utd = false;
		} else {
			if ((it->second).second == -1) {
				(it->second).second = 0;
			}
		}
	}
	void remove_hf_site(int i)
	{
		MAP_ISP::iterator it;
		if ((it=m_sf_sites.find(i)) != m_sf_sites.end()) {
			(it->second).second = -1;
			m_is_s_hvf_utd = false;
		} else {
			if ((it->second).second == 1) {
				m_sf_sites.erase(it);
			}
		}
	}
	bool move_hf_site(Vector3 &sp, Vector3 &d)
	{
		int pv = -1;
		if ((pv=pick_vertex_by_ray_normal(sp, d, 0.001)) != -1)
		{
			if (pv == m_pick_sf_site) {
				return false;
			}
			MAP_ISP::iterator it1, it2;
			if ((it1=m_sf_sites.find(m_pick_sf_site)) != m_sf_sites.end())
			{
				short src = (it1->second).first;
				if ((it2=m_sf_sites.find(pv)) != m_sf_sites.end()) {	// existed
					if ((it2->second).second == -1) {	// need downdate
						
						if ((it1->second).second == 1) {
							m_sf_sites.erase(it1);
						} else {
							(it1->second).second = -1;
						}
						(it2->second).first = src;
						(it2->second).second = 0;	// cancel downdate
						m_pick_sf_site = pv;
						m_is_s_hf_utd = false;
						m_is_built_sf_color_vbo = false;
						return true;
					} else {
						return false;
					}
				}
				if ((it1->second).second == 1) {
					m_sf_sites.erase(it1);
				} else {
					(it1->second).second = -1;
				}
				m_sf_sites.insert(std::make_pair(pv, std::make_pair(src,1)));
				m_pick_sf_site = pv;
				m_is_s_hf_utd = false;
				m_is_built_sf_color_vbo = false;
				return true;
			}
		}
		return false;
	}
	bool move_hvf_site(Vector3 &sp, Vector3 &d)
	{
		int pv = -1;
		if ((pv=pick_vertex_by_ray_normal(sp, d, 0.001)) != -1)
		{
			if (pv == m_pick_hvf_site) {
				return false;
			}
			MAP_IVS::iterator it1, it2;
			if ((it1=m_hvf_sites.find(m_pick_hvf_site)) != m_hvf_sites.end())
			{
				Vector3 vn1(VN(m_pick_hvf_site)[0], VN(m_pick_hvf_site)[1], VN(m_pick_hvf_site)[2]);
				Vector3 vn2(VN(pv)[0], VN(pv)[1], VN(pv)[2]);
				Vector3 vec = (Matrix4().setrotate(Acos(vn1.dot(vn2)), vn1.cross(vn2))).transform((it1->second).first);
				if ((it2=m_hvf_sites.find(pv)) != m_hvf_sites.end())
				{ // if the pv existed in m_hvf_sites
					if ((it2->second).second == -1) {	// need downdate
						if ((it1->second).second == 1) {
							m_hvf_sites.erase(it1);
						} else {
							(it1->second).second = -1;
						}
						(it2->second).first = vec;
						(it2->second).second = 0;	// cancel downdate
						m_pick_hvf_site = pv;
						m_is_s_hvf_utd = false;
						m_is_built_hvf_s_vbo = false;
						return true;
					} else {
						return false;
					}
				}
				if ((it1->second).second == 1) {
					m_hvf_sites.erase(it1);
				} else {
					(it1->second).second = -1;
				}
				m_hvf_sites.insert(std::make_pair(pv, std::make_pair(vec,1)));
				m_pick_hvf_site = pv;
				m_is_s_hvf_utd = false;
				m_is_built_hvf_s_vbo = false;
				return true;
			}
		}
		return false;
	}
	void unpick_hf_site(void)
	{
		m_pick_sf_site = -1;
	}
	void unpick_hvf_site(void)
	{
		m_pick_hvf_site = -1;
	}
	bool pick_hf_site_by_ray(Vector3 &sp, Vector3 &d)
	{
		float min_t = FLT_MAX;
		float min_dist=m_hf_site_radii*m_hf_site_radii, dist;
		float t = 0.0f;
		Vector3 vert;
		d.normalize();
		MAP_ISP::iterator it;
		m_pick_sf_site = -1;
		for(it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++)
		{
			if ((it->second).second == -1) {
				continue;
			}
			vert.set(VP(it->first)[0], VP(it->first)[1], VP(it->first)[2]);
			t = d.dot(vert - sp);
			if (t <= 0 || t >= min_t) {
				continue;
			}
			vert = vert - (sp + d * t);
			dist = vert.sqauremagnitude();
			if (dist < min_dist) {
				vert.set(VN(it->first)[0], VN(it->first)[1], VN(it->first)[2]);
				if (vert.dot(d) < 0.36) {
					m_pick_sf_site = it->first;	// vertex index
					min_dist = dist;
					min_t = t;
				}
			}
		}
		return (m_pick_sf_site==-1) ? false : true;
	}
	bool pick_hvf_site_by_ray(Vector3 &sp, Vector3 &d)
	{
		float min_t = FLT_MAX;
		float min_dist=m_hvf_site_radii*m_hvf_site_radii, dist;
		float t = 0.0f;
		Vector3 vert;
		d.normalize();
		MAP_IVS::iterator it;
		m_pick_hvf_site = -1;
		for(it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++)
		{
			if ((it->second).second == -1) {
				continue;
			}
			vert.set(VP(it->first)[0], VP(it->first)[1], VP(it->first)[2]);
			t = d.dot(vert - sp);
			if (t <= 0 || t >= min_t) {
				continue;
			}
			vert = vert - (sp + d * t);
			dist = vert.sqauremagnitude();
			if (dist < min_dist) {
				vert.set(VN(it->first)[0], VN(it->first)[1], VN(it->first)[2]);
				if (vert.dot(d) < 0.36) {
					m_pick_hvf_site = it->first;	// vertex index
					min_dist = dist;
					min_t = t;
				}
			}
		}
		return (m_pick_hvf_site==-1) ? false : true;
	}

	void ctrl_hvf_site(Vector3 &sp, Vector3 &d)
	{
		MAP_IVS::iterator it;
		if ((it=m_hvf_sites.find(m_pick_hvf_site)) == m_hvf_sites.end()) {
			return;
		}
		int vi = it->first;
		Vector3 vp(VP(vi)[0], VP(vi)[1], VP(vi)[2]);
		Vector3 vn(VN(vi)[0], VN(vi)[1], VN(vi)[2]);
		Vector3 pp, pvec;
		Vector3 dir(d);
		dir.normalize();
		pp = sp + dir * ((vp-sp).dot(dir)) - vp;
		pvec = pp.cross(vn);
		if (IsZeroL(pvec[0])&&IsZeroL(pvec[1])&&IsZeroL(pvec[2])) {
			(it->second).first.set(0.0, 0.0, 0.0);
			return;
		}
		pvec = vn.cross(pvec);
		pvec.normalize();
		(it->second).first = pvec * (pp.dot(pvec));
		m_is_s_hvf_utd = false;
	}

	void tag_region(const std::vector<int> &seed, const std::vector<int> &border)
	{
		tag_vertices(0);
		for (int i=0; i<border.size(); i++) {	// border
			index_to_vertex_map[border[i]]->tag(1);
		}
		for (int i=0; i<seed.size(); i++) {
			flood_fill_tag(seed[i], 1);
		}
	}

	void tag_region(const std::vector<std::pair<int,short>> &seeds,
					const std::vector<std::pair<std::vector<int>,short>> &borders)
	{
		tag_vertices(0);
		for (int i=0; i<borders.size(); i++) {	// border
			for (int j=0; j<borders[i].first.size(); j++) {
				index_to_vertex_map[borders[i].first[j]]->tag(borders[i].second);
			}
		}
		for (int i=0; i<seeds.size(); i++) {
			if (seeds[i].second == 0) {
				return;
			}
			flood_fill_tag(seeds[i].first, seeds[i].second);
		}
	}

	void flood_fill_tag(int s, short t)
	{
		index_to_vertex_map[s]->tag(t);
		Halfedge_around_vertex_circulator pHalfEdge, end;
		pHalfEdge = index_to_vertex_map[s]->vertex_begin();
		end = pHalfEdge;
		CGAL_For_all(pHalfEdge, end)
		{
			Vertex_handle vh = pHalfEdge->opposite()->vertex();
			if (pHalfEdge->opposite()->vertex()->tag() == 0) {
				flood_fill_tag(vh->id(), t);
			}
		}
	}

	bool set_hf_site(int v, short src=1)
	{
		if (v<0 || v>=size_of_vertices()) {
			return false;
		}
		MAP_ISP::iterator it;
		if ((it=m_sf_sites.find(v)) != m_sf_sites.end()) {
			if ((it->second).second == -1) {
				(it->second).second = 0;
				(it->second).first = src;
				m_is_s_hf_utd = false;
				m_is_built_sf_color_vbo = false;
				return true;
			} else {
				return false;
			}
		}
		m_sf_sites.insert(std::make_pair(v, std::make_pair(src,1)));
		m_is_s_hf_utd = false;
		m_is_built_sf_color_vbo = false;
		return true;
	}
	bool set_hvf_site(int v)
	{
		if (v<0 || v>=size_of_vertices()) {
			return false;
		}
		MAP_IVS::iterator it;
		Vector3 z_axis(0.0, 0.0, 1.0);
		Vector3 vn(VN(v)[0], VN(v)[1], VN(v)[2]);
		Vector3 vec = vn.cross(z_axis);
		vec.normalize();
		if ((it=m_hvf_sites.find(v)) != m_hvf_sites.end()) {
			if ((it->second).second == -1) {
				(it->second).second = 0;
				(it->second).first = vec;
				m_is_s_hvf_utd = false;
				m_is_built_hvf_s_vbo = false;
				m_pick_hvf_site = v;
				return true;
			} else {
				return false;
			}
		}
		m_hvf_sites.insert(std::make_pair(v, std::make_pair(vec,1)));
		m_is_s_hvf_utd = false;
		m_is_built_hvf_s_vbo = false;
		m_pick_hvf_site = v;
		return true;
	}

	void remove_hf_sites_by_column(Vector3 &sp, Vector3 &dx, Vector3 &dy, Vector3 &dz)
	{
		float t1 = 0.0f, t2 = 0.0f, t3 = 0.0f;
		float width = dx.magnitude();
		float height = dy.magnitude();
		dx.normalize();
		dy.normalize();
		dz.normalize();
		Vector3 vec, vert;
		std::vector<MAP_ISP::iterator> its;
		for (MAP_ISP::iterator it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++)
		{
			vert.set(VP(it->first).x(), VP(it->first).y(), VP(it->first).z());
			vec = vert - sp;
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			its.push_back(it);
		}
		for (unsigned int i=0; i<its.size(); i++)
		{
			if ((its[i]->second).second == 1) {
				m_sf_sites.erase(its[i]);
			} else {
				(its[i]->second).second = -1;
			}
		}
		m_is_s_hf_utd = false;
		m_is_built_sf_color_vbo = false;
	}
	void remove_hvf_sites_by_column(Vector3 &sp, Vector3 &dx, Vector3 &dy, Vector3 &dz)
	{
		float t1 = 0.0f, t2 = 0.0f, t3 = 0.0f;
		float width = dx.magnitude();
		float height = dy.magnitude();
		dx.normalize();
		dy.normalize();
		dz.normalize();
		Vector3 vec, vert;
		std::vector<MAP_IVS::iterator> its;
		for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++)
		{
			vert.set(VP(it->first).x(), VP(it->first).y(), VP(it->first).z());
			vec = vert - sp;
			if (dx.dot(vec)<=0 || dy.dot(vec)<=0 || dz.dot(vec)<=0) {
				continue;
			}
			if (width < fabs(dx.dot(vec))) {
				continue;
			}
			if (height < fabs(dy.dot(vec))) {
				continue;
			}
			its.push_back(it);
		}
		for (unsigned int i=0; i<its.size(); i++)
		{
			if ((its[i]->second).second == 1) {
				m_hvf_sites.erase(its[i]);
			} else {
				(its[i]->second).second = -1;
			}
		}
		m_is_s_hvf_utd = false;
		m_is_built_hvf_s_vbo = false;
	}

	
	//////////////////////////////////////////////////////////////////////////
	CVector* comp_s_sf_rhs_vec_PNT(cholmod_common *c)
	{
		CVector *cvRHSV = new CVector((int)size_of_vertices(), c);
		// BNM: d+n is equivallent to d*(1+n/d), where the big number is (1+n/d)
		cvRHSV->clear_zero();
		MAP_ISP::iterator it;
		for (it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++) {
			if ((it->second).first == 1) {
				(*cvRHSV)[it->first] = BN;
			}
		}
		return cvRHSV;
	}
	
	CMatrix* comp_s_hf_lap_uniform_PNT(cholmod_common *c)
	{
		int N = (int)size_of_vertices();
		CMatrix *cmAL = new CMatrix(N, true, c);
		Halfedge_around_vertex_circulator pHalfEdge, end;
		MAP_ISP::iterator it;
		for (Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			pHalfEdge = pVertex->vertex_begin();
			end = pHalfEdge;
			CGAL_For_all(pHalfEdge, end)
			{
				cmAL->set_coef(pVertex->id(), pHalfEdge->opposite()->vertex()->id(), -1.0);
			}
			if ((it=m_sf_sites.find(pVertex->id())) != m_sf_sites.end()) {
				cmAL->set_coef(pVertex->id(), pVertex->id(), (FT)valence(pVertex)+BN);
				(it->second).second = 0;
			} else {
				cmAL->set_coef(pVertex->id(), pVertex->id(), (FT)valence(pVertex));
			}
		}
		return cmAL;
	}

	CMatrix* comp_s_hf_lap_cot_PNT(cholmod_common *c)
	{
		int N = (int)size_of_vertices();
		CMatrix *cmAL = new CMatrix(N, true, c);
		Halfedge_around_vertex_circulator pHalfEdge, end;
		MAP_ISP::iterator it;
		Vector3 pv, lpnv, pnv, npnv, e1v, e2v, ec;
		for(Vertex_iterator pVertex=vertices_begin(); pVertex!=vertices_end(); pVertex++)
		{
			const Point& p = pVertex->point();
			pv.set(p[0], p[1], p[2]);
			pHalfEdge = pVertex->vertex_begin();
			end = pHalfEdge;
			FT diag_sum = 0.0;
			CGAL_For_all(pHalfEdge, end)
			{
				const Point& lpn = (--pHalfEdge)->opposite()->vertex()->point();
				const Point& pn  = (++pHalfEdge)->opposite()->vertex()->point();
				const Point& npn = (++pHalfEdge)->opposite()->vertex()->point();
				--pHalfEdge;
				lpnv.set(lpn[0], lpn[1], lpn[2]);
				pnv.set(pn[0], pn[1], pn[2]);
				npnv.set(npn[0], npn[1], npn[2]);
				e1v = pv - npnv;
				e2v = pnv - npnv;
				FT ne_cos = e1v.dot(e2v);
				FT ne_sin = e1v.cross(e2v).magnitude();
				FT cot_alpha;
				if (ne_sin < std::numeric_limits<FT>::epsilon()) {
					cot_alpha = 5.0;
				} else {
					cot_alpha = ne_cos / ne_sin;
				}
				e1v = pv - lpnv;
				e2v = pnv - lpnv;
				ne_cos = e1v.dot(e2v);
				ne_sin = e1v.cross(e2v).magnitude();
				FT cot_beta;
				if (ne_sin < std::numeric_limits<FT>::epsilon()) {
					cot_beta = 5.0;
				} else {
					cot_beta = ne_cos / ne_sin;
				}
				FT w = 0.5 * (cot_alpha+cot_beta);
				cmAL->set_coef(pVertex->id(), pHalfEdge->opposite()->vertex()->id(), -w);
				diag_sum += w;
			}
			if ((it=m_sf_sites.find(pVertex->id())) != m_sf_sites.end()) {
				cmAL->set_coef(pVertex->id(), pVertex->id(), diag_sum+BN);
				(it->second).second = 0;
			} else {
				cmAL->set_coef(pVertex->id(), pVertex->id(), diag_sum);
			}
		}
		return cmAL;
	}

	void compute_s_hf()
	{
		if (m_sf_sites.empty()) {
			return;
		}
		double start;
		cholmod_common c;
		cholmod_start(&c);	// start CHOLMOD
		cholmod_dense *X;
		
		if (m_s_F == NULL) {
			if (m_s_hf_ws == std::string("Cotangent")) {
				CMatrix *cmA = comp_s_hf_lap_cot_PNT(&c);
				cholmod_sparse *csA = (cholmod_sparse*)cmA->get_cholmod_sparse();
				m_s_F = cholmod_analyze(csA, &c);	// analyze
				cholmod_factorize(csA, m_s_F, &c);	// factorize
				SAFE_DELETE(cmA);
			} else if (m_s_hf_ws == std::string("Uniform")) {
			}
		} else {
			CMatrix *cmC = new CMatrix((int)size_of_vertices(), false, &c);
			cholmod_sparse *Cnew;
			bool bNeedDown = false;
			bool bNeedUp = false;
			// build downdate sparse
			std::vector<MAP_ISP::iterator> its;
			for (MAP_ISP::iterator it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++) {
				if ((it->second).second == -1) {	// -1: to be downdated
					cmC->set_coef(it->first, it->first, SQBN);
					its.push_back(it);
					bNeedDown = true;
				}
			}
			// delete really
			for (unsigned int i=0; i<its.size(); i++) {
				m_sf_sites.erase(its[i]);
			}
			if (bNeedDown) {	// if needed, perform downdating
				Cnew = cholmod_submatrix((cholmod_sparse*)cmC->get_cholmod_sparse(), (int*)m_s_F->Perm,
										 m_s_F->n, NULL, -1, TRUE, TRUE, &c);
				cholmod_updown(FALSE, Cnew, m_s_F, &c);
				cholmod_free_sparse(&Cnew, &c);
				cmC->clear_sparse();
			}
			// build update sparse
			for (MAP_ISP::iterator it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++) {
				if ((it->second).second == 1) {	// +1: to be updated
					cmC->set_coef(it->first, it->first, SQBN);
					(it->second).second = 0;
					bNeedUp = true;
				}
			}
			if (bNeedUp) {	// if needed, perform updating
				Cnew = cholmod_submatrix((cholmod_sparse*)cmC->get_cholmod_sparse(), (int*)m_s_F->Perm,
										 m_s_F->n, NULL, -1, TRUE, TRUE, &c);
				cholmod_updown(TRUE, Cnew, m_s_F, &c);
				cholmod_free_sparse(&Cnew, &c);
			}
			delete cmC;
		}
		CVector *RHV_hf = comp_s_sf_rhs_vec_PNT(&c);	// set rhs vector
		X = cholmod_solve(CHOLMOD_A, m_s_F, (cholmod_dense*)RHV_hf->get_cholmod_dense(), &c);	// solve Ax=b
		SAFE_DELETE(RHV_hf);
		
		// copy
		if (m_s_sf == NULL) m_s_sf = new FT [size_of_vertices()];
		for (int i=0; i<size_of_vertices(); i++) m_s_sf[i]=(FT)((double*)X->x)[i];
		// clamp harmonic values
		clamp_harmonic_field(m_s_sf, size_of_vertices());
		cholmod_free_dense(&X, &c);
		cholmod_finish(&c);		// end CHOLMOD
		m_is_s_hf_utd = true;
	}
	
	void set_s_hvf_rhs_vec(CVector *tvRHSV, int dim)
	{
		// BNM: d+n is equivallent to d*(1+n/d), where the big number is (1+n/d)
		tvRHSV->clear_zero();
		MAP_IVS::iterator it;
		for (it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++) {
			(*tvRHSV)[it->first] = BN * ((it->second).first)[dim];
		}
	}
	void set_s_hvf_lap_uniform_PNT(CMatrix *tmAssLM)
	{
		Halfedge_around_vertex_circulator pHalfEdge, end;
		FT diag_sum(0.0);
		short *tag = new short [size_of_vertices()];
		memset(tag, 0, size_of_vertices()*sizeof(short));
		for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++) {
			tag[it->first] = 1;
			(it->second).second = 0;
		}
		// Set Laplacian matrix
		// BNM: d+n is equivallent to d*(1+n/d), where the big number is (1+n/d)
		for (int i=0; i<size_of_vertices(); i++)
		{
			pHalfEdge = index_to_vertex_map[i]->vertex_begin();
			end = pHalfEdge;
			diag_sum = 0.0;
			CGAL_For_all(pHalfEdge, end)
			{
				tmAssLM->set_coef(i, pHalfEdge->opposite()->vertex()->id(), -1.0);
				diag_sum += 1.0;
			}
			if (tag[i] == 1) {
				tmAssLM->set_coef(i, i, diag_sum+BN);
			} else {
				tmAssLM->set_coef(i, i, diag_sum);
			}
		}
		SAFE_DELETE_ARRAY(tag);
	}

	const Vector3& get_hvf_v(int i)
	{
		return m_s_vf[i];
	}

	void compute_s_hvf(void)
	{
		if (m_hvf_sites.empty()) {
			return;
		}
		cholmod_common c;
		cholmod_start(&c);	// start CHOLMOD
		if (m_s_hvf_F == NULL) {	// if not existed, compute new factorization
			CMatrix *AM_hf = new CMatrix((int)size_of_vertices(), true, &c);
			set_s_hvf_lap_uniform_PNT(AM_hf);
			m_s_hvf_F = cholmod_analyze((cholmod_sparse*)AM_hf->get_cholmod_sparse(), &c);	// analyze
			cholmod_factorize((cholmod_sparse*)AM_hf->get_cholmod_sparse(), m_s_hvf_F, &c);	// factorize
			delete AM_hf;
		} else {
			CMatrix *cmC = new CMatrix((int)size_of_vertices(), false, &c);
			cholmod_sparse *Cnew;
			bool bNeedDown = false;
			bool bNeedUp = false;
			// build downdate sparse
			std::vector<MAP_IVS::iterator> its;
			for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++) {
				if ((it->second).second == -1) {	// -1: to be downdated
					cmC->set_coef(it->first, it->first, SQBN);
					its.push_back(it);
					bNeedDown = true;
				}
			}
			// delete really
			for (unsigned int i=0; i<its.size(); i++) {
				m_hvf_sites.erase(its[i]);
			}
			if (bNeedDown) {	// if needed, perform downdating
				Cnew = cholmod_submatrix((cholmod_sparse*)cmC->get_cholmod_sparse(), (int*)m_s_hvf_F->Perm,
										 m_s_hvf_F->n, NULL, -1, TRUE, TRUE, &c);
				cholmod_updown(FALSE, Cnew, m_s_hvf_F, &c);
				cholmod_free_sparse(&Cnew, &c);
				cmC->clear_sparse();
			}
			// build update sparse
			for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++) {
				if ((it->second).second == 1) {	// +1: to be updated
					cmC->set_coef(it->first, it->first, SQBN);
					(it->second).second = 0;	// turn it back to 0: up-to-date
					bNeedUp = true;
				}
			}
			if (bNeedUp) {	// if needed, perform updating
				Cnew = cholmod_submatrix((cholmod_sparse*)cmC->get_cholmod_sparse(), (int*)m_s_hvf_F->Perm,
										 m_s_hvf_F->n, NULL, -1, TRUE, TRUE, &c);
				cholmod_updown(TRUE, Cnew, m_s_hvf_F, &c);
				cholmod_free_sparse(&Cnew, &c);
			}
			delete cmC;
		}
		CVector *RHV_hf = new CVector((int)size_of_vertices(), &c);
		if (m_s_vf == NULL) m_s_vf = new Vector3 [size_of_vertices()];
		for (int d=0; d<3; d++)
		{
			set_s_hvf_rhs_vec(RHV_hf, d);	// set rhs vector
			cholmod_dense *X = cholmod_solve(CHOLMOD_A, m_s_hvf_F, (cholmod_dense*)RHV_hf->get_cholmod_dense(), &c);	// solve Ax=b
			for (int i=0; i<size_of_vertices(); i++) m_s_vf[i][d]=(FT)((double*)X->x)[i];
			cholmod_free_dense(&X, &c);
		}
		delete RHV_hf;
		// projection
		project_harmonic_vector_field(m_s_vf, 0.04, 0.16);
		cholmod_finish(&c);		// end CHOLMOD
		m_is_s_hvf_utd = true;
	}

	void project_harmonic_vector_field(Vector3 *hvf, FT low=1.0, FT high=1.0)
	{
		if (hvf==NULL || low>high || low<0.0) {
			return;
		}
		Vector3 vn, pvec;
		if (low == high) {
			m_s_hvm_min = std::numeric_limits<FT>::max();
			m_s_hvm_max = std::numeric_limits<FT>::min();
			for (int i=0; i<size_of_vertices(); i++) {
				vn.set(VN(i)[0], VN(i)[1], VN(i)[2]);
				pvec = hvf[i].cross(vn);
				FT m(0.0);
				if (IsZeroL(pvec[0])&&IsZeroL(pvec[1])&&IsZeroL(pvec[2])) {
					hvf[i].set(0.0, 0.0, 0.0);
				} else {
					hvf[i] = vn.cross(pvec);
					m = hvf[i].magnitude();
				}
				if (m > m_s_hvm_max) {
					m_s_hvm_max = m;
				}
				if (m < m_s_hvm_min) {
					m_s_hvm_min = m;
				}
			}
		} else {
			FT mmax=std::numeric_limits<FT>::min();
			FT mmin=std::numeric_limits<FT>::max();
			std::vector<FT> mag(size_of_vertices(), 0.0);
			for (int i=0; i<size_of_vertices(); i++) {
				vn.set(VN(i)[0], VN(i)[1], VN(i)[2]);
				pvec = hvf[i].cross(vn);
				if (IsZeroL(pvec[0])&&IsZeroL(pvec[1])&&IsZeroL(pvec[2])) {
					hvf[i].set(0.0, 0.0, 0.0);
					mag[i] = 0.0;
				} else {
					hvf[i] = vn.cross(pvec);
					mag[i] = hvf[i].magnitude();
				}
				if (mag[i] > mmax) {
					mmax = mag[i];
				}
				if (mag[i] < mmin) {
					mmin = mag[i];
				}
			}
			FT scl = (high - low) / (mmax - mmin);
			for (int i=0; i<size_of_vertices(); i++) {
				hvf[i] *= ((low + scl*(mag[i]-mmin)) / mag[i]);
			}
			m_s_hvm_min = low;
			m_s_hvm_max = high;
		}
	}

	void gl_draw_hf_sites(void)
	{
		if (m_sf_sites.empty()) {
			return;
		}
		GLfloat mat_source[] = {1.0f, 0.0f, 0.0f, 0.72f};
		GLfloat mat_sink[]	 = {0.2f, 0.32f, 0.9f, 0.7f};
		::glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_CURRENT_BIT|GL_POLYGON_BIT);
		::glEnable(GL_LIGHTING);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		::glEnable(GL_BLEND);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		for (MAP_ISP::iterator it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++)
		{
			if ((it->second).second == -1) {
				continue;
			}
			if ((it->second).first == 1) {
				::glColor4fv(mat_source);
			} else {
				::glColor4fv(mat_sink);
			}
			/*::glColor4fv(mat_source);*/
			::glPushMatrix();
			::glTranslatef(VP(it->first)[0], VP(it->first)[1], VP(it->first)[2]);
			::glutSolidSphere(m_hf_site_radii, 16, 16);
			::glPopMatrix();
		}
		::glPopAttrib();
	}
	void gl_draw_hvf_sites(void)
	{
		if (m_hvf_sites.empty()) {
			return;
		}
		GLfloat vec_mat[] = {1.0f, 0.1f, 0.1f, 1.0f};
		GLfloat pick_mat[] = {0.1f, 0.76f, 0.1f, 1.0f};
		Vector3 z_axis(0.0, 0.0, 1.0);
		float arrow_radia = 0.5 * m_hvf_site_radii;
		float arrow_head_radia = m_hvf_site_radii;
		float arrow_head_len = arrow_head_radia * 3.0;
		float arrow_bar_len, vec_length;
		GLUquadric *pQuadric = gluNewQuadric();
		::glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_CURRENT_BIT|GL_POLYGON_BIT);
		::glEnable(GL_LIGHTING);
		::glDisable(GL_CULL_FACE);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++)
		{
			if (it->first == m_pick_hvf_site) {
				::glColor4fv(pick_mat);
			} else {
				::glColor4fv(vec_mat);
			}
			Vector3 &vec = (it->second).first;
			vec_length = vec.magnitude(); 
			arrow_bar_len = vec_length - arrow_head_len;
			float rot_angle = Acos(vec.z/vec.magnitude());
			Vector3 rot_axis = z_axis.cross(vec);
			::glPushMatrix();
			::glTranslatef(VP(it->first)[0], VP(it->first)[1], VP(it->first)[2]);
			::glutSolidSphere(arrow_head_radia, 16, 16);
			::glRotatef(rot_angle, rot_axis.x, rot_axis.y, rot_axis.z);
			::gluCylinder(pQuadric, arrow_radia, arrow_radia, arrow_bar_len, 10, 6);
			::glTranslatef(0.0f, 0.0f, arrow_bar_len);
			::gluDisk(pQuadric, arrow_radia, arrow_head_radia, 16, 2);	// cone bottom
			::gluCylinder(pQuadric, arrow_head_radia, 0.0, arrow_head_len, 16, 4);	// cone
			::glPopMatrix();
		}
		::glPopAttrib();
		gluDeleteQuadric(pQuadric);
	}

	void gl_draw_hvf_sites_simple(void)
	{
		if (m_hvf_sites.empty()) {
			return;
		}
		//GLfloat vec_mat[] = {1.0f, 0.1f, 0.1f, 1.0f};
		//GLfloat pick_mat[] = {0.1f, 0.76f, 0.1f, 1.0f};
		GLfloat green[] = {0.3f, 1.0f, 0.3f, 1.0f};
		Vector3 z_axis(0.0, 0.0, 1.0);
		float arrow_radia = 0.25 * m_hvf_site_radii;
		float arrow_head_radia = 0.5 * m_hvf_site_radii;
		float arrow_head_len = arrow_head_radia * 2.0;
		float arrow_bar_len, vec_length;
		GLUquadric *pQuadric = gluNewQuadric();
		::glPushAttrib(GL_LIGHTING_BIT|GL_ENABLE_BIT|GL_CURRENT_BIT|GL_POLYGON_BIT);
		::glEnable(GL_LIGHTING);
		::glDisable(GL_CULL_FACE);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		::glColor4fv(green);
		for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++)
		{
			//if (it->first == m_pick_hvf_site) {
			//	::glColor4fv(pick_mat);
			//} else {
			//	::glColor4fv(vec_mat);
			//}
			Vector3 &vec = (it->second).first;
			vec_length = vec.magnitude(); 
			arrow_bar_len = vec_length - arrow_head_len;
			float rot_angle = Acos(vec.z/vec.magnitude());
			Vector3 rot_axis = z_axis.cross(vec);
			::glPushMatrix();
			::glTranslatef(VP(it->first)[0], VP(it->first)[1], VP(it->first)[2]);
			::glRotatef(rot_angle, rot_axis.x, rot_axis.y, rot_axis.z);
			::gluCylinder(pQuadric, arrow_radia, arrow_radia, arrow_bar_len, 6, 2);
			::glTranslatef(0.0f, 0.0f, arrow_bar_len);
			::gluCylinder(pQuadric, arrow_head_radia, 0.0, arrow_head_len, 8, 4);	// cone
			::glPopMatrix();
		}
		::glPopAttrib();
		gluDeleteQuadric(pQuadric);
	}

	void do_sampling_for_hvf_show(FT dR)
	{
		sample_vert(m_s_hvf_p, dR);
	}

	void gl_draw_hvf(void)
	{
		GLfloat vec_mat[] = {0.0f, 0.1f, 0.68f, 1.0f};
		::glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_HINT_BIT);
		::glDisable(GL_LIGHTING);
		::glDisable(GL_BLEND);
		::glColor3fv(vec_mat);
		// enable antialas
		if (m_s_hvf_p.empty())
		{
			::glPointSize(3.0);
			::glBegin(GL_POINTS);
			for (int i=0; i<size_of_vertices(); i++)
			{
				::glVertex3f(VP(i)[0], VP(i)[1], VP(i)[2]);
			}
			::glEnd();
			::glBegin(GL_LINES);
			for (int i=0; i<size_of_vertices(); i++)
			{
				::glVertex3f(VP(i)[0], VP(i)[1], VP(i)[2]);
				::glVertex3f(VP(i)[0] + m_s_vf[i].v[0],
					VP(i)[1] + m_s_vf[i].v[1],
					VP(i)[2] + m_s_vf[i].v[2]);
			}
			::glEnd();
		}
		else
		{
			for (int i=0; i<m_s_hvf_p.size(); i++) {
				glPushMatrix();
				glTranslatef(VP(m_s_hvf_p[i])[0], VP(m_s_hvf_p[i])[1], VP(m_s_hvf_p[i])[2]);
				glutSolidSphere(0.012f, 5, 5);
				glPopMatrix();
			}
			//glEnable(GL_LINE_SMOOTH);
			//glEnable(GL_BLEND);
			//glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
			glLineWidth(1.5);
			::glBegin(GL_LINES);
			for (int i=0; i<m_s_hvf_p.size(); i++)
			{
				::glVertex3f(VP(m_s_hvf_p[i])[0], VP(m_s_hvf_p[i])[1], VP(m_s_hvf_p[i])[2]);
				::glVertex3f(VP(m_s_hvf_p[i])[0] + m_s_vf[m_s_hvf_p[i]].v[0],
							 VP(m_s_hvf_p[i])[1] + m_s_vf[m_s_hvf_p[i]].v[1],
							 VP(m_s_hvf_p[i])[2] + m_s_vf[m_s_hvf_p[i]].v[2]);
			}
			::glEnd();
		}
		::glPopAttrib();
	}

	FT compute_avg_elen(const std::vector<int> &v)
	{	// compute average edge length in vertex set v
		std::map<int,int> vset;
		std::map<int,int>::iterator iV1, iV2;
		for (int i=0; i<v.size(); i++) {
			vset.insert(std::make_pair(v[i], 0));	// id - bIsHandled
		}
		Halfedge_around_vertex_circulator pHalfEdge, end;
		Vector edge;
		FT len = 0.0;
		int num = 0;
		for (iV1=vset.begin(); iV1!=vset.end(); iV1++)
		{
			pHalfEdge = end = VB(iV1->first);
			CGAL_For_all(pHalfEdge, end)
			{
				if ((iV2=vset.find(pHalfEdge->opposite()->vertex()->id())) != vset.end()) {
					if (iV2->second == 0) {
						const Point& p1 = pHalfEdge->vertex()->point();
						const Point& p2 = pHalfEdge->opposite()->vertex()->point();
						edge = p1 - p2;
						len += (FT)std::sqrt(edge*edge);
						num++;
					}
				}
			}
			iV1->second = 1;
		}
		return (len/(FT)num);
	}

	bool is_boundary_vert(const std::set<int> &pset, int v)
	{
		Halfedge_around_vertex_circulator pHalfEdge = VB(v);
		Halfedge_around_vertex_circulator end = pHalfEdge;
		CGAL_For_all(pHalfEdge, end)
		{
			if (pset.find(pHalfEdge->opposite()->vertex()->id()) == pset.end()) {
				return true;
			}
		}
		return false;
	}

	void sample_vert(const std::vector<int> &vIn, std::vector<int> &vOut, FT dR)
	{
		KD_tree STree;	// kd tree for all vertices
		std::map<Point,int> mVPToIndex;		// vertex point(pos) to index
		std::map<Point,int>::iterator iVPTI;
		for (int i=0; i<vIn.size(); i++) {
			STree.insert(VP(vIn[i]));
			mVPToIndex.insert(std::make_pair(VP(vIn[i]), i));
		}
		bool bChange = true;
		std::map<int, short> RM; // indices : removed(1)/processed(2) 
		std::map<int, short>::iterator iRM;
		std::vector<Point> FP;	// found points
		while (bChange)
		{
			bChange = false;
			for (int i=0; i<vIn.size(); i++)
			{
				if (RM.find(i) != RM.end())
				{ // found in RM, has been removed or processed
					continue;
				}
				FP.clear();
				Fuzzy_sphere fs(VP(vIn[i]), dR, 0.0);
				STree.search(std::back_inserter(FP), fs);
				for (int j=0; j<FP.size(); j++)
				{	// remove all vertices in fuzzy sphere fs
					if ((iVPTI=mVPToIndex.find(FP[j])) != mVPToIndex.end())
					{	// find the record of FP[i] to get its id
						if (iVPTI->second!=i && RM.find(iVPTI->second)==RM.end())
						{	// not yet been removed
							RM.insert(std::make_pair(iVPTI->second, 1));	// 1 for remove
							bChange = true;				// changing
						}
					}
				}
				RM.insert(std::make_pair(i, 2));	// 2 for process
			}
		}
		vOut.clear();
		// collect all the vertices left
		for (int i=0; i<vIn.size(); i++)
		{
			if ((iRM=RM.find(i)) != RM.end()) {
				if (iRM->second == 1) {	// removed
					continue;
				}
			}
			vOut.push_back(i);
		}
	}

	void sample_vert(std::vector<int> &vOut, FT dR)
	{	// from all the vertices of the current mesh
		KD_tree STree;	// kd tree for all vertices
		std::map<Point,int> mVPToIndex;		// vertex point(pos) to index
		std::map<Point,int>::iterator iVPTI;
		for (int i=0; i<size_of_vertices(); i++) {
			STree.insert(VP(i));
			mVPToIndex.insert(std::make_pair(VP(i), i));
		}
		bool bChange = true;
		std::map<int, short> RM; // indices : removed(1)/processed(2) 
		std::map<int, short>::iterator iRM;
		std::vector<Point> FP;	// found points
		while (bChange)
		{
			bChange = false;
			for (int i=0; i<size_of_vertices(); i++)
			{
				if (RM.find(i) != RM.end())
				{ // found in RM, has been removed or processed
					continue;
				}
				FP.clear();
				Fuzzy_sphere fs(VP(i), dR, 0.0);
				STree.search(std::back_inserter(FP), fs);
				for (int j=0; j<FP.size(); j++)
				{	// remove all vertices in fuzzy sphere fs
					if ((iVPTI=mVPToIndex.find(FP[j])) != mVPToIndex.end())
					{	// find the record of FP[i] to get its id
						if (iVPTI->second!=i && RM.find(iVPTI->second)==RM.end())
						{	// not yet been removed
							RM.insert(std::make_pair(iVPTI->second, 1));	// 1 for remove
							bChange = true;				// changing
						}
					}
				}
				RM.insert(std::make_pair(i, 2));	// 2 for process
			}
		}
		vOut.clear();
		// collect all the vertices left
		for (int i=0; i<size_of_vertices(); i++)
		{
			if ((iRM=RM.find(i)) != RM.end()) {
				if (iRM->second == 1) {	// removed
					continue;
				}
			}
			vOut.push_back(i);
		}
	}

	int read_s_hf(std::ifstream &stream)
	{
		Vertex_iterator pVertex;
		int	nb_vertices, nb_sites;
		std::string buf;
		stream >> buf;
		if (buf == "SHF")
		{
			stream >> buf >> nb_vertices;
			if (buf != "v") {
				MSG_BOX_ERROR("read_s_hf: error format!");
				return -1;
			}
			if (nb_vertices != size_of_vertices()) {
				MSG_BOX_ERROR("read_s_hf: number of vertices wrong!");
				return -1;
			}
			if (m_s_sf == NULL) {
				m_s_sf = new FT[size_of_vertices()];
			}
			int id; FT hfv;
			for (int i=0; i<nb_vertices; i++) {
				stream >> id >> hfv;
				// clamp harmonic values
				if (hfv > 1.0) {
					hfv = 1.0;
				} else if (hfv < 0.0) {
					hfv = 0.0;
				}
				m_s_sf[id] = hfv;
			}
			stream >> buf >> nb_sites;
			if (buf != "s") {
				MSG_BOX_ERROR("read_s_hf: error format!");
				return -1;
			}
			if (nb_sites<1) {
				MSG_BOX_ERROR("read_s_hf: number of sites wrong!");
				return -1;
			}
			m_sf_sites.clear();
			for (int i=0; i<nb_sites; i++) {
				int id, t;
				stream >> id >> t;
				m_sf_sites.insert(std::make_pair(id,std::make_pair(t,0)));
			}
			m_is_s_hf_utd = true;
			if (m_s_F != NULL) {
				cholmod_common c;
				cholmod_free_factor(&m_s_F, &c);
				m_s_F = NULL;
			}
			return 0;
		}
		MSG_BOX_ERROR("read_s_hf: error format!");
		return -1;
	}
	void write_s_hf(std::ofstream &stream)
	{
		Vertex_iterator pVertex;
		stream << "SHF" << std::endl;
		stream << "v " << size_of_vertices() << std::endl;
		for(int i=0; i<size_of_vertices(); i++) {
			stream << i << " " << m_s_sf[i] << std::endl;
		}
		stream << "s " << m_sf_sites.size() << std::endl;
		for (MAP_ISP::iterator it=m_sf_sites.begin(); it!=m_sf_sites.end(); it++) {
			if ((it->second).second == 0) {
				stream << it->first << " " << (it->second).first << std::endl;
			}
		}
	}
	int read_s_hvf(std::ifstream &stream)
	{
		Vertex_iterator pVertex;
		int	nb_vertices, nb_sites;
		std::string buf;
		stream >> buf;
		if (buf == "SHVF")
		{
			stream >> buf >> nb_vertices;
			if (buf != "v") {
				MSG_BOX_ERROR("read_s_hvf: error format!");
				return -1;
			}
			if (nb_vertices != size_of_vertices()) {
				MSG_BOX_ERROR("read_s_hvf: number of vertices wrong!");
				return -1;
			}
			if (m_s_vf == NULL) {
				m_s_vf = new Vector3 [size_of_vertices()];
			}
			int id; FT hfv;
			for (int i=0; i<nb_vertices; i++) {
				stream >> id;
				stream >> m_s_vf[id].x >> m_s_vf[id].y >> m_s_vf[id].z;
			}
			stream >> buf >> nb_sites;
			if (buf != "s") {
				MSG_BOX_ERROR("read_s_hvf: error format!");
				return -1;
			}
			if (nb_sites<1) {
				MSG_BOX_ERROR("read_s_hvf: number of sites wrong!");
				return -1;
			}
			m_hvf_sites.clear();
			for (int i=0; i<nb_sites; i++) {
				int id;
				Vector3 vec;
				stream >> id >> vec.x >> vec.y >> vec.z;
				m_hvf_sites.insert(std::make_pair(id,std::make_pair(vec,0)));
			}
			m_is_s_hvf_utd = true;
			if (m_s_hvf_F != NULL) {
				cholmod_common c;
				cholmod_free_factor(&m_s_hvf_F, &c);
				m_s_hvf_F = NULL;
			}
			return 0;
		}
		MSG_BOX_ERROR("read_s_hvf: error format!");
		return -1;
	}
	void write_s_hvf(std::ofstream &stream)
	{
		Vertex_iterator pVertex;
		stream << "SHVF" << std::endl;
		stream << "v " << size_of_vertices() << std::endl;
		for(int i=0; i<size_of_vertices(); i++) {
			stream << i << " " << m_s_vf[i].x << " " << m_s_vf[i].y << " " << m_s_vf[i].z << std::endl;
		}
		stream << "s " << m_hvf_sites.size() << std::endl;
		for (MAP_IVS::iterator it=m_hvf_sites.begin(); it!=m_hvf_sites.end(); it++) {
			if ((it->second).second == 0) {
				stream << it->first << " " << ((it->second).first).x << " "
					   << ((it->second).first).y << " " << ((it->second).first).z << std::endl;
			}
		}
	}

	void gl_draw_face_line(void)
	{
		::glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_LINE_BIT|GL_LIGHTING_BIT|GL_POLYGON_BIT);
		// wireframe
		::glDisable(GL_LIGHTING);
		::glColor3f(0.3f, 0.3f, 0.3f);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		::glLineWidth(1.0f);
		::glCallList(m_gl_display_list);
		// filled polygon
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		::glEnable(GL_LIGHTING);
		::glCallList(m_gl_display_list);
		::glPopAttrib();
	}

	void gl_build_display_list(bool smooth_shading, bool use_normals, bool use_texcoords)
	{
		if (::glIsList(m_gl_display_list)) {
			::glDeleteLists(m_gl_display_list, 1);
		}
		m_gl_display_list = ::glGenLists(1);
		::glNewList(m_gl_display_list, GL_COMPILE);
			gl_redraw(smooth_shading, use_normals, use_texcoords);
		::glEndList();
	}

	// draw	using	OpenGL commands	(display lists)
	void gl_redraw(bool smooth_shading, bool use_normals, bool use_texcoords)
	{
		// draw	polygons
		::glBegin(GL_TRIANGLES);
		for(Facet_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++)
		{
			gl_draw_facet(pFacet, smooth_shading, use_normals, use_texcoords);
		}
		::glEnd();
	}

	void gl_draw_facet(Facet_handle pFacet, bool smooth_shading, bool use_normals, bool use_texcoords)
	{
		// one normal per face
		if (use_normals && !smooth_shading)
		{
			const Facet::Normal_3& normal = pFacet->normal();
			glNormal3F(normal[0], normal[1], normal[2]);
		}

		// revolve around current face to get vertices
		Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
		do
		{
			// one normal per vertex
			if (use_normals && smooth_shading)
			{
				const Facet::Normal_3& normal = pHalfedge->vnormal();
				glNormal3F(normal[0], normal[1], normal[2]);
			}
			if (use_texcoords)
			{
				glTexCoord2Fv(pHalfedge->vertex()->texcoord());
			}
			// polygon assembly	is performed per vertex
			const Point& point = pHalfedge->vertex()->point();
			glVertex3F(point[0], point[1], point[2]);
		}
		while(++pHalfedge != pFacet->facet_begin());
	}

	//////////////////////////////////Begin of VBO///////////////////////////////////
	void gl_build_vbo(bool smooth_shading, bool use_normals, bool use_texcoords)
	{
		std::vector<FT> pos_array;
		std::vector<FT> norm_array;
		if (m_ibo_array == NULL) {
			m_ibo_array = new GLuint [3*size_of_facets()];
		}
		int fi, vi;
		Facet_iterator pFacet;
		tag_vertices(-1);
		m_vb_id.clear();
		m_vb_ia_id.clear();
		for(pFacet=facets_begin(), fi=0; pFacet!=facets_end(); pFacet++, fi++) {
			Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
			vi = 0;
			do {
				if (pHalfedge->vertex()->tag()==-1 || pHalfedge->vertex()->dup()==1) {
					const Point& point = pHalfedge->vertex()->point();
					pos_array.push_back(point[0]);
					pos_array.push_back(point[1]);
					pos_array.push_back(point[2]);
					const Facet::Normal_3& normal = pHalfedge->vnormal();
					norm_array.push_back(normal[0]);
					norm_array.push_back(normal[1]);
					norm_array.push_back(normal[2]);
					pHalfedge->vertex()->tag(m_vb_id.size());
					m_vb_id.push_back(pHalfedge->vertex()->id());
					m_vb_ia_id.push_back(3*fi+vi);
				}
				m_ibo_array[3*fi+vi] = pHalfedge->vertex()->tag();
				vi++;
			} while(++pHalfedge != pFacet->facet_begin());
		}

		// Load positions
		glGenBuffers(1, &m_gl_vbo_pos);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		int object_size = sizeof(FT) * 3 * m_vb_id.size();
		glBufferData(GL_ARRAY_BUFFER, object_size, NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, (FT*)(&(*pos_array.begin())));
		// Load normals
		glGenBuffers(1, &m_gl_vbo_norm);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glBufferData(GL_ARRAY_BUFFER, object_size, NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, (FT*)(&(*norm_array.begin())));
		// Load indices
		glGenBuffers(1, &m_gl_ibo);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		object_size = sizeof(GLuint) * 3 * size_of_facets();
		glBufferData(GL_ELEMENT_ARRAY_BUFFER_ARB, object_size, 0, GL_STATIC_DRAW);
		glBufferSubData(GL_ELEMENT_ARRAY_BUFFER_ARB, 0, object_size, m_ibo_array);
		// End of init
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	void gl_build_vbo_depth(GLdouble *modelview, GLdouble *proj, GLint *view)
	{
		std::vector<FT> pos_array;
		std::vector<FT> norm_array;
		if (m_ibo_array == NULL) {
			m_ibo_array = new GLuint [3*size_of_facets()];
		}
		Facet_iterator pFacet;
		std::vector<std::pair<FT,int>> Depth;
		GLdouble winx, winy, winz, winza;
		int fi, vi;
		for(pFacet=facets_begin(),fi=0; pFacet!=facets_end(); pFacet++,fi++) {
			Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
			winza=0.0; vi=0;
			do {
				const Point& point = pHalfedge->vertex()->point();
				gluProject(point[0], point[1], point[2], modelview, proj, view, &winx, &winy, &winz);
				winza += winz;
				vi++;
			} while(++pHalfedge != pFacet->facet_begin());
			Depth.push_back(std::make_pair((FT)winza/(FT)vi, fi));
		}
		std::sort(Depth.begin(), Depth.end(), std::greater<std::pair<FT,int>>());
		tag_vertices(-1);
		m_vb_id.clear();
		m_vb_ia_id.clear();
		for(fi=0; fi<Depth.size(); fi++) {
			Halfedge_around_facet_circulator pHalfedge = FB(Depth[fi].second);
			vi=0;
			do {
				if (pHalfedge->vertex()->tag()==-1 || pHalfedge->vertex()->dup()==1) {
					const Point& point = pHalfedge->vertex()->point();
					pos_array.push_back(point[0]);
					pos_array.push_back(point[1]);
					pos_array.push_back(point[2]);
					const Facet::Normal_3& normal = pHalfedge->vnormal();
					norm_array.push_back(normal[0]);
					norm_array.push_back(normal[1]);
					norm_array.push_back(normal[2]);
					pHalfedge->vertex()->tag(m_vb_id.size());
					m_vb_id.push_back(pHalfedge->vertex()->id());
					m_vb_ia_id.push_back(3*fi+vi);
				}
				m_ibo_array[3*fi+vi] = pHalfedge->vertex()->tag();
				vi++;
			} while(++pHalfedge != FB(Depth[fi].second));
		}

		// Load positions
		glGenBuffers(1, &m_gl_vbo_pos);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		int object_size = sizeof(FT) * 3 * m_vb_id.size();
		glBufferData(GL_ARRAY_BUFFER, object_size, NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, (FT*)(&(*pos_array.begin())));
		// Load normals
		glGenBuffers(1, &m_gl_vbo_norm);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glBufferData(GL_ARRAY_BUFFER, object_size, NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, (FT*)(&(*norm_array.begin())));
		// Load indices
		glGenBuffers(1, &m_gl_ibo);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		object_size = sizeof(GLuint) * 3 * size_of_facets();
		glBufferData(GL_ELEMENT_ARRAY_BUFFER_ARB, object_size, 0, GL_STATIC_DRAW);
		glBufferSubData(GL_ELEMENT_ARRAY_BUFFER_ARB, 0, object_size, m_ibo_array);
		// End of init
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	void gl_build_vbo_hv(FT *hf)
	{
		if (m_vb_id.empty()) {
			return;
		}
		FT *hv_array = new FT [m_vb_id.size()];
		for (int i=0; i<m_vb_id.size(); i++) {
			hv_array[i] = hf[m_vb_id[i]];
		}
		if (m_gl_vbo_hv == 0) {
			glGenBuffers(1, &m_gl_vbo_hv);
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_hv);
		int object_size = sizeof(FT) * m_vb_id.size();
		glBufferData(GL_ARRAY_BUFFER, object_size, hv_array, GL_STATIC_DRAW);
		// End of init
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		SAFE_DELETE_ARRAY(hv_array);
	}

	void gl_build_vbo_sf_color(CPseudoColorRGB &PC, FT *hf)
	{
		if (m_vb_id.empty()) {
			return;
		}
		// Build a color buffer for the current VBO
		PC.SetPCValueRange(0.0, 1.0);
		GLubyte *color_array = new GLubyte [3*m_vb_id.size()];
		for (int i=0; i<m_vb_id.size(); i++) {
			PC.GetPC(&color_array[3*i], hf[m_vb_id[i]]);
		}
		// Load colors
		if (m_gl_vbo_hf_color == 0) {
			glGenBuffers(1, &m_gl_vbo_hf_color);
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_hf_color);
		int object_size = sizeof(GLubyte) * 3 * m_vb_id.size();
		glBufferData(GL_ARRAY_BUFFER, object_size, color_array, GL_STATIC_DRAW);
		// End of init
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		SAFE_DELETE_ARRAY(color_array);
		m_is_built_sf_color_vbo = true;
	}

	void gl_build_vbo_sf_color(CPseudoColorRGB &PC, const std::vector<FT> &f)
	{
		if (m_vb_id.empty()) {
			return;
		}
		// Build a color buffer for the current VBO
		FT min = *(min_element(f.begin(), f.end()));
		FT max = *(max_element(f.begin(), f.end()));
		GLubyte *color_array = new GLubyte [3*m_vb_id.size()];
		if ((max-min) > std::numeric_limits<FT>::epsilon()) {
			FT scl = 1.0 / (max-min);
			for (int i=0; i<m_vb_id.size(); i++) {
				PC.GetPC(&color_array[3*i], (f[m_vb_id[i]]-min)*scl);
			}
		} else {
			memset(color_array, 0.0, 3*m_vb_id.size()*sizeof(FT));
		}
		// Load colors
		if (m_gl_vbo_hf_color == 0) {
			glGenBuffers(1, &m_gl_vbo_hf_color);
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_hf_color);
		int object_size = sizeof(GLubyte) * 3 * m_vb_id.size();
		glBufferData(GL_ARRAY_BUFFER, object_size, color_array, GL_STATIC_DRAW);
		// End of init
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		SAFE_DELETE_ARRAY(color_array);
		m_is_built_sf_color_vbo = true;
	}

	void gl_draw_hf_vbo(void)
	{
		::glPushAttrib(GL_ENABLE_BIT|GL_LIGHTING_BIT);
		::glEnable(GL_LIGHTING);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_hf_color);
		glColorPointer(3, GL_UNSIGNED_BYTE, 0, 0);
		glEnableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		::glPopAttrib();
	}

	void gl_draw_hf_vbo_fl(void)
	{
		::glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_LINE_BIT|GL_LIGHTING_BIT|GL_POLYGON_BIT);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);		
		// wireframe
		::glDisable(GL_LIGHTING);
		::glColor3ub(78, 78, 78);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		::glLineWidth(1.0f);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_hf_color);
		glColorPointer(3, GL_UNSIGNED_BYTE, 0, 0);
		glEnableClientState(GL_COLOR_ARRAY);
		// filled polygon
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		::glEnable(GL_LIGHTING);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		::glPopAttrib();
	}

	void gl_draw_cluster_vbo(void)
	{
		::glPushAttrib(GL_ENABLE_BIT|GL_LIGHTING_BIT);
		::glEnable(GL_LIGHTING);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_cluster_color);
		glColorPointer(3, GL_UNSIGNED_BYTE, 0, 0);
		glEnableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		::glPopAttrib();
	}

	void gl_draw_tex_vbo(void)
	{
		::glPushAttrib(GL_ENABLE_BIT|GL_LIGHTING_BIT);
		::glEnable(GL_LIGHTING);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_tex_color);
		glColorPointer(3, GL_UNSIGNED_BYTE, 0, 0);
		glEnableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		::glPopAttrib();
	}

	void gl_draw_mh_hf_vbo(bool hdl_metaphor)
	{
		::glPushAttrib(GL_ENABLE_BIT|GL_LIGHTING_BIT);
		::glEnable(GL_LIGHTING);
		::glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
		::glEnable(GL_COLOR_MATERIAL);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_hf_color);
		glColorPointer(3, GL_UNSIGNED_BYTE, 0, 0);
		glEnableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		if (hdl_metaphor)
		{
			glDisableClientState(GL_COLOR_ARRAY);
			for (int i=0; i<m_hdl_f.size(); i++)
			{
				if (i != m_curr_manip) {
					glColor3f(0.2f, 0.64f, 0.2f);
				} else {
					glColor3f(0.8f, 0.2f, 0.2f);
				}
				glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo_mf_hdl[i]);
				glDrawElements(GL_TRIANGLES, 3*m_hdl_f[i].size(), GL_UNSIGNED_INT, 0);
			}
		}
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		::glPopAttrib();
	}

	void gl_draw_vbo(void)
	{
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	void gl_draw_mh_vbo(bool hdl_metaphor)
	{
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		if (hdl_metaphor && !m_hdl_f.empty())
		{
			glPushAttrib(GL_ENABLE_BIT|GL_LIGHTING_BIT);
			glEnable(GL_LIGHTING);
			glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
			glEnable(GL_COLOR_MATERIAL);
			for (int i=0; i<m_hdl_f.size(); i++)
			{
				if (i != m_curr_manip) {
					glColor3f(0.2f, 0.64f, 0.2f);
				} else {
					glColor3f(0.8f, 0.2f, 0.2f);
				}
				glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo_mf_hdl[i]);
				glDrawElements(GL_TRIANGLES, 3*m_hdl_f[i].size(), GL_UNSIGNED_INT, 0);
			}
			glPopAttrib();
		}
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	void gl_build_hb_vbo_hf_color(CPseudoColorRGB &PC)
	{
		gl_build_vbo_sf_color(PC, m_hb_hf);
	}
	void gl_build_mh_vbo_hf_color(CPseudoColorRGB &PC)
	{
		if (m_curr_manip<0 || m_curr_manip>=m_mh_hf.size()) {
			return;
		}
		gl_build_vbo_sf_color(PC, m_mh_hf[m_curr_manip]);
	}
	void gl_build_sf_color(CPseudoColorRGB &PC)
	{
		if (m_is_s_hf_utd && m_sf_sites.size()>0) {
			gl_build_vbo_sf_color(PC, m_s_sf);
		}
	}
	void gl_build_hb_vbo_hv(void)
	{
		gl_build_vbo_hv(m_hb_hf);
	}
	void gl_build_mh_vbo_hv(void)
	{
		if (m_curr_manip<0 || m_curr_manip>=m_mh_hf.size()) {
			return;
		}
		gl_build_vbo_hv(m_mh_hf[m_curr_manip]);
	}
	GLuint get_vbo_hv(void)
	{
		return m_gl_vbo_hv;
	}

	void gl_mh_ibo_add(const std::list<Facet_handle> &flist)
	{	// must be called right after 'm_hdl_f.push_back(flist)'
		if (m_ibo_array == NULL) {
			return;
		}
		int num_facets = flist.size();
		GLuint *facet_array = new GLuint [3*num_facets];
		std::list<Facet_handle>::const_iterator pFacet;
		Halfedge_around_facet_circulator pHalfedge;
		int fi;
		for (pFacet=flist.begin(), fi=0; pFacet!=flist.end(); pFacet++, fi++)
		{
			// Revolve around current face to get vertices
			int i = (*pFacet)->facet_begin()->facet()->id();
			facet_array[3*fi+0] = m_ibo_array[3*i+0];
			facet_array[3*fi+1] = m_ibo_array[3*i+1];
			facet_array[3*fi+2] = m_ibo_array[3*i+2];
		}
		// Load indices
		GLuint bufobj;
		glGenBuffers(1, &bufobj);
		m_gl_ibo_mf_hdl.push_back(bufobj);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, bufobj);
		int object_size = sizeof(GLuint) * 3 * num_facets;
		glBufferData(GL_ELEMENT_ARRAY_BUFFER_ARB, object_size, 0, GL_STATIC_DRAW);
		glBufferSubData(GL_ELEMENT_ARRAY_BUFFER_ARB, 0, object_size, facet_array);
		// End of init
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
		// delete data
		SAFE_DELETE_ARRAY(facet_array);
	}
	void gl_mh_ibo_erase(int index)
	{	// must be called right after 'm_hdl_f.erase(m_hdl_f.begin()+m_hdl[(*pv)])'
		glDeleteBuffers(1, &m_gl_ibo_mf_hdl[index]);
		m_gl_ibo_mf_hdl.erase(m_gl_ibo_mf_hdl.begin()+index);
	}

	void gl_draw_vbo_face_line(void)
	{
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		glVertexPointer(3, GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_VERTEX_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		glNormalPointer(GL_TYPE<FT>::FLAG, 0, 0);
		glEnableClientState(GL_NORMAL_ARRAY);
		::glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_LINE_BIT|GL_LIGHTING_BIT|GL_POLYGON_BIT);
		// wireframe
		::glDisable(GL_LIGHTING);
		::glColor3ub(78, 78, 78);
		::glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		::glLineWidth(1.0f);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		// filled polygon
		::glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		::glEnable(GL_LIGHTING);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, m_gl_ibo);
		glDrawElements(GL_TRIANGLES, 3*size_of_facets(), GL_UNSIGNED_INT, 0);
		::glPopAttrib();
	}

	void update_vertices_from_bo(GLuint vbo_p, GLuint vbo_n)
	{
		if (m_vb_id.empty() || m_vb_ia_id.empty()) {
			return;
		}
		glBindBuffer(GL_ARRAY_BUFFER, vbo_p);
		float *vp = (float*)glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY);
		if (vp == NULL) {
			glUnmapBuffer(GL_ARRAY_BUFFER);
			return;
		}
		glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
		float *vn = (float*)glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY);
		if (vn == NULL) {
			glUnmapBuffer(GL_ARRAY_BUFFER);
			return;
		}
		FT *pos_array = new FT [3*m_vb_id.size()];
		FT *normal_array = new FT [3*m_vb_id.size()];
		int i0, i1, i2;
		for (int i=0; i<m_vb_id.size(); i++)
		{
			i0 = 3*m_vb_ia_id[i]+0;
			i1 = 3*m_vb_ia_id[i]+1;
			i2 = 3*m_vb_ia_id[i]+2;
			VP(m_vb_id[i]) = Point(vp[i0], vp[i1], vp[i2]);
			pos_array[3*i+0] = vp[i0];
			pos_array[3*i+1] = vp[i1];
			pos_array[3*i+2] = vp[i2];
			normal_array[3*i+0] = vn[i0];
			normal_array[3*i+1] = vn[i1];
			normal_array[3*i+2] = vn[i2];
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		int object_size = sizeof(FT) * 3 * m_vb_id.size();
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, pos_array);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_p);
		glUnmapBuffer(GL_ARRAY_BUFFER);
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		object_size = sizeof(FT) * 3 * m_vb_id.size();
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, normal_array);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
		glUnmapBuffer(GL_ARRAY_BUFFER);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		SAFE_DELETE_ARRAY(pos_array);
		SAFE_DELETE_ARRAY(normal_array);
	}

	void update_positions_vbo(GLuint buf_obj)
	{
		if (m_vb_id.empty() || m_vb_ia_id.empty()) {
			return;
		}
		glBindBuffer(GL_ARRAY_BUFFER, buf_obj);
		float *vd = (float*)glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY);
		if (vd == NULL) {
			glUnmapBuffer(GL_ARRAY_BUFFER);
			return;
		}
		FT *pos_array = new FT [3*m_vb_id.size()];
		for (int i=0; i<3*size_of_facets(); i++)
		{
			VP(m_vb_id[m_ibo_array[i]]) = Point(vd[3*i+0], vd[3*i+1], vd[3*i+2]);
			pos_array[3*m_ibo_array[i]+0] = vd[3*i+0];
			pos_array[3*m_ibo_array[i]+1] = vd[3*i+1];
			pos_array[3*m_ibo_array[i]+2] = vd[3*i+2];
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_pos);
		int object_size = sizeof(FT) * 3 * m_vb_id.size();
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, pos_array);
		glBindBuffer(GL_ARRAY_BUFFER, buf_obj);
		glUnmapBuffer(GL_ARRAY_BUFFER);
		glBindBuffer(0);
		SAFE_DELETE_ARRAY(pos_array);
	}
	void update_normals_vbo(GLuint buf_obj)
	{
		if (m_vb_id.empty() || m_vb_ia_id.empty()) {
			return;
		}
		glBindBuffer(GL_ARRAY_BUFFER, buf_obj);
		float *vd = (float*)glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY);
		if (vd == NULL) {
			glUnmapBuffer(GL_ARRAY_BUFFER);
			return;
		}
		FT *normal_array = new FT [3*m_vb_id.size()];
		for (int i=0; i<3*size_of_facets(); i++)
		{
			normal_array[3*m_ibo_array[i]+0] = vd[3*i+0];
			normal_array[3*m_ibo_array[i]+1] = vd[3*i+1];
			normal_array[3*m_ibo_array[i]+2] = vd[3*i+2];
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_gl_vbo_norm);
		int object_size = sizeof(FT) * 3 * m_vb_id.size();
		glBufferSubData(GL_ARRAY_BUFFER, 0, object_size, normal_array);
		glBindBuffer(GL_ARRAY_BUFFER, buf_obj);
		glUnmapBuffer(GL_ARRAY_BUFFER);
		glBindBuffer(0);
		SAFE_DELETE_ARRAY(normal_array);
	}
	//////////////////////////////////End of VBO/////////////////////////////////////

	// write in	obj	file format	(OBJ).
	void write_obj(char	*pFilename, int incr=1) //	1-based	by default
	{
		if (pFilename == NULL) {
			return;
		}
		std::ofstream	stream(pFilename);

		// output	vertices
		for (Point_iterator pPoint=points_begin(); pPoint!=points_end(); pPoint++) {
			stream <<'v'<<' '<<pPoint->x()<<' '<<pPoint->y()<<' '<<pPoint->z()<< std::endl;
		}

		// precompute	vertex indices
		if (!m_is_set_items_id) {
			set_hds_items_id();
		}

		// output	facets
		for(Facet_iterator pFacet	=	facets_begin();
				pFacet !=	facets_end();	
				pFacet++)	
		{
			stream <<	'f';
			Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
			do 
				stream <<	'	'	<< pHalfedge->vertex()->id()+incr;
			while(++pHalfedge	!= pFacet->facet_begin());
			stream <<	std::endl;
		}
	}

	// write in	ply2 file format
	void write_ply2(char *pFilename) //	1-based	by default
	{
		if (pFilename == NULL) {
			return;
		}
		std::ofstream stream(pFilename);
		
		stream <<size_of_vertices()<< std::endl <<size_of_facets()<< std::endl;
		// output vertices
		for (Point_iterator pPoint=points_begin(); pPoint!=points_end(); pPoint++) {
			stream <<pPoint->x()<<' '<<pPoint->y()<<' '<<pPoint->z()<< std::endl;
		}
		// precompute vertex indices
		if (!m_is_set_items_id) {
			set_hds_items_id();
		}
		// output facets
		for (Facet_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++)	
		{
			Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
			stream << CGAL::circulator_size(pHalfedge) << ' ' << pHalfedge->vertex()->id();
			while(++pHalfedge != pFacet->facet_begin()) {
				stream <<' '<<pHalfedge->vertex()->id();
			}
			stream << std::endl;
		}
	}

	void write_smf(char *pFilename) //	1-based	by default
	{
		if (pFilename == NULL) {
			return;
		}
		std::ofstream stream(pFilename);

		stream << "#$SMF 2.0" << std::endl;
		stream << "#$vertices " << size_of_vertices() << std::endl;
		stream << "#$faces " << size_of_facets() << std::endl;
		// output vertices
		for (Point_iterator pPoint=points_begin(); pPoint!=points_end(); pPoint++) {
			stream << "v " << pPoint->x() << ' ' << pPoint->y() << ' ' << pPoint->z() << std::endl;
		}
		// precompute vertex indices
		if (!m_is_set_items_id) {
			set_hds_items_id();
		}
		// output facets
		for (Facet_iterator pFacet=facets_begin(); pFacet!=facets_end(); pFacet++)	
		{
			Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
			stream << "f " << pHalfedge->vertex()->id()+1;
			while(++pHalfedge != pFacet->facet_begin()) {
				stream <<' '<< pHalfedge->vertex()->id()+1;
			}
			stream << std::endl;
		}
	}

	// draw bounding box
	void gl_draw_bounding_box1()
	{
		::glBegin(GL_LINES);
			// along x axis
			glVertex3F(m_min[0],m_min[1],m_min[2]);
			glVertex3F(m_max[0],m_min[1],m_min[2]);
			glVertex3F(m_min[0],m_min[1],m_max[2]);
			glVertex3F(m_max[0],m_min[1],m_max[2]);
			glVertex3F(m_min[0],m_max[1],m_min[2]);
			glVertex3F(m_max[0],m_max[1],m_min[2]);
			glVertex3F(m_min[0],m_max[1],m_max[2]);
			glVertex3F(m_max[0],m_max[1],m_max[2]);
			// along y axis
			glVertex3F(m_min[0],m_min[1],m_min[2]);
			glVertex3F(m_min[0],m_max[1],m_min[2]);
			glVertex3F(m_min[0],m_min[1],m_max[2]);
			glVertex3F(m_min[0],m_max[1],m_max[2]);
			glVertex3F(m_max[0],m_min[1],m_min[2]);
			glVertex3F(m_max[0],m_max[1],m_min[2]);
			glVertex3F(m_max[0],m_min[1],m_max[2]);
			glVertex3F(m_max[0],m_max[1],m_max[2]);
			// along z axis
			glVertex3F(m_min[0],m_min[1],m_min[2]);
			glVertex3F(m_min[0],m_min[1],m_max[2]);
			glVertex3F(m_min[0],m_max[1],m_min[2]);
			glVertex3F(m_min[0],m_max[1],m_max[2]);
			glVertex3F(m_max[0],m_min[1],m_min[2]);
			glVertex3F(m_max[0],m_min[1],m_max[2]);
			glVertex3F(m_max[0],m_max[1],m_min[2]);
			glVertex3F(m_max[0],m_max[1],m_max[2]);
		::glEnd();
	}

	// count #boundaries
	unsigned int nb_boundaries()
	{
		unsigned int nb = 0;
		tag_halfedges(0);
		Halfedge_handle	seed_halfedge	=	NULL;
		while((seed_halfedge = get_border_halfedge_tag(0)) !=	NULL)
		{
			nb++;
			seed_halfedge->tag(1);
			Vertex_handle	seed_vertex	= seed_halfedge->prev()->vertex();
			Halfedge_handle	current_halfedge = seed_halfedge;
			Halfedge_handle	next_halfedge;
			do
			{
				next_halfedge	=	current_halfedge->next();
				next_halfedge->tag(1);
				current_halfedge = next_halfedge;
			}
			while(next_halfedge->prev()->vertex()	!= seed_vertex);
		}
		return nb;
	}

	// get any border	halfedge with	tag
	Halfedge_handle	get_border_halfedge_tag(int	tag)
	{
		for(Halfedge_iterator pHalfedge	=	halfedges_begin();
				pHalfedge	!= halfedges_end();
				pHalfedge++)
			if(pHalfedge->is_border()	&&
				 pHalfedge->tag()	== tag)
				return pHalfedge;
		return NULL;
	}

	// get any facet with tag
	Facet_handle get_facet_tag(const int tag)
	{
		for (Facet_iterator pFace = facets_begin(); pFace != facets_end(); pFace++)
			if (pFace->tag() == tag)
				return pFace;
		return NULL;
	}

	// tag component 
	void tag_component(Facet_handle	pSeedFacet, const int tag_free, const int tag_done)
	{
		pSeedFacet->tag(tag_done);
		std::list<Facet_handle> facets;
		facets.push_front(pSeedFacet);
		while(!facets.empty())
		{
			Facet_handle pFacet = facets.front();
			facets.pop_front();
			pFacet->tag(tag_done);
			Halfedge_around_facet_circulator pHalfedge = pFacet->facet_begin();
			Halfedge_around_facet_circulator end = pHalfedge;
			CGAL_For_all(pHalfedge,end)
			{
				Facet_handle pNFacet = pHalfedge->opposite()->facet();
				if(pNFacet != NULL && pNFacet->tag() == tag_free)
				{
					facets.push_front(pNFacet);
					pNFacet->tag(tag_done);
				}
			}
		}
	}

	// count #components
	unsigned int nb_components()
	{
		unsigned int nb = 0;
		tag_facets(0);
		Facet_handle seed_facet = NULL;
		while((seed_facet = get_facet_tag(0)) != NULL)
		{
			nb++;
			tag_component(seed_facet,0,1);
		}
		return nb;
	}

	// compute the genus
	// V - E + F + B = 2 (C	- G)
	// C ->	#connected components
	// G : genus
	// B : #boundaries
	int	genus()
	{
		int	c	=	nb_components();
		int	b	=	nb_boundaries();
		int	v	=	size_of_vertices();
		int	e	=	size_of_halfedges()/2;
		int	f	=	size_of_facets();
		return genus(c,v,f,e,b);
	}
	int	genus(int c, int v, int f, int e, int b)
	{
		return (2*c+e-b-f-v)/2;
	}
};

template <class	kernel, class items>
class ROI_vertex
{
	typedef typename Enriched_polyhedron<kernel,items>::Vertex_handle Vertex_handle;
private:
	Vertex_handle	m_v;
	bool			m_border;
	
public:
	ROI_vertex()
	{
		m_v = 0;
		m_border = false;
	}
	ROI_vertex(Vertex_handle &v, bool b=false)
	{
		m_v = v;
		m_border = b;
	}
	Vertex_handle&	vertex() {return m_v;}
	void			set_vertex_handle(Vertex_handle &v) {m_v = v;}
	bool			is_border() {return m_border;}
	void			set_border(bool b) {m_border = b;}
};

// compute facet normal
template <class	Kernel, class Facet>
struct Facet_normal	// (functor)
{
	typedef typename Kernel::FT FT;
	typedef typename typename Facet::Halfedge_handle Halfedge_handle;
	typedef typename Facet::Normal_3 FNormal;
	void operator()(Facet& f)
	{
		FNormal sum = CGAL::NULL_VECTOR;
		Facet::Halfedge_around_facet_circulator h = f.facet_begin();
		do {
			FNormal normal	= CGAL::cross_product(
				h->next()->vertex()->point() - h->vertex()->point(),
				h->next()->next()->vertex()->point() - h->next()->vertex()->point());
			FT sqnorm = normal * normal;
			if(sqnorm != 0)
				normal = normal	/ (float)std::sqrt(sqnorm);
			sum = sum + normal;
		} while (++h != f.facet_begin());
		FT sqnorm = sum * sum;
		if (sqnorm != 0.0) {
			f.normal() = sum / std::sqrt(sqnorm);
		} else {
			f.normal() = CGAL::NULL_VECTOR;
			TRACE("degenerate face\n");
		}
	}
};

// compute facet normal	
template <class	Kernel, class Facet>
struct Facet_normal2	// (functor)
{
	typedef typename Kernel::FT FT;
	typedef typename typename Facet::Halfedge_handle Halfedge_handle;
	typedef typename Facet::Normal_3 FNormal;
	void operator()(Facet& f)
	{
		Halfedge_handle h = f.halfedge();
		if (h == NULL) {
			f.normal() = CGAL::NULL_VECTOR;
			return;
		}
		FNormal normal	= CGAL::cross_product(
				h->next()->vertex()->point() - h->vertex()->point(),
				h->next()->next()->vertex()->point() - h->next()->vertex()->point());
		FT sqnorm = normal * normal;
		if (sqnorm != 0.0) {
			f.normal() = normal	/ (float)std::sqrt(sqnorm);
		} else {
			f.normal() = CGAL::NULL_VECTOR;
			TRACE("degenerate face\n");
		}
	}
};

// compute vertex normal 
template <class	Kernel, class Vertex>
struct Vertex_normal //	(functor)
{
	typedef typename Kernel::FT FT;
	typedef typename Vertex::Normal Normal;
	void operator()(Vertex&	v)
	{
		Normal	normal = CGAL::NULL_VECTOR;
		Vertex::Halfedge_around_vertex_const_circulator	pHalfedge =	v.vertex_begin();
		Vertex::Halfedge_around_vertex_const_circulator	begin = pHalfedge;
		CGAL_For_all(pHalfedge,begin) {
			if(!pHalfedge->is_border()) {
				normal = normal	+ pHalfedge->facet()->normal();
			}
		}
		FT sqnorm = normal * normal;
		if (sqnorm != 0.0f) {
			v.normal() = normal	/ (float)std::sqrt(sqnorm);
		} else {
			v.normal() = CGAL::NULL_VECTOR;
		}
	}
};

// compute vertex normal for rendering
template <class	Kernel, class Vertex>
class HalfedgeVertex_normal //	(functor)
{
	typedef typename Kernel::FT FT;
	typedef typename Vertex::Halfedge_around_vertex_circulator HCirculator;
	typedef typename Vertex::Normal Normal;
private:
	FT m_threshold;
public:
	HalfedgeVertex_normal(FT angle) : m_threshold(Cos(angle)) {}
	void operator()(Vertex& v)
	{
		HCirculator pHalfedge =	v.vertex_begin();
		if (pHalfedge == NULL) {	// isolated vertex
			return;
		}
		HCirculator begin = pHalfedge;
		std::vector<HCirculator> ridge;
		FT max_cos = m_threshold;
		HCirculator pHEMax;
		Normal normal;
		// find ridge edges
		CGAL_For_all(pHalfedge, begin)
		{
			if (pHalfedge->is_border() || pHalfedge->opposite()->is_border()) {
				ridge.push_back(pHalfedge);
				continue;
			}
			FT cos_value = pHalfedge->facet()->normal() * pHalfedge->opposite()->facet()->normal();
			if (cos_value < m_threshold) {
				ridge.push_back(pHalfedge);
			} else if (cos_value >= max_cos) {
				max_cos = cos_value;
				pHEMax = pHalfedge;
			}
		}
		if (ridge.size() == 1) {
			ridge.push_back(pHEMax);
		}
		// no ridge edge, compute average of all faces
		if (ridge.size() == 0) {
			//normal = CGAL::NULL_VECTOR;
			//pHalfedge =	v.vertex_begin();
			//CGAL_For_all(pHalfedge, begin) {
			//	if(!pHalfedge->is_border()) {
			//		normal = normal + pHalfedge->facet()->normal();
			//	}
			//}
			//FT sqnorm = normal * normal;
			//if (sqnorm != 0.0f) {
			//	normal = normal / (FT)std::sqrt(sqnorm);
			//} else {
			//	normal = begin->facet()->normal();
			//}
			pHalfedge =	v.vertex_begin();
			CGAL_For_all(pHalfedge, begin) {
				if(!pHalfedge->is_border()) {
					//pHalfedge->vnormal() = normal;
					pHalfedge->vnormal() = v.normal();	// average normal has been computed
				}
			}
			v.dup(0);	// no ridge, no need to duplicate
			return;
		}
		// compute average in each group (divided by ridges)
		for (int i=0; i<ridge.size(); i++)
		{
			if (ridge[i]->is_border()) {
				continue;
			}
			normal = CGAL::NULL_VECTOR;
			pHalfedge =	ridge[i];
			CGAL_For_all(pHalfedge, ridge[(i+1)%ridge.size()]) {
				normal = normal + pHalfedge->facet()->normal();
			}
			FT sqnorm = normal * normal;
			if (sqnorm != 0.0f) {
				normal = normal / (FT)std::sqrt(sqnorm);
			} else {
				normal = ridge[i]->facet()->normal();
			}
			pHalfedge =	ridge[i];
			CGAL_For_all(pHalfedge, ridge[(i+1)%ridge.size()]) {
				pHalfedge->vnormal() = normal;
			}
		}
		v.dup(1);	// need to duplicate
	}
};

