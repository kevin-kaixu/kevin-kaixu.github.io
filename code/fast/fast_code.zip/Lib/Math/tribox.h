/********************************************************/
/* AABB-triangle overlap test code                      */
/* by Tomas Akenine-Mler                              */
/* Function: int triBoxOverlap(float boxcenter[3],      */
/*          float boxhalfsize[3],float triverts[3][3]); */
/* History:                                             */
/*   2001-03-05: released the code in its first version */
/*   2001-06-18: changed the order of the tests, faster */
/*                                                      */
/* Acknowledgment: Many thanks to Pierre Terdiman for  */
/* suggestions and discussions on how to optimize code. */
/* Thanks to David Hunt for finding a ">="-bug!         */
/********************************************************/
#pragma once

#include "mathlib.h"

int triBoxOverlap(double boxcenter[3], double boxhalfsize[3], double triverts[3][3]);
int triBoxOverlap(float boxcenter[3], float boxhalfsize[3], float triverts[3][3]);
BOOL triBoxOverlap(const double *boxcenter, const double *boxhalfsize, const double *triA, const double *triB, const double *triC);
BOOL triBoxOverlap(const float *boxcenter, const float *boxhalfsize, const float *triA, const float *triB, const float *triC);
