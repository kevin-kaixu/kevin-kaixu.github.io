// DlgHFVSampleSetting.cpp : implementation file
//

#include "stdafx.h"
#include "..\MeshStudio.h"
#include "DlgHFVSampleSetting.h"


// CDlgHFVSampleSetting dialog

IMPLEMENT_DYNAMIC(CDlgHFVSampleSetting, CDialog)

CDlgHFVSampleSetting::CDlgHFVSampleSetting(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgHFVSampleSetting::IDD, pParent)
	, m_fRadia(0.1)
{

}

CDlgHFVSampleSetting::~CDlgHFVSampleSetting()
{
}

void CDlgHFVSampleSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_SIMP_PERCENT, m_fRadia);
	DDV_MinMaxUInt(pDX, m_fRadia, 0.0, 100.0);
}


BEGIN_MESSAGE_MAP(CDlgHFVSampleSetting, CDialog)
END_MESSAGE_MAP()


// CDlgHFVSampleSetting message handlers
