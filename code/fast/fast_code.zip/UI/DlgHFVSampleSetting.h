#pragma once


// CDlgHFVSampleSetting dialog

class CDlgHFVSampleSetting : public CDialog
{
	DECLARE_DYNAMIC(CDlgHFVSampleSetting)

public:
	CDlgHFVSampleSetting(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgHFVSampleSetting();

	float m_fRadia;

// Dialog Data
	enum { IDD = IDD_DLG_HFV_SAMPLE_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
