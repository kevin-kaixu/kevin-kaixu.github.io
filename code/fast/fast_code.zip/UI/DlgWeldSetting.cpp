// DlgWeldSetting.cpp : implementation file
//

#include "stdafx.h"
#include "..\MeshStudio.h"
#include "DlgWeldSetting.h"


// CDlgWeldSetting dialog

IMPLEMENT_DYNAMIC(CDlgWeldSetting, CDialog)

CDlgWeldSetting::CDlgWeldSetting(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgWeldSetting::IDD, pParent)
{
	m_dWeldTRate = 3.0;
}

CDlgWeldSetting::~CDlgWeldSetting()
{
}

void CDlgWeldSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_WELD_T, m_dWeldTRate);
	DDV_MinMaxUInt(pDX, m_dWeldTRate, 0.00001, 100.0);
}


BEGIN_MESSAGE_MAP(CDlgWeldSetting, CDialog)
END_MESSAGE_MAP()


// CDlgWeldSetting message handlers
