// DlgCrestParam.cpp : implementation file
//

#include "stdafx.h"
#include "../MeshStudio.h"
#include "DlgCrestParam.h"
#include "DlgWeldSetting.h"


// CDlgCrestParam dialog

IMPLEMENT_DYNAMIC(CDlgCrestParam, CDialog)

CDlgCrestParam::CDlgCrestParam(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCrestParam::IDD, pParent)
{
	m_pView = NULL;
	R_MIN = 0.0;
	R_MAX = R_H_MAX = 10.0;
	R_L_MAX = R_MAX / 10.0;
	S_MIN = 0.0;
	S_MAX = S_H_MAX = 10.0;
	S_L_MAX = S_MAX / 10.0;
	C_MIN = 0.0;
	C_MAX = C_H_MAX = 10.0;
	C_L_MAX = C_MAX / 10.0;
	L_MIN = 0.0;
	L_MAX = L_H_MAX = 10.0;
	L_L_MAX = L_MAX / 10.0;
	m_bShowHVF = TRUE;
	m_bAmpLowR = FALSE;
	m_bAmpLowS = FALSE;
	m_bAmpLowC = FALSE;
	m_bAmpLowL = FALSE;
	m_bShowDir = TRUE;
	m_bShowEpDir = FALSE;
	m_bFilterConvex = FALSE;
	m_bFilterConcave = FALSE;
}

CDlgCrestParam::CDlgCrestParam(CMeshStudioView *pView)
{
	m_pView = pView;
	R_MIN = 0.0;
	R_MAX = R_H_MAX = 10.0;
	R_L_MAX = R_MAX / 10.0;
	S_MIN = 0.0;
	S_MAX = S_H_MAX = 10.0;
	S_L_MAX = S_MAX / 10.0;
	C_MIN = 0.0;
	C_MAX = C_H_MAX = 10.0;
	C_L_MAX = C_MAX / 10.0;
	L_MIN = 0.0;
	L_MAX = L_H_MAX = 10.0;
	L_L_MAX = L_MAX / 10.0;
	m_bShowHVF = TRUE;
	m_bAmpLowR = FALSE;
	m_bAmpLowS = FALSE;
	m_bAmpLowC = FALSE;
	m_bAmpLowL = FALSE;
	m_bShowDir = TRUE;
	m_bShowEpDir = FALSE;
	m_bFilterConvex = FALSE;
	m_bFilterConcave = FALSE;
}

CDlgCrestParam::~CDlgCrestParam()
{
}

void CDlgCrestParam::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER_R, m_sliderR);
	DDX_Control(pDX, IDC_SLIDER_S, m_sliderS);
	DDX_Control(pDX, IDC_SLIDER_C, m_sliderC);
	DDX_Control(pDX, IDC_SLIDER_L, m_sliderL);
	DDX_Control(pDX, IDC_CHECK_SHOW_HVF, m_checkShowHVF);
	DDX_Control(pDX, IDC_HFV_SAMPLE, m_btnSampleHVF);
	DDX_Check(pDX, IDC_CHECK_SHOW_HVF, m_bShowHVF);
	DDX_Check(pDX, IDC_CHECK_SHOW_DIR, m_bShowDir);
	DDX_Check(pDX, IDC_CHECK_SHOW_EP_DIR, m_bShowEpDir);
	DDX_Check(pDX, IDC_CHECK_AMP_LOW_R, m_bAmpLowR);
	DDX_Check(pDX, IDC_CHECK_AMP_LOW_S, m_bAmpLowS);
	DDX_Check(pDX, IDC_CHECK_AMP_LOW_C, m_bAmpLowC);
	DDX_Check(pDX, IDC_CHECK_AMP_LOW_L, m_bAmpLowL);
	DDX_Check(pDX, IDC_CHECK_FILTER_CONVEX, m_bFilterConvex);
	DDX_Check(pDX, IDC_CHECK_FILTER_CONCAVE, m_bFilterConcave);
}

BOOL CDlgCrestParam::Create(void)
{
	return CDialog::Create(CDlgCrestParam::IDD);
}

CMeshStudioView* CDlgCrestParam::GetMainView(void)
{
	CMeshStudioApp *pApp = (CMeshStudioApp*)AfxGetApp();
	CMainFrame *pMainFrame = (CMainFrame*)pApp->m_pMainWnd;
	CChildFrame *pFrame = (CChildFrame*)pMainFrame->GetActiveFrame();
	return (CMeshStudioView*)pFrame->m_wndSplitter.GetPane(0, 0);
}

void CDlgCrestParam::UpdateCrestFiltering(void)
{
	if (m_pView == NULL) {
		m_pView = GetMainView();
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	pDoc->m_pCrestline->filter_crestlines();
	if (pDoc->m_pMesh->is_s_hvf_uptodate() && m_bShowHVF) {
		pDoc->m_pCrestline->compute_site_vectors();
		pDoc->m_pMesh->compute_s_hvf();
	}
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::UpdateRT(void)
{
	if (m_pView == NULL) {
		m_pView = GetMainView();
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	FTP sigma = (FTP)m_sliderR.GetPos()/1000.0;
	CString str;
	FTP value = R_MIN+sigma*(R_MAX-R_MIN);
	str.Format("Ridgeness threshold: %.3f", value);
	SetDlgItemText(IDC_STATIC_R, str);
	pDoc->m_pCrestline->SetTRidgeness(value);
}

void CDlgCrestParam::UpdateLT(void)
{
	if (m_pView == NULL) {
		m_pView = GetMainView();
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	FTP sigma = (FTP)m_sliderL.GetPos()/1000.0;
	CString str;
	FTP value = L_MIN+sigma*(L_MAX-L_MIN);
	str.Format("Length threshold: %.3f", value);
	SetDlgItemText(IDC_STATIC_L, str);
	pDoc->m_pCrestline->SetTLength(value);
}

void CDlgCrestParam::UpdateST(void)
{
	if (m_pView == NULL) {
		m_pView = GetMainView();
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	FTP sigma = (FTP)m_sliderS.GetPos()/1000.0;
	CString str;
	FTP value = S_MIN+sigma*(S_MAX-S_MIN);
	str.Format("Sphericalness threshold: %.3f", value);
	SetDlgItemText(IDC_STATIC_S, str);
	pDoc->m_pCrestline->SetTSphericalness(value);
}

void CDlgCrestParam::UpdateCT(void)
{
	if (m_pView == NULL) {
		m_pView = GetMainView();
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	FTP sigma = (FTP)m_sliderC.GetPos()/1000.0;
	CString str;
	FTP value = C_MIN+sigma*(C_MAX-C_MIN);
	str.Format("Cylindeness threshold: %.3f", value);
	SetDlgItemText(IDC_STATIC_C, str);
	pDoc->m_pCrestline->SetTCyclideness(value);
}

BEGIN_MESSAGE_MAP(CDlgCrestParam, CDialog)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_HVF_COMPUTE, &CDlgCrestParam::OnBnClickedVFComp)
	ON_BN_CLICKED(IDC_DIR_OPT, &CDlgCrestParam::OnBnClickedOptOrien)
	ON_BN_CLICKED(IDC_CHECK_FILTER_CONVEX, &CDlgCrestParam::OnBnClickedCheckFilterConvex)
	ON_BN_CLICKED(IDC_CHECK_FILTER_CONCAVE, &CDlgCrestParam::OnBnClickedCheckFilterConcave)
	ON_BN_CLICKED(IDC_CHECK_SHOW_HVF, &CDlgCrestParam::OnBnClickedCheckShowHVF)
	ON_BN_CLICKED(IDC_CHECK_SHOW_DIR, &CDlgCrestParam::OnBnClickedCheckShowDir)
	ON_BN_CLICKED(IDC_CHECK_SHOW_EP_DIR, &CDlgCrestParam::OnBnClickedCheckShowEpDir)
	ON_BN_CLICKED(IDC_CHECK_AMP_LOW_R, &CDlgCrestParam::OnBnClickedCheckAmpLowRT)
	ON_BN_CLICKED(IDC_CHECK_AMP_LOW_S, &CDlgCrestParam::OnBnClickedCheckAmpLowST)
	ON_BN_CLICKED(IDC_CHECK_AMP_LOW_C, &CDlgCrestParam::OnBnClickedCheckAmpLowCT)
	ON_BN_CLICKED(IDC_CHECK_AMP_LOW_L, &CDlgCrestParam::OnBnClickedCheckAmpLowLT)
	ON_BN_CLICKED(IDC_SAVE_CREST, &CDlgCrestParam::OnBnClickedSaveLines)
	ON_BN_CLICKED(IDC_SAVE_VF, &CDlgCrestParam::OnBnClickedSaveVF)
	ON_BN_CLICKED(IDC_HFV_SAMPLE, &CDlgCrestParam::OnBnClickedSampleVF)
	ON_BN_CLICKED(IDC_PICK_LINE, &CDlgCrestParam::OnBnClickedPickLine)
	ON_BN_CLICKED(IDC_REMOVE_LP, &CDlgCrestParam::OnBnClickedRemoveLPoint)
	ON_BN_CLICKED(IDC_FILTER_PICK, &CDlgCrestParam::OnBnClickedFilterPick)
	ON_BN_CLICKED(IDC_BREAK_PICK, &CDlgCrestParam::OnBnClickedBreakPick)
	ON_BN_CLICKED(IDC_LINK_PICK, &CDlgCrestParam::OnBnClickedLinkPick)
	ON_BN_CLICKED(IDC_WELD_LINES, &CDlgCrestParam::OnBnClickedWeldLines)
END_MESSAGE_MAP()


// CDlgCrestParam message handlers
BOOL CDlgCrestParam::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if (m_pView == NULL) {
		m_pView = GetMainView();
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return TRUE;
	}

	R_MIN = pDoc->m_pCrestline->GetMinRidgeness();
	R_MAX = R_H_MAX = pDoc->m_pCrestline->GetMaxRidgeness();
	R_L_MAX = R_MAX / 10.0;
	S_MIN = pDoc->m_pCrestline->GetMinSphericalness();
	S_MAX = S_H_MAX = pDoc->m_pCrestline->GetMaxSphericalness();
	S_L_MAX = S_MAX / 10.0;
	C_MIN = pDoc->m_pCrestline->GetMinCyclideness();
	C_MAX = C_H_MAX = pDoc->m_pCrestline->GetMaxCyclideness();
	C_L_MAX = C_MAX / 10.0;
	L_MIN = pDoc->m_pCrestline->GetMinLength();
	L_MAX = L_H_MAX = pDoc->m_pCrestline->GetMaxLength();
	L_L_MAX = L_MAX / 10.0;

	m_bShowHVF = (m_pView->m_ShowHVF!=HVFS_NONE);
	m_checkShowHVF.SetCheck(m_pView->m_ShowHVF!=HVFS_NONE);
	m_checkShowHVF.EnableWindow(FALSE);
	m_btnSampleHVF.EnableWindow(m_bShowHVF);
	m_bAmpLowR = FALSE;
	m_bAmpLowS = FALSE;
	m_bAmpLowC = FALSE;
	m_bShowDir = pDoc->m_pCrestline->GetShowDir();
	m_bShowEpDir = pDoc->m_pCrestline->GetShowEpDir();

	CString str;
	str.Format("Ridgeness threshold: 0.0");
	SetDlgItemText(IDC_STATIC_R, str);
	str.Format("Sphericalness threshold: 0.0");
	SetDlgItemText(IDC_STATIC_S, str);
	str.Format("Cylindeness threshold: 0.0");
	SetDlgItemText(IDC_STATIC_C, str);
	str.Format("Length threshold: 0.0");
	SetDlgItemText(IDC_STATIC_L, str);

	m_sliderR.SetRange(0, 1000, TRUE);
	m_sliderR.SetPos(0);
	m_sliderR.EnableWindow(TRUE);
	m_sliderS.SetRange(0, 1000, TRUE);
	m_sliderS.SetPos(0);
	m_sliderS.EnableWindow(TRUE);
	m_sliderC.SetRange(0, 1000, TRUE);
	m_sliderC.SetPos(0);
	m_sliderC.EnableWindow(TRUE);
	m_sliderL.SetRange(0, 1000, TRUE);
	m_sliderL.SetPos(0);
	m_sliderL.EnableWindow(TRUE);

	SetWindowPos(NULL, 36, 70, 290, 590, SWP_SHOWWINDOW);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCrestParam::UpdateSliderPos()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	bool bUpdateFilter = false;
	FTP sigma = (FTP)m_sliderR.GetPos()/1000.0;
	FTP dValue = R_MIN+sigma*(R_MAX-R_MIN);
	R_MIN = pDoc->m_pCrestline->GetMinRidgeness();
	R_MAX = R_H_MAX = pDoc->m_pCrestline->GetMaxRidgeness();
	R_L_MAX = R_MAX / 10.0;
	R_MAX = m_bAmpLowR ? R_L_MAX : R_MAX;
	if (dValue > R_MAX) {
		m_sliderR.SetPos(1000);
		pDoc->m_pCrestline->SetTRidgeness(R_MAX);
		bUpdateFilter = true;
	} else if (dValue < R_MIN) {
		m_sliderR.SetPos(0);
		pDoc->m_pCrestline->SetTRidgeness(R_MIN);
		bUpdateFilter = true;
	} else {
		m_sliderR.SetPos((int)((dValue-R_MIN)/(R_MAX-R_MIN)*1000.0));
	}
	//////////////////////////////////////////////////////////////////////////
	sigma = (FTP)m_sliderS.GetPos()/1000.0;
	dValue = S_MIN+sigma*(S_MAX-S_MIN);
	S_MIN = pDoc->m_pCrestline->GetMinSphericalness();
	S_MAX = S_H_MAX = pDoc->m_pCrestline->GetMaxSphericalness();
	S_L_MAX = S_MAX / 10.0;
	S_MAX = m_bAmpLowS ? S_L_MAX : S_MAX;
	if (dValue > S_MAX) {
		m_sliderS.SetPos(1000);
		pDoc->m_pCrestline->SetTSphericalness(S_MAX);
		bUpdateFilter = true;
	} else if (dValue < S_MIN) {
		m_sliderS.SetPos(0);
		pDoc->m_pCrestline->SetTSphericalness(S_MIN);
		bUpdateFilter = true;
	} else {
		m_sliderS.SetPos((int)((dValue-S_MIN)/(S_MAX-S_MIN)*1000.0));
	}
	//////////////////////////////////////////////////////////////////////////
	sigma = (FTP)m_sliderC.GetPos()/1000.0;
	dValue = C_MIN+sigma*(C_MAX-C_MIN);
	C_MIN = pDoc->m_pCrestline->GetMinCyclideness();
	C_MAX = C_H_MAX = pDoc->m_pCrestline->GetMaxCyclideness();
	C_L_MAX = C_MAX / 10.0;
	C_MAX = m_bAmpLowC ? C_L_MAX : C_MAX;
	if (dValue > C_MAX) {
		m_sliderC.SetPos(1000);
		pDoc->m_pCrestline->SetTCyclideness(C_MAX);
		bUpdateFilter = true;
	} else if (dValue < C_MIN) {
		m_sliderC.SetPos(0);
		pDoc->m_pCrestline->SetTCyclideness(C_MIN);
		bUpdateFilter = true;
	} else {
		m_sliderC.SetPos((int)((dValue-C_MIN)/(C_MAX-C_MIN)*1000.0));
	}
	//////////////////////////////////////////////////////////////////////////
	sigma = (FTP)m_sliderL.GetPos()/1000.0;
	dValue = L_MIN+sigma*(L_MAX-L_MIN);
	L_MIN = pDoc->m_pCrestline->GetMinLength();
	L_MAX = L_H_MAX = pDoc->m_pCrestline->GetMaxLength();
	L_L_MAX = L_MAX / 10.0;
	L_MAX = m_bAmpLowL ? L_L_MAX : L_MAX;
	if (dValue > L_MAX) {
		m_sliderL.SetPos(1000);
		pDoc->m_pCrestline->SetTLength(L_MAX);
		bUpdateFilter = true;
	} else if (dValue < L_MIN) {
		m_sliderL.SetPos(0);
		pDoc->m_pCrestline->SetTLength(L_MIN);
		bUpdateFilter = true;
	} else {
		m_sliderL.SetPos((int)((dValue-L_MIN)/(L_MAX-L_MIN)*1000.0));
	}
	if (bUpdateFilter) {
		UpdateCrestFiltering();
		m_pView->InvalidateRect(NULL, FALSE);
	}
}

void CDlgCrestParam::OnOK()
{
	// TODO: Add extra validation here
	if (m_pView != NULL) {	// non-modal
		UpdateData(TRUE);
		m_pView->PostMessage(WM_DLG_CREST_PARAM_OK, IDOK);
	} else {
		CDialog::OnOK();
	}
}

void CDlgCrestParam::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	CWnd *pFocusWnd = GetFocus();
	switch(nSBCode)
	{
	case TB_BOTTOM:
	case TB_ENDTRACK:
	case TB_LINEDOWN:
	case TB_LINEUP:
	case TB_PAGEDOWN:
	case TB_PAGEUP:
	case TB_THUMBPOSITION:
	case TB_THUMBTRACK:
	case TB_TOP:
		if (&m_sliderR == pFocusWnd) {
			UpdateRT();
			UpdateCrestFiltering();
		} else if (&m_sliderS == pFocusWnd) {
			UpdateST();
			UpdateCrestFiltering();
		} else if (&m_sliderC == pFocusWnd) {
			UpdateCT();
			UpdateCrestFiltering();
		} else if (&m_sliderL == pFocusWnd) {
			UpdateLT();
			UpdateCrestFiltering();
		}
		break;
	default:
		break;
	}
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CDlgCrestParam::OnBnClickedVFComp()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	BeginWaitCursor();
	pDoc->StatusMessage("Computing vector field constrained by curves...");
	double start = clock();
	if (pDoc->m_pCrestline->site_vectors_empty()) {
		pDoc->m_pCrestline->compute_site_vectors();
	}
	pDoc->m_pMesh->compute_s_hvf();
	double duration = (double)((clock()-start)/CLOCKS_PER_SEC);
	pDoc->StatusMessage("Computing vector field constrained by curves... done! (%g s)", duration);
	EndWaitCursor();
	m_checkShowHVF.EnableWindow(TRUE);
	m_bShowHVF = TRUE;
	m_pView->m_ShowHVF = HVFS_SIMPLE;
	m_checkShowHVF.SetCheck(m_bShowHVF);
	m_btnSampleHVF.EnableWindow(m_bShowHVF);
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedOptOrien()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	BeginWaitCursor();
	pDoc->StatusMessage("Optimizing curve orientations...");
	double start = clock();
	pDoc->m_pCrestline->compute_optimal_orien();
	double duration = (double)((clock()-start)/CLOCKS_PER_SEC);
	pDoc->StatusMessage("Optimizing curve orientations... done! (%g s)", duration);
	EndWaitCursor();
	m_checkShowHVF.EnableWindow(TRUE);
	m_bShowHVF = TRUE;
	m_pView->m_ShowHVF = HVFS_SIMPLE;
	m_checkShowHVF.SetCheck(m_bShowHVF);
	m_btnSampleHVF.EnableWindow(m_bShowHVF);
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedSaveVF()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	pDoc->OnSaveSiteHVF();
}

void CDlgCrestParam::OnBnClickedSampleVF()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	pDoc->OnHVFSample();
}

void CDlgCrestParam::OnBnClickedSaveLines()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline == NULL) {
		return;
	}
	CString sFilename;
	CFileDialog *cfdSave;
	static char BASED_CODE szFilter[] = "Ridges (*.ccl)|*.ccl|All Files (*.*)|*.*||";
	cfdSave = new CFileDialog(FALSE, "ccl", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSave->m_ofn.lpstrTitle = "Save crest lines";
	if (cfdSave->DoModal() == IDOK)
	{
		sFilename = cfdSave->GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ofstream stream(sFilename);
			if (!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
			} else {
				BeginWaitCursor();
				pDoc->m_pCrestline->write_cleaned_crestlines(stream);
				EndWaitCursor();
			}
		}
	}
}

void CDlgCrestParam::OnBnClickedCheckFilterConvex()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	m_bFilterConvex = !m_bFilterConvex;
	if (m_bFilterConvex) {
		pDoc->m_pCrestline->filter_convex();
	} else {
		pDoc->m_pCrestline->unfilter_convex();
	}
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedCheckFilterConcave()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	m_bFilterConcave = !m_bFilterConcave;
	if (m_bFilterConcave) {
		pDoc->m_pCrestline->filter_concave();
	} else {
		pDoc->m_pCrestline->unfilter_concave();
	}
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedCheckShowHVF()
{
	// TODO: Add your control notification handler code here
	m_bShowHVF = !m_bShowHVF;
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (m_bShowHVF) {
		m_pView->m_ShowHVF = HVFS_SIMPLE;
	} else {
		m_pView->m_ShowHVF = HVFS_NONE;
	}
	m_btnSampleHVF.EnableWindow(m_bShowHVF);
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedCheckShowDir()
{
	// TODO: Add your control notification handler code here
	m_bShowDir = !m_bShowDir;
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	pDoc->m_pCrestline->SetShowDir(m_bShowDir);
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedCheckShowEpDir()
{
	// TODO: Add your control notification handler code here
	m_bShowEpDir = !m_bShowEpDir;
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	pDoc->m_pCrestline->SetShowEpDir(m_bShowEpDir);
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedCheckAmpLowRT()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	m_bAmpLowR = !m_bAmpLowR;
	if (m_bAmpLowR) {
		FTP sigma = (FTP)m_sliderR.GetPos()/1000.0;
		FTP dValue = R_MIN+sigma*(R_MAX-R_MIN);
		R_MAX = R_L_MAX;
		if (dValue > R_MAX) {
			m_sliderR.SetPos(1000);
			pDoc->m_pCrestline->SetTRidgeness(R_MAX);
			UpdateCrestFiltering();
			m_pView->InvalidateRect(NULL, FALSE);
		} else {
			m_sliderR.SetPos((int)((dValue-R_MIN)/(R_MAX-R_MIN)*1000.0));
		}
	} else {
		FTP sigma = (FTP)m_sliderR.GetPos()/1000.0;
		FTP dValue = R_MIN+sigma*(R_MAX-R_MIN);
		R_MAX = R_H_MAX;
		m_sliderR.SetPos((int)((dValue-R_MIN)/(R_MAX-R_MIN)*1000.0));
	}
}

void CDlgCrestParam::OnBnClickedCheckAmpLowLT()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	m_bAmpLowL = !m_bAmpLowL;
	if (m_bAmpLowL) {
		FTP sigma = (FTP)m_sliderL.GetPos()/1000.0;
		FTP dValue = L_MIN+sigma*(L_MAX-L_MIN);
		L_MAX = L_L_MAX;
		if (dValue > L_MAX) {
			m_sliderL.SetPos(1000);
			pDoc->m_pCrestline->SetTRidgeness(L_MAX);
			UpdateCrestFiltering();
			m_pView->InvalidateRect(NULL, FALSE);
		} else {
			m_sliderL.SetPos((int)((dValue-L_MIN)/(L_MAX-L_MIN)*1000.0));
		}
	} else {
		FTP sigma = (FTP)m_sliderL.GetPos()/1000.0;
		FTP dValue = L_MIN+sigma*(L_MAX-L_MIN);
		L_MAX = L_H_MAX;
		m_sliderL.SetPos((int)((dValue-L_MIN)/(L_MAX-L_MIN)*1000.0));
	}
}

void CDlgCrestParam::OnBnClickedCheckAmpLowST()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	m_bAmpLowS = !m_bAmpLowS;
	if (m_bAmpLowS) {
		FTP sigma = (FTP)m_sliderS.GetPos()/1000.0;
		FTP dValue = S_MIN+sigma*(S_MAX-S_MIN);
		S_MAX = S_L_MAX;
		if (dValue > S_MAX) {
			m_sliderS.SetPos(1000);
			pDoc->m_pCrestline->SetTRidgeness(S_MAX);
			UpdateCrestFiltering();
			m_pView->InvalidateRect(NULL, FALSE);
		} else {
			m_sliderS.SetPos((int)((dValue-S_MIN)/(S_MAX-S_MIN)*1000.0));
		}
	} else {
		FTP sigma = (FTP)m_sliderS.GetPos()/1000.0;
		FTP dValue = S_MIN+sigma*(S_MAX-S_MIN);
		S_MAX = S_H_MAX;
		m_sliderS.SetPos((int)((dValue-S_MIN)/(S_MAX-S_MIN)*1000.0));
	}
}

void CDlgCrestParam::OnBnClickedCheckAmpLowCT()
{
	// TODO: Add your control notification handler code here
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	m_bAmpLowC = !m_bAmpLowC;
	if (m_bAmpLowC) {
		FTP sigma = (FTP)m_sliderC.GetPos()/1000.0;
		FTP dValue = C_MIN+sigma*(C_MAX-C_MIN);
		C_MAX = C_L_MAX;
		if (dValue > C_MAX) {
			m_sliderC.SetPos(1000);
			pDoc->m_pCrestline->SetTRidgeness(C_MAX);
			UpdateCrestFiltering();
			m_pView->InvalidateRect(NULL, FALSE);
		} else {
			m_sliderC.SetPos((int)((dValue-C_MIN)/(C_MAX-C_MIN)*1000.0));
		}
	} else {
		FTP sigma = (FTP)m_sliderC.GetPos()/1000.0;
		FTP dValue = C_MIN+sigma*(C_MAX-C_MIN);
		C_MAX = C_H_MAX;
		m_sliderC.SetPos((int)((dValue-C_MIN)/(C_MAX-C_MIN)*1000.0));
	}
}

void CDlgCrestParam::OnBnClickedPickLine()
{
	m_pView->m_MouseLBAction = MLBA_PICK_RIDGE;
}

void CDlgCrestParam::OnBnClickedRemoveLPoint()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	if (pDoc->m_pCrestline->remove_picked_line_point()) {
		m_pView->InvalidateRect(NULL, FALSE);
	}
}

void CDlgCrestParam::OnBnClickedFilterPick()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	pDoc->m_pCrestline->filter_picked();
	m_pView->InvalidateRect(NULL, FALSE);
}

void CDlgCrestParam::OnBnClickedBreakPick()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	if (pDoc->m_pCrestline->break_picked()) {
		m_pView->InvalidateRect(NULL, FALSE);
	}
}

void CDlgCrestParam::OnBnClickedLinkPick()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	if (pDoc->m_pCrestline->link_picked()) {
		m_pView->InvalidateRect(NULL, FALSE);
	}
}

void CDlgCrestParam::OnBnClickedWeldLines()
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc*)m_pView->GetDocument();
	if (pDoc->m_pCrestline==NULL) {
		return;
	}
	CDlgWeldSetting dlg;
	if (dlg.DoModal() == IDOK) {
		pDoc->m_pCrestline->weld_close_lines(dlg.m_dWeldTRate);
		m_pView->InvalidateRect(NULL, FALSE);
		UpdateSliderPos();
	}
}