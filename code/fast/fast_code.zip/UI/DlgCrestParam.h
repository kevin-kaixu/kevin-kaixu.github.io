#pragma once

#include "../MainFrm.h"
#include "../ChildFrm.h"
#include "../MeshStudioView.h"
#include "../MeshStudioDoc.h"
#include "../GlobalFunc.h"

#define WM_DLG_CREST_PARAM_OK		WM_USER+3
#define WM_DLG_CREST_PARAM_APPLY	WM_USER+4

// CDlgCrestParam dialog

class CDlgCrestParam : public CDialog
{
	DECLARE_DYNAMIC(CDlgCrestParam)

public:
	CDlgCrestParam(CWnd* pParent = NULL);   // standard constructor
	CDlgCrestParam(CMeshStudioView *pView);
	virtual ~CDlgCrestParam();

	BOOL Create(void);
	CMeshStudioView* GetMainView(void);

	void UpdateRT(void);
	void UpdateST(void);
	void UpdateCT(void);
	void UpdateLT(void);
	void UpdateCrestFiltering(void);
	void UpdateSliderPos(void);

	CSliderCtrl	m_sliderR;
	CSliderCtrl m_sliderS;
	CSliderCtrl m_sliderC;
	CSliderCtrl m_sliderL;
	BOOL		m_bAmpLowR;
	BOOL		m_bAmpLowS;
	BOOL		m_bAmpLowC;
	BOOL		m_bAmpLowL;
	CButton		m_checkShowHVF;
	CButton		m_btnSampleHVF;

// Dialog Data
	enum { IDD = IDD_DLG_CREST_SETTING };

private:
	CMeshStudioView *m_pView;

	FTP R_MIN;
	FTP R_MAX, R_L_MAX, R_H_MAX;
	FTP S_MIN;
	FTP S_MAX, S_L_MAX, S_H_MAX;
	FTP C_MIN;
	FTP C_MAX, C_L_MAX, C_H_MAX;
	FTP L_MIN;
	FTP L_MAX, L_L_MAX, L_H_MAX;

	BOOL m_bFilterConvex;
	BOOL m_bFilterConcave;
	BOOL m_bShowHVF;
	BOOL m_bShowDir;
	BOOL m_bShowEpDir;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnOK();
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedVFComp();
	afx_msg void OnBnClickedOptOrien();
	afx_msg void OnBnClickedCheckFilterConvex();
	afx_msg void OnBnClickedCheckFilterConcave();
	afx_msg void OnBnClickedCheckShowHVF();
	afx_msg void OnBnClickedCheckShowDir();
	afx_msg void OnBnClickedCheckShowEpDir();
	afx_msg void OnBnClickedCheckAmpLowRT();
	afx_msg void OnBnClickedCheckAmpLowST();
	afx_msg void OnBnClickedCheckAmpLowCT();
	afx_msg void OnBnClickedCheckAmpLowLT();
	afx_msg void OnBnClickedSaveLines();
	afx_msg void OnBnClickedSaveVF();
	afx_msg void OnBnClickedSampleVF();
	afx_msg void OnBnClickedPickLine();
	afx_msg void OnBnClickedRemoveLPoint();
	afx_msg void OnBnClickedFilterPick();
	afx_msg void OnBnClickedBreakPick();
	afx_msg void OnBnClickedLinkPick();
	afx_msg void OnBnClickedWeldLines();
};
