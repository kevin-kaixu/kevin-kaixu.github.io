#pragma once
#include "../GlobalFunc.h"

// CDlgWeldSetting dialog

class CDlgWeldSetting : public CDialog
{
	DECLARE_DYNAMIC(CDlgWeldSetting)

public:
	CDlgWeldSetting(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgWeldSetting();

	FTP m_dWeldTRate;

// Dialog Data
	enum { IDD = IDD_DLG_WELD_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
