// MainFrm.h : interface of the CMainFrame class
//


#pragma once

#include "TextualStatusBar.h"
#include <string>

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:
	CMenu	m_OrgMenu;
	BOOL	m_bFullScreenMode;
	BOOL	m_bShowDfHGCToolbar;
	BOOL	m_bShowDfSMToolbar;
	BOOL	m_bShowHFToolbar;
	BOOL	m_bShowHVFToolbar;
private:
	// used for full-screen mode
	BOOL		m_bStatusBarWasVisible;
	BOOL		m_bToolBarWasVisible;
	CRect		m_mainRect;
	CToolBar*	m_pwndFullScreenBar;
	BOOL		m_bChildMax;

// Operations
public:
	void FullScreenModeOn();
	void FullScreenModeOff();
	void HFEditToolbarOn();
	void HFEditToolbarOff();
	void HVFEditToolbarOn();
	void HVFEditToolbarOff();

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CTextualStatusBar m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CToolBar	m_wndToolBarLeft;
	CToolBar	m_wndHFToolbar;
	CToolBar	m_wndHVFToolbar;
	CComboBox	m_wndHFTBComboBox;
	CStatic		m_staticHFTBMethod;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnViewFullScreen();
	afx_msg void OnUpdateViewFullScreen(CCmdUI *pCmdUI);
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


