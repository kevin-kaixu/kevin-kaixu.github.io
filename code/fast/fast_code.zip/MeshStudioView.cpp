// MeshStudioView.cpp : implementation of the CMeshStudioView class
//

#include "stdafx.h"
#include "MeshStudio.h"
#include "MeshStudioDoc.h"
#include "MeshStudioView.h"
#include "OptionFormView.h"
#include "Lib\3D\Utility.h"
#include "GlobalFunc.h"
#include "Lib\GL\OpenGLFunc.h"
#include "UI\DlgCrestParam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMeshStudioView

IMPLEMENT_DYNCREATE(CMeshStudioView, CView)

BEGIN_MESSAGE_MAP(CMeshStudioView, CView)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ACTIVATE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_KEYDOWN()
	ON_WM_SETCURSOR()
	ON_WM_TIMER()
END_MESSAGE_MAP()

const float CMeshStudioView::PICK_DIST_EPSILON = 0.001f;
// CMeshStudioView construction/destruction

CMeshStudioView::CMeshStudioView()
{
	// TODO: add construction code here
	m_pOptFormView = NULL;
	// OpenGL
	m_hGLContext = NULL;
	m_GLPixelIndex = 0;

	m_MouseLBAction = MLBA_CAM_SPIN;
	m_bDrawAxes = false;
	m_bBoundingBox = FALSE;
	m_bDrawFaceAndLine = FALSE;
	m_bCullBackFace = FALSE;

	// Default light colors
	m_LightAmbient[0] = m_LightAmbient[1] = m_LightAmbient[2] = 0.4f;
	m_LightDiffuse[0] = m_LightDiffuse[1] = m_LightDiffuse[2] = 0.9f;
	m_LightSpecular[0] = m_LightSpecular[1] = m_LightSpecular[2] = 0.8f;
	m_LightAmbient[3] = m_LightDiffuse[3] = m_LightSpecular[3] = 1.0f;
	m_LightShininess = 50.0f;
	m_LightPosition[0] = 0.0;
	m_LightPosition[1] = 0.0;
	m_LightPosition[2] = 20.0;
	m_LightPosition[3] = 1.0;
	// Material colors
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	m_BackColor[0]  = (float)GetRValue(pApp->m_OptionColorGLBack) / 255.0f;
	m_BackColor[1]  = (float)GetGValue(pApp->m_OptionColorGLBack) / 255.0f;
	m_BackColor[2]  = (float)GetBValue(pApp->m_OptionColorGLBack) / 255.0f;
	m_MatAmbient[0] = (float)GetRValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
	m_MatAmbient[1] = (float)GetGValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
	m_MatAmbient[2] = (float)GetBValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
	m_MatDiffuse[0] = (float)GetRValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
	m_MatDiffuse[1] = (float)GetGValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
	m_MatDiffuse[2] = (float)GetBValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
	m_MatSpecular[0] = (float)GetRValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
	m_MatSpecular[1] = (float)GetGValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
	m_MatSpecular[2] = (float)GetBValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
	m_MatTransparency = m_MatAmbient[3] = m_MatDiffuse[3] = m_MatSpecular[3] = 1.0f;
	m_MatShininess = (float)pApp->m_OptionGLMatShininess;

	m_bTransparent = false;
	m_bSmoothShading = true;
	m_bLeftButtonDown = FALSE;

	m_fSpeedCamMove = 1.0f / 50.0f;
	m_fSpeedCamZoom = 1.0f / 2000.0f;

	m_fViewHeight = 4.0;
	m_fViewNear = -100.0;
	m_fViewFar = 100.0;
	m_bProjOrtho = true;

	m_bPickByRect = FALSE;
	m_bUnpickVert = FALSE;
	m_PickItem = PI_NONE;
	m_PickedVertex = -1;
	m_PickedFacet = -1;

	m_bParameterized = false;
	m_bGenSpacePar = false;
	m_bDrawSpacePar = false;
	m_pParamTexture = NULL;
	m_pTrackBall = NULL;

	m_PseudoColor.SetPCRamp(0.0, 1.0);
	m_PseudoColor.SetPCType((PC_TYPE)pApp->m_OptionPCTypeSel);

	m_bIsUpdateView = false;
	
	m_ShowHVF = HVFS_NONE;

	m_iSVId = 0;
	m_bShowVert = FALSE;

	m_pDlgCrestParam = new CDlgCrestParam(this);
}

void CMeshStudioView::InitCamera(void)
{
	m_fCamMove[0] = 0.0f;
	m_fCamMove[1] = 0.0f;
	m_fCamMove[2] = 0.0f;
	m_fCamZoom = 1.0f;
	m_pTrackBall->Reset();
}

CMeshStudioView::~CMeshStudioView()
{
	SAFE_DELETE(m_pDlgCrestParam);
}

BOOL CMeshStudioView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CMeshStudioView drawing
// OnPaint message is preferred
void CMeshStudioView::OnDraw(CDC* /*pDC*/)
{
}


// CMeshStudioView diagnostics

#ifdef _DEBUG
void CMeshStudioView::AssertValid() const
{
	CView::AssertValid();
}

void CMeshStudioView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMeshStudioDoc* CMeshStudioView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMeshStudioDoc)));
	return (CMeshStudioDoc*)m_pDocument;
}
#endif //_DEBUG

// CMeshStudioView message handlers

//////////////////////////////////////////////
// OPENGL
//////////////////////////////////////////////

//********************************************
// SetWindowPixelFormat
//********************************************
BOOL CMeshStudioView::SetWindowPixelFormat(HDC hDC)
{
	PIXELFORMATDESCRIPTOR pixelDesc;
	
	pixelDesc.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pixelDesc.nVersion = 1;
	
	pixelDesc.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
		PFD_DOUBLEBUFFER | PFD_STEREO_DONTCARE;
	
	pixelDesc.iPixelType = PFD_TYPE_RGBA;
	pixelDesc.cColorBits = 32;
	pixelDesc.cRedBits = 8;
	pixelDesc.cRedShift = 16;
	pixelDesc.cGreenBits = 8;
	pixelDesc.cGreenShift = 8;
	pixelDesc.cBlueBits = 8;
	pixelDesc.cBlueShift = 0;
	pixelDesc.cAlphaBits = 0;
	pixelDesc.cAlphaShift = 0;
	pixelDesc.cAccumBits = 64;
	pixelDesc.cAccumRedBits = 16;
	pixelDesc.cAccumGreenBits = 16;
	pixelDesc.cAccumBlueBits = 16;
	pixelDesc.cAccumAlphaBits = 0;
	pixelDesc.cDepthBits = 32;
	pixelDesc.cStencilBits = 8;
	pixelDesc.cAuxBuffers = 0;
	pixelDesc.iLayerType = PFD_MAIN_PLANE;
	pixelDesc.bReserved = 0;
	pixelDesc.dwLayerMask = 0;
	pixelDesc.dwVisibleMask = 0;
	pixelDesc.dwDamageMask = 0;
	
	m_GLPixelIndex = ChoosePixelFormat(hDC, &pixelDesc);
	if(m_GLPixelIndex == 0) // Choose default
	{
		m_GLPixelIndex = 1;
		if(DescribePixelFormat(hDC,m_GLPixelIndex,
			sizeof(PIXELFORMATDESCRIPTOR), &pixelDesc)==0)
			return FALSE;
	}
	
	if(!SetPixelFormat(hDC,m_GLPixelIndex, &pixelDesc))
		return FALSE;
	
	return TRUE;
}

//********************************************
// CreateViewGLContext
// Create an OpenGL rendering context
//********************************************
BOOL CMeshStudioView::CreateViewGLContext(HDC hDC)
{
	m_hGLContext = wglCreateContext(hDC);
	
	if (m_hGLContext == NULL)
		return FALSE;
	
	if (wglMakeCurrent(hDC, m_hGLContext) == FALSE)
		return FALSE;
	
	return TRUE;
}

void CMeshStudioView::SetRenderingContext(HDC hDC)
{
	if (hDC == NULL) {
		HWND hWnd = GetSafeHwnd();
		HDC hDC = ::GetDC(hWnd);
		wglMakeCurrent(hDC, m_hGLContext);
		::ReleaseDC(hWnd, hDC);
	} else {
		wglMakeCurrent(hDC, m_hGLContext);
	}
}

void CMeshStudioView::UpdateMatTransparency(GLclampf fTransparency)
{
	m_MatTransparency = fTransparency;
	glGetMaterialfv(GL_FRONT, GL_AMBIENT, m_MatAmbient);
	glGetMaterialfv(GL_FRONT, GL_DIFFUSE, m_MatDiffuse);
	glGetMaterialfv(GL_FRONT, GL_SPECULAR, m_MatSpecular);
	m_MatAmbient[3] = m_MatDiffuse[3] = m_MatSpecular[3] = m_MatTransparency;
	if (fTransparency == 1.0f) {
		glMaterialfv(GL_FRONT, GL_AMBIENT, m_MatAmbient);
		GLfloat fBackMat[3];
		fBackMat[0] = 0.5f * m_MatAmbient[0];
		fBackMat[1] = 0.5f * m_MatAmbient[1];
		fBackMat[2] = 0.5f * m_MatAmbient[2];
		glMaterialfv(GL_BACK, GL_AMBIENT, fBackMat);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, m_MatDiffuse);
		fBackMat[0] = 0.5f * m_MatDiffuse[0];
		fBackMat[1] = 0.5f * m_MatDiffuse[1];
		fBackMat[2] = 0.5f * m_MatDiffuse[2];
		glMaterialfv(GL_BACK, GL_DIFFUSE, fBackMat);
		glMaterialfv(GL_FRONT, GL_SPECULAR, m_MatSpecular);
		fBackMat[0] = 0.5f * m_MatSpecular[0];
		fBackMat[1] = 0.5f * m_MatSpecular[1];
		fBackMat[2] = 0.5f * m_MatSpecular[2];
		glMaterialfv(GL_BACK, GL_SPECULAR, fBackMat);
	} else {
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, m_MatAmbient);
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, m_MatDiffuse);
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, m_MatSpecular);
	}
}

//********************************************
// Create an OpenGL framework
//********************************************
int CMeshStudioView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	HWND hWnd = GetSafeHwnd();
	HDC hDC = ::GetDC(hWnd);
	
	if(SetWindowPixelFormat(hDC) == FALSE)
		return 0;
	
	if(CreateViewGLContext(hDC) == FALSE)
		return 0;

	::ReleaseDC(hWnd, hDC);
	
	// Default mode
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_NORMALIZE);

	if (m_bCullBackFace) {
		glEnable(GL_CULL_FACE);
	} else {
		glDisable(GL_CULL_FACE);
	}
	glFrontFace(GL_CCW);
	glClearDepth(1.0f);
	glClearColor(m_BackColor[0], m_BackColor[1], m_BackColor[2], 1.0f);

	// Lights, material properties
	glLightfv(GL_LIGHT0, GL_AMBIENT, m_LightAmbient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, m_LightDiffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, m_LightSpecular);
	glLightf(GL_LIGHT0, GL_SHININESS, m_LightShininess);
	glLightfv(GL_LIGHT0, GL_POSITION, m_LightPosition);
	glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 1.0);
	glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 1.0);
	
	glMaterialfv(GL_FRONT, GL_AMBIENT, m_MatAmbient);
	GLfloat fBackMat[3];
	fBackMat[0] = 0.5f * m_MatAmbient[0];
	fBackMat[1] = 0.5f * m_MatAmbient[1];
	fBackMat[2] = 0.5f * m_MatAmbient[2];
	glMaterialfv(GL_BACK, GL_AMBIENT, fBackMat);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, m_MatDiffuse);
	fBackMat[0] = 0.5f * m_MatDiffuse[0];
	fBackMat[1] = 0.5f * m_MatDiffuse[1];
	fBackMat[2] = 0.5f * m_MatDiffuse[2];
	glMaterialfv(GL_BACK, GL_DIFFUSE, fBackMat);
	glMaterialfv(GL_FRONT, GL_SPECULAR, m_MatSpecular);
	fBackMat[0] = 0.5f * m_MatSpecular[0];
	fBackMat[1] = 0.5f * m_MatSpecular[1];
	fBackMat[2] = 0.5f * m_MatSpecular[2];
	glMaterialfv(GL_BACK, GL_SPECULAR, fBackMat);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, m_MatShininess);

	// Default : lighting
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	// Texture
	m_pParamTexture = new CTexture("check_64x64.bmp", true);
	m_pParamTexture->ChangeSettings(GL_NEAREST, GL_LINEAR_MIPMAP_LINEAR, GL_REPEAT,
									GL_REPEAT, GL_MODULATE);
	glDisable(GL_TEXTURE_2D);

	// Setup the blending function
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	if (m_bTransparent) {
		glEnable(GL_BLEND);
	} else {
		glDisable(GL_BLEND);
	}

	// Shading option
	if (m_bSmoothShading) {
		glShadeModel(GL_SMOOTH);
	} else {
		glShadeModel(GL_FLAT);
	}

	// Polygon offset
	::glEnable(GL_POLYGON_OFFSET_FILL);
	::glPolygonOffset(1.0f, 1.0f);

	// Init the TrackBall
	m_pTrackBall = new CTrackBall<FTP>((CWnd*)this, TIMER_ANIMATE, ANIMATE_RATE);
	
	InitCamera();
	
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
	ASSERT_VALID(pDoc);
	pDoc->m_pView = this;
	
	if (!IsOpenGLVersionSupported(2, 0)) {
		// Check if work with OpenGL 2.0
		MSG_BOX_WARNING("OpenGL 2.0 is not supported!");
	} else {
		pDoc->StatusMessage("OpenGL 2.0 is supported!");
	}

	return 0;
}

void CMeshStudioView::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	
	// Model is stored in Document
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
	ASSERT_VALID(pDoc);
	
	// Useful in multi-doc templates
	SetRenderingContext(dc.m_ps.hdc);
	
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	
	glPushMatrix();

	// Position / translation / scale
	glTranslated(m_fCamMove[0], m_fCamMove[1], m_fCamMove[2]);
	m_pTrackBall->TBMatrix();
	glScalef(m_fCamZoom, m_fCamZoom, m_fCamZoom);
	
	if (m_bDrawAxes) {
		DrawAxes();
	}
	if (pDoc->m_pMesh != NULL)
	{
		if (m_PickItem == PI_VERTEX) {
			pDoc->m_pMesh->gl_draw_picked_vertices();
		} else if (m_PickItem == PI_TRIANGLE) {
			pDoc->m_pMesh->gl_draw_picked_facets(m_bSmoothShading, true);
		}
		if (m_bShowVert) {
			pDoc->m_pMesh->gl_draw_vertex(m_iSVId);
		}
		if (m_bBoundingBox) {
			pDoc->m_pMesh->gl_draw_bounding_box2();
		}
		if (pDoc->m_pCrestline!=NULL) {			// * show crest lines
			pDoc->m_pCrestline->gl_draw_crestlines_3d();
		}
		if (m_bDrawFaceAndLine) {// i should add face+line as a argument to gl_draw_vbo
			if (m_ShowHVF!=HVFS_NONE && pDoc->m_pMesh->is_s_hvf_uptodate()) {
				pDoc->m_pMesh->gl_draw_vbo_face_line();
				pDoc->m_pMesh->gl_draw_hvf();
				if (pDoc->m_pCrestline == NULL) {
					pDoc->m_pMesh->gl_draw_hvf_sites();
				}
			} else {
				pDoc->m_pMesh->gl_draw_vbo_face_line();
			}
		} else {
			if (m_ShowHVF!=HVFS_NONE && pDoc->m_pMesh->is_s_hvf_uptodate()) {
				pDoc->m_pMesh->gl_draw_vbo();
				pDoc->m_pMesh->gl_draw_hvf();
				if (pDoc->m_pCrestline == NULL) {
					pDoc->m_pMesh->gl_draw_hvf_sites();
				}
			} else {
				pDoc->m_pMesh->gl_draw_vbo();
			}
		}
	}

	glPopMatrix();
	
	if (m_bPickByRect) {
		DrawPickingRect();
	}

	// Double buffer
	SwapBuffers(dc.m_ps.hdc);
	glFlush();

	m_bIsUpdateView = true;	// finished update view
}

void CMeshStudioView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	SetRenderingContext();

	// Set OpenGL perspective, viewport and mode
	m_pTrackBall->ReSize(cx, cy);

	//
	if (m_pOptFormView != NULL) {
		m_pOptFormView->UpdateRenderViewSize(cx, cy);
	}
	
	// perspective projection
	if (m_bProjOrtho) {
		m_WindowSize.cx = cx;
		m_WindowSize.cy = cy;
		float dAspect = (float)cx / (float)((cy == 0) ? 1 : cy);
		m_fViewWidth = m_fViewHeight * dAspect;
		glViewport(0, 0, cx, cy);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-m_fViewWidth, m_fViewWidth, -m_fViewHeight, m_fViewHeight, m_fViewNear, m_fViewFar);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(0.0, 0.0, -5.0);
	} else {
		CSize size(cx, cy);
		double aspect;
		aspect = (cy == 0) ? (double)size.cx : (double)size.cx/(double)size.cy;
		glViewport(0, 0, size.cx, size.cy);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(25, aspect, 0.01, m_fViewFar);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(0.0, 0.0, -18.0);
	}
	Build2DSceneList();
}

void CMeshStudioView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	SetRenderingContext();
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
	if (!pDoc->m_bClosing && pDoc->m_pMesh!=NULL) {
		pDoc->UpdateMeshProperties(pDoc->m_pMesh);
	}

	CView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

// avoid flickering
BOOL CMeshStudioView::OnEraseBkgnd(CDC*)
{
	return TRUE;
}

// destroy rendering context
void CMeshStudioView::OnDestroy()
{
	if(wglGetCurrentContext() != NULL)
		wglMakeCurrent(NULL,NULL);

	if(m_hGLContext != NULL)
	{
		wglDeleteContext(m_hGLContext);
		m_hGLContext = NULL;
	}
}

void CMeshStudioView::Build2DSceneList(void)
{
	if (glIsList(m_2DDisplayList)) {
		glDeleteLists(m_2DDisplayList, 1);
	}

	m_2DDisplayList = glGenLists(1);
	glNewList(m_2DDisplayList, GL_COMPILE);

		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		gluOrtho2D(0, m_WindowSize.cx, 0, m_WindowSize.cy);

	glEndList();
}

void CMeshStudioView::DrawPickingRect()
{
	glPushAttrib(GL_ENABLE_BIT|GL_CURRENT_BIT|GL_LINE_BIT|GL_POINT_BIT|GL_DEPTH_BUFFER_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glColor3f(1.0f-m_BackColor[0], 1.0f-m_BackColor[1], 1.0f-m_BackColor[2]);
	glCallList(m_2DDisplayList);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glBegin(GL_LINE_LOOP);
	glVertex2f(m_PickingRectStart.x, m_WindowSize.cy-m_PickingRectStart.y);
	glVertex2f(m_PickingRectEnd.x, m_WindowSize.cy-m_PickingRectStart.y);
	glVertex2f(m_PickingRectEnd.x, m_WindowSize.cy-m_PickingRectEnd.y);
	glVertex2f(m_PickingRectStart.x, m_WindowSize.cy-m_PickingRectEnd.y);
	glEnd();
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopAttrib();
}

void CMeshStudioView::PickByPoint(int px, int py, PICK_ITEM item)
{
	CMeshStudioDoc *pDoc = GetDocument();
	COptionFormView *pFView = GetOptionFormView();
	CString s;
	Vector3 sp, dir;
	GetPickSPDir(px, py, sp, dir);
	
	switch(item) {
	case PI_VERTEX:
		if (!m_bUnpickVert) {
			m_PickedVertex = pDoc->m_pMesh->pick_vertex_by_ray(sp, dir, PICK_DIST_EPSILON);
			if (m_PickedVertex != -1) {
				s.Format("%d", m_PickedVertex);
				pFView->SetDlgItemText(IDC_TEXT_PCK_ID, s);
				//if (pDoc->m_pMesh->is_comp_hb_harmonic_field())
				//{
				//	pDoc->m_pMesh->get_vert_harmonic_value();
				//}
			} else {
				pFView->SetDlgItemText(IDC_TEXT_PCK_ID, "");
			}
		}
		break;
	case PI_TRIANGLE:
		m_PickedFacet = pDoc->m_pMesh->pick_facet_by_ray(sp, dir);
		if (m_PickedFacet != -1) {
			s.Format("%d", m_PickedFacet);
			pFView->SetDlgItemText(IDC_TEXT_PCK_ID, s);
		} else {
			pFView->SetDlgItemText(IDC_TEXT_PCK_ID, "");
		}
		break;
	default:
		AfxMessageBox("PickByPoint: Bad pick item!");
		break;
	}
}

bool CMeshStudioView::PickRidgeByColumn(int startx, int starty, int endx, int endy)
{
	GLdouble modelview[4*4];
	GLdouble projection[4*4];
	GLint    viewport[4];
	GLdouble sobjx, sobjy, sobjz;
	GLdouble zobjx, zobjy, zobjz;
	GLdouble xobjx, xobjy, xobjz;
	GLdouble yobjx, yobjy, yobjz;
	CMeshStudioDoc *pDoc = GetDocument();
	COptionFormView *pFView = GetOptionFormView();
	CString s;
	BeginWaitCursor();
	glPushMatrix();
	glTranslated(m_fCamMove[0], m_fCamMove[1], 0.0f);
	m_pTrackBall->TBMatrix();
	glScalef(m_fCamZoom, m_fCamZoom, m_fCamZoom);
	glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
	glPopMatrix();
	glGetDoublev(GL_PROJECTION_MATRIX, projection);
	glGetIntegerv(GL_VIEWPORT, viewport);
	gluUnProject(startx, starty, 0.0f,
		modelview, projection, viewport,
		&sobjx, &sobjy, &sobjz);
	gluUnProject(endx, starty, 0.0f,
		modelview, projection, viewport,
		&xobjx, &xobjy, &xobjz);
	gluUnProject(startx, endy, 0.0f,
		modelview, projection, viewport,
		&yobjx, &yobjy, &yobjz);
	gluUnProject(endx, endy, 1.0f,
		modelview, projection, viewport,
		&zobjx, &zobjy, &zobjz);
	if (pDoc->m_pCrestline != NULL)
	{
		return pDoc->m_pCrestline->pick_line_by_colomn(Vector3(sobjx, sobjy, sobjz),
			Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
			Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
			Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz),
			::GetKeyState(VK_CONTROL)<0);
	}
	else
	{
		return false;
	}
}

void CMeshStudioView::GetPickSPDir(int px, int py, Vector3 &sp, Vector3 &dir)
{
	GLdouble modelview[4*4];
	GLdouble projection[4*4];
	GLint viewport[4];
	GLdouble objx, objy, objz;
	GLdouble sobjx, sobjy, sobjz;

	glPushMatrix();
	glTranslated(m_fCamMove[0], m_fCamMove[1], 0.0f);
	m_pTrackBall->TBMatrix();
	glScalef(m_fCamZoom, m_fCamZoom, m_fCamZoom);
	glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
	glPopMatrix();
	glGetDoublev(GL_PROJECTION_MATRIX, projection);
	glGetIntegerv(GL_VIEWPORT, viewport);
	gluUnProject(px, py, 0.0f,
				modelview, projection, viewport,
				&sobjx, &sobjy, &sobjz);
	gluUnProject(px, py, 1.0f,
				modelview, projection, viewport,
				&objx, &objy, &objz);
	sp.set(sobjx, sobjy, sobjz);
	dir.set(objx-sobjx, objy-sobjy, objz-sobjz);
}

void CMeshStudioView::PickByRect(int startx, int starty, int endx, int endy, PICK_ITEM item)
{
	GLdouble modelview[4*4];
	GLdouble projection[4*4];
	GLint    viewport[4];
	GLdouble sobjx, sobjy, sobjz;
	GLdouble zobjx, zobjy, zobjz;
	GLdouble xobjx, xobjy, xobjz;
	GLdouble yobjx, yobjy, yobjz;
	CMeshStudioDoc *pDoc = GetDocument();
	COptionFormView *pFView = GetOptionFormView();
	CString s;

	BeginWaitCursor();
	glPushMatrix();
		glTranslated(m_fCamMove[0], m_fCamMove[1], 0.0f);
		m_pTrackBall->TBMatrix();
		glScalef(m_fCamZoom, m_fCamZoom, m_fCamZoom);
		glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
	glPopMatrix();
	glGetDoublev(GL_PROJECTION_MATRIX, projection);
	glGetIntegerv(GL_VIEWPORT, viewport);
	gluUnProject(startx, starty, 0.0f,
				modelview, projection, viewport,
				&sobjx, &sobjy, &sobjz);
	gluUnProject(endx, starty, 0.0f,
				modelview, projection, viewport,
				&xobjx, &xobjy, &xobjz);
	gluUnProject(startx, endy, 0.0f,
				modelview, projection, viewport,
				&yobjx, &yobjy, &yobjz);
	gluUnProject(endx, endy, 1.0f,
				modelview, projection, viewport,
				&zobjx, &zobjy, &zobjz);
	
	switch(item) {
	case PI_VERTEX:
		if (m_bUnpickVert) {
			pDoc->m_pMesh->unpick_vertices_by_column(Vector3(sobjx, sobjy, sobjz),
													 Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
													 Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
													 Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz));
		} else {
			pDoc->m_pMesh->pick_vertices_by_column(Vector3(sobjx, sobjy, sobjz),
												   Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
												   Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
												   Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz));
		}
		s.Format("%d", pDoc->m_pMesh->nb_picked_vertices());
		pFView->SetDlgItemText(IDC_TEXT_NUM_PCK, s);
		break;
	case PI_TRIANGLE:
		pDoc->m_pMesh->pick_facets_by_column(Vector3(sobjx, sobjy, sobjz),
										     Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
										   	 Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
										 	 Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz));
		s.Format("%d", pDoc->m_pMesh->nb_picked_facets());
		pFView->SetDlgItemText(IDC_TEXT_NUM_PCK, s);
		break;
	default:
		AfxMessageBox("PickByRect: Bad pick item!");
		break;
	}
	EndWaitCursor();
}

void CMeshStudioView::PickByRect(Mesh *pMesh,
								 GLdouble *modelview, GLdouble *projection, GLint *viewport,
								 int startx, int starty, int endx, int endy, PICK_ITEM item)
{
	GLdouble sobjx, sobjy, sobjz;
	GLdouble zobjx, zobjy, zobjz;
	GLdouble xobjx, xobjy, xobjz;
	GLdouble yobjx, yobjy, yobjz;
	COptionFormView *pFView = GetOptionFormView();
	CString s;

	BeginWaitCursor();
	gluUnProject(startx, starty, 0.0f,
				modelview, projection, viewport,
				&sobjx, &sobjy, &sobjz);
	gluUnProject(endx, starty, 0.0f,
				modelview, projection, viewport,
				&xobjx, &xobjy, &xobjz);
	gluUnProject(startx, endy, 0.0f,
				modelview, projection, viewport,
				&yobjx, &yobjy, &yobjz);
	gluUnProject(endx, endy, 1.0f,
				modelview, projection, viewport,
				&zobjx, &zobjy, &zobjz);
	
	switch(item) {
	case PI_VERTEX:
		if (m_bUnpickVert) {
			pMesh->unpick_vertices_by_column(Vector3(sobjx, sobjy, sobjz),
											 Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
											 Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
											 Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz));
		} else {
			pMesh->pick_vertices_by_column(Vector3(sobjx, sobjy, sobjz),
										   Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
										   Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
										   Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz));
		}
		s.Format("%d", pMesh->nb_picked_vertices());
		pFView->SetDlgItemText(IDC_TEXT_NUM_PCK, s);
		break;
	case PI_TRIANGLE:
		pMesh->pick_facets_by_column(Vector3(sobjx, sobjy, sobjz),
									 Vector3(xobjx-sobjx, xobjy-sobjy, xobjz-sobjz),
									 Vector3(yobjx-sobjx, yobjy-sobjy, yobjz-sobjz),
									 Vector3(zobjx-sobjx, zobjy-sobjy, zobjz-sobjz));
		s.Format("%d", pMesh->nb_picked_facets());
		pFView->SetDlgItemText(IDC_TEXT_NUM_PCK, s);
		break;
	default:
		AfxMessageBox("PickByRect: Bad pick item!");
		break;
	}
	EndWaitCursor();
}

void CMeshStudioView::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_MouseLBAction==MLBA_CAM_SPIN) {
		m_pTrackBall->MouseDown(point.x, point.y);
	}
	m_LeftDownPos = point;
	m_bLeftButtonDown = TRUE;

	if (m_MouseLBAction==MLBA_PICK) {
		m_PickingRectStart = point;
		if (::GetKeyState(VK_CONTROL) >= 0) {
			if (m_PickItem == PI_VERTEX && !m_bUnpickVert) {
				m_PickedVertex = -1;
				GetDocument()->m_pMesh->clear_picked_vertices();
			} else if (m_PickItem == PI_TRIANGLE) {
				m_PickedFacet = -1;
				GetDocument()->m_pMesh->clear_picked_facets();
			}
		}
		PickByPoint(point.x, m_WindowSize.cy-point.y, m_PickItem);
		InvalidateRect(NULL, FALSE);
	} else if (m_MouseLBAction==MLBA_PICK_RIDGE) {
		m_PickingRectStart = point;
	}
	SetCapture();

	CView::OnLButtonDown(nFlags, point);
}

void CMeshStudioView::OnRButtonDown(UINT nFlags, CPoint point)
{
	m_RightDownPos = point;
	CView::OnRButtonDown(nFlags, point);
}

void CMeshStudioView::OnRButtonUp(UINT nFlags, CPoint point)
{
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
	CView::OnRButtonUp(nFlags, point);
}

void CMeshStudioView::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_MouseLBAction==MLBA_CAM_SPIN) {
		m_pTrackBall->MouseUp();
	}
	m_bLeftButtonDown = FALSE;
	
	if (m_bPickByRect)
	{
		if (m_MouseLBAction==MLBA_PICK) {
			PickByRect(m_PickingRectStart.x, m_WindowSize.cy-m_PickingRectStart.y, 
				m_PickingRectEnd.x, m_WindowSize.cy-m_PickingRectEnd.y, m_PickItem);
		} else if (m_MouseLBAction == MLBA_PICK_RIDGE) {
			PickRidgeByColumn(m_PickingRectStart.x, m_WindowSize.cy-m_PickingRectStart.y, 
				m_PickingRectEnd.x, m_WindowSize.cy-m_PickingRectEnd.y);
		}
		InvalidateRect(NULL, FALSE);
		m_bPickByRect = FALSE;
	}
	
	ReleaseCapture();

	CView::OnLButtonUp(nFlags, point);
}

void CMeshStudioView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	if (::GetKeyState(VK_LBUTTON) < 0) {
		if ( m_MouseLBAction==MLBA_CAM_MOVE 
			|| (m_MouseLBAction==MLBA_CAM_SPIN && ::GetKeyState(VK_SHIFT)<0) 
			|| (m_MouseLBAction==MLBA_CAM_ZOOM && ::GetKeyState(VK_SHIFT)<0) ) {
			m_fCamMove[0] -= (float)(m_LeftDownPos.x - point.x) * m_fSpeedCamMove;
			m_fCamMove[1] += (float)(m_LeftDownPos.y - point.y) * m_fSpeedCamMove;
			InvalidateRect(NULL, FALSE);
		} else if (m_MouseLBAction == MLBA_CAM_ZOOM) {
			m_fCamZoom += (float)(m_LeftDownPos.y - point.y) * m_fSpeedCamZoom * 0.4f;
			InvalidateRect(NULL, FALSE);
		} else if (m_MouseLBAction==MLBA_CAM_SPIN) {
			if (::GetKeyState(VK_SHIFT) >= 0) {
				m_pTrackBall->Motion(point.x, point.y);
				m_pOptFormView->InvalidateDepthOrder();
			}
		} else if (m_MouseLBAction==MLBA_PICK || m_MouseLBAction==MLBA_PICK_RIDGE) {
			m_bPickByRect = TRUE;
			m_PickingRectEnd = point;
			InvalidateRect(NULL, FALSE);
		}
		m_LeftDownPos = point;
	} else if (::GetKeyState(VK_RBUTTON) < 0) {
		m_fCamMove[0] -= (float)(m_RightDownPos.x - point.x) * m_fSpeedCamMove;
		m_fCamMove[1] += (float)(m_RightDownPos.y - point.y) * m_fSpeedCamMove;
		InvalidateRect(NULL, FALSE);
		m_RightDownPos = point;
	}
	CView::OnMouseMove(nFlags, point);
}

BOOL CMeshStudioView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: Add your message handler code here and/or call default
	m_fCamZoom += (zDelta * m_fSpeedCamZoom);
	if (m_fCamZoom < 0.0f) {
		m_fCamZoom = 0.0f;
	}
	InvalidateRect(NULL, FALSE);
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

void CMeshStudioView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	CMainFrame *pMainFrame = (CMainFrame *)pApp->m_pMainWnd;
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
	switch(nChar) {
	case VK_ESCAPE:
		if (pMainFrame->m_bFullScreenMode) {
			pMainFrame->FullScreenModeOff();
		}
		break;
	default:
		break;
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CMeshStudioView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	HCURSOR hCursor;

	switch (m_MouseLBAction)
	{
	case MLBA_CAM_SPIN:
	case MLBA_AA_SPIN_Y:
		hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR_CAM_SPIN);
		SetCursor(hCursor);
		break;
	case MLBA_CAM_ZOOM:
		hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR_CAM_ZOOM);
		SetCursor(hCursor);
		break;
	case MLBA_CAM_MOVE:
		hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR_CAM_MOVE);
		SetCursor(hCursor);
		break;
	case MLBA_PICK:
	case MLBA_PICK_RIDGE:
		hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR_PICK);
		SetCursor(hCursor);
		break;
	default:
		hCursor = AfxGetApp()->LoadCursor(IDC_ARROW);
		SetCursor(hCursor);
		break;
	}
	return TRUE;
}

void CMeshStudioView::OnTimer(UINT nIDEvent)
{
	if (nIDEvent == TIMER_ANIMATE) {
		FTP dAngle = m_pTrackBall->Animate();
		if (m_bTransparent && (dAngle==0.0||dAngle==60.0
			||dAngle==120.0||dAngle==180.0||dAngle==240.0||dAngle==300.0)) {
			COptionFormView *pFView = GetOptionFormView();
			pFView->OnDepthSort();
		}
	}
	CView::OnTimer(nIDEvent);
}
