// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "MeshStudio.h"

#include "MainFrm.h"
#include ".\mainfrm.h"
#include "GlobalFunc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_FULL_SCREEN, OnViewFullScreen)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FULL_SCREEN, OnUpdateViewFullScreen)
	ON_WM_CLOSE()
	ON_WM_SIZE()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,
	IDS_MESSAGE0,
	IDS_MESSAGE1,
	IDS_MESSAGE2,
	IDS_MESSAGE3,
	IDS_MESSAGE4,
	IDS_MESSAGE5,
};

static UINT buttons[] =
{
	ID_FILE_NEW,
	ID_FILE_OPEN,
	ID_FILE_SAVE,
	ID_SEPARATOR,
	ID_RENDER_AXES,
	ID_RENDER_BOUNDINGBOX,
	ID_SEPARATOR,
	ID_CURVATURE_DRAW_KMIN,
	ID_CURVATURE_DRAW_KMAX,
	ID_CURVATURE_DRAW_ASYMPTOTIC,
	ID_CURVATURE_DRAW_MEAN,
	ID_SEPARATOR,
	ID_SEPARATOR,
	ID_VIEW_FULL_SCREEN,
	ID_APP_ABOUT,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_bFullScreenMode = FALSE;
	m_bShowDfHGCToolbar = FALSE;
	m_bShowDfSMToolbar = FALSE;
	m_bShowHFToolbar = FALSE;
	m_bShowHVFToolbar = FALSE;
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
//	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
//		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
//		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
//	{
//		TRACE0("Failed to create toolbar\n");
//		return -1;      // fail to create
//	}
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC))
	{
		MSG_BOX_ERROR("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_FILE_NEW);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_FILE_OPEN);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_FILE_SAVE);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_RENDER_AXES);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_RENDER_BOUNDING_BOX);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_DRAW_CURV_KMIN);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_DRAW_CURV_KMAX);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_DRAW_CURV_ASYMPTOTIC);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_DRAW_CURV_MEAN);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_FULL_SCREEN);
	m_wndToolBar.GetToolBarCtrl().AddBitmap(1, IDB_HELP);
//	m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);
	m_wndToolBar.SetButtons(buttons, sizeof(buttons)/sizeof(UINT));
	m_wndToolBar.SetSizes(CSize(30,28), CSize(23,22));
	m_wndToolBar.SetWindowText(_T("Standard"));
//	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	if (!m_wndToolBarLeft.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBarLeft.LoadToolBar(IDR_TOOLBAR_LEFT))
	{
		MSG_BOX_ERROR("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndHFToolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndHFToolbar.LoadToolBar(IDR_TOOLBAR_HF_EDIT))
	{
		MSG_BOX_ERROR("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndHFToolbar.SetWindowText("Harmonic Scalar Field Edit");

	if (!m_wndHVFToolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndHVFToolbar.LoadToolBar(IDR_TOOLBAR_HVF_EDIT))
	{
		MSG_BOX_ERROR("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndHVFToolbar.SetWindowText("Harmonic Vector Field Edit");

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		MSG_BOX_ERROR("Failed to create status bar\n");
		return -1;      // fail to create
	}
	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBarLeft.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	DockControlBar(&m_wndToolBarLeft, AFX_IDW_DOCKBAR_LEFT);
	ShowControlBar(&m_wndHFToolbar, FALSE, FALSE);
	ShowControlBar(&m_wndHVFToolbar, FALSE, FALSE);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		 | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE | WS_SYSMENU;

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////
// Full screen
//////////////////////////////////////////////////////////////////////////
void CMainFrame::FullScreenModeOn()
{
	// available only if there is an active doc
	CMDIChildWnd* pChild=MDIGetActive();
	if(!pChild) return;
	m_bToolBarWasVisible=(m_wndToolBar.IsWindowVisible()!=0);
	m_wndToolBar.ShowWindow(SW_HIDE);
	m_bStatusBarWasVisible=(m_wndStatusBar.IsWindowVisible()!=0);
	m_wndStatusBar.ShowWindow(SW_HIDE);
	// first create the new toolbar
	// this will contain the full-screen off button
	m_pwndFullScreenBar=new CToolBar;
	m_pwndFullScreenBar->Create(this);
	m_pwndFullScreenBar->LoadToolBar(IDR_FULL_SCREEN);
	m_pwndFullScreenBar->SetBarStyle(m_pwndFullScreenBar->GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	// to look better:
	m_pwndFullScreenBar->ModifyStyle(0, TBSTYLE_FLAT);
	m_pwndFullScreenBar->EnableDocking(0);
	// place the full-screen off button somewhere:
	CPoint pt(720, 30);
	FloatControlBar(m_pwndFullScreenBar,pt);
	
	// now save the old positions of the main and child windows
	GetWindowRect(&m_mainRect);
	// remove the caption of the mainWnd:
	LONG style=::GetWindowLong(m_hWnd,GWL_STYLE);
	style&=~WS_CAPTION;
	::SetWindowLong(m_hWnd,GWL_STYLE,style);
	int screenx=GetSystemMetrics(SM_CXSCREEN);
	int screeny=GetSystemMetrics(SM_CYSCREEN);
	// resize:
	SetWindowPos(NULL,0,0,screenx,screeny,SWP_NOZORDER);
	//SetWindowPos(NULL,-5,-5,80,80,SWP_NOZORDER);
	style=::GetWindowLong(pChild->m_hWnd,GWL_STYLE);
	m_bChildMax=(style & WS_MAXIMIZE)?true:false;
	// note here: m_bMainMax is not needed since m_hWnd only
	// changed its caption...
	///***************
	//Save the Original Menu and set menu to NULL
    ASSERT(m_OrgMenu.GetSafeHmenu()==NULL);
    CMenu* pOldMenu=GetMenu();
    m_OrgMenu.Attach(pOldMenu->Detach());
    SetMenu((CMenu*)NULL);
	//************
	// and maximize the child window
	// it will remove its caption, too.
	 //pChild->
	this->ShowWindow(SW_SHOWMAXIMIZED);
	style=::GetWindowLong(pChild->m_hWnd,GWL_STYLE);
	style&=~WS_CAPTION;
	::SetWindowLong(pChild->m_hWnd,GWL_STYLE,style);
	//pChild->SetWindowPos (NULL,-5,-5,screenx+5,screeny+5,SWP_NOZORDER);
	pChild->ShowWindow(SW_SHOWMAXIMIZED);

	//RecalcLayout();
	m_bFullScreenMode = TRUE;
}

void CMainFrame::FullScreenModeOff()
{
	ASSERT(m_OrgMenu.GetSafeHmenu()!=NULL);
    SetMenu(&m_OrgMenu);
    m_OrgMenu.Detach();

	// You can use SaveBarState() in OnClose(),
	// so remove the newly added toolbar entirely
	// in order SaveBarState() not
	// to save its state. That is why I used dynamic
	// allocation
	delete m_pwndFullScreenBar;
	LONG style=::GetWindowLong(m_hWnd,GWL_STYLE);
	style|=WS_CAPTION;
	::SetWindowLong(m_hWnd,GWL_STYLE,style);
	if(m_bToolBarWasVisible)
		m_wndToolBar.ShowWindow(SW_SHOW);
	if(m_bStatusBarWasVisible)
		m_wndStatusBar.ShowWindow(SW_SHOW);
	MoveWindow(&m_mainRect);
	RecalcLayout();
	CMDIChildWnd* pChild=MDIGetActive();

	style=::GetWindowLong(pChild->m_hWnd,GWL_STYLE);
	style|=WS_CAPTION;
	::SetWindowLong(pChild->m_hWnd,GWL_STYLE,style);
	// pChild can be NULL if the USER closed all the
	// childs during Full Screen Mode:
	if(pChild){
		if(m_bChildMax)
			MDIMaximize(pChild);
		else MDIRestore(pChild);
	}
	m_bFullScreenMode = FALSE;
}

void CMainFrame::HFEditToolbarOn()
{
	m_wndHFToolbar.EnableDocking(CBRS_ALIGN_ANY);
	CPoint pt(600, 100);
	FloatControlBar(&m_wndHFToolbar, pt);
	ShowControlBar(&m_wndHFToolbar, TRUE, FALSE);
	m_bShowHFToolbar = TRUE;
}

void CMainFrame::HFEditToolbarOff()
{
	ShowControlBar(&m_wndHFToolbar, FALSE, FALSE);
	m_bShowHFToolbar = FALSE;
}

void CMainFrame::HVFEditToolbarOn()
{
	m_wndHVFToolbar.EnableDocking(CBRS_ALIGN_ANY);
	CPoint pt(520, 100);
	FloatControlBar(&m_wndHVFToolbar, pt);
	ShowControlBar(&m_wndHVFToolbar, TRUE, FALSE);
	m_bShowHVFToolbar = TRUE;
}

void CMainFrame::HVFEditToolbarOff()
{
	ShowControlBar(&m_wndHVFToolbar, FALSE, FALSE);
	m_bShowHVFToolbar = FALSE;
}

// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers


void CMainFrame::OnViewFullScreen()
{
	if (m_bFullScreenMode) {
		FullScreenModeOff();
	} else {
		FullScreenModeOn();
	}
}

void CMainFrame::OnUpdateViewFullScreen(CCmdUI *pCmdUI)
{
	CMDIChildWnd* pChild = MDIGetActive();
	pCmdUI->Enable(pChild != NULL);
	pCmdUI->SetCheck(m_bFullScreenMode);
}

void CMainFrame::OnClose()
{
	if (m_bFullScreenMode) {
		FullScreenModeOff();
	}
	CMDIFrameWnd::OnClose();
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	CMDIFrameWnd::OnSize(nType, cx, cy);
}