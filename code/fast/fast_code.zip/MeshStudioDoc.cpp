// MeshStudioDoc.cpp : implementation of the CMeshStudioDoc class
//

#include "stdafx.h"
#include "MeshStudio.h"
#include "MeshStudioDoc.h"
#include "MeshStudioView.h"
#include "OptionFormView.h"
#include "UI\DlgHFVSampleSetting.h"
#include "UI\DlgCrestParam.h"
// STL stuff
#include <iostream>
#include <fstream>
// CGAL (off) + obj IO
#include <CGAL/IO/Polyhedron_iostream.h>
#include "Lib/Mesh/Parser/parser_obj.h"
#include "Lib/Mesh/Parser/parser_wrl.h"
#include <CGAL/IO/Polyhedron_VRML_2_ostream.h>
#include "Lib/Mesh/Parser/parser_smf.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMeshStudioDoc

IMPLEMENT_DYNCREATE(CMeshStudioDoc, CDocument)

BEGIN_MESSAGE_MAP(CMeshStudioDoc, CDocument)
	ON_COMMAND(ID_FILE_RELOAD, &CMeshStudioDoc::OnFileReload)
	ON_UPDATE_COMMAND_UI(ID_FILE_RELOAD, &CMeshStudioDoc::OnUpdateFileReload)
	ON_COMMAND(ID_CAM_MANIP_MOVE, &CMeshStudioDoc::OnCamManipMove)
	ON_UPDATE_COMMAND_UI(ID_CAM_MANIP_MOVE, &CMeshStudioDoc::OnUpdateCamManipMove)
	ON_COMMAND(ID_CAM_MANIP_SPIN, &CMeshStudioDoc::OnCamManipSpin)
	ON_UPDATE_COMMAND_UI(ID_CAM_MANIP_SPIN, &CMeshStudioDoc::OnUpdateCamManipSpin)
	ON_COMMAND(ID_CAM_MANIP_ZOOM, &CMeshStudioDoc::OnCamManipZoom)
	ON_UPDATE_COMMAND_UI(ID_CAM_MANIP_ZOOM, &CMeshStudioDoc::OnUpdateCamManipZoom)
	ON_COMMAND(ID_CAM_RESTORE_VIEW, &CMeshStudioDoc::OnCamRestoreView)
	ON_COMMAND(ID_CAM_SAVE_VIEW, &CMeshStudioDoc::OnCamSaveView)
	ON_COMMAND(ID_CAM_LOAD_VIEW, &CMeshStudioDoc::OnCamLoadView)
	ON_COMMAND(ID_CAM_VIEW_ALL, &CMeshStudioDoc::OnCamViewAll)
	ON_COMMAND(ID_CAM_MANIP_ANIM_SPIN, &CMeshStudioDoc::OnCamManipAnimSpin)
	ON_UPDATE_COMMAND_UI(ID_CAM_MANIP_ANIM_SPIN, &CMeshStudioDoc::OnUpdateCamManipAnimSpin)
	ON_COMMAND(ID_CAM_MANIP_ANIM_SPIN_Y, &CMeshStudioDoc::OnCamManipAnimSpinY)
	ON_UPDATE_COMMAND_UI(ID_CAM_MANIP_ANIM_SPIN_Y, &CMeshStudioDoc::OnUpdateCamManipAnimSpinY)
	ON_COMMAND(ID_CAM_MANIP_SPIN_X, &CMeshStudioDoc::OnCamManipSpinX)
	ON_COMMAND(ID_CAM_MANIP_SPIN_R_X, &CMeshStudioDoc::OnCamManipSpinRX)
	ON_COMMAND(ID_CAM_MANIP_SPIN_Y, &CMeshStudioDoc::OnCamManipSpinY)
	ON_COMMAND(ID_CAM_MANIP_SPIN_R_Y, &CMeshStudioDoc::OnCamManipSpinRY)
	ON_COMMAND(ID_CAM_MANIP_SPIN_Z, &CMeshStudioDoc::OnCamManipSpinZ)
	ON_COMMAND(ID_CAM_MANIP_SPIN_R_Z, &CMeshStudioDoc::OnCamManipSpinRZ)
	ON_COMMAND(ID_CAM_MANIP_ZOOM_IN, &CMeshStudioDoc::OnCamManipZoomIn)
	ON_COMMAND(ID_CAM_MANIP_ZOOM_OUT, &CMeshStudioDoc::OnCamManipZoomOut)
	ON_COMMAND(ID_RENDER_AXES, &CMeshStudioDoc::OnRenderAxes)
	ON_UPDATE_COMMAND_UI(ID_RENDER_AXES, &CMeshStudioDoc::OnUpdateRenderAxes)
	ON_COMMAND(ID_FILE_EXPORT, &CMeshStudioDoc::OnFileExport)
	ON_COMMAND(ID_PICK_VERTEX, &CMeshStudioDoc::OnPickVertex)
	ON_UPDATE_COMMAND_UI(ID_PICK_VERTEX, &CMeshStudioDoc::OnUpdatePickVertex)
	ON_COMMAND(ID_SAVE_SEL_VERT, &CMeshStudioDoc::OnSaveSelVert)
	ON_UPDATE_COMMAND_UI(ID_SAVE_SEL_VERT, &CMeshStudioDoc::OnUpdateSaveSelVert)
	ON_COMMAND(ID_SAVE_SEL_TRI, &CMeshStudioDoc::OnSaveSelTri)
	ON_UPDATE_COMMAND_UI(ID_SAVE_SEL_TRI, &CMeshStudioDoc::OnUpdateSaveSelTri)
	ON_COMMAND(ID_OPEN_SEL_VERT, &CMeshStudioDoc::OnOpenSelVert)
	ON_UPDATE_COMMAND_UI(ID_OPEN_SEL_VERT, &CMeshStudioDoc::OnUpdateOpenSelVert)
	ON_COMMAND(ID_OPEN_SEL_TRI, &CMeshStudioDoc::OnOpenSelTri)
	ON_UPDATE_COMMAND_UI(ID_OPEN_SEL_TRI, &CMeshStudioDoc::OnUpdateOpenSelTri)
	ON_COMMAND(ID_UNPICK_VERTEX, OnUnpickVertex)
	ON_UPDATE_COMMAND_UI(ID_UNPICK_VERTEX, OnUpdateUnpickVertex)
	ON_COMMAND(ID_PICK_TRIANGLE, &CMeshStudioDoc::OnPickTriangle)
	ON_UPDATE_COMMAND_UI(ID_PICK_TRIANGLE, &CMeshStudioDoc::OnUpdatePickTriangle)
	ON_COMMAND(ID_RENDER_BOUNDINGBOX, &CMeshStudioDoc::OnRenderBoundingbox)
	ON_UPDATE_COMMAND_UI(ID_RENDER_BOUNDINGBOX, &CMeshStudioDoc::OnUpdateRenderBoundingbox)
	ON_COMMAND(ID_RENDER_MODE_FILL, &CMeshStudioDoc::OnRenderModeFill)
	ON_UPDATE_COMMAND_UI(ID_RENDER_MODE_FILL, &CMeshStudioDoc::OnUpdateRenderModeFill)
	ON_COMMAND(ID_RENDER_MODE_POINT, &CMeshStudioDoc::OnRenderModePoint)
	ON_UPDATE_COMMAND_UI(ID_RENDER_MODE_POINT, &CMeshStudioDoc::OnUpdateRenderModePoint)
	ON_COMMAND(ID_RENDER_MODE_LINE, &CMeshStudioDoc::OnRenderModeLine)
	ON_UPDATE_COMMAND_UI(ID_RENDER_MODE_LINE, &CMeshStudioDoc::OnUpdateRenderModeLine)
	ON_COMMAND(ID_RENDER_MODE_FILL_LINE, &CMeshStudioDoc::OnRenderModeFillLine)
	ON_UPDATE_COMMAND_UI(ID_RENDER_MODE_FILL_LINE, &CMeshStudioDoc::OnUpdateRenderModeFillLine)
	ON_COMMAND(ID_SAVE_S_HVF, &CMeshStudioDoc::OnSaveSiteHVF)
	ON_COMMAND(ID_HFV_SAMPLE, &CMeshStudioDoc::OnHVFSample)
	ON_COMMAND(ID_CRESTLINE_OPEN, &CMeshStudioDoc::OnOpenCrest)
	ON_UPDATE_COMMAND_UI(ID_CRESTLINE_OPEN, &CMeshStudioDoc::OnUpdateOpenCrest)
END_MESSAGE_MAP()

// CMeshStudioDoc construction/destruction

CMeshStudioDoc::CMeshStudioDoc()
{
	// TODO: add one-time construction code here
	m_pMesh = NULL;
	m_pCrestline = NULL;
	m_bClosing = FALSE;
	m_method_curvature = 0;
	m_sMeshPathName = "";
}

CMeshStudioDoc::~CMeshStudioDoc()
{
	SAFE_DELETE(m_pMesh);
	SAFE_DELETE(m_pCrestline);
}

BOOL CMeshStudioDoc::OnNewDocument()
{
	m_pView->m_bDrawAxes = true;
	
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

// CMeshStudioDoc serialization
void CMeshStudioDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CMeshStudioDoc diagnostics

#ifdef _DEBUG
void CMeshStudioDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMeshStudioDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CMeshStudioDoc commands

BOOL CMeshStudioDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if(!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	m_sMeshPathName = lpszPathName;
	LoadMesh(m_sMeshPathName, m_pMesh);
	return TRUE;
}

BOOL CMeshStudioDoc::SaveModel(LPCTSTR lpszPathName, Mesh *pMesh)
{
	CString sPath = lpszPathName;
	sPath = sPath.Left(sPath.ReverseFind('\\'));
	// Current path
	SetCurrentDirectory(sPath);

	// Get extension
	CString sExtension = lpszPathName;
	sExtension = sExtension.Right(sExtension.GetLength()-sExtension.ReverseFind('.')-1);
	sExtension.MakeLower();
	// save off file 
	if (sExtension == "off")
	{
		// OFF extension
		std::ofstream stream(lpszPathName);
		if(!stream) {
			return FALSE;
		}
		StatusMessage("Saving OFF file...");
	//	pMesh->ununitize();
		stream << *pMesh;
	//	pMesh->unitize();
		StatusMessage("Saving OFF file...done");
	}
	else if (sExtension == "wrl")
	{
		// WRL extension
		std::ofstream stream(lpszPathName);
		if (!stream) {
			return FALSE;
		}
		CGAL::VRML_2_ostream out(stream);
		StatusMessage("Saving WRL file...");
		out << *pMesh;
		StatusMessage("Saving WRL file...done");
	}
	// save obj file 
	else if (sExtension == "obj")
	{
		StatusMessage("Saving OBJ file...");
		pMesh->write_obj((char *)lpszPathName);
		StatusMessage("Saving OBJ file...done");
	}
	// save ply2 file 
	else if (sExtension == "ply2")
	{
		StatusMessage("Saving PLY2 file...");
		pMesh->write_ply2((char *)lpszPathName);
		StatusMessage("Saving PLY2 file...done");
	}
	else if (sExtension == "smf")
	{
		StatusMessage("Saving SMF 2.0 file...");
		pMesh->write_smf((char *)lpszPathName);
		StatusMessage("Saving SMF 2.0 file...done");
	}
	return TRUE;
}

BOOL CMeshStudioDoc::OnSaveDocument(LPCTSTR lpszPathName)
{
	if (AfxMessageBox("Overwrite original model?", MB_OKCANCEL|MB_ICONEXCLAMATION) == IDOK)
	{
		return SaveModel(lpszPathName, m_pMesh);
	}
	return FALSE;
}

//*******************************************
// User message in status bar
//*******************************************
void CMeshStudioDoc::StatusMessage(char* fmt,...)
{   
	CWinApp *pApp = AfxGetApp();
	if(pApp->m_pMainWnd != NULL) 
	{ 
		char buffer[256];
		CStatusBar* pStatus = 
			(CStatusBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(
			AFX_IDW_STATUS_BAR);
		
		// fill buffer
		va_list argptr;      
		va_start(argptr,fmt);
		vsprintf(buffer,fmt,argptr);
		va_end(argptr);
		
		if(pStatus != NULL) 
		{
			pStatus->SetPaneText(0,buffer);
			pStatus->UpdateWindow(); 
		}
  }
	return;
}

//*******************************************
// update mesh properties in status bar
//*******************************************
void CMeshStudioDoc::UpdateMeshProperties(Mesh *pMesh, bool update_component, bool update_boundary)
{
	CWinApp *pApp = AfxGetApp();
	if(pApp->m_pMainWnd != NULL) 
	{ 
		CStatusBar* pStatus = 
			(CStatusBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(
			AFX_IDW_STATUS_BAR);
		
		if(pStatus != NULL) 
		{
			static unsigned int c = 0;
			if (update_component)
				c = pMesh->nb_components();
			static unsigned int b = 0;
			if (update_boundary)
				b = pMesh->nb_boundaries();
			unsigned int v = pMesh->size_of_vertices();
			unsigned int e = pMesh->size_of_halfedges()/2;
			unsigned int f = pMesh->size_of_facets();
			unsigned int g = pMesh->genus(c,v,f,e,b);

			// components
			CString components;
			components.Format("%d component%c",c,(c>1) ? 's' : ' ');

			// vertices
			CString vertices;
			vertices.Format("%d vertices",v);

			// facets
			CString facets;
			facets.Format("%d facets",f);

			// edges
			CString edges;
			edges.Format("%d edges",e);

			// boundaries
			CString boundaries;
			if (b == 0) {
				boundaries.Format("no boundary");
			} else {
				if (b == 1)
					boundaries.Format("1 boundary");
				else
					boundaries.Format("%d boundaries",b);
			}
			// genus
			CString genus;
			genus.Format("genus %d",g);
			pStatus->SetPaneText(1,components);
			pStatus->SetPaneText(2,vertices);
			pStatus->SetPaneText(3,facets);
			pStatus->SetPaneText(4,edges);
			pStatus->SetPaneText(5,boundaries);
			pStatus->SetPaneText(6,genus);
			pStatus->UpdateWindow(); 
		}
  }
}

//*******************************************
// reset mesh properties in status bar
//*******************************************
void CMeshStudioDoc::ResetMeshProperties()
{   
	if(AfxGetApp()->m_pMainWnd != NULL) 
	{ 
		CStatusBar* pStatus = 
			(CStatusBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(
			AFX_IDW_STATUS_BAR);
		if(pStatus != NULL) 
		{
			pStatus->SetPaneText(1,CString(""));
			pStatus->SetPaneText(2,CString(""));
			pStatus->SetPaneText(3,CString(""));
			pStatus->SetPaneText(4,CString(""));
			pStatus->SetPaneText(5,CString(""));
			pStatus->SetPaneText(6,CString(""));
			pStatus->UpdateWindow(); 
		}
  }
}
void CMeshStudioDoc::OnCloseDocument()
{
	ResetMeshProperties();
	m_bClosing = TRUE;
	CMainFrame *pFrameWnd = (CMainFrame*)AfxGetMainWnd();
	if (pFrameWnd->m_bFullScreenMode) {
		pFrameWnd->FullScreenModeOff();
	}
	CDocument::OnCloseDocument();
}

// Reload mesh data from current mesh data file
bool CMeshStudioDoc::ReloadMesh(Mesh *&pMesh)
{
	if (pMesh == NULL) {
		return false;
	}
	delete pMesh;
	pMesh = NULL;
	return LoadMesh(m_sMeshPathName, pMesh);
}

// Load mesh data from a mesh file
bool CMeshStudioDoc::LoadMesh(const CString &sMeshPathName, Mesh *&pMesh)
{
	CString sPath = sMeshPathName;
	sPath = sPath.Left(sPath.ReverseFind('\\'));
	// Current path
	SetCurrentDirectory(sPath);

	// Get extension
	CString sExtension = sMeshPathName;
	sExtension = sExtension.Right(sExtension.GetLength()-sExtension.ReverseFind('.')-1);
	sExtension.MakeLower();

	// off extension
	if (sExtension == "off")
	{
		pMesh = new Enriched_polyhedron<Enriched_kernel, Enriched_items>;
		CGAL_assertion(pMesh != NULL);
		// read from stream 
		std::ifstream stream(sMeshPathName);
		if (!stream)
		{
			CString s;
			s.Format("LoadMesh: cannot open file %s", sMeshPathName);
			AfxMessageBox(s);
			return false;
		}
		stream >> *pMesh;
	}
	else if (sExtension == "obj")
	{
		pMesh = new Enriched_polyhedron<Enriched_kernel, Enriched_items>;
		CGAL_assertion(pMesh != NULL);
		Parser_obj<Enriched_kernel, Enriched_items> parser;
		parser.read(sMeshPathName, pMesh);
	}
	else if (sExtension == "wrl")
	{
		pMesh = new Enriched_polyhedron<Enriched_kernel, Enriched_items>;
		CGAL_assertion(pMesh != NULL);
		Parser_wrl<Enriched_kernel, Enriched_items> parser;
		parser.read(sMeshPathName, pMesh);
	}
	else if (sExtension == "smf")
	{
		pMesh = new Enriched_polyhedron<Enriched_kernel, Enriched_items>;
		CGAL_assertion(pMesh != NULL);
		Parser_smf<Enriched_kernel, Enriched_items> parser;
		parser.read(sMeshPathName, pMesh);
	}
	else
	{
		AfxMessageBox("LoadMesh: extension not supported");
		return false;
	}

	m_pView->SetRenderingContext();
	// update mesh properties in the status bar 
	// and compute normals
	pMesh->unitize();
	pMesh->compute_type();
	UpdateMeshProperties(pMesh, true, true);
	pMesh->set_id_to_items_map();
	pMesh->set_hds_items_id();
	pMesh->compute_normals();
	//m_pMesh->gl_build_display_list(true, true, false);
	pMesh->gl_build_vbo(true, true, false);
	pMesh->gl_build_bounding_box_disp_list();

	return true;
}

void CMeshStudioDoc::OnFileReload()
{
	// TODO: Add your command handler code here
	BeginWaitCursor();
	ReloadMesh(m_pMesh);
	EndWaitCursor();
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnUpdateFileReload(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_pMesh != NULL);
}

void CMeshStudioDoc::OnCamManipSpin()
{
	// TODO: Add your command handler code here
	m_pView->m_pTrackBall->SetAnimate(FALSE);
	m_pView->m_MouseLBAction = MLBA_CAM_SPIN;
}

void CMeshStudioDoc::OnUpdateCamManipSpin(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_pView->m_MouseLBAction == MLBA_CAM_SPIN);
}

void CMeshStudioDoc::OnCamManipZoom()
{
	// TODO: Add your command handler code here
	m_pView->m_MouseLBAction = MLBA_CAM_ZOOM;
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
}

void CMeshStudioDoc::OnUpdateCamManipZoom(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_pView->m_MouseLBAction == MLBA_CAM_ZOOM);
}

void CMeshStudioDoc::OnCamManipMove()
{
	// TODO: Add your command handler code here
	m_pView->m_MouseLBAction = MLBA_CAM_MOVE;
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
}

void CMeshStudioDoc::OnUpdateCamManipMove(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_pView->m_MouseLBAction == MLBA_CAM_MOVE);
}

void CMeshStudioDoc::OnCamRestoreView()
{
	// TODO: Add your command handler code here
	m_pView->InitCamera();
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamSaveView()
{
	CString sFilename;
	CFileDialog *cfdSaveCV;
	static char BASED_CODE szFilter[] = "Camera View(*.cmv)|*.cmv|All Files (*.*)|*.*||";
	cfdSaveCV = new CFileDialog(FALSE, "cmv", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSaveCV->m_ofn.lpstrTitle ="Save camera view";
	if (cfdSaveCV->DoModal() == IDOK)
	{
		sFilename = cfdSaveCV->GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ofstream stream(sFilename);
			if(!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
				return;
			}
			stream << m_pView->m_fCamMove[0] << std::endl;
			stream << m_pView->m_fCamMove[1] << std::endl;
			stream << m_pView->m_fCamMove[2] << std::endl;
			stream << m_pView->m_fCamZoom << std::endl;
			FTP mat[16];
			m_pView->m_pTrackBall->GetTBMatrix(mat);
			for (int i=0; i<16; i++) {
				stream << mat[i] << std::endl;
			}
		}
	}
}

void CMeshStudioDoc::OnCamLoadView()
{
	CString sFilename;
	static char BASED_CODE szFilter[] = "Camera View(*.cmv)|*.cmv|All Files (*.*)|*.*||";
	CFileDialog cfdOpenCV(TRUE, "cmv", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdOpenCV.m_ofn.lpstrTitle ="Open camera view";
	if (cfdOpenCV.DoModal() == IDOK)
	{
		sFilename = cfdOpenCV.GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ifstream stream(sFilename);
			if(!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
				return;
			}
			stream >> m_pView->m_fCamMove[0];
			stream >> m_pView->m_fCamMove[1];
			stream >> m_pView->m_fCamMove[2];
			stream >> m_pView->m_fCamZoom;
			FTP mat[16];
			for (int i=0; i<16; i++) {
				stream >> mat[i];
			}
			m_pView->m_pTrackBall->SetTBMatrix(mat);
			m_pView->InvalidateRect(NULL, FALSE);
		}
	}
}

void CMeshStudioDoc::OnCamViewAll()
{
	// TODO: Add your command handler code here
}

void CMeshStudioDoc::OnCamManipAnimSpin()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	} else {
		m_pView->m_pTrackBall->SetAnimate(TRUE);
	}
}

void CMeshStudioDoc::OnUpdateCamManipAnimSpin(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_pView->m_MouseLBAction == MLBA_CAM_SPIN && m_pView->m_pTrackBall->GetAnimate());
	pCmdUI->Enable(m_pView->m_MouseLBAction == MLBA_CAM_SPIN);
}

void CMeshStudioDoc::OnCamManipAnimSpinY()
{
	// TODO: Add your command handler code here
	if (m_pView->m_MouseLBAction == MLBA_AA_SPIN_Y) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
		m_pView->m_MouseLBAction = MLBA_CAM_SPIN;
	} else {
		m_pView->m_pTrackBall->SetMotionSpinY();
		m_pView->m_pTrackBall->SetAnimate(TRUE);
		m_pView->m_MouseLBAction = MLBA_AA_SPIN_Y;
	}
}

void CMeshStudioDoc::OnUpdateCamManipAnimSpinY(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_pView->m_pTrackBall->GetAnimate() && m_pView->m_MouseLBAction==MLBA_AA_SPIN_Y);
}

void CMeshStudioDoc::OnCamManipSpinX()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_pTrackBall->Rotate(5.0f, Vector3(1.0f, 0.0f, 0.0f));
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipSpinRX()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_pTrackBall->Rotate(5.0f, Vector3(-1.0f, 0.0f, 0.0f));
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipSpinY()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_pTrackBall->Rotate(5.0f, Vector3(0.0f, 1.0f, 0.0f));
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipSpinRY()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_pTrackBall->Rotate(5.0f, Vector3(0.0f, -1.0f, 0.0f));
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipSpinZ()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_pTrackBall->Rotate(5.0f, Vector3(0.0f, 0.0f, 1.0f));
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipSpinRZ()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_pTrackBall->Rotate(5.0f, Vector3(0.0f, 0.0f, -1.0f));
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipZoomIn()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_fCamZoom += 160.0f * m_pView->m_fSpeedCamZoom * 0.4f;
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnCamManipZoomOut()
{
	// TODO: Add your command handler code here
	if (m_pView->m_pTrackBall->GetAnimate()) {
		m_pView->m_pTrackBall->SetAnimate(FALSE);
	}
	m_pView->m_fCamZoom -= 160.0f * m_pView->m_fSpeedCamZoom * 0.4f;
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnRenderAxes()
{
	// TODO: Add your command handler code here
	m_pView->m_bDrawAxes = !m_pView->m_bDrawAxes;
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnUpdateRenderAxes(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_pView->m_bDrawAxes);
}

void CMeshStudioDoc::OnFileExport()
{
	// TODO: Add your command handler code here
	CString sPathName;
	CFileDialog *cfdSaveMeshAs;
	static char BASED_CODE szFilter[] = "VRML 2.0 (*.wrl)|*.wrl|\
										OBJ File Format (*.off)|*.off|\
										Wave Front Format (*.obj)|*.obj|\
										Stanford PLY2 (*.ply2)|*.ply2|\
										Michael Garland's SMF 2.0 (*.smf)|*.smf|\
										All Files (*.*)|*.*||";

	cfdSaveMeshAs = new CFileDialog(FALSE, "wrl", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSaveMeshAs->m_ofn.lpstrTitle = "Export model";
	if (cfdSaveMeshAs->DoModal() == IDOK)
	{
		sPathName = cfdSaveMeshAs->GetPathName();
		if (!sPathName.IsEmpty()) {
			BeginWaitCursor();
			SaveModel(sPathName, m_pMesh);
			EndWaitCursor();
		}
	}
}

void CMeshStudioDoc::OnPickVertex()
{
	// TODO: Add your command handler code here
	COptionFormView *pFView = m_pView->GetOptionFormView();
	if (m_pView->m_MouseLBAction==MLBA_PICK 
		&& m_pView->m_PickItem==PI_VERTEX
		&& !m_pView->m_bUnpickVert) 
	{
		m_pView->m_MouseLBAction = MLBA_CAM_SPIN;
		pFView->SetDlgItemText(IDC_STATIC_PI, "Item");
	} else {
		m_pView->m_MouseLBAction = MLBA_PICK;
		m_pView->m_PickItem = PI_VERTEX;
		m_pView->m_bUnpickVert = FALSE;
		if (m_pView->m_pTrackBall->GetAnimate()) {
			m_pView->m_pTrackBall->SetAnimate(FALSE);
		}
		m_pView->InvalidateRect(NULL, FALSE);
		pFView->SetDlgItemText(IDC_STATIC_PI, "Vertex");
	}
}

void CMeshStudioDoc::OnUpdatePickVertex(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->m_MouseLBAction==MLBA_PICK 
					&& m_pView->m_PickItem==PI_VERTEX
					&& !m_pView->m_bUnpickVert);
}

void CMeshStudioDoc::OnSaveSelVert()
{
	CString sFilename;
	CFileDialog *cfdSaveSlv;
	static char BASED_CODE szFilter[] = "Selected vertices(*.slv)|*.slv|All Files (*.*)|*.*||";
	cfdSaveSlv = new CFileDialog(FALSE, "slv", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSaveSlv->m_ofn.lpstrTitle ="Save selected vertices";
	if (cfdSaveSlv->DoModal() == IDOK)
	{
		sFilename = cfdSaveSlv->GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ofstream stream(sFilename);
			if (!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
			} else {
				m_pMesh->write_picked_vertices(stream);
			}
		}
	}
}

void CMeshStudioDoc::OnUpdateSaveSelVert(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL 
					&& m_pMesh->nb_picked_vertices()>0
					&& m_pView->m_PickItem==PI_VERTEX);
}

void CMeshStudioDoc::OnSaveSelTri()
{
	CString sFilename;
	CFileDialog *cfdSaveSlt;
	static char BASED_CODE szFilter[] = "Selected vertices(*.slt)|*.slt|All Files (*.*)|*.*||";
	cfdSaveSlt = new CFileDialog(FALSE, "slt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSaveSlt->m_ofn.lpstrTitle ="Save selected triangles";
	if (cfdSaveSlt->DoModal() == IDOK)
	{
		sFilename = cfdSaveSlt->GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ofstream stream(sFilename);
			if (!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
			} else {
				m_pMesh->write_picked_facets(stream);
			}
		}
	}
}

void CMeshStudioDoc::OnUpdateSaveSelTri(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL 
		&& m_pMesh->nb_picked_facets()>0
		&& m_pView->m_PickItem==PI_TRIANGLE);
}

void CMeshStudioDoc::OnOpenSelVert()
{
	CString sFilename;
	static char BASED_CODE szFilter[] = "Selected vertices(*.slv)|*.slv|All Files (*.*)|*.*||";
	CFileDialog cfdOpenSlv(TRUE, "slv", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdOpenSlv.m_ofn.lpstrTitle ="Open selected vertices";
	if (cfdOpenSlv.DoModal() == IDOK)
	{
		sFilename = cfdOpenSlv.GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ifstream stream(sFilename);
			if(!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
			} else {
				m_pMesh->read_picked_vertices(stream);
				m_pView->m_PickItem = PI_VERTEX;
				m_pView->InvalidateRect(NULL, FALSE);
			}
		}
	}
}

void CMeshStudioDoc::OnUpdateOpenSelVert(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh != NULL);
}

void CMeshStudioDoc::OnOpenSelTri()
{
	CString sFilename;
	static char BASED_CODE szFilter[] = "Selection triangles(*.slt)|*.slt|All Files (*.*)|*.*||";
	CFileDialog cfdOpenSlf(TRUE, "slt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdOpenSlf.m_ofn.lpstrTitle ="Open selection triangles";
	if (cfdOpenSlf.DoModal() == IDOK)
	{
		sFilename = cfdOpenSlf.GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ifstream stream(sFilename);
			if(!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
			} else {
				m_pMesh->read_picked_facets(stream);
				m_pView->m_PickItem = PI_TRIANGLE;
				m_pView->InvalidateRect(NULL, FALSE);
			}
		}
	}
}

void CMeshStudioDoc::OnUpdateOpenSelTri(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh != NULL);
}

void CMeshStudioDoc::OnUnpickVertex()
{
	if (m_pView->m_MouseLBAction==MLBA_PICK 
		&& m_pView->m_PickItem==PI_VERTEX
		&& m_pView->m_bUnpickVert) 
	{
		m_pView->m_MouseLBAction = MLBA_CAM_SPIN;
	} else {
		m_pView->m_MouseLBAction = MLBA_PICK;
		m_pView->m_bUnpickVert = TRUE;
		m_pView->m_PickItem = PI_VERTEX;
		if (m_pView->m_pTrackBall->GetAnimate()) {
			m_pView->m_pTrackBall->SetAnimate(FALSE);
		}
		m_pView->InvalidateRect(NULL, FALSE);
	}
}

void CMeshStudioDoc::OnUpdateUnpickVertex(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->m_MouseLBAction==MLBA_PICK 
						&& m_pView->m_PickItem==PI_VERTEX
						&& m_pView->m_bUnpickVert);
}

void CMeshStudioDoc::OnPickTriangle()
{
	// TODO: Add your command handler code here
	COptionFormView *pFView = m_pView->GetOptionFormView();
	if (m_pView->m_MouseLBAction==MLBA_PICK && m_pView->m_PickItem==PI_TRIANGLE) {
		m_pView->m_MouseLBAction = MLBA_CAM_SPIN;
		pFView->SetDlgItemText(IDC_STATIC_PI, "Item");
	} else {
		m_pView->m_MouseLBAction = MLBA_PICK;
		m_pView->m_PickItem = PI_TRIANGLE;
		if (m_pView->m_pTrackBall->GetAnimate()) {
			m_pView->m_pTrackBall->SetAnimate(FALSE);
		}
		m_pView->InvalidateRect(NULL, FALSE);
		pFView->SetDlgItemText(IDC_STATIC_PI, "Facet");
	}
}

void CMeshStudioDoc::OnUpdatePickTriangle(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->m_MouseLBAction==MLBA_PICK && m_pView->m_PickItem==PI_TRIANGLE);
}

void CMeshStudioDoc::OnRenderBoundingbox()
{
	// TODO: Add your command handler code here
	m_pView->m_bBoundingBox = !m_pView->m_bBoundingBox;
	m_pView->InvalidateRect(NULL, FALSE);
}

void CMeshStudioDoc::OnUpdateRenderBoundingbox(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->m_bBoundingBox);
}

void CMeshStudioDoc::OnRenderModeFill()
{
	// TODO: Add your command handler code here
	COptionFormView *pFView = m_pView->GetOptionFormView();
	pFView->m_radioPlgPoint.SetCheck(0);
	pFView->m_radioPlgLine.SetCheck(0);
	pFView->m_radioPlgFL.SetCheck(0);
	pFView->m_radioPlgFace.SetCheck(1);
	pFView->OnBnClickedRadioPlgFace();
}

void CMeshStudioDoc::OnUpdateRenderModeFill(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->GetOptionFormView()->m_radioPlgFace.GetCheck());
}

void CMeshStudioDoc::OnRenderModePoint()
{
	// TODO: Add your command handler code here
	COptionFormView *pFView = m_pView->GetOptionFormView();
	pFView->m_radioPlgPoint.SetCheck(1);
	pFView->m_radioPlgLine.SetCheck(0);
	pFView->m_radioPlgFL.SetCheck(0);
	pFView->m_radioPlgFace.SetCheck(0);
	pFView->OnBnClickedRadioPlgPoint();
}

void CMeshStudioDoc::OnUpdateRenderModePoint(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->GetOptionFormView()->m_radioPlgPoint.GetCheck());
}

void CMeshStudioDoc::OnRenderModeLine()
{
	// TODO: Add your command handler code here
	COptionFormView *pFView = m_pView->GetOptionFormView();
	pFView->m_radioPlgPoint.SetCheck(0);
	pFView->m_radioPlgLine.SetCheck(1);
	pFView->m_radioPlgFL.SetCheck(0);
	pFView->m_radioPlgFace.SetCheck(0);
	pFView->OnBnClickedRadioPlgLine();
}

void CMeshStudioDoc::OnUpdateRenderModeLine(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->GetOptionFormView()->m_radioPlgLine.GetCheck());
}

void CMeshStudioDoc::OnRenderModeFillLine()
{
	// TODO: Add your command handler code here
	COptionFormView *pFView = m_pView->GetOptionFormView();
	pFView->m_radioPlgPoint.SetCheck(0);
	pFView->m_radioPlgLine.SetCheck(0);
	pFView->m_radioPlgFL.SetCheck(1);
	pFView->m_radioPlgFace.SetCheck(0);
	pFView->OnBnClickedRadioPlgFL();
}

void CMeshStudioDoc::OnUpdateRenderModeFillLine(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_pMesh!=NULL);
	pCmdUI->SetCheck(m_pView->GetOptionFormView()->m_radioPlgFL.GetCheck());
}

void CMeshStudioDoc::OnSaveSiteHVF()
{
	CString sFilename;
	CFileDialog *cfdSaveHF;
	static char BASED_CODE szFilter[] = "Site-based Harmonic Vector Field (*.shvf)|*.shvf|All Files (*.*)|*.*||";
	cfdSaveHF = new CFileDialog(FALSE, "shvf", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSaveHF->m_ofn.lpstrTitle = "Save site-based harmonic vector fields";
	if (cfdSaveHF->DoModal() == IDOK)
	{
		sFilename = cfdSaveHF->GetPathName();
		if (!sFilename.IsEmpty()) {
			std::ofstream stream(sFilename);
			if (!stream) {
				CString s;
				s.Format("Cannot open file: %s!", sFilename);
				AfxMessageBox(s);
			} else {
				BeginWaitCursor();
				if (!m_pMesh->is_s_hvf_uptodate()) {
					m_pMesh->compute_s_hvf();
				}
				m_pMesh->write_s_hvf(stream);
				EndWaitCursor();
			}
		}
	}
}

void CMeshStudioDoc::OnHVFSample()
{
	CDlgHFVSampleSetting dlg;
	if (dlg.DoModal() == IDOK) {
		BeginWaitCursor();
		m_pMesh->do_sampling_for_hvf_show(dlg.m_fRadia);
		EndWaitCursor();
		m_pView->InvalidateRect(NULL, FALSE);
	}
}

void CMeshStudioDoc::OnOpenCrest()
{
	if (m_pCrestline == NULL) {
		m_pCrestline = new Crestline(m_pMesh);
	}
	CString sFilename;
	static char BASED_CODE szFilter[] = "Cleaned crest lines (*ccl)|*.ccl|Shin's crest lines (*.txt)|*.txt|All Files (*.*)|*.*||";
	CFileDialog cfdOpenHF(TRUE, "ccl", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdOpenHF.m_ofn.lpstrTitle ="Open ridge lines";
	if (cfdOpenHF.DoModal() == IDOK) {
		sFilename = cfdOpenHF.GetPathName();
		if (!sFilename.IsEmpty()) {
			BeginWaitCursor();
			StatusMessage("Loading crest lines...");
			double start = clock();
			if (m_pCrestline->load_crestlines(sFilename) != -1) {
				if (m_pView->m_pDlgCrestParam->GetSafeHwnd() == 0) {
					m_pView->m_pDlgCrestParam->Create();	// display the non-modal dialog
				} else {
					m_pView->m_pDlgCrestParam->ShowWindow(SW_SHOW);
				}
				m_pView->InvalidateRect(NULL, FALSE);
				double duration = (double)((clock()-start)/CLOCKS_PER_SEC);
				StatusMessage("Loading crest lines... done! (%g s)", duration);
			} else {
				StatusMessage("Loading crest lines... failed!");
			}
			EndWaitCursor();
		}
	}
}

void CMeshStudioDoc::OnUpdateOpenCrest(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_pMesh!=NULL);
}