// OptionFormView.cpp :
//

#include "stdafx.h"
#include "MeshStudio.h"
#include "OptionFormView.h"
#include "MeshStudioView.h"
#include ".\optionformview.h"
#include "lib\3D\PsudoColorRGB.h"


// COptionFormView

IMPLEMENT_DYNCREATE(COptionFormView, CFormView)

COptionFormView::COptionFormView()
	: CFormView(COptionFormView::IDD)
	, m_bPointAntialias(false)
	, m_bLineAntialias(false)
{
}

COptionFormView::~COptionFormView()
{
}

void COptionFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_FRAME_COLOR_BACK, m_ctrlBackColor);
	DDX_Control(pDX, IDC_FRAME_COLOR_MAT_AMB, m_ctrlMatAmb);
	DDX_Control(pDX, IDC_FRAME_COLOR_MAT_DIF, m_ctrlMatDif);
	DDX_Control(pDX, IDC_FRAME_COLOR_MAT_SPEC, m_ctrlMatSpec);
	DDX_Control(pDX, IDC_SLIDER_MAT_SHN, m_sliderMatShn);
	DDX_Control(pDX, IDC_SLIDER_PCR_LOW, m_sliderPCRLow);
	DDX_Control(pDX, IDC_SLIDER_PCR_HIGH, m_sliderPCRHigh);
	DDX_Control(pDX, IDC_SLIDER_MAT_TRANS, m_sliderMatTrans);
	DDX_Control(pDX, IDC_CHECK_PLG_P_ANTIALIAS, m_checkPlgPointAntialias);
	DDX_Control(pDX, IDC_CHECK_PLG_L_ANTIALIAS, m_checkPlgLineAntialias);
	DDX_Control(pDX, IDC_CHECK_PLG_F_SMOOTH, m_checkPlgFaceSmooth);
	DDX_Control(pDX, IDC_RADIO_PLG_FACE, m_radioPlgFace);
	DDX_Control(pDX, IDC_RADIO_PLG_LINE, m_radioPlgLine);
	DDX_Control(pDX, IDC_RADIO_PLG_POINT, m_radioPlgPoint);
	DDX_Control(pDX, IDC_RADIO_ORTHO, m_radioOrtho);
	DDX_Control(pDX, IDC_RADIO_PERSP, m_radioPersp);
	DDX_Control(pDX, IDC_RADIO_PLG_FL, m_radioPlgFL);
	DDX_Control(pDX, IDC_CHECK_MAT_TRANS, m_checkMatTrans);
	DDX_Control(pDX, IDC_CHECK_PLG_CULL, m_checkPlgCull);
	DDX_Control(pDX, IDC_COMBO_MAT_PREDEDINE, m_comboMatPredefine);
	DDX_Control(pDX, IDC_COMBO_PC_TYPE, m_comboPCType);
	DDX_Control(pDX, IDC_FRAME_PCOLOR_RAMP, m_ctrlPColorRamp);
	DDX_Control(pDX, IDC_EDIT_SV_ID, m_editSVId);
	DDX_Control(pDX, IDC_CHECK_SV, m_checkShowVert);
	DDX_Control(pDX, IDC_DEPTH_SORT, m_btnDepthSort);
}

BEGIN_MESSAGE_MAP(COptionFormView, CFormView)
	ON_WM_MBUTTONUP()
	ON_WM_PAINT()
	ON_WM_LBUTTONUP()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_CHECK_MAT_TRANS, &COptionFormView::OnBnClickedCheckMatTrans)
	ON_BN_CLICKED(IDC_RADIO_PLG_POINT, &COptionFormView::OnBnClickedRadioPlgPoint)
	ON_BN_CLICKED(IDC_RADIO_PLG_LINE, &COptionFormView::OnBnClickedRadioPlgLine)
	ON_BN_CLICKED(IDC_RADIO_ORTHO, &COptionFormView::OnBnClickedRadioProjOrtho)
	ON_BN_CLICKED(IDC_RADIO_PERSP, &COptionFormView::OnBnClickedRadioProjPersp)
	ON_BN_CLICKED(IDC_RADIO_PLG_FACE, &COptionFormView::OnBnClickedRadioPlgFace)
	ON_BN_CLICKED(IDC_RADIO_PLG_FL, &COptionFormView::OnBnClickedRadioPlgFL)
	ON_BN_CLICKED(IDC_CHECK_PLG_P_ANTIALIAS, &COptionFormView::OnBnClickedCheckPlgPAntialias)
	ON_BN_CLICKED(IDC_CHECK_PLG_L_ANTIALIAS, &COptionFormView::OnBnClickedCheckPlgLAntialias)
	ON_BN_CLICKED(IDC_CHECK_PLG_F_SMOOTH, &COptionFormView::OnBnClickedCheckPlgFSmooth)
	ON_BN_CLICKED(IDC_CHECK_PLG_CULL, &COptionFormView::OnBnClickedCheckPlgCull)
	ON_CBN_SELCHANGE(IDC_COMBO_MAT_PREDEDINE, &COptionFormView::OnCbnSelchangeComboMatPrededine)
	ON_CBN_SELCHANGE(IDC_COMBO_PC_TYPE, &COptionFormView::OnCbnSelchangeComboPCType)
	ON_BN_CLICKED(IDC_MAT_SAVE, &COptionFormView::OnBnClickedMatSave)
	ON_BN_CLICKED(IDC_MAT_LOAD, &COptionFormView::OnBnClickedMatLoad)
	ON_BN_CLICKED(IDC_DEPTH_SORT, &COptionFormView::OnDepthSort)
	ON_BN_CLICKED(IDC_CHECK_SV, &COptionFormView::OnBnClickedShowVert)
	ON_EN_CHANGE(IDC_EDIT_SV_ID, &COptionFormView::OnEnChangeEditSVId)
END_MESSAGE_MAP()


// COptionFormView 

#ifdef _DEBUG
void COptionFormView::AssertValid() const
{
	CFormView::AssertValid();
}

void COptionFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CMeshStudioView* COptionFormView::GetMeshStudioView()
{
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	CMainFrame *pMainFrame = (CMainFrame *)pApp->m_pMainWnd;
	CChildFrame *pFrame = (CChildFrame *)pMainFrame->GetActiveFrame();
	CMeshStudioView *pView = (CMeshStudioView *)pFrame->m_wndSplitter.GetPane(0, 0);
	return pView;
}

CMeshStudioDoc* COptionFormView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMeshStudioDoc)));
	return (CMeshStudioDoc*)m_pDocument;
}
#endif //_DEBUG


// COptionFormView ��Ϣ��������

void COptionFormView::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	
	// Options are stored in Application
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	CRect rect;
	
	// Color back
	m_ctrlBackColor.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushBack(pApp->m_OptionColorGLBack);
	dc.FillRect(&rect, &BrushBack);
	// Color light ambient
	m_ctrlMatAmb.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushLightAmbient(pApp->m_OptionColorGLMatAmbient);
	dc.FillRect(&rect, &BrushLightAmbient);
	// Color light diffuse
	m_ctrlMatDif.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushLightDiffuse(pApp->m_OptionColorGLMatDiffuse);
	dc.FillRect(&rect, &BrushLightDiffuse);
	// Color light specular
	m_ctrlMatSpec.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushLightSpecular(pApp->m_OptionColorGLMatSpecular);
	dc.FillRect(&rect, &BrushLightSpecular);

	// Color ramp
	m_ctrlPColorRamp.GetWindowRect(&rect);
	ScreenToClient(&rect);
	GLubyte fPsudoColor[3];
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_PseudoColor.SetPCValueRange(0.0, 1.0);
	for(int i=rect.left;i<rect.right-1;i++)
	{
		pView->m_PseudoColor.GetPC(fPsudoColor, (double)(i-rect.left)/(double)rect.Width(), true);
		CBrush brush(RGB(fPsudoColor[0], fPsudoColor[1], fPsudoColor[2]));
		CRect SmallRect(i, rect.top, i+1, rect.bottom);
		dc.FillRect(&SmallRect,&brush);
	}
}

void COptionFormView::OnLButtonUp(UINT nFlags, CPoint point)
{
	CRect rect;
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();

	m_ctrlBackColor.GetWindowRect(&rect);
	ScreenToClient(&rect);
	if (rect.PtInRect(point))
	{
		CColorDialog dlg(pApp->m_OptionColorGLBack);
		if (dlg.DoModal() == IDOK)
		{
			pApp->m_OptionColorGLBack = dlg.GetColor();
			CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
			pView->m_BackColor[0] = (float)GetRValue(pApp->m_OptionColorGLBack) / 255.0f;
			pView->m_BackColor[1] = (float)GetGValue(pApp->m_OptionColorGLBack) / 255.0f;
			pView->m_BackColor[2] = (float)GetBValue(pApp->m_OptionColorGLBack) / 255.0f;
			glClearColor(pView->m_BackColor[0], pView->m_BackColor[1], pView->m_BackColor[2], 1.0f);
			this->InvalidateRect(&rect, FALSE);
			pView->InvalidateRect(NULL, FALSE);
		}
	}
	// Option ambient light color
	m_ctrlMatAmb.GetWindowRect(&rect);
	ScreenToClient(&rect);
	if (rect.PtInRect(point))
	{
		CColorDialog dlg(pApp->m_OptionColorGLMatAmbient);
		if (dlg.DoModal() == IDOK)
		{
			pApp->m_OptionColorGLMatAmbient = dlg.GetColor();	
			CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
			// Refresh Light0
			pView->m_MatAmbient[0] = (float)GetRValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
			pView->m_MatAmbient[1] = (float)GetGValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
			pView->m_MatAmbient[2] = (float)GetBValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
			glMaterialfv(GL_FRONT, GL_AMBIENT, pView->m_MatAmbient);
			GLfloat fBackMat[3];
			fBackMat[0] = 0.5f * pView->m_MatAmbient[0];
			fBackMat[1] = 0.5f * pView->m_MatAmbient[1];
			fBackMat[2] = 0.5f * pView->m_MatAmbient[2];
			glMaterialfv(GL_BACK, GL_AMBIENT, fBackMat);
			// Refresh views
			this->InvalidateRect(&rect, FALSE);
			pView->InvalidateRect(NULL, FALSE);
			m_comboMatPredefine.SetWindowText("(Not Used)");
		}
	}
	// Option diffuse light color
	m_ctrlMatDif.GetWindowRect(&rect);
	ScreenToClient(&rect);
	if (rect.PtInRect(point))
	{
		CColorDialog dlg(pApp->m_OptionColorGLMatDiffuse);
		if (dlg.DoModal() == IDOK)
		{
			pApp->m_OptionColorGLMatDiffuse = dlg.GetColor();	
			CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
			// Refresh Light0
			pView->m_MatDiffuse[0] = (float)GetRValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
			pView->m_MatDiffuse[1] = (float)GetGValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
			pView->m_MatDiffuse[2] = (float)GetBValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
			glMaterialfv(GL_FRONT, GL_DIFFUSE, pView->m_MatDiffuse);
			GLfloat fBackMat[3];
			fBackMat[0] = 0.5f * pView->m_MatDiffuse[0];
			fBackMat[1] = 0.5f * pView->m_MatDiffuse[1];
			fBackMat[2] = 0.5f * pView->m_MatDiffuse[2];
			glMaterialfv(GL_BACK, GL_DIFFUSE, fBackMat);
			// Refresh views
			this->InvalidateRect(&rect, FALSE);
			pView->InvalidateRect(NULL, FALSE);
			m_comboMatPredefine.SetWindowText("(Not Used)");
		}
	}
	// Option specular light color
	m_ctrlMatSpec.GetWindowRect(&rect);
	ScreenToClient(&rect);
	if (rect.PtInRect(point))
	{
		CColorDialog dlg(pApp->m_OptionColorGLMatSpecular);
		if (dlg.DoModal() == IDOK)
		{
			pApp->m_OptionColorGLMatSpecular = dlg.GetColor();	
			CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
			// Refresh Light0
			pView->m_MatSpecular[0] = (float)GetRValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
			pView->m_MatSpecular[1] = (float)GetGValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
			pView->m_MatSpecular[2] = (float)GetBValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
			glMaterialfv(GL_FRONT, GL_SPECULAR, pView->m_MatSpecular);
			GLfloat fBackMat[3];
			fBackMat[0] = 0.5f * pView->m_MatSpecular[0];
			fBackMat[1] = 0.5f * pView->m_MatSpecular[1];
			fBackMat[2] = 0.5f * pView->m_MatSpecular[2];
			glMaterialfv(GL_BACK, GL_SPECULAR, fBackMat);
			// Refresh views
			this->InvalidateRect(&rect, FALSE);
			pView->InvalidateRect(NULL, FALSE);
			m_comboMatPredefine.SetWindowText("(Not Used)");
		}
	}
	CFormView::OnLButtonUp(nFlags, point);
}

void COptionFormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->SetOptionFormView(this);
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();

	m_sliderPCRLow.SetRange(0, 100, TRUE);
	m_sliderPCRLow.SetPos(0);
	m_sliderPCRLow.SetTicFreq(10);
	m_sliderPCRLow.EnableWindow(TRUE);
	m_sliderPCRHigh.SetRange(0, 100, TRUE);
	m_sliderPCRHigh.SetPos(100);
	m_sliderPCRHigh.EnableWindow(TRUE);

	m_checkMatTrans.EnableWindow(TRUE);
	m_sliderMatTrans.SetRange(1, 100, TRUE);
	m_sliderMatTrans.SetPos(50);
	m_checkMatTrans.SetCheck(pView->m_bTransparent);
	m_sliderMatTrans.EnableWindow(pView->m_bTransparent);
	m_btnDepthSort.EnableWindow(pView->m_bTransparent);
	m_sliderMatShn.SetRange(1, 120, TRUE);
	m_sliderMatShn.SetPos((pApp->m_OptionGLMatShininess>=0 && pApp->m_OptionGLMatShininess<=120) ? pApp->m_OptionGLMatShininess : 60);
	m_checkPlgPointAntialias.EnableWindow(FALSE);
	m_checkPlgLineAntialias.EnableWindow(FALSE);
	m_checkPlgFaceSmooth.EnableWindow(TRUE);
	m_radioPlgFace.SetCheck(1);

	m_radioOrtho.SetCheck(pView->m_bProjOrtho);
	
	m_checkPlgFaceSmooth.SetCheck(pView->m_bSmoothShading);
	m_checkPlgCull.SetCheck(pView->m_bCullBackFace);
	// predifined materials
	m_comboMatPredefine.AddString("Cyan blue");
	m_comboMatPredefine.AddString("Light blue");
	m_comboMatPredefine.AddString("Black plastic");
	m_comboMatPredefine.AddString("Brass");
	m_comboMatPredefine.AddString("Skin");
	m_comboMatPredefine.AddString("Jade");
	m_comboMatPredefine.AddString("Emerald");
	m_comboMatPredefine.AddString("Obsidian");
	m_comboMatPredefine.AddString("Pewter");
	m_comboMatPredefine.AddString("Copper");
	m_comboMatPredefine.AddString("Gold");
	m_comboMatPredefine.AddString("Polished gold");
	m_comboMatPredefine.AddString("Chrome");
	m_comboMatPredefine.AddString("Silver");
	m_comboMatPredefine.AddString("Polished silver");
	m_comboMatPredefine.AddString("Polished bronze");
	m_comboMatPredefine.AddString("Polished copper");
	m_comboMatPredefine.AddString("Pearl");
	m_comboMatPredefine.AddString("Ruby");
	m_comboMatPredefine.AddString("Turquoise");
	m_comboMatPredefine.SetCurSel(0);
	if (pApp->m_OptionGLPreDfMatSel>=0 && pApp->m_OptionGLPreDfMatSel<20) {
		m_comboMatPredefine.SetCurSel(pApp->m_OptionGLPreDfMatSel);
	} else {
		m_comboMatPredefine.SetWindowText("(Not Used)");
	}
	// Psudo-color types
	m_comboPCType.AddString("Jet");
	m_comboPCType.AddString("Hot");
	m_comboPCType.AddString("Cool");
	m_comboPCType.AddString("Bone");
	m_comboPCType.AddString("Flag");
	m_comboPCType.AddString("Zebra");
	m_comboPCType.AddString("Space Jet");
	m_comboPCType.AddString("Jet Isoline");
	m_comboPCType.AddString("Spring");
	m_comboPCType.AddString("Summer");
	m_comboPCType.AddString("Autumn");
	m_comboPCType.AddString("Winter");
	switch(pView->m_PseudoColor.GetPCType())
	{
	case PCT_JET:
		m_comboPCType.SetCurSel(0);
		break;
	case PCT_HOT:
		m_comboPCType.SetCurSel(1);
		break;
	case PCT_COOL:
		m_comboPCType.SetCurSel(2);
		break;
	case PCT_BONE:
		m_comboPCType.SetCurSel(3);
		break;
	case PCT_FLAG:
		m_comboPCType.SetCurSel(4);
		break;
	case PCT_ZEBRA:
		m_comboPCType.SetCurSel(5);
		break;
	case PCT_SPACE_JET:
		m_comboPCType.SetCurSel(6);
		break;
	case PCT_JET_ISOLINE:
		m_comboPCType.SetCurSel(7);
		break;
	case PCT_SPRING:
		m_comboPCType.SetCurSel(8);
		break;
	case PCT_SUMMER:
		m_comboPCType.SetCurSel(9);
		break;
	case PCT_AUTUMN:
		m_comboPCType.SetCurSel(10);
		break;
	case PCT_WINTER:
		m_comboPCType.SetCurSel(11);
		break;
	default:
		m_comboPCType.SetWindowText("(Error)");
	    break;
	}

	// Picking
	SetDlgItemText(IDC_STATIC_PI, "Item");
	SetDlgItemText(IDC_TEXT_PCK_ID, "N/A");
	SetDlgItemText(IDC_TEXT_NUM_PCK, "N/A");
	m_strSVId.Format("%d", pView->m_iSVId);
	SetDlgItemText(IDC_EDIT_SV_ID, m_strSVId);
}

void COptionFormView::UpdateMatShininess(void)
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_MatShininess = (float)m_sliderMatShn.GetPos();
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, pView->m_MatShininess);
	// For save configuration
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	pApp->m_OptionGLMatShininess = pView->m_MatShininess;
}

void COptionFormView::UpdateTransparency(void)
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	if (pView->m_bTransparent) {
		glEnable(GL_BLEND);
		pView->UpdateMatTransparency((float)m_sliderMatTrans.GetPos() / 100.0f);
	} else {
		glDisable(GL_BLEND);
	}
}

void COptionFormView::UpdatePsudoColorSetting(void)
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_PseudoColor.SetPCRamp((double)m_sliderPCRLow.GetPos()/100.0,
									(double)m_sliderPCRHigh.GetPos()/100.0);
}

void COptionFormView::UpdatePointAntialias()
{
	if (m_bPointAntialias) {
		glEnable(GL_POINT_SMOOTH);
		glEnable(GL_BLEND);
		glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
		glPointSize(4.5f);
	}
	else {
		glDisable(GL_POINT_SMOOTH);
		glDisable(GL_BLEND);
		glPointSize(1.0f);
	}
}

void COptionFormView::UpdateLineAntialias()
{
	if (m_bLineAntialias) {
		glEnable(GL_LINE_SMOOTH);
		glEnable(GL_BLEND);
		glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
		glLineWidth(1.5f);
	}
	else {
		glDisable(GL_LINE_SMOOTH);
		glDisable(GL_BLEND);
		glLineWidth(1.0f);
	}
}

void COptionFormView::UpdateFaceShadingMode()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	if (pView->m_bSmoothShading) {
		glShadeModel(GL_SMOOTH);
	} else {
		glShadeModel(GL_FLAT);
	}
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
}

void COptionFormView::DisableTransparent()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	//pView->m_bTransparent = false;
	pView->UpdateMatTransparency(1.0f);	// disable completely, avoiding transparent
										// anti-aliasing points/lines
	m_checkMatTrans.EnableWindow(FALSE);
	m_sliderMatTrans.EnableWindow(FALSE);
}

void COptionFormView::EnableTransparent()
{
	UpdateTransparency();
	m_checkMatTrans.EnableWindow(TRUE);
	m_sliderMatTrans.EnableWindow(GetMeshStudioView()->m_bTransparent);
}

void COptionFormView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	CWnd *pFocusWnd = GetFocus();
	switch(nSBCode)
	{
	case TB_BOTTOM:
	case TB_ENDTRACK:
	case TB_LINEDOWN:
	case TB_LINEUP:
	case TB_PAGEDOWN:
	case TB_PAGEUP:
	case TB_THUMBPOSITION:
	case TB_THUMBTRACK:
	case TB_TOP:
		if (&m_sliderMatShn==pFocusWnd)
		{
			UpdateMatShininess();
			m_comboMatPredefine.SetWindowText("(Not Used)");
		}
		else if (&m_sliderMatTrans==pFocusWnd)
		{
			UpdateTransparency();
		}
		else if (&m_sliderPCRLow==pFocusWnd)
		{
			if (m_sliderPCRLow.GetPos() > m_sliderPCRHigh.GetPos()) {
				m_sliderPCRHigh.SetPos(m_sliderPCRLow.GetPos()+1);
			}
			UpdatePsudoColorSetting();
		}
		else if (&m_sliderPCRHigh==pFocusWnd)
		{
			if (m_sliderPCRLow.GetPos() > m_sliderPCRHigh.GetPos()) {
				m_sliderPCRLow.SetPos(m_sliderPCRHigh.GetPos()-1);
			}
			UpdatePsudoColorSetting();
		}
		GetMeshStudioView()->InvalidateRect(NULL, FALSE);
		break;
	default:
		break;
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void COptionFormView::OnBnClickedCheckMatTrans()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bTransparent = !pView->m_bTransparent;
	m_sliderMatTrans.EnableWindow(pView->m_bTransparent);
	m_btnDepthSort.EnableWindow(pView->m_bTransparent);
	if (!pView->m_bTransparent) {
		m_sliderMatTrans.SetPos(50);
	}
	UpdateTransparency();
	m_comboMatPredefine.SetWindowText("(Not Used)");
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedRadioPlgPoint()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
	m_checkPlgPointAntialias.EnableWindow(TRUE);
	m_checkPlgLineAntialias.EnableWindow(FALSE);
	m_checkPlgFaceSmooth.EnableWindow(FALSE);
	UpdatePointAntialias();
	DisableTransparent();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bDrawFaceAndLine = FALSE;
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedRadioPlgLine()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	//glEnable(GL_CULL_FACE);
	m_checkPlgLineAntialias.EnableWindow(TRUE);
	m_checkPlgPointAntialias.EnableWindow(FALSE);
	m_checkPlgFaceSmooth.EnableWindow(FALSE);
	UpdateLineAntialias();
	DisableTransparent();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bDrawFaceAndLine = FALSE;
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedRadioProjOrtho()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bProjOrtho = true;
	CRect rect;
	pView->GetWindowRect(rect);
	ScreenToClient(rect);
	pView->OnSize(SIZE_RESTORED, rect.Width(), rect.Height());
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedRadioProjPersp()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bProjOrtho = false;
	CRect rect;
	pView->GetWindowRect(rect);
	ScreenToClient(rect);
	pView->OnSize(SIZE_RESTORED, rect.Width(), rect.Height());
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::InvalidateDepthOrder(void)
{
	if (m_checkMatTrans.GetCheck()) {
		m_btnDepthSort.EnableWindow(TRUE);
	}
}

void COptionFormView::UpdateRenderViewSize(int cx, int cy)
{
	CString str;
	str.Format("View size: %d, %d", cx, cy);
	SetDlgItemText(IDC_STATIC_SIZE, str);
}

void COptionFormView::OnBnClickedRadioPlgFace()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	//glDisable(GL_CULL_FACE);
	m_checkPlgFaceSmooth.EnableWindow(TRUE);
	m_checkPlgPointAntialias.EnableWindow(FALSE);
	m_checkPlgLineAntialias.EnableWindow(FALSE);
//	UpdateFaceShadingMode();
	EnableTransparent();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bDrawFaceAndLine = FALSE;
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedRadioPlgFL()
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	//glDisable(GL_CULL_FACE);
	m_checkPlgFaceSmooth.EnableWindow(TRUE);
	m_checkPlgPointAntialias.EnableWindow(FALSE);
	m_checkPlgLineAntialias.EnableWindow(FALSE);;
//	UpdateFaceShadingMode();
	DisableTransparent();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bDrawFaceAndLine = TRUE;
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedCheckPlgPAntialias()
{
	m_bPointAntialias = !m_bPointAntialias;
	UpdatePointAntialias();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedCheckPlgLAntialias()
{
	m_bLineAntialias = !m_bLineAntialias;
	UpdateLineAntialias();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedCheckPlgFSmooth()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bSmoothShading = !pView->m_bSmoothShading;
	UpdateFaceShadingMode();
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedCheckPlgCull()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bCullBackFace = !pView->m_bCullBackFace;
	if (pView->m_bCullBackFace) {
		glEnable(GL_CULL_FACE);
	} else {
		glDisable(GL_CULL_FACE);
	}
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnCbnSelchangeComboPCType()
{
	CString string;
	m_comboPCType.GetLBText(m_comboPCType.GetCurSel(), string);
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	if(string == "Jet")
	{
		pView->m_PseudoColor.SetPCType(PCT_JET);
	}
	else if (string == "Hot")
	{
		pView->m_PseudoColor.SetPCType(PCT_HOT);
	}
	else if (string == "Cool")
	{
		pView->m_PseudoColor.SetPCType(PCT_COOL);
	}
	else if (string == "Bone")
	{
		pView->m_PseudoColor.SetPCType(PCT_BONE);
	}
	else if (string == "Flag")
	{
		pView->m_PseudoColor.SetPCType(PCT_FLAG);
	}
	else if (string == "Zebra")
	{
		pView->m_PseudoColor.SetPCType(PCT_ZEBRA);
	}
	else if (string == "Space Jet")
	{
		pView->m_PseudoColor.SetPCType(PCT_SPACE_JET);
	}
	else if (string == "Jet Isoline")
	{
		pView->m_PseudoColor.SetPCType(PCT_JET_ISOLINE);
	}
	else if (string == "Spring")
	{
		pView->m_PseudoColor.SetPCType(PCT_SPRING);
	}
	else if (string == "Summer")
	{
		pView->m_PseudoColor.SetPCType(PCT_SUMMER);
	}
	else if (string == "Autumn")
	{
		pView->m_PseudoColor.SetPCType(PCT_AUTUMN);
	}
	else if (string == "Winter")
	{
		pView->m_PseudoColor.SetPCType(PCT_WINTER);
	}
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	pApp->m_OptionPCTypeSel = m_comboPCType.GetCurSel();
	CRect rect;
	m_ctrlPColorRamp.GetWindowRect(&rect);
	ScreenToClient(&rect);
	this->InvalidateRect(&rect, FALSE);
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnCbnSelchangeComboMatPrededine()
{
	CString string;
	m_comboMatPredefine.GetLBText(m_comboMatPredefine.GetCurSel(), string);

	GLfloat	ambient[]  = {0.0f,0.0f,0.0f,1.0f};
	GLfloat	diffuse[]  = {0.0f,0.0f,0.0f,1.0f};
	GLfloat	specular[]  = {0.0f,0.0f,0.0f,1.0f};
	GLfloat shininess[] = {0.0f};

	// Change
	if(string == "Silver")
	{
		// Ambient
		ambient[0] = 0.19225f;
		ambient[1] = 0.19225f;
		ambient[2] = 0.19225f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.50754f;
		diffuse[1] = 0.50754f;
		diffuse[2] = 0.50754f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.508273f;
		specular[1] = 0.508273f;
		specular[2] = 0.508273f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 51.2f;
	}

	else

	// Change
	if(string == "Gold")
	{
		// Ambient
		ambient[0] = 0.24725f;
		ambient[1] = 0.1995f;
		ambient[2] = 0.0745f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.75164f;
		diffuse[1] = 0.60648f;
		diffuse[2] = 0.22648f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.628281f;
		specular[1] = 0.555802f;
		specular[2] = 0.366065f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 51.2f;
	}

	else

	// Change
	if(string == "Jade")
	{
		// Ambient
		ambient[0] = 0.135f;
		ambient[1] = 0.2225f;
		ambient[2] = 0.1575f;
		ambient[3] = 0.95f;
		// Diffuse
		diffuse[0] = 0.54f;
		diffuse[1] = 0.89f;
		diffuse[2] = 0.63f;
		diffuse[3] = 0.95f;
		// Specular
		specular[0] = 0.316228f;
		specular[1] = 0.316228f;
		specular[2] = 0.316228f;
		specular[3] = 0.95f;
		// Shininess
		shininess[0] = 12.8f;
	}

	else

	// Change
	if(string == "Light blue")
	{
		// Ambient
		ambient[0] = 0.0f;
		ambient[1] = 0.5f;
		ambient[2] = 0.75f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.0f;
		diffuse[1] = 0.5f;
		diffuse[2] = 1.0f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.75f;
		specular[1] = 0.75f;
		specular[2] = 0.75f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 64.0f;
	}

	else

	// Change
	if(string == "Cyan blue")
	{
		// Ambient
		ambient[0] = 0.107843f;
		ambient[1] = 0.250961f;
		ambient[2] = 0.243275f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.513726f;
		diffuse[1] = 0.921569f;
		diffuse[2] = 0.85098f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.309804f;
		specular[1] = 0.309804f;
		specular[2] = 0.309804f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 64.0f;
	}

	else

	// Change
	if(string == "Skin")
	{
		// Ambient
		ambient[0] = 0.83f;
		ambient[1] = 0.69f;
		ambient[2] = 0.588f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.83f;
		diffuse[1] = 0.69f;
		diffuse[2] = 0.588f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.25f;
		specular[1] = 0.25f;
		specular[2] = 0.25f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 64.0f;
	}

	else

	// Change
	if(string == "Emerald")
	{
		// Ambient
		ambient[0] = 0.0215f;
		ambient[1] = 0.1745f;
		ambient[2] = 0.0215f;
		ambient[3] = 0.55f;
		// Diffuse
		diffuse[0] = 0.07568f;
		diffuse[1] = 0.61424f;
		diffuse[2] = 0.07568f;
		diffuse[3] = 0.55f;
		// Specular
		specular[0] = 0.633f;
		specular[1] = 0.727811f;
		specular[2] = 0.633f;
		specular[3] = 0.55f;
		// Shininess
		shininess[0] = 76.8f;
	}

	else

	// Change
	if(string == "Polished silver")
	{
		// Ambient
		ambient[0] = 0.23125f;
		ambient[1] = 0.23125f;
		ambient[2] = 0.23125f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.2775f;
		diffuse[1] = 0.2775f;
		diffuse[2] = 0.2775f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.773911f;
		specular[1] = 0.773911f;
		specular[2] = 0.773911f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 89.6f;
	}

	else

	// Change
	if(string == "Chrome")
	{
		// Ambient
		ambient[0] = 0.25f;
		ambient[1] = 0.25f;
		ambient[2] = 0.25f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.4f;
		diffuse[1] = 0.4f;
		diffuse[2] = 0.4f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.774597f;
		specular[1] = 0.774597f;
		specular[2] = 0.774597f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 76.8f;
	}

	else

	// Change
	if(string == "Copper")
	{
		// Ambient
		ambient[0] = 0.19125f;
		ambient[1] = 0.0735f;
		ambient[2] = 0.0225f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.7038f;
		diffuse[1] = 0.27048f;
		diffuse[2] = 0.0828f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.256777f;
		specular[1] = 0.137622f;
		specular[2] = 0.086014f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 12.8f;
	}

	else

	// Change
	if(string == "Polished gold")
	{
		// Ambient
		ambient[0] = 0.24725f;
		ambient[1] = 0.2245f;
		ambient[2] = 0.0645f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.34615f;
		diffuse[1] = 0.3143f;
		diffuse[2] = 0.0903f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.797357f;
		specular[1] = 0.723991f;
		specular[2] = 0.208006f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 83.2f;
	}

	else

	// Change
	if(string == "Pewter")
	{
		// Ambient
		ambient[0] = 0.105882f;
		ambient[1] = 0.058824f;
		ambient[2] = 0.113725f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.427451f;
		diffuse[1] = 0.470588f;
		diffuse[2] = 0.541176f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.333333f;
		specular[1] = 0.333333f;
		specular[2] = 0.521569f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 9.84615f;
	}

	else

	// Change
	if(string == "Obsidian")
	{
		// Ambient
		ambient[0] = 0.05375f;
		ambient[1] = 0.05f;
		ambient[2] = 0.06625f;
		ambient[3] = 0.82f;
		// Diffuse
		diffuse[0] = 0.18275f;
		diffuse[1] = 0.17f;
		diffuse[2] = 0.22525f;
		diffuse[3] = 0.82f;
		// Specular
		specular[0] = 0.332741f;
		specular[1] = 0.328634f;
		specular[2] = 0.346435f;
		specular[3] = 0.82f;
		// Shininess
		shininess[0] = 38.4f;
	}

	else

	// Change
	if(string == "Black plastic")
	{
		// Ambient
		ambient[0] = 0.0f;
		ambient[1] = 0.0f;
		ambient[2] = 0.0f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.01f;
		diffuse[1] = 0.01f;
		diffuse[2] = 0.01f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.5f;
		specular[1] = 0.5f;
		specular[2] = 0.5f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 32.0f;
	}
	
	else

	// Change
	if(string == "Polished bronze")
	{
		// Ambient
		ambient[0] = 0.25f;
		ambient[1] = 0.148f;
		ambient[2] = 0.006475f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.4f;
		diffuse[1] = 0.2368f;
		diffuse[2] = 0.1036f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.774597f;
		specular[1] = 0.458561f;
		specular[2] = 0.200621f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 76.8f;
	}
	
	else

	// Change
	if(string == "Polished copper")
	{
		// Ambient
		ambient[0] = 0.2295f;
		ambient[1] = 0.08825f;
		ambient[2] = 0.0275f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.5508f;
		diffuse[1] = 0.2118f;
		diffuse[2] = 0.066f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.580594f;
		specular[1] = 0.223257f;
		specular[2] = 0.0695701f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 51.2f;
	}

	else

	// Change
	if(string == "Pearl")
	{
		// Ambient
		ambient[0] = 0.25f;
		ambient[1] = 0.20725f;
		ambient[2] = 0.20725f;
		ambient[3] = 0.922f;
		// Diffuse
		diffuse[0] = 1.0f;
		diffuse[1] = 0.829f;
		diffuse[2] = 0.829f;
		diffuse[3] = 0.922f;
		// Specular
		specular[0] = 0.296648f;
		specular[1] = 0.296648f;
		specular[2] = 0.296648f;
		specular[3] = 0.922f;
		// Shininess
		shininess[0] = 11.264f;
	}

	else

	// Change
	if(string == "Ruby")
	{
		// Ambient
		ambient[0] = 0.1745f;
		ambient[1] = 0.01175f;
		ambient[2] = 0.01175f;
		ambient[3] = 0.55f;
		// Diffuse
		diffuse[0] = 0.61424f;
		diffuse[1] = 0.04136f;
		diffuse[2] = 0.04136f;
		diffuse[3] = 0.55f;
		// Specular
		specular[0] = 0.727811f;
		specular[1] = 0.626959f;
		specular[2] = 0.626959f;
		specular[3] = 0.55f;
		// Shininess
		shininess[0] = 76.8f;
	}

	else

	// Change
	if(string == "Turquoise")
	{
		// Ambient
		ambient[0] = 0.1f;
		ambient[1] = 0.18725f;
		ambient[2] = 0.1745f;
		ambient[3] = 0.8f;
		// Diffuse
		diffuse[0] = 0.396f;
		diffuse[1] = 0.74151f;
		diffuse[2] = 0.69102f;
		diffuse[3] = 0.8f;
		// Specular
		specular[0] = 0.297254f;
		specular[1] = 0.30829f;
		specular[2] = 0.306678f;
		specular[3] = 0.8f;
		// Shininess
		shininess[0] = 12.8f;
	}

	else

	// Change
	if(string == "Brass")
	{
		// Ambient
		ambient[0] = 0.329412f;
		ambient[1] = 0.223529f;
		ambient[2] = 0.027451f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.780392f;
		diffuse[1] = 0.268627f;
		diffuse[2] = 0.113725f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.992157f;
		specular[1] = 0.741176f;
		specular[2] = 0.807843f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 27.8974f;
	}

	else

	// Change
	if(string == "Brass")
	{
		// Ambient
		ambient[0] = 0.329412f;
		ambient[1] = 0.223529f;
		ambient[2] = 0.027451f;
		ambient[3] = 1.0f;
		// Diffuse
		diffuse[0] = 0.780392f;
		diffuse[1] = 0.268627f;
		diffuse[2] = 0.113725f;
		diffuse[3] = 1.0f;
		// Specular
		specular[0] = 0.992157f;
		specular[1] = 0.741176f;
		specular[2] = 0.807843f;
		specular[3] = 1.0f;
		// Shininess
		shininess[0] = 27.8974f;
	}
	// Apply
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	pApp->m_OptionGLPreDfMatSel = m_comboMatPredefine.GetCurSel();
	pApp->m_OptionColorGLMatAmbient = RGB((BYTE)(ambient[0]*255.0f),
										  (BYTE)(ambient[1]*255.0f),
										  (BYTE)(ambient[2]*255.0f));
	pApp->m_OptionColorGLMatDiffuse = RGB((BYTE)(diffuse[0]*255.0f),
										  (BYTE)(diffuse[1]*255.0f),
										  (BYTE)(diffuse[2]*255.0f));
	pApp->m_OptionColorGLMatSpecular = RGB((BYTE)(specular[0]*255.0f),
										 (BYTE)(specular[1]*255.0f),
										 (BYTE)(specular[2]*255.0f));
	pApp->m_OptionGLMatShininess = (int)shininess[0];

	m_sliderMatShn.SetPos((int)shininess[0]);
	UpdateMatShininess();
	// Refresh matrials
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_MatAmbient[0] = (float)GetRValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
	pView->m_MatAmbient[1] = (float)GetGValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
	pView->m_MatAmbient[2] = (float)GetBValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
	pView->m_MatDiffuse[0] = (float)GetRValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
	pView->m_MatDiffuse[1] = (float)GetGValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
	pView->m_MatDiffuse[2] = (float)GetBValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
	pView->m_MatSpecular[0] = (float)GetRValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
	pView->m_MatSpecular[1] = (float)GetGValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
	pView->m_MatSpecular[2] = (float)GetBValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
	glMaterialfv(GL_FRONT, GL_AMBIENT, pView->m_MatAmbient);
	GLfloat fBackMat[3];
	fBackMat[0] = 0.5f * pView->m_MatAmbient[0];
	fBackMat[1] = 0.5f * pView->m_MatAmbient[1];
	fBackMat[2] = 0.5f * pView->m_MatAmbient[2];
	glMaterialfv(GL_BACK, GL_AMBIENT, fBackMat);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, pView->m_MatDiffuse);
	fBackMat[0] = 0.5f * pView->m_MatDiffuse[0];
	fBackMat[1] = 0.5f * pView->m_MatDiffuse[1];
	fBackMat[2] = 0.5f * pView->m_MatDiffuse[2];
	glMaterialfv(GL_BACK, GL_DIFFUSE, fBackMat);
	glMaterialfv(GL_FRONT, GL_SPECULAR, pView->m_MatSpecular);
	fBackMat[0] = 0.5f * pView->m_MatSpecular[0];
	fBackMat[1] = 0.5f * pView->m_MatSpecular[1];
	fBackMat[2] = 0.5f * pView->m_MatSpecular[2];
	glMaterialfv(GL_BACK, GL_SPECULAR, fBackMat);
	CRect rect;
	CPaintDC dc(this);
	m_ctrlMatAmb.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushLightAmbient(pApp->m_OptionColorGLMatAmbient);
	dc.FillRect(&rect, &BrushLightAmbient);
	this->InvalidateRect(&rect, FALSE);
	m_ctrlMatDif.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushLightDiffuse(pApp->m_OptionColorGLMatDiffuse);
	dc.FillRect(&rect, &BrushLightDiffuse);
	this->InvalidateRect(&rect, FALSE);
	m_ctrlMatSpec.GetWindowRect(&rect);
	ScreenToClient(&rect);
	CBrush BrushLightSpecular(pApp->m_OptionColorGLMatSpecular);
	dc.FillRect(&rect, &BrushLightSpecular);
	this->InvalidateRect(&rect, FALSE);
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnBnClickedMatSave()
{
	// TODO: Add your control notification handler code here
	CString sFileName;
	static char BASED_CODE szFilter[] = "OpenGL Material(*.glm)|*.glm||";

	CFileDialog cfdSaveGLM(FALSE, "glm", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdSaveGLM.m_ofn.lpstrTitle = "Store OpenGL material";

	SetCurrentDirectory(".\\");
	if (cfdSaveGLM.DoModal() == IDOK)
	{
		sFileName = cfdSaveGLM.GetPathName();
		if (!sFileName.IsEmpty()) {
			BeginWaitCursor();
			CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
			pDoc->StatusMessage("Saving OpenGL material...");
			std::ofstream stream(sFileName);
			if (!stream)
			{
				AfxMessageBox("Can not open file!", MB_OK|MB_ICONSTOP);
				return;
			}
			CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
			stream << "amb 4 "
				   << pView->m_MatAmbient[0] << " "
				   << pView->m_MatAmbient[1] << " "
				   << pView->m_MatAmbient[2] << " "
				   << pView->m_MatAmbient[3] << std::endl;
			stream << "diff 4 "
				   << pView->m_MatDiffuse[0] << " "
				   << pView->m_MatDiffuse[1] << " "
				   << pView->m_MatDiffuse[2] << " "
				   << pView->m_MatDiffuse[3] << std::endl;
			stream << "spec 4 "
				   << pView->m_MatSpecular[0] << " "
				   << pView->m_MatSpecular[1] << " "
				   << pView->m_MatSpecular[2] << " "
				   << pView->m_MatSpecular[3] << std::endl;
			stream << "shin 1 " << pView->m_MatShininess << std::endl;
			pDoc->StatusMessage("Saving OpenGL material... done");
			EndWaitCursor();
		}
	}
}

void COptionFormView::OnBnClickedMatLoad()
{
	// TODO: Add your control notification handler code here
	GLfloat	ambient[]  = {0.0f,0.0f,0.0f,1.0f};
	GLfloat	diffuse[]  = {0.0f,0.0f,0.0f,1.0f};
	GLfloat	specular[]  = {0.0f,0.0f,0.0f,1.0f};
	GLfloat shininess[] = {0.0f};
	CString sFileName;
	static char BASED_CODE szFilter[] = "OpenGL Material(*.glm)|*.glm||";

	CFileDialog cfdLoadGLM(TRUE, "glm", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	cfdLoadGLM.m_ofn.lpstrTitle = "Load OpenGL material";

	SetCurrentDirectory(".\\");
	if (cfdLoadGLM.DoModal() == IDOK)
	{
		sFileName = cfdLoadGLM.GetPathName();
		if (!sFileName.IsEmpty()) {
			BeginWaitCursor();
			CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
			pDoc->StatusMessage("Loading OpenGL material...");
			FILE *pFile;
			errno_t err = fopen_s(&pFile, (const char*)sFileName, "r");
			if (err != 0) {
				AfxMessageBox("Can not open file!", MB_OK|MB_ICONSTOP);
				return;
			}
			CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
			char	buf[128];
			while (fscanf(pFile, "%s", buf) != EOF)
			{
				if (!strcmp(buf, "amb"))
				{
					int nItem;
					fscanf_s(pFile, "%d", &nItem);
					if (nItem == 4) {
						fscanf_s(pFile, "%f%f%f%f", &ambient[0],
													&ambient[1],
													&ambient[2],
													&ambient[3]);
					} else if (nItem == 3) {
						fscanf_s(pFile, "%f%f%f", &ambient[0],
												  &ambient[1],
												  &ambient[2]);
					} else {
						AfxMessageBox("Bad item: ambient!", MB_OK|MB_ICONSTOP);
						return;
					}
					// eat up rest of the line 
					fgets(buf, sizeof(buf), pFile);
				}
				else if (!strcmp(buf, "diff"))
				{
					int nItem;
					fscanf_s(pFile, "%d", &nItem);
					if (nItem == 4) {
						fscanf_s(pFile, "%f%f%f%f", &diffuse[0],
													&diffuse[1],
													&diffuse[2],
													&diffuse[3]);
					} else if (nItem == 3) {
						fscanf_s(pFile, "%f%f%f", &diffuse[0],
												  &diffuse[1],
												  &diffuse[2]);
					} else {
						AfxMessageBox("Bad item: diffuse!", MB_OK|MB_ICONSTOP);
						return;
					}
					// eat up rest of the line 
					fgets(buf, sizeof(buf), pFile);
				}
				else if (!strcmp(buf, "spec"))
				{
					int nItem;
					fscanf_s(pFile, "%d", &nItem);
					if (nItem == 4) {
						fscanf_s(pFile, "%f%f%f%f", &specular[0],
													&specular[1],
													&specular[2],
													&specular[3]);
					} else if (nItem == 3) {
						fscanf_s(pFile, "%f%f%f", &specular[0],
												  &specular[1],
												  &specular[2]);
					} else {
						AfxMessageBox("Bad item: specular!", MB_OK|MB_ICONSTOP);
						return;
					}
					// eat up rest of the line 
					fgets(buf, sizeof(buf), pFile);
				}
				else if (!strcmp(buf, "shin"))
				{
					int nItem;
					fscanf_s(pFile, "%d", &nItem);
					if (nItem == 1) {
						fscanf_s(pFile, "%f", &shininess[0]);
					} else {
						AfxMessageBox("Bad item: shininess!", MB_OK|MB_ICONSTOP);
						return;
					}
					// eat up rest of the line
					fgets(buf, sizeof(buf), pFile);
				}
				else
				{
					// eat up rest of the line
					fgets(buf, sizeof(buf), pFile);
				}
			}
			pDoc->StatusMessage("Loading OpenGL material... done");
			EndWaitCursor();
			// Apply
			CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
			pApp->m_OptionColorGLMatAmbient = RGB((BYTE)(ambient[0]*255.0f),
													(BYTE)(ambient[1]*255.0f),
													(BYTE)(ambient[2]*255.0f));
			pApp->m_OptionColorGLMatDiffuse = RGB((BYTE)(diffuse[0]*255.0f),
													(BYTE)(diffuse[1]*255.0f),
													(BYTE)(diffuse[2]*255.0f));
			pApp->m_OptionColorGLMatSpecular = RGB((BYTE)(specular[0]*255.0f),
													(BYTE)(specular[1]*255.0f),
													(BYTE)(specular[2]*255.0f));
			pApp->m_OptionGLMatShininess = (int)shininess[0];
			m_sliderMatShn.SetPos((int)shininess[0]);
			UpdateMatShininess();
			// Refresh matrials
			pView->m_MatAmbient[0] = (float)GetRValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
			pView->m_MatAmbient[1] = (float)GetGValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
			pView->m_MatAmbient[2] = (float)GetBValue(pApp->m_OptionColorGLMatAmbient) / 255.0f;
			pView->m_MatDiffuse[0] = (float)GetRValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
			pView->m_MatDiffuse[1] = (float)GetGValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
			pView->m_MatDiffuse[2] = (float)GetBValue(pApp->m_OptionColorGLMatDiffuse) / 255.0f;
			pView->m_MatSpecular[0] = (float)GetRValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
			pView->m_MatSpecular[1] = (float)GetGValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
			pView->m_MatSpecular[2] = (float)GetBValue(pApp->m_OptionColorGLMatSpecular) / 255.0f;
			glMaterialfv(GL_FRONT, GL_AMBIENT, pView->m_MatAmbient);
			GLfloat fBackMat[3];
			fBackMat[0] = 0.5f * pView->m_MatAmbient[0];
			fBackMat[1] = 0.5f * pView->m_MatAmbient[1];
			fBackMat[2] = 0.5f * pView->m_MatAmbient[2];
			glMaterialfv(GL_BACK, GL_AMBIENT, fBackMat);
			glMaterialfv(GL_FRONT, GL_DIFFUSE, pView->m_MatDiffuse);
			fBackMat[0] = 0.5f * pView->m_MatDiffuse[0];
			fBackMat[1] = 0.5f * pView->m_MatDiffuse[1];
			fBackMat[2] = 0.5f * pView->m_MatDiffuse[2];
			glMaterialfv(GL_BACK, GL_DIFFUSE, fBackMat);
			glMaterialfv(GL_FRONT, GL_SPECULAR, pView->m_MatSpecular);
			fBackMat[0] = 0.5f * pView->m_MatSpecular[0];
			fBackMat[1] = 0.5f * pView->m_MatSpecular[1];
			fBackMat[2] = 0.5f * pView->m_MatSpecular[2];
			glMaterialfv(GL_BACK, GL_SPECULAR, fBackMat);
			CRect rect;
			CPaintDC dc(this);
			m_ctrlMatAmb.GetWindowRect(&rect);
			ScreenToClient(&rect);
			CBrush BrushLightAmbient(pApp->m_OptionColorGLMatAmbient);
			dc.FillRect(&rect, &BrushLightAmbient);
			this->InvalidateRect(&rect, FALSE);
			m_ctrlMatDif.GetWindowRect(&rect);
			ScreenToClient(&rect);
			CBrush BrushLightDiffuse(pApp->m_OptionColorGLMatDiffuse);
			dc.FillRect(&rect, &BrushLightDiffuse);
			this->InvalidateRect(&rect, FALSE);
			m_ctrlMatSpec.GetWindowRect(&rect);
			ScreenToClient(&rect);
			CBrush BrushLightSpecular(pApp->m_OptionColorGLMatSpecular);
			dc.FillRect(&rect, &BrushLightSpecular);
			this->InvalidateRect(&rect, FALSE);
			pView->InvalidateRect(NULL, FALSE);
			m_comboMatPredefine.SetWindowText("(Not Used)");
		}
	}
}

void COptionFormView::OnEnChangeEditSVId()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	// TODO:  Add your control notification handler code here
	CString strInput;
	GetDlgItemText(IDC_EDIT_SV_ID, strInput);
	if (IsValidNumericUINT(strInput)) {
		CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
		CMeshStudioDoc *pDoc = (CMeshStudioDoc*)pView->GetDocument();
		int iSVId = atoi(strInput);
		if (iSVId >= pDoc->m_pMesh->size_of_vertices()) {
			MSG_BOX_ERROR("Invalid vertex id!");
			SetDlgItemText(IDC_EDIT_SV_ID, m_strSVId);
			return;
		}
		m_strSVId = strInput;
		pView->m_iSVId = atoi(m_strSVId);
	} else {
		SetDlgItemText(IDC_EDIT_SV_ID, m_strSVId);
	}
}

void COptionFormView::OnBnClickedShowVert()
{
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	pView->m_bShowVert = !pView->m_bShowVert;
	pView->InvalidateRect(NULL, FALSE);
}

void COptionFormView::OnDepthSort()
{
	GLdouble modelview[4*4];
	GLdouble projection[4*4];
	GLint    viewport[4];
	CMeshStudioDoc *pDoc = (CMeshStudioDoc *)GetDocument();
	CMeshStudioView *pView = (CMeshStudioView *)GetMeshStudioView();
	glPushMatrix();
	glTranslated(pView->m_fCamMove[0], pView->m_fCamMove[1], 0.0f);
	pView->m_pTrackBall->TBMatrix();
	glScalef(pView->m_fCamZoom, pView->m_fCamZoom, pView->m_fCamZoom);
	glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
	glPopMatrix();
	glGetDoublev(GL_PROJECTION_MATRIX, projection);
	glGetIntegerv(GL_VIEWPORT, viewport);
	pDoc->m_pMesh->gl_build_vbo_depth(modelview, projection, viewport);
	m_btnDepthSort.EnableWindow(FALSE);
	pView->InvalidateRect(NULL, FALSE);
}