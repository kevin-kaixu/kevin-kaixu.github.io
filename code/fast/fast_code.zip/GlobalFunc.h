//
// ==[ XPGL: eXPerimental Graphics Library ]== 
//
// Copyright 2006 JeGX / oZone3D.Net
// http://www.oZone3D.Net - jegx@ozone3d.net
//
// This SOFTWARE is distributed in the hope that it will be useful.
// TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
// *AS IS* AND oZone3D.Net DISCLAIM ALL WARRANTIES, EITHER EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL oZone3D.Net 
// BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF oZone3D.Net HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES 
//


#pragma once

#include <float.h>
#include <limits.h>
#include <string>

// Floating point number precision
#define DOUBLE_PRECISION 1	// uncomment this if double precision needed

#ifdef DOUBLE_PRECISION
#define FTP double
#define FT_MAX DBL_MAX
#else
#define FTP float
#define FT_MAX FLT_MAX
#endif


#define SAFE_DELETE( ptr ) \
	if(ptr) \
	{ \
		delete ptr; \
		ptr = NULL; \
	} \

#define SAFE_DELETE_ARRAY( ptr ) \
	if(ptr) \
	{ \
		delete [] ptr; \
		ptr = NULL; \
	} \


void MSG_BOX_INFO( const char *strString, ... );
void MSG_BOX_WARNING( const char *strString, ... );
void MSG_BOX_ERROR( const char *strString, ... );
void MSG_BOX_ERROR_T( const char *strString, ... );

size_t ExecuteProcess(std::wstring FullPathToExe, std::wstring Parameters, size_t SecondsToWait);
bool IsValidNumericUFLOAT(CString &str);
bool IsValidNumericINT(CString &str);
bool IsValidNumericUINT(CString &str);