// MeshStudio.h : main header file for the MeshStudio application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// CMeshStudioApp:
// See MeshStudio.cpp for the implementation of this class
//

class CMeshStudioApp : public CWinApp
{
public:
	CMeshStudioApp();

	COLORREF	m_OptionColorGLBack;
	COLORREF	m_OptionColorGLMatAmbient;
	COLORREF	m_OptionColorGLMatDiffuse;
	COLORREF	m_OptionColorGLMatSpecular;
	UINT		m_OptionGLMatShininess;
	int			m_OptionGLPreDfMatSel;
	int			m_OptionPCTypeSel;
	CString		m_sAppPath;

	BOOL SaveOptions(void);
	BOOL LoadOptions(void);

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	DECLARE_MESSAGE_MAP()
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	virtual int ExitInstance();
};

extern CMeshStudioApp theApp;