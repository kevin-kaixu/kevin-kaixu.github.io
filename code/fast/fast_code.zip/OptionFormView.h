#pragma once
#include "afxwin.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "afxcmn.h"
// COptionFormView ������ͼ

class CMeshStudioDoc;
class CMeshStudioView;
class CPseudoColorRGB;
class COptionFormView : public CFormView
{
	DECLARE_DYNCREATE(COptionFormView)

protected:
	COptionFormView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~COptionFormView();

public:
	enum { IDD = IDD_FORMVIEW };
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	CMeshStudioDoc* GetDocument();
	CMeshStudioView *GetMeshStudioView();
	void UpdateMatShininess(void);
	void UpdateTransparency(void);
	void UpdatePointAntialias(void);
	void UpdatePsudoColorSetting(void);
	void UpdateLineAntialias(void);
	void UpdateFaceShadingMode(void);
	void EnableTransparent(void);
	void DisableTransparent(void);
	void UpdateRenderViewSize(int cx, int cy);
	void InvalidateDepthOrder(void);
public:
	CStatic m_ctrlBackColor;
	CStatic m_ctrlMatAmb;
	CStatic m_ctrlMatDif;
	CStatic m_ctrlMatSpec;
	afx_msg void OnPaint();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	CSliderCtrl m_sliderMatShn;
	CSliderCtrl m_sliderPCRLow;
	CSliderCtrl m_sliderPCRHigh;
	virtual void OnInitialUpdate();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	CSliderCtrl m_sliderMatTrans;
	afx_msg void OnBnClickedCheckMatTrans();
	afx_msg void OnBnClickedRadioPlgPoint();
	CButton m_checkPlgPointAntialias;
	CButton m_checkPlgLineAntialias;
	CButton m_checkPlgFaceSmooth;
	CButton m_radioPlgFace;
	CButton m_radioPlgPoint;
	CButton m_radioPlgLine;
	CButton m_radioPlgFL;
	CButton m_radioOrtho;
	CButton m_radioPersp;
	afx_msg void OnBnClickedRadioPlgLine();
	afx_msg void OnBnClickedRadioProjOrtho();
	afx_msg void OnBnClickedRadioProjPersp();
	afx_msg void OnBnClickedRadioPlgFace();
	afx_msg void OnBnClickedRadioPlgFL();
	CButton m_checkMatTrans;
	afx_msg void OnBnClickedCheckPlgPAntialias();
	bool m_bPointAntialias;
	bool m_bLineAntialias;
	afx_msg void OnBnClickedCheckPlgLAntialias();
	afx_msg void OnBnClickedCheckPlgFSmooth();
	afx_msg void OnBnClickedCheckPlgCull();
	CButton m_checkPlgCull;
	CComboBox m_comboMatPredefine;
	CComboBox m_comboPCType;
	afx_msg void OnCbnSelchangeComboMatPrededine();
	afx_msg void OnCbnSelchangeComboPCType();
	CStatic m_ctrlPColorRamp;
public:
	CButton m_checkShowVert;
	CButton m_btnDepthSort;
	CEdit m_editSVId;
	CString	m_strSVId;
public:
	afx_msg void OnBnClickedMatSave();
	afx_msg void OnBnClickedMatLoad();
	afx_msg void OnDepthSort();
	afx_msg void OnBnClickedShowVert();
	afx_msg void OnEnChangeEditSVId();
};

#ifndef _DEBUG  // debug version in MainRenderView.cpp
inline CMeshStudioView* COptionFormView::GetMeshStudioView()
{
	CMeshStudioApp *pApp = (CMeshStudioApp *)AfxGetApp();
	CMainFrame *pMainFrame = (CMainFrame *)pApp->m_pMainWnd;
	CChildFrame *pFrame = (CChildFrame *)pMainFrame->GetActiveFrame();
	CMeshStudioView *pView = (CMeshStudioView *)pFrame->m_wndSplitter.GetPane(0, 0);
	return pView;
}
inline CMeshStudioDoc* COptionFormView::GetDocument()
{
	return (CMeshStudioDoc*)m_pDocument;
}
#endif
