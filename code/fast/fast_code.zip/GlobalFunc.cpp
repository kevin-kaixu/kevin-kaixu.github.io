//
// ==[ XPGL: eXPerimental Graphics Library ]== 
//
// Copyright 2006 JeGX / oZone3D.Net
// http://www.oZone3D.Net - jegx@ozone3d.net
//
// This SOFTWARE is distributed in the hope that it will be useful.
// TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THIS SOFTWARE IS PROVIDED
// *AS IS* AND oZone3D.Net DISCLAIM ALL WARRANTIES, EITHER EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL oZone3D.Net 
// BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE USE OF OR INABILITY TO USE THIS SOFTWARE, EVEN IF oZone3D.Net HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES 
//

#include "stdafx.h"
#include "GlobalFunc.h"
#include <locale>

void MSG_BOX_INFO( const char *strString, ... )
{
	char buf[4096]={0};
	va_list	argumentPtr;
	va_start( argumentPtr, strString );
	vsprintf( buf, strString, argumentPtr );	
	va_end( argumentPtr );

	MessageBox( NULL, buf, "MeshStudio Information", MB_OK|MB_ICONINFORMATION );

}

void MSG_BOX_WARNING( const char *strString, ... )
{
	char buf[4096]={0};
	va_list	argumentPtr;
	va_start( argumentPtr, strString );
	vsprintf( buf, strString, argumentPtr );	
	va_end( argumentPtr );

	MessageBox( NULL, buf, "MeshStudio WARNING", MB_OK|MB_ICONWARNING );
}


void MSG_BOX_ERROR( const char *strString, ... )
{
	char buf[4096]={0};
	va_list	argumentPtr;
	va_start( argumentPtr, strString );
	vsprintf( buf, strString, argumentPtr );	
	va_end( argumentPtr );

	MessageBox( NULL, buf, "MeshStudio ERROR", MB_OK|MB_ICONERROR );
}

void MSG_BOX_ERROR_T( const char *strString, ... )
{
	char buf[4096]={0};
	va_list	argumentPtr;
	va_start( argumentPtr, strString );
	vsprintf( buf, strString, argumentPtr );	
	va_end( argumentPtr );

	MessageBox( NULL, buf, "MeshStudio ERROR", MB_OK|MB_ICONERROR );
	exit(0);
}

size_t ExecuteProcess(std::wstring FullPathToExe, std::wstring Parameters,
					  size_t SecondsToWait)
{
	size_t iMyCounter = 0, iReturnVal = 0, iPos = 0;
	DWORD dwExitCode = 0;
	std::wstring sTempStr = L"";

	/* - NOTE - You should check here to see if the exe even exists */

	/* Add a space to the beginning of the Parameters */
	if (Parameters.size() != 0)
	{
		if (Parameters[0] != L' ')
		{
			Parameters.insert(0,L" ");
		}
	}

	/* The first parameter needs to be the exe itself */
	sTempStr = FullPathToExe;
	iPos = sTempStr.find_last_of(L"\\");
	sTempStr.erase(0, iPos +1);
	Parameters = sTempStr.append(Parameters);

	/*
	CreateProcessW can modify Parameters thus we
	allocate needed memory
	*/
	wchar_t * pwszParam = new wchar_t[Parameters.size() + 1];
	if (pwszParam == 0)
	{
		return 1;
	}
	const wchar_t* pchrTemp = Parameters.c_str();
	wcscpy_s(pwszParam, Parameters.size() + 1, pchrTemp);

	/* CreateProcess API initialization */
	STARTUPINFOW siStartupInfo;
	PROCESS_INFORMATION piProcessInfo;
	memset(&siStartupInfo, 0, sizeof(siStartupInfo));
	memset(&piProcessInfo, 0, sizeof(piProcessInfo));
	siStartupInfo.cb = sizeof(siStartupInfo);

	if (CreateProcessW(const_cast<LPCWSTR>(FullPathToExe.c_str()),
		pwszParam, 0, 0, false,
		CREATE_DEFAULT_ERROR_MODE, 0, 0,
		&siStartupInfo, &piProcessInfo) != false)
	{
		/* Watch the process. */
		dwExitCode = WaitForSingleObject(piProcessInfo.hProcess,
			(SecondsToWait * 1000));
	}
	else
	{
		/* CreateProcess failed */
		iReturnVal = GetLastError();
	}

	/* Free memory */
	delete[]pwszParam;
	pwszParam = 0;

	/* Release handles */
	CloseHandle(piProcessInfo.hProcess);
	CloseHandle(piProcessInfo.hThread);

	return iReturnVal;
}

bool IsValidNumericUFLOAT(CString &str)
{
	std::locale loc("English-US");
	char c = '\0';
	int num_dot = 0;
	for (int s=0; s<str.GetLength(); s++)
	{
		c = str.GetAt(s);
		if (std::isdigit(c, loc)) {
			continue;
		} else if (c=='.' && num_dot==0) {
			num_dot++;
		} else {
			return false;
		}
	}
	return true;
}

bool IsValidNumericINT(CString &str)
{
	std::locale loc("English-US");
	char c = '\0';
	int num_minus = 0;
	for (int s=0; s<str.GetLength(); s++)
	{
		c = str.GetAt(s);
		if (std::isdigit(c, loc)) {
			continue;
		} else if (c=='-' && s==0) {
			continue;
		} else {
			return false;
		}
	}
	return true;
}

bool IsValidNumericUINT(CString &str)
{
	std::locale loc("English-US");
	char c = '\0';
	int num_dot = 0;
	for (int s=0; s<str.GetLength(); s++)
	{
		c = str.GetAt(s);
		if (std::isdigit(c, loc)) {
			continue;
		} else {
			return false;
		}
	}
	return true;
}