// MeshStudioView.h : interface of the CMeshStudioView class
//


#pragma once

#include "MeshStudioDoc.h"
#include "Lib/3D/TrackBall.h"
#include "Lib/3D/Texture.h"
#include "Lib/3D/PsudoColorRGB.h"
#include <set>

#define	TIMER_ANIMATE	1
#define	ANIMATE_RATE	40

enum _MOUSE_LB_ACTION { MLBA_CAM_SPIN=0, MLBA_CAM_MOVE, MLBA_CAM_ZOOM,
						MLBA_PICK, MLBA_PICK_RIDGE, MLBA_AA_SPIN_Y
};
enum _PICK_ITEM {PI_NONE=0, PI_VERTEX, PI_TRIANGLE};
enum _CLUSTER_DRAW {LD_NONE=0, LD_PLAIN, LD_HF_COLOR};
enum _DEF_METAPHORE {DMT_NONE=0, DMT_ROI, DMT_HB, DMT_MH};
enum _DEF_METHOD {DFM_NONE=0, DFM_LAP, DFM_EMB, DFM_HGC, DFM_SM};
enum _HVF_SHOW {HVFS_NONE=0, HVFS_SIMPLE, HVFS_COMPLEX};

typedef enum _MOUSE_LB_ACTION MOUSE_LB_ACTION;
typedef enum _PICK_ITEM PICK_ITEM;
typedef enum _CLUSTER_DRAW CLUSTER_DRAW;
typedef enum _DEF_METHOD DEF_METHOD;
typedef enum _DEF_METAPHORE DEF_METAPHORE;
typedef enum _HVF_SHOW HVF_SHOW;

class COptionFormView;

class CMeshStudioView : public CView
{
protected: // create from serialization only
	CMeshStudioView();
	DECLARE_DYNCREATE(CMeshStudioView)

// Attributes
public:
	CMeshStudioDoc* GetDocument() const;
	void SetOptionFormView(COptionFormView *pFView) {m_pOptFormView = pFView;}
	COptionFormView* GetOptionFormView(void) {return m_pOptFormView;}

public:
	CTrackBall<FTP>		*m_pTrackBall;
	CTexture			*m_pParamTexture;	// Chessboard texture for showing parameterizaiton
	CPseudoColorRGB		m_PseudoColor;

	CDlgCrestParam		*m_pDlgCrestParam;

	// Mouse 
	CPoint m_LeftDownPos;
	CPoint m_RightDownPos;
	HCURSOR m_CursorRotation;
	MOUSE_LB_ACTION m_MouseLBAction;
	BOOL m_bLeftButtonDown;

	bool m_bIsUpdateView;

	// OpenGL
	HGLRC m_hGLContext;
	int m_GLPixelIndex;

	bool m_bProjOrtho;

	// colors
	GLfloat m_BackColor[3];
	GLfloat m_LightAmbient[4];
	GLfloat m_LightDiffuse[4];
	GLfloat m_LightSpecular[4];
	GLfloat m_LightShininess;
	GLfloat m_LightPosition[4];

	GLfloat	m_MatAmbient[4];
	GLfloat	m_MatDiffuse[4];
	GLfloat	m_MatSpecular[4];
	GLfloat	m_MatShininess;
	GLclampf m_MatTransparency;
	bool m_bTransparent;
	bool m_bSmoothShading;
	bool m_bDrawAxes;
	BOOL m_bBoundingBox;
	BOOL m_bDrawFaceAndLine;
	BOOL m_bCullBackFace;
	bool m_bParameterized;
	bool m_bGenSpacePar;
	bool m_bDrawSpacePar;

	GLuint m_2DDisplayList;

	// Position, rotation ,scaling
	void InitCamera(void);
	float m_fCamMove[3];
	float m_fCamZoom;
	float m_fSpeedCamMove;
	float m_fSpeedCamZoom;

	// Window, Viewport
	float	m_fViewWidth, m_fViewHeight;
	float	m_fViewNear, m_fViewFar;
	CSize   m_WindowSize;

	// Mouse picking
	CPoint m_PickingRectStart;
	CPoint m_PickingRectEnd;
	BOOL m_bPickByRect;
	static const float PICK_DIST_EPSILON;
	PICK_ITEM m_PickItem;
	int m_PickedVertex;
	int m_PickedFacet;
	BOOL m_bUnpickVert;
	int m_iSVId;
	BOOL m_bShowVert;

	HVF_SHOW m_ShowHVF;

// Operations
public:
	// OpenGL specific
	BOOL SetWindowPixelFormat(HDC hDC);
	BOOL CreateViewGLContext(HDC hDC);
	void SetRenderingContext(HDC hDC=NULL);

	void UpdateMatTransparency(GLclampf fTransparency);
	void DrawPickingRect(void);

	void PickByPoint(int px, int py, PICK_ITEM item);
	void PickByRect(int startx, int starty, int endx, int endy, PICK_ITEM item);
	void PickByRect(Mesh *pMesh, GLdouble *modelview, GLdouble *projection, GLint *viewport,
					int startx, int starty, int endx, int endy, PICK_ITEM item);
	bool PickRidgeByColumn(int startx, int starty, int endx, int endy);

protected:
	void Build2DSceneList(void);
	void GetPickSPDir(int px, int py, Vector3 &sp, Vector3 &dir);

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~CMeshStudioView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	COptionFormView *m_pOptFormView;
public:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnTimer(UINT nIDEvent);
};

#ifndef _DEBUG  // debug version in MeshStudioView.cpp
inline CMeshStudioDoc* CMeshStudioView::GetDocument() const
   { return reinterpret_cast<CMeshStudioDoc*>(m_pDocument); }
#endif

