function  featurePreprocess(className)
% Purpose:
% Normalize feature data and split it accords to every mesh's triangle
% number
% Input:
% className   - Filename of meshes class name , eg. 'AntSIG'
    %%%%    Authors:    Zhige Xie
    %%%%    NUDT,603, China
    %%%%    EMAIL:     zhigexie@gmail.com
    %%%%    DATE:       2014-02-10

featureTxtName= sprintf('final_%s.txt', className); 
data = load(featureTxtName);
result = zeros(size(data,1),888);
result(:,1) = data(:,1);
 % The first column is seg number, do not need to nomarlize
for n = 2:888
    minValue = min(data(:,n));
    maxValue = max(data(:,n));
    result(:,n) = (data(:,n)-minValue)/(maxValue - minValue); % all model descritpro after normalized
end
clear data;
normalizedFeatureTxtName =  sprintf('%s_normalized.txt', className); 
dlmwrite(normalizedFeatureTxtName, result, 'delimiter', '\t','precision',8);

featureIndexDictFileName=sprintf('%s_indexDict.txt', className); 
indexDict = load(featureIndexDictFileName);                 
indexDict = indexDict';
size(indexDict)

for  i = 1:1:(size(indexDict,2)-1)                                                             
    finalData{i} = (result(indexDict(i)+1:indexDict(i+1),:));
end
 
finalDataSaveFileName=sprintf('%sFinalData', className); 
save(finalDataSaveFileName, 'finalData', '-v7.3');
clear restult;
clear finalData;


