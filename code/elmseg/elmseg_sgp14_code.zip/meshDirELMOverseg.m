function meshDirELMOverseg(className, numberofHiddenNeurons, runningTimes, leaveNumber, saveLabel)
%% Input:
% className   - filename of meshes class name , eg. 'AntSIG'
% numberofHiddenNeurons - the number of neurons used in ELM
% runningTimes - we should run the code many time to obatin the average
% segmentaion accuracy
% leaveNumber - The number of mesh we used for test, the other meshed are
% used for training.
% saveLabel - set 1 if you want to save the segmentation results.
%% Output:
% meanTestAccuracy: the average segmentation accuracy.
% outputSegmentation file: 97labelelm.seg, 98labelelm.seg and etc.
% 97.98..is the number of testing mesh.
%
%% Usage: meshDirELMOverseg('AntSIG', 100, 5, 1, 0)  % AntSIG dataset, 100 nuerons,
% running 5 times, training 19 meshes/tesing 1 mesh, do not save
% segmentatiion results.
    %%%%    Authors:    Zhige Xie
    %%%%    NUDT,603, China
    %%%%    EMAIL:     zhigexie@gmail.com
    %%%%    DATE:       2014-02-10
 
finalHistogramFilename = sprintf('%sHistogramOverseg', className); 
load(finalHistogramFilename);
disp('finalHistogramData loading Finished!')    
finalData=finalDataHistogram;
    
offNameListFilename = sprintf('%s_offNameList.txt', className); 
offNumList = load(offNameListFilename );  % generate from python, we will load it form txt
%
RunTimes = runningTimes; 
neuronNum = numberofHiddenNeurons; 

meshNum = size(finalData,2);
ranNum=randperm(meshNum);
leaveNum= leaveNumber
train = ranNum(1:meshNum-leaveNum) 
test = ranNum(meshNum-leaveNum+1:meshNum)


meshTrain =  finalData{train(1)};
for i = 2:meshNum-leaveNum
    meshTrain = cat(1,meshTrain,finalData{train(i)});
    %train(i)
end

meshTest =  finalData{test(1)};  
if leaveNum >1 
    for i = 2:leaveNum 
        meshTest = cat(1,meshTest, finalData{test(i)});
    end
end

[TrainingAccuracy, Y, classifier] = elm_train(meshTrain ,2^10, neuronNum, 'sig');
[TestingAccuracy, TY] = elm_test(meshTest ,classifier);
[ResultLabel] = Labeling(TY);
if leaveNum == 1
        segName = sprintf('%dlabelelm.seg', offNumList(test));
        dlmwrite(segName,ResultLabel,'delimiter', '\n','precision',2);
end
%TrainingTimeTotal = TrainingTime;
TrainingAccuracyTotal = TrainingAccuracy;
%TestingTimeTotal = TestingTime;
TestingAccuracyTotal = TestingAccuracy;

for i = 2:RunTimes
    sprintf('This is the %d times of running!',i)
    ranNum=randperm(meshNum);  
    train = ranNum(1:meshNum-leaveNum) 
    test = ranNum(meshNum-leaveNum+1:meshNum)
   meshTrain =  finalData{train(1)};
    for i = 2:meshNum-leaveNum
        meshTrain = cat(1,meshTrain,finalData{train(i)});
        %train(i)
    end

  meshTest =  finalData{test(1)}; 
  if leaveNum >1 
    for i = 2:leaveNum 
        meshTest = cat(1,meshTest, finalData{test(i)});
    end
end

    [TrainingAccuracy, Y, classifier] = elm_train(meshTrain ,2^10, neuronNum, 'sig');
    [TestingAccuracy, TY] = elm_test(meshTest ,classifier);
    [ResultLabel] = Labeling(TY);
    if  saveLabel
        segName = sprintf('%dlabelelm.seg', offNumList(test));
        dlmwrite(segName,ResultLabel,'delimiter', '\n','precision',2);
    end
    %TrainingTimeTotal = cat(1,TrainingTimeTotal, TrainingTime);
    TrainingAccuracyTotal = cat(1,TrainingAccuracyTotal,TrainingAccuracy);
    %TestingTimeTotal =cat(1, TestingTimeTotal,TestingTime);
    TestingAccuracyTotal = cat(1,TestingAccuracyTotal ,TestingAccuracy);
end
clear finalData;
clear finalDataHistogram;
clear meshTrain;
clear meshTest;
clear finalData;
clear normalizedData;
meanTestAccuracy = mean(TestingAccuracyTotal);
resultWorkSpaceName = sprintf('resultOverseg_%s_leave%d_%dtimes_%dneurons', className, leaveNumber, runningTimes,numberofHiddenNeurons); 
save(resultWorkSpaceName);
disp('The mean of TestAccuracy is:' );
meanTestAccuracy




