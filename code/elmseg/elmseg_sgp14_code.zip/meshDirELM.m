function meshDirELM(className, numberofHiddenNeurons, runningTimes, leaveNumber)
% Input:
% className   - Filename of meshes class name , eg. 'ChairCoseg'
% normalizedFeatureTxtName - Filename of output final normalized txt file
% (with index number of each off) e.g. 'ChairCoseg_normalized.txt'
%
    %%%%    Authors:    Zhige Xie
    %%%%    NUDT,603, China
    %%%%    EMAIL:     zhigexie@gmail.com
    %%%%    DATE:       2014-02-10
finalDataFilename = sprintf('%sFinalData', className); 
load(finalDataFilename);
disp('finalData loading Finished!')
%load offNameList from txt file
offNameListFilename = sprintf('%s_offNameList.txt', className); 
offNumList = load(offNameListFilename );  % generate from python, we will load it form txt
%
RunTimes = runningTimes; % ���Դ���
neuronNum = numberofHiddenNeurons; % ��Ԫ��Ŀ    

meshNum = size(finalData,2);
ranNum=randperm(meshNum);  %�����޸�
leaveNum= leaveNumber
train = ranNum(1:meshNum-leaveNum) 
test = ranNum(meshNum-leaveNum+1:meshNum)
%trainTotal = train;
%testTotal = test; 
% �������ݱ��밴��˳�򣨷�����ȡ�ָ�����

meshTrain =  finalData{train(1)};
for i = 2:meshNum-leaveNum
    meshTrain = cat(1,meshTrain,finalData{train(i)});
    %train(i)
end

meshTest =  finalData{test(1)};  % ��ʱΪ��1
if leaveNum >1 
    for i = 2:leaveNum 
        meshTest = cat(1,meshTest, finalData{test(i)});
    end
end

[TrainingAccuracy, Y, classifier] = elm_train(meshTrain ,2^10, neuronNum, 'sig');
[TestingAccuracy, TY] = elm_test(meshTest ,classifier);
[ResultLabel] = Labeling(TY);
% ���浱ǰmesh��label���
if leaveNum == 1
        segName = sprintf('%dlabelelm.seg', offNumList(test));
        dlmwrite(segName,ResultLabel,'delimiter', '\n','precision',2);
end
TrainingAccuracyTotal = TrainingAccuracy;
TestingAccuracyTotal = TestingAccuracy;
%ResultLabelTotal{1} =  ResultLabel

for i = 2:RunTimes
    sprintf('This is the %d times of running!',i)
    ranNum=randperm(meshNum);  %�����޸�
    train = ranNum(1:meshNum-leaveNum) 
    test = ranNum(meshNum-leaveNum+1:meshNum)
    %trainTotal = train;
    %testTotal = test;
    
    % �������ݱ��밴��˳�򣨷�����ȡ�ָ�����

   meshTrain =  finalData{train(1)};
    for i = 2:meshNum-leaveNum
        meshTrain = cat(1,meshTrain,finalData{train(i)});
        %train(i)
    end

  meshTest =  finalData{test(1)}; 
  if leaveNum >1 
    for i = 2:leaveNum 
        meshTest = cat(1,meshTest, finalData{test(i)});
    end
end

    [,TrainingAccuracy, Y, classifier] = elm_train(meshTrain ,2^10, neuronNum, 'sig');
    [TestingAccuracy, TY] = elm_test(meshTest ,classifier);
    [ResultLabel] = Labeling(TY);
    if leaveNum == 1
        segName = sprintf('%dlabelelm.seg', offNumList(test));
        dlmwrite(segName,ResultLabel,'delimiter', '\n','precision',2);
    end
    TrainingAccuracyTotal = cat(1,TrainingAccuracyTotal,TrainingAccuracy);
    TestingAccuracyTotal = cat(1,TestingAccuracyTotal ,TestingAccuracy);
    %ResultLabelTotal{i} =  ResultLabel;
end
clear finalData;
clear meshTrain;
clear meshTest;
clear finalData;
clear normalizedData;
meanTestAccuracy = mean(TestingAccuracyTotal);
resultWorkSpaceName = sprintf('result_%s_leave%d_%dtimes_%dneurons', className, leaveNumber, runningTimes,numberofHiddenNeurons); 
save(resultWorkSpaceName);
disp('The mean of TestAccuracy is:' );
meanTestAccuracy




