function [ResultLabel] = Labeling(TY)

n = size(TY, 2);
LabelNumber = size(TY,1);

for i = 1:n
    for j = 1:LabelNumber
            [maxNumber, label] = max(TY(:,i));
            ResultLabel(i) = label;
        end
    end
end

            