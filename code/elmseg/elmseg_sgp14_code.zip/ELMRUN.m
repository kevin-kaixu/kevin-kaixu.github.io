%This is the main script for face-level segmentation.
% If you using AntSIGFinalData.mat provided by us, the featurePreprocess is
% not needed

%% script
cd('D:\BaiduYunDownload\SGP_SourceCode\ELM_SGP14_Code')
%featurePreprocess('AntSIG')
%meshDirELM('AntSIG', 100, 5, 1, 1)  
meshDirELM('AntSIG', 500, 5, 5)
%meshDirELM('AntSIG', 500, 5, 10)
%meshDirELM('AntSIG', 500, 5, 15)

