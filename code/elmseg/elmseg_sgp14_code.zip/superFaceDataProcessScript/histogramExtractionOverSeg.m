function  hist = histogramExtractionOverSeg(finalD, desc_dir, meshName, meshNum)
%super-face histogram extraction 
% Adapted from Yunhai's code.
% Zhigexie@gmail.com. 
% Usage:  hist221 = histogramExtractionOverSeg(finalData,'E:\dataSIG\Fish\desc', 221, 1);


finalData=finalD;
Y=finalData{1,meshNum}';
Y=Y(2:888, :);   
desc_dirname = desc_dir;
areaFile = sprintf('%d_area', meshName);
area = load([desc_dirname filesep areaFile '.txt']); 
segFile = sprintf('%d', meshName);
IDX = load([desc_dirname filesep segFile  'OS.seg']); 
labels=sort(unique(IDX));


bins=cell(size(Y,1),1);
for i=1:size(Y,1)
    bins{i}=0:1/30:1;
end;
%     % special bins for normal angle;
% bins_normals=[1/12:1/6:1+1/12];
% bins_normals=[0, bins_normals];
% bins{find(ismember(map,['normalsangle']))}=bins_normals;


hist=cell(size(Y,1),1);
for i=1:length(labels)
    l=labels(i);         
    for j=1:size(Y,1)
        tht = features_histogram(Y(j,:), bins{j},l, IDX,area);   
        if (j == 3)
            tht(:) = 0;
        end
        hist{j}=[hist{j},tht];
    end
end;


