function [hist,vq]=features_histogram(values, bins,seg, face_seg,area)

binsc=length(bins)-1;
hist=zeros(binsc,1);

faces=ismember(face_seg,seg);
curr_value=values(faces);
curr_area=area(faces);
curr_value(curr_value<bins(1))=bins(1);
curr_value(curr_value>bins(end))=0.99*bins(end);

for k=1:binsc
    if sum(curr_area)==0
        hist(k)=0;
    else
    hist(k)=sum(curr_area((curr_value>=bins(k))&(curr_value<bins(k+1))));
    hist(k)=hist(k)/sum(curr_area);
end;
    if sum(isnan(hist(k)))>0
        kk=0;
    end
end;

rhist=round(1000*hist);
vq=[];
for i=1:length(rhist)
    instances=rhist(i);
    if instances>0
         vq=[vq ; repmat(bins(i)+(bins(i+1)-bins(i))/2,instances,1)];
    end
end;


