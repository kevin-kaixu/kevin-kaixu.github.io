% Script to run overseg histogram training data build
cd('L:\dataSIG\Ant\OS100');  % Change it!
load AntSIGFinalData;  % Change it!
desc_name = 'L:\dataSIG\Ant\OS100'; % Change it!
 
finalDataHistogram ={};
i=81; % Change it! 
j=1;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];

i=82; % Change it!
j=2;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
   
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=83;% Change it!
j=3;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=84;% Change it!
j=4;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
   
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=85;% Change it!
j=5;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
 
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=86;% Change it!
j=6;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=87;% Change it!
j=7;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
    
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=88;% Change it!
j=8;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
    
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=89;% Change it!
j=9;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
  
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=90;% Change it!
j=10;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
   
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=91;% Change it!
j=11;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=92;% Change it!
j=12;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=93;% Change it!
j=13;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=94;% Change it!
j=14;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
   
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=95;% Change it!
j=15;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=96;% Change it!
j=16;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=97;% Change it!
j=17;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);
 
finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=98;% Change it!
j=18;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=99;% Change it!
j=19;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];
i=100;% Change it!
j=20;
    seg2segFile=sprintf('%d.seg2seg', i);
    histTemp = histogramExtractionOverSeg(finalData,desc_name, i, j);
    trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum);

finalDataHistogram=[finalDataHistogram,trainHistAll ];

save('AntSIGHistogramOverseg.mat','finalDataHistogram' );
disp 'Histogram OK!'


