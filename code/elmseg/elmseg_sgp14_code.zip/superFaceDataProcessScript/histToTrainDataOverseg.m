function trainHistAll = histToTrainDataOverseg(histTemp, seg2segFile, labelSizeNum)
    trueLabel = load(seg2segFile); 
    histSize=size(histTemp,1);
    labelSize=labelSizeNum;
    trainHistAll=[];
    tag=1;
    tag2=1;
    for j=1:labelSize
             %trainHist=j;
             trainHist=trueLabel(j);
        for i=1:histSize
             tempHist=histTemp{i};
             trainHist=[trainHist;tempHist(:,j)];
        end
         trainHist= trainHist';
         if tag2
            trainHistAll =trainHist;
            tag2=0;
         else
            %size(trainHistAll)
            %size(trainHist)
            trainHistAll=cat(1,trainHistAll,trainHist);%[trainHistAll;trainHist];
         end
         trainHist=[];
    end