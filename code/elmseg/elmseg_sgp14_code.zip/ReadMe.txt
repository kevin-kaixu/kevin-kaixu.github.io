This is the source code for our ELM mesh segmentation paper in SGP2014.

Just run ELMRUN.m for face-level segmentation. Before that, you should change the path in ELMRUN.m.
