# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 02:27:27 2014
Goal: read oversegmentation file for every mesh and transfer the oversegmenation labels to the ground truth segmentation labels
@author: zhigexie@gmail.com
"""
import os 
import string
import time

path = r"D:\xzg\SGP_SourceCode\ELM_SGP14_Code\LabeledDB\Ant"  # Change it
os.chdir(path)
oversegNum=100

#obtain the off list in the dir
offList=os.listdir(path)
offListNum=[]
for item in offList:
    itemSplit = item.split('.')
    if itemSplit[1]=='off':
        offListNum.append(string.atoi(itemSplit[0]))

print offListNum 
       

starttime = time.clock()  
     
for offIndex in offListNum:             
    pSegFile = open(r"%dOS.seg" %offIndex,'r')  # oversegmentation file for every mesh
    pSegFile2 = open(r"%d.seg" %offIndex,'r')   # ground truth segmentaion file  
    segTosegLabelFile = open(r"%d.seg2seg" %offIndex,'w')
    offFile = open(r"%d.off" %offIndex,'r')
    
    #read triangle number
    offFile.readline()
    tempLine = offFile.readline().split()
    print tempLine
    trinum = string.atoi(tempLine[1])    
    print trinum
    
    print 'off Num is %d' %offIndex
    
    #read oversegmetation file, label number is key, while triangle number is value 
    LabelOverseg= {}
    for i in range(trinum):
        tempLine= pSegFile.readline().split()[0]
        LabelOverseg.setdefault(tempLine,[]).append(i)
        #LabelOverseg[tempLine]= trinum
        
    #read ground truth segmentaion file,  triangle number is key, while label number is value 
    LabelElm= {}
    for i in range(trinum):
        tempLine1= pSegFile2.readline()[0]
        LabelElm[i]= tempLine1 
          
    segList = []
    for j in range(oversegNum):
        segList.append(LabelOverseg['%d' %j])
        
    labelDict = {}   
    for j in range(oversegNum):
        for item in segList[j]:
           labelValue=LabelElm[item]
           labelDict.setdefault(j,[]).append(labelValue)
    
    voteLabel={}  
    frequency={}    
    for j in range(oversegNum):
        for item in labelDict[j]:
            frequency.setdefault(j,[]).append(labelDict[j].count(item))
            #frequency.append(labelDict[j].count(item))
        maxIndex = frequency[j].index(max(frequency[j]))
        maxFreItem = labelDict[j][maxIndex]
        segTosegLabelFile.write(maxFreItem)
        segTosegLabelFile.write('\n')
        for item in LabelOverseg['%d' %j]:
            voteLabel[item] = maxFreItem
endtime = time.clock()  

print (endtime-starttime) 