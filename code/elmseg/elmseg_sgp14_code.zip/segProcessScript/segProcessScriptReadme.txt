This is the readme file for segmentation Process Script in our ELM-SGP14 paper.

First changing the path or name for a specific dataset in every  '# Change it!' line in SigSegToLabel.py and Dir_superface_segToseg.py.Then,

1.Using SigSegToLabel.py to :  transfer **_label.txt in herzman's dataset into *.seg format, which can be loaded by Princeton mesh segmentation benchmark's code.

2.Using Dir_superface_segToseg.py to : read oversegmentation file for every mesh and transfer the oversegmenation labels to the ground truth segmentation labels.

Done!
