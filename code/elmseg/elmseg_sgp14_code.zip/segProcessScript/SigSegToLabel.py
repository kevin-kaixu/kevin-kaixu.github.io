# -*- coding: utf-8 -*-
"""
Created on Mon Dec 16 23:06:19 2013
Goal: transfer **_label.txt in herzman's dataset into *.seg format, which can be loaded by Princeton mesh segmentation benchmark's code
Detail: the label.txt in herzman's dataset is:
                         label1 indexNumber 
                 e.g.  " support 1
                         backsupport 2
                         arm 3
                         leg 4 "
@author: zhigexie@gmail.com
"""

import os 
import string

path = r"D:\xzg\SGP_SourceCode\ELM_SGP14_Code\LabeledDB\Ant"    # Change it
os.chdir(path)

offList=os.listdir(path)
offListNum=[]
for item in offList:
    itemSplit = item.split('.')
    if itemSplit[1]=='off':
        offListNum.append(string.atoi(itemSplit[0]))
print offListNum        

labelIndexDict={}
labelIndexFile = open("labels.txt" ,'r')
for item in labelIndexFile:
    tempItem = item.split()
    labelIndexDict[tempItem[0]] = string.atoi( tempItem[1])    
print labelIndexDict

for index in offListNum:   
    print index
    pSegFile = open("%d_labels.txt" %index,'r')
    pLabelFile = open("%d.seg" %index,'w')
    
    LabelNumber=0
    for item in pSegFile:
        result=item[0].isdigit()
        #print result
        if not(result):
          LabelNumber=LabelNumber+1
    print LabelNumber
    
    offFile = open("%d.off" %index,'r')
    offFile.readline()
    tempLine1 = offFile.readline().split()
    #print tempLine1
    TriTotalNumber = string.atoi(tempLine1[1])
    #print TriTotalNumber
    

    pSegFile = open("%d_labels.txt" %index,'r')
    LabelArray= {}
    for i in range(LabelNumber):
        tempLabel = pSegFile.readline().split()[0]
        #print tempLabel
        tempLabelIndex= labelIndexDict[tempLabel]
        print tempLabelIndex
        tempLine = pSegFile.readline().split()
        for TriNum in tempLine:
            TriNum1 = string.atoi(TriNum)  
            #LabelArray.insert(TriNum1,i+1)
            LabelArray[TriNum1]=tempLabelIndex
    
    #print LabelArray
            
    for j in range(TriTotalNumber):        
            #temp = '%d' %LabelArray[j]
            temp = '%d' %LabelArray[j+1]
            pLabelFile.write(temp)
            pLabelFile.write('\n')
            #print LabelArray[j]
            
    print '%d ok' %index

