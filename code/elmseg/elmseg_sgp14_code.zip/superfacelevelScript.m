% super-face-level experiment script

cd('L:\dataSIG\Ant\OS100');
meshDirELMOverseg('AntSIG', 100, 2, 1,0)

