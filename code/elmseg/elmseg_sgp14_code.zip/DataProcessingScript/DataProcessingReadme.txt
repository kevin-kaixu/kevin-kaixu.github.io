This is the readme file for descirptor Data Processing in our ELM-SGP14 paper.

First changing the path or name for a specific dataset in every  '# Change it!' line in link_single.py and link_alldescriptor.py .

Then, the whole process can be seperated into 3 steps:
1. Using any mesh descriptor extraction toolbox to extract many different descriptors on every triangles for ever mesh. 
Note that every descriptor should be stored as a txt file, and every line correspond to the descriptor for one triangle. 
Just as 81_anisotropy.txt, 81_area.txt, 81_curv1.txt,81_pcafeat.txt,81_sdf.txt and etc. in the ./Ant/desc dir.

2. using link_single.py to link all the descriptors for one mesh into one txt file.

3. using link_alldescriptor.py to combine 3d descriptor files for many meshes into one file.

Done!
