# -*- coding: utf-8 -*-
"""
Created on Thu Feb 06 17:20:16 2014
Goal: Combine 3d descriptor files for many meshes into one file
Usage: replace the according  path and name, in '# Change it' line in this code.
@author: zhigexie@gmail.com
"""

import os 
import string
import numpy as np


path = r"L:\dataSIG\Ant\desc"                # Change it
os.chdir(path)

offList=os.listdir(path)
offListNum=[]
for item in offList:
    itemSplit = item.split('.')
    if itemSplit[1]=='off':
        offListNum.append(string.atoi(itemSplit[0]))
print offListNum 

pFileFinal = open("final_AntSIG.txt",'w')   # Change it
dataIndex=[]

for i in offListNum :
    offFile = open("%d.off" %i,'r') 
    offFile.readline()
    
    tempLine = offFile.readline().split()
    print tempLine
    trinum = string.atoi(tempLine[1])
    pTemp = open('%d_final.txt' %i, 'r')
    for j in range(trinum):
        a = pTemp.readline()
        pFileFinal.write(a)
    dataIndex.append(string.atoi(tempLine[1]))    
    print tempLine[1]    

print dataIndex
dataIndexDict = np.add.accumulate(dataIndex)
print dataIndexDict

dictFile = open('AntSIG_indexDict.txt', 'w')   # Change it 
dictFile.write('0\n')
for i in range(len(offListNum)):                               
    dictFile.write('%d\n' %dataIndexDict[i])
    