# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 11:44:21 2013
Goal: Link all the descriptors for one mesh into one txt file.
Usage: replace the according  path and name, in '# Change it' line in this code.
@author: zhigexie@gmail.com
"""

import os 
import string

# here set path to your descriptor path
path = r"L:\dataSIG\Ant\desc"  # Change it
os.chdir(path)

pFileFinal = open("AntSIG_offNameList.txt",'w')   # Change it
offList=os.listdir(path)
offListNum=[]
for item in offList:
    itemSplit = item.split('.')
    if itemSplit[1]=='off':
        offListNum.append(string.atoi(itemSplit[0]))
print offListNum 

for item in offListNum :
    pFileFinal.write('%d\n' %item)

for num in offListNum :
#for num in (81,82):
    file0  = path + "\\%d.seg" %num
    file1 = path + "\\%d_anisotropy.txt" %num
    file2 = path + "\\%d_bborient.txt" %num 
    file3 = path + "\\%d_bbpos1.txt" %num 
    file4 = path + "\\%d_bbpos2.txt" %num 
    file5 = path + "\\%d_centroid.txt" %num 
    file6 = path + "\\%d_curvfeat.txt" %num 
    file7 = path + "\\%d_geodavg.txt" %num 
    file8 = path + "\\%d_geodcntxt.txt" %num 
    file9 = path + "\\%d_geodcntxtnorm2.txt" %num 
    file10 = path + "\\%d_geodcntxtnorm4.txt" %num 
    file11 = path + "\\%d_geodcntxtnorm6.txt" %num 
    file12 = path + "\\%d_geodcntxtnorm.txt" %num 
    file13 = path + "\\%d_pcafeat.txt" %num 
    file14 = path + "\\%d_sdfval.txt" %num
     
    
    pFile0 = open(file0,'r')
    pFile1 = open(file1,'r')
    pFile2 = open(file2,'r')
    pFile3 = open(file3,'r')
    pFile4 = open(file4,'r')
    pFile5 = open(file5,'r')
    pFile6 = open(file6,'r')
    pFile7 = open(file7,'r')
    pFile8 = open(file8,'r')
    pFile9 = open(file9,'r')
    pFile10 = open(file10,'r')
    pFile11 = open(file11,'r')
    pFile12 = open(file12,'r')
    pFile13 = open(file13,'r')
    pFile14 = open(file14,'r')
    
    
    offFile = open("%d.off" %num,'r')
    offFile.readline()
    tempLine = offFile.readline().split()
    print tempLine
    trinum = string.atoi(tempLine[1])
    print trinum
    
    pFileFinal = open("%d_final.txt" %num,'w') 
    
    for i in range(trinum):
        a0 = pFile0.readline().strip('\n')
        a1 = pFile1.readline().strip('\n')
        a2 = pFile2.readline().strip('\n')
        a3 = pFile3.readline().strip('\n')
        a4 = pFile4.readline().strip('\n')
        a5 = pFile5.readline().strip('\n')
        a6 = pFile6.readline().strip('\n')
        a7 = pFile7.readline().strip('\n')
        a8 = pFile8.readline().strip('\n')
        a9 = pFile9.readline().strip('\n')
        a10 = pFile10.readline().strip('\n')
        a11 = pFile11.readline().strip('\n')
        a12 = pFile12.readline().strip('\n')
        a13 = pFile13.readline().strip('\n')
        a14 = pFile14.readline()
        
        pFileFinal.write(a0+a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12+a13+a14)    
    print '%d'%num + 'ok'    

