This dataset contains the 2D and 3D models used in the following paper:

Kai Xu, Hao Zhang, Wei Jiang, Ramsay Dyer, Zhi-Quan Cheng, Ligang Liu, Baoquan Chen, "Multi-Scale Partial Intrinsic Symmetry Detection," ACM Transactions on Graphics (SIGGRAPH Asia 2012), 31(6).
(Project page: www.kevinkaixu.net/k/projects/msym.html)


* 3D shapes
The folder 3D/ contains 16 3D shapes:
The Neptune, Momento, Dancing_children are from the AIM@SHAPE repository (shapes.aimatshape.net);
The Thai_statue model is from the The Stanford 3D Scanning Repository (graphics.stanford.edu/data/3Dscanrep);
The Gravgen model is from Ran Gal (www.cs.tau.ac.il/~galran/);
The Indonesian_lay model is from Hui Huang (http://web.siat.ac.cn/~huihuang/research.html);
Other models are all from the Internet (we apologize for not being able to point to the original sources).

* 2D shapes
The folder 2D/ contains 5 2D shapes. For each 2D shape, we provide its 2D silhouette in a BMP image file.


Please send email to kevin.kai.xu@gmail.com for any question.